----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

Credits = {}
Credits.creditText = {}
Credits.endFound = false
Credits.TopLabelIndex = 1
Credits.BottomLabelIndex = 1
Credits.CREDIT_SPEED = 1000
----------------------------------------------------------------
-- Functions
----------------------------------------------------------------

function Credits.Initialize()
	local text = LoadTextFile("credits.txt")
	
	local lineIndex = 1
	local startIndex = 1
	local endIndex = 1
	
	for i=1, 1000 do
		endIndex = wstring.find(text,L"\n",startIndex)
		if( endIndex == nil ) then
			break
		end
		
		-- the endIndex-2 is to ignore the CR and LF chars that we don't care about
		-- add space to end because we can't set labels to L""
		Credits.creditText[lineIndex] = wstring.sub(text,startIndex,endIndex-2).. L" "
		
		startIndex = endIndex + 1
		lineIndex = lineIndex + 1
	end
end

function Credits.OnShown()
	-- create the first label
	Credits.TopLabelIndex = 1
	Credits.BottomLabelIndex = 1
	Credits.endFound = false
	Credits.CreateLabel(1)
end

function Credits.OnHidden()

end

function Credits.Shutdown()

end


function Credits.OnUpdate(timePassed)
	if( WindowGetShowing("Credits") == true ) then
		local x,y = WindowGetOffsetFromParent("CreditsText"..Credits.TopLabelIndex)
		y = y - (((Credits.CREDIT_SPEED*timePassed)/10)+0.5)
		WindowSetOffsetFromParent("CreditsText"..Credits.TopLabelIndex,x,y)
		
		if( Credits.endFound == false ) then
			-- find out if the bottom label is completely on the screen
			local screenx, screeny = WindowGetScreenPosition("CreditsText"..Credits.BottomLabelIndex)
			local dimx, dimy = LabelGetTextDimensions("CreditsText"..Credits.BottomLabelIndex)
			
			local resy = SystemData.screenResolution.y / InterfaceCore.scale
			if( screeny + dimy < resy ) then
				Credits.BottomLabelIndex = Credits.BottomLabelIndex + 1
				Credits.CreateLabel(Credits.BottomLabelIndex)
			end
		end
		
		-- if the top label is offscreen delete it and anchor the next window
		screenx, screeny = WindowGetScreenPosition("CreditsText"..Credits.TopLabelIndex)
		dimx, dimy = LabelGetTextDimensions("CreditsText"..Credits.TopLabelIndex)
		
		if( screeny + dimy < 0 ) then
			DestroyWindow("CreditsText"..Credits.TopLabelIndex)
			Credits.TopLabelIndex = Credits.TopLabelIndex + 1
			if( (Credits.endFound == true) and (Credits.TopLabelIndex == Credits.BottomLabelIndex) ) then
				Login.ShowCredits()
			else
				WindowClearAnchors("CreditsText"..Credits.TopLabelIndex)
				WindowAddAnchor("CreditsText"..Credits.TopLabelIndex,"bottomleft","Root","topleft",0,0)
				WindowSetOffsetFromParent("CreditsText"..Credits.TopLabelIndex,0,(y+dimy))
			end
		end		
	end
end

function Credits.CreateLabel(lineIndex)
	if( lineIndex > table.getn(Credits.creditText) ) then
		Credits.endFound = true
	else
		CreateWindowFromTemplate("CreditsText"..lineIndex,"CreditsTextTemplate","Credits")
		if( lineIndex == Credits.TopLabelIndex ) then
			WindowAddAnchor("CreditsText"..lineIndex,"bottomleft","Root","topleft",0,100)
		else
			dimx,dimy = LabelGetTextDimensions("CreditsText"..lineIndex-1)
			WindowAddAnchor("CreditsText"..lineIndex,"topleft","CreditsText"..lineIndex-1,"topleft",0,dimy)
		end
		LabelSetText("CreditsText"..lineIndex,Credits.creditText[lineIndex])
	end
end

function Credits.Cleanup()
	for i=Credits.TopLabelIndex, Credits.BottomLabelIndex do	
		--Debug.Print("Credits.Cleanup: "..i)
		DestroyWindow("CreditsText"..i)
	end
end