----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

Login = {}

Login.TID = {}
Login.TID.LABEL_1 =	1077841		-- Login to Ultima Online
Login.TID.LABEL_2 =	1077842		-- Account Name
Login.TID.LABEL_3 =	3000103		-- Password
Login.TID.LABEL_4 =	1077843		-- LOGIN
Login.TID.LABEL_5 =	1077844		-- SELECT SERVER
Login.TID.LABEL_6 =	3005087		-- Shard
Login.TID.LABEL_7 =	1077845		-- Latency
Login.TID.LABEL_8 =	1077846		-- Packet Loss
Login.TID.LABEL_9 =	1006044		-- OK
Login.TID.LABEL_10 = 1077847	-- I AGREE
Login.TID.LABEL_11 = 1077848	-- I DISAGREE
Login.TID.LABEL_12 = 1077849	-- SELECT CHARACTER
Login.TID.LABEL_13 = 1077850	-- PLAY NOW
Login.TID.LABEL_14 = 1077851	-- DELETE
Login.TID.LABEL_15 = 1077852	-- CREATE
Login.TID.LABEL_16 = 1077900	-- Your account has been blocked.
Login.TID.LABEL_17 = 1077853	-- You do not have any free character slots.
Login.TID.LABEL_18 = 3000012	-- Another character from this account is currently online in this world.  You must either log in as that character or wait for it to time out.
Login.TID.LABEL_19 = 1077854	-- You used an invalid name.
Login.TID.LABEL_20 = 1077855	-- YOU MUST SELECT A SERVER!
Login.TID.LABEL_21 = 1077856	-- No character to login with.
Login.TID.LABEL_22 = 1077857	-- YOU CANNOT CREATE ANY MORE CHARACTERS!
Login.TID.LABEL_23 = 3002002    -- DELETE CONFIRM WINDOW TITLE
Login.TID.LABEL_24 = 3001033    -- CHARACTER DELETE WINDOW TEXT
Login.TID.LABEL_CREDITS = 3000123             -- Credits
Login.TID.LABEL_ACCOUNT = 3000099             -- Account
Login.TID.LABEL_UOCOM = 1078985               -- uo.com
Login.TID.LABEL_NETWORK_ERROR = 1077864       -- Network Error
Login.TID.LABEL_CUSTOMUI = 1079522            -- Unload Custom UI

-- *** TODO - The Japanese Login Error Message was changed while KR is still in Beta
---           they may want to change it back to 3000033 when we are ready for general release to Japan.
--Login.TID.LABEL_GENERAL_LOGIN_ERROR = 3000033 -- We were unable to authenticate your login. Usually this..
Login.TID.LABEL_GENERAL_LOGIN_ERROR = 1078991 -- We were unable to authenticate your login. Usually this..

Login.TID.LABEL_TIME_OUT = 1078859            -- Log in time out.
Login.TID.LABEL_CONNECTION_FAILED = 3000016   -- Couldn't connect to Ultima Online. Please try again in a few moments.
Login.TID.LABEL_CONNECTION_LOST = 3000004     -- Connection lost

Login.STAGE_SPLASH            = 1
Login.STAGE_ACCOUNTPASSWORD   = 2
Login.STAGE_SERVERSELECT      = 3
Login.STAGE_CHARACTERSELECT   = 4
Login.STAGE_CHARACTERCREATION = 5
Login.STAGE_CREDITS           = 6

Login.LoginStages = {}
Login.LoginStages[Login.STAGE_SPLASH] = {}
Login.LoginStages[Login.STAGE_SPLASH].VisibleWindows = { "Splash" }
Login.LoginStages[Login.STAGE_SPLASH].SplashImages = {}
Login.LoginStages[Login.STAGE_SPLASH].SplashImages.CurImage = "EnglishSplash"
Login.LoginStages[Login.STAGE_SPLASH].SplashImages[SystemData.Settings.Language.LANGUAGE_JPN] = "JapaneseSplash"
Login.LoginStages[Login.STAGE_SPLASH].Delay = 4.0 -- time splash screen is displayed in seconds
Login.LoginStages[Login.STAGE_SPLASH].Timer = 0.0 -- timer for splash screen

-- USERNAME/ACCOUNT STAGE VALUES
Login.LoginStages[Login.STAGE_ACCOUNTPASSWORD] = {}
Login.LoginStages[Login.STAGE_ACCOUNTPASSWORD].VisibleWindows = { "Login", "LoginWindow", "InternalLoginConfig", "LoginBuild" }
if (SystemData.Settings.Language.type == SystemData.Settings.Language.LANGUAGE_JPN) then
	Login.LoginStages[Login.STAGE_ACCOUNTPASSWORD].LoginBG = "login_background1_jp"	
else
	Login.LoginStages[Login.STAGE_ACCOUNTPASSWORD].LoginBG = "login_background1"
end
Login.LoginStages[Login.STAGE_ACCOUNTPASSWORD].Account = ""
Login.LoginStages[Login.STAGE_ACCOUNTPASSWORD].Password = ""
Login.LoginStages[Login.STAGE_ACCOUNTPASSWORD].SortedShardList = {}

-- SERVER SELECT STAGE VALUES
Login.LoginStages[Login.STAGE_SERVERSELECT] = {}
Login.LoginStages[Login.STAGE_SERVERSELECT].VisibleWindows = { "Login", "ServerSelectWindow" }
if (SystemData.Settings.Language.type == SystemData.Settings.Language.LANGUAGE_JPN) then
	Login.LoginStages[Login.STAGE_SERVERSELECT].LoginBG = "login_background2_jp"	
else
	Login.LoginStages[Login.STAGE_SERVERSELECT].LoginBG = "login_background2"
end
Login.LoginStages[Login.STAGE_SERVERSELECT].CurShardNum = nil
Login.LoginStages[Login.STAGE_SERVERSELECT].NumShards = 0
Login.LoginStages[Login.STAGE_SERVERSELECT].Timer = 0.0
Login.LoginStages[Login.STAGE_SERVERSELECT].ShardUpdateDelay = 2.0

-- CHARACTER SELECT STAGE VALUES
Login.LoginStages[Login.STAGE_CHARACTERSELECT] = {}
Login.LoginStages[Login.STAGE_CHARACTERSELECT].VisibleWindows = { "Login", "CharacterSelectWindow" }
if (SystemData.Settings.Language.type == SystemData.Settings.Language.LANGUAGE_JPN) then
	Login.LoginStages[Login.STAGE_CHARACTERSELECT].LoginBG = "login_background3_jp"	
else
	Login.LoginStages[Login.STAGE_CHARACTERSELECT].LoginBG = "login_background3"
end
Login.LoginStages[Login.STAGE_CHARACTERSELECT].CurCharNum = nil
Login.LoginStages[Login.STAGE_CHARACTERSELECT].NumChars = 0
Login.LoginStages[Login.STAGE_CHARACTERSELECT].MaxChars = 6

-- CHARACTER CREATION STAGE VALUES
Login.LoginStages[Login.STAGE_CHARACTERCREATION] = {}
Login.LoginStages[Login.STAGE_CHARACTERCREATION].VisibleWindows = { "CharacterCreation" }
if (SystemData.Settings.Language.type == SystemData.Settings.Language.LANGUAGE_JPN) then
	Login.LoginStages[Login.STAGE_CHARACTERCREATION].LoginBG = "login_background4_jp"	
else
	Login.LoginStages[Login.STAGE_CHARACTERCREATION].LoginBG = "CC_Background"
end

Login.LoginStages[Login.STAGE_CREDITS] = {}
Login.LoginStages[Login.STAGE_CREDITS].VisibleWindows = { "Credits" }
Login.LoginStages[Login.STAGE_CREDITS].LastStage = nil

Login.EnglishProductionShardTimeZones = {0,5,8}
Login.JapaneseProductionShardTimeZones = {246,247}
Login.TestShardTimeZones = {50}

Login.SEVENTH_ANNIVERSARY_ENTITLEMENT = 32

Login.CurLoginStage = nil
Login.LastLoginStage = nil
Login.CurStageData = nil

function Login.Initialize()
	if( IsInternalBuild() ) then
		LoadResources( "Data/Interface/Login/Source", "", "InternalLogin.xml" )
		CreateWindow("InternalLoginConfig",true)
		Login.LoginStages[Login.STAGE_SPLASH].Delay = 1.0
	end

    WindowRegisterEventHandler("Login", SystemData.Events.LOGIN_FAILED, "Login.HandleLoginFailed")
	WindowRegisterEventHandler("Login", SystemData.Events.LOGIN_CONNECT_FAILED, "Login.HandleLoginConnectFailed")
	WindowRegisterEventHandler("Login", SystemData.Events.LOGIN_CONNECT_LOST, "Login.HandleLoginConnectLost")    
	WindowRegisterEventHandler("Login", SystemData.Events.UPDATE_SHARDLIST, "Login.HandleUpdateShardList")
	WindowRegisterEventHandler("Login", SystemData.Events.UPDATE_CHARLIST, "Login.HandleUpdateCharList")
       
    CreateWindow("LoginBackground",false)
    CreateWindow("LeftBorder",false)
    CreateWindow("Login_QuitButton",false)
    CreateWindow("CreditsButton",false)  
    CreateWindow("AccountButton",false)
    CreateWindow("UOComButton",false)
    CreateWindow("CustomUiButton",false)
    CreateWindow("CustomUiWindow",false)
    CreateWindow("LoginBuild", false)
    
	CreateWindow("Splash",false)
    CreateWindow("Credits",false)    

	local buffer, buffer2
    
	-- CUSTOM UI INIT
	Interface.OnCloseCallBack["CustomUiWindow"] = Login.ResetCustomUiComboBox
	WindowUtils.SetWindowTitle("CustomUiWindow",GetStringFromTid(Login.TID.LABEL_CUSTOMUI))
	LabelSetText( "CustomUiWindowCustomSkinsLabel", GetStringFromTid(1079523) ) -- "Use Custom UI:"
	local skinItr
	for skinItr = 1, #SystemData.CustomUIList do
		local text = SystemData.CustomUIList[skinItr]
		if text == "" then
			ComboBoxAddMenuItem( "CustomUiWindowCustomSkinsCombo", GetStringFromTid(3000094) ) -- "Default"
		else
			ComboBoxAddMenuItem( "CustomUiWindowCustomSkinsCombo", StringToWString(text) )
		end
		
		if( SystemData.Settings.Interface.customUiName == SystemData.CustomUIList[skinItr] ) then
			ComboBoxSetSelectedMenuItem("CustomUiWindowCustomSkinsCombo", skinItr )
		end		
	end   
    ButtonSetText("CustomUiWindowOkayButton",GetStringFromTid(UO_StandardDialog.TID_OKAY))
    ButtonSetText("CustomUiWindowCancelButton",GetStringFromTid(UO_StandardDialog.TID_CANCEL))
    
    -- LOGIN WINDOW ELEMENTS
    LabelSetText ("LoginTitle", GetStringFromTid(Login.TID.LABEL_1))
    LabelSetText ("LoginWindowUsernamePrompt", GetStringFromTid(Login.TID.LABEL_2))
    LabelSetText ("LoginWindowPasswordPrompt", GetStringFromTid(Login.TID.LABEL_3))
    ButtonSetText("LoginWindowLoginButton", GetStringFromTid(Login.TID.LABEL_4))
	 
    if (UserData.Settings.Login.lastUserName) then
    	TextEditBoxSetText("Username", StringToWString(UserData.Settings.Login.lastUserName))
    end
    ButtonSetText("CreditsButton",GetStringFromTid(Login.TID.LABEL_CREDITS))
    ButtonSetText("AccountButton",GetStringFromTid(Login.TID.LABEL_ACCOUNT))
    ButtonSetText("UOComButton",GetStringFromTid(Login.TID.LABEL_UOCOM))
    ButtonSetText("CustomUiButton",GetStringFromTid(Login.TID.LABEL_CUSTOMUI))
    
    local  verMajor, verMinor, verSub, verBuild = GetBuildVersion()
    LabelSetText("LoginBuildVersion", L"Build Version: "..verMajor..L"."..verMinor..L"."..verSub..L"."..verBuild)

    -- SERVER SELECT WINDOW ELEMENTS
    LabelSetText("ServerSelectWindowTitle", GetStringFromTid(Login.TID.LABEL_5))
    LabelSetText("ServerSelectWindowNameHeader", GetStringFromTid(Login.TID.LABEL_6))
    LabelSetText("ServerSelectWindowLatencyHeader", GetStringFromTid(Login.TID.LABEL_7))
    LabelSetText("ServerSelectWindowPacketLossHeader", GetStringFromTid(Login.TID.LABEL_8))
    ButtonSetText("ServerSelectWindowOKButton", GetStringFromTid(Login.TID.LABEL_9))

    -- CHARACTER SELECT WINDOW ELEMENTS
    LabelSetText("CharacterSelectWindowTitle", GetStringFromTid(Login.TID.LABEL_12))
    ButtonSetText("CharacterSelectWindowPlayNowButton", GetStringFromTid(Login.TID.LABEL_13))
    ButtonSetText("CharacterSelectWindowDeleteCharacterButton", GetStringFromTid(Login.TID.LABEL_14))
    ButtonSetText("CharacterSelectWindowCreateCharacterButton", GetStringFromTid(Login.TID.LABEL_15))
    ButtonSetDisabledFlag("CharacterSelectWindowCreateCharacterButton", true)

    -- Create the initial character items and hide them
    for i=1, Login.LoginStages[Login.STAGE_CHARACTERSELECT].MaxChars + 1 do
        local currentCharacterWindowName = "Character_"..i
        CreateWindowFromTemplate( currentCharacterWindowName, "CharacterListItemTemplate", "CharacterSelectContent" )
        WindowSetShowing(currentCharacterWindowName, false)
    end

	-- if the current resolution is taller than the height of the background then stretch the image
	local loginBgW, loginBgH = WindowGetDimensions("LoginBackground")
	local resHeight = SystemData.screenResolution.y
	local ratio = resHeight / loginBgH
	if( ratio > 1 ) then
		WindowSetDimensions("LoginBackground",loginBgW*ratio,loginBgH*ratio)
		DynamicImageSetTextureScale("LoginBackground",ratio)
		WindowSetDimensions("Splash",loginBgW*ratio,loginBgH*ratio)
		DynamicImageSetTextureScale("Splash",ratio)
	end

   	if( IsLoginBefore() ) then
		Login.ShowCommonBackground()
		Login.SetStage(Login.STAGE_ACCOUNTPASSWORD)
	else
		Login.SetStage(Login.STAGE_SPLASH)
	end
end

function Login.SetStage(curStage)
    --Debug.Print("Login.SetStage: "..curStage)
    
    if( Login.CurStageData ~= nil and Login.CurStageData.Shutdown ~= nil ) then
        Login.CurStageData.Shutdown()
    end    
    
    Login.LastLoginStage = Login.CurLoginStage
    Login.CurLoginStage = curStage
    Login.CurStageData = Login.LoginStages[Login.CurLoginStage]
    
    WindowSetShowing("Splash", false)
    WindowSetShowing("LoginWindow", false)
    WindowSetShowing("ServerSelectWindow", false)
    WindowSetShowing("CharacterSelectWindow", false)
    WindowSetShowing("CharacterCreation", false)
	CharacterCreation.HideColorPickerWindows()
    WindowSetShowing("Credits", false)
    
    if( DoesWindowNameExist("InternalLoginConfig") ) then
        WindowSetShowing("InternalLoginConfig", false)
    end    
    
    for index, windowName in pairs(Login.CurStageData.VisibleWindows) do
        if( DoesWindowNameExist(windowName) ) then
            WindowSetShowing(windowName, true)
        end
    end
    
    if( Login.CurStageData.Initialize ~= nil ) then
        Login.CurStageData.Initialize()
    end
    
    if( Login.LoginStages[curStage].LoginBG ~= nil ) then
   	    DynamicImageSetTexture("LoginBackground", Login.LoginStages[curStage].LoginBG, 0, 0) 
   	end
end

function Login.ShowErrorMessage(bodyText,focusOnClose,callback)
    local okayButton = { textTid=UO_StandardDialog.TID_OKAY, callback=callback }
    local windowData = 
    {
        windowName = "Login",
        titleTid = Login.TID.LABEL_NETWORK_ERROR,
        body = bodyText,
        focusOnClose = focusOnClose,
        buttons = { okayButton }
    }
    UO_StandardDialog.CreateDialog(windowData)
end

function Login.HandleLoginFailed()
	ButtonSetDisabledFlag("LoginWindowLoginButton", false)

    if (SystemData.Login.statusCode == 2) then
		local curString = WindowUtils.translateMarkup(GetStringFromTid(Login.TID.LABEL_16))
        Login.ShowErrorMessage(curString,"Username")
    elseif (SystemData.Login.statusCode == 3) then
        Login.ShowErrorMessage(GetStringFromTid(Login.TID.LABEL_17),"Username")
    elseif (SystemData.Login.statusCode == 5) then
        local callback = function () Login.SetStage(Login.STAGE_ACCOUNTPASSWORD) end
        Login.ShowErrorMessage(GetStringFromTid(Login.TID.LABEL_18),"Username",callback)
    elseif (SystemData.Login.statusCode == 10) then
    	--local callback = function () WindowSetShowing ( "CharacterCreation", true); CharacterCreation.ShowApproveWindow() end
        local callback = function () Login.SetStage(Login.STAGE_ACCOUNTPASSWORD) end
	    WindowSetShowing ( "CharacterCreation", false)
	    Login.ShowErrorMessage(GetStringFromTid(Login.TID.LABEL_19),"ApproveNameWindowVal", callback)
	    TextEditBoxSetText("ApproveNameWindowVal", L"")
    elseif (SystemData.Login.statusCode == 254) then
        local callback = function () Login.SetStage(Login.STAGE_ACCOUNTPASSWORD) end
        Login.ShowErrorMessage(GetStringFromTid(Login.TID.LABEL_TIME_OUT),"Username",callback)
    else
        TextEditBoxSetText("Password", L"")
        Login.ShowErrorMessage(GetStringFromTid(Login.TID.LABEL_GENERAL_LOGIN_ERROR), "Password")
    end
end

function Login.HandleLoginConnectFailed()
    local callback = function () Login.SetStage(Login.STAGE_ACCOUNTPASSWORD) end
    Login.ShowErrorMessage(GetStringFromTid(Login.TID.LABEL_CONNECTION_FAILED),"Username",callback)
end

function Login.HandleLoginConnectLost()
    local callback = function () Login.SetStage(Login.STAGE_ACCOUNTPASSWORD) end
    Login.ShowErrorMessage(GetStringFromTid(Login.TID.LABEL_CONNECTION_LOST),"Username",callback)
end

function Login.UpdateTime(timePassed)
    if( Login.CurLoginStage == Login.STAGE_SPLASH ) then
        Login.CurStageData.Timer = Login.CurStageData.Timer + timePassed
        if ( Login.CurStageData.Timer > Login.CurStageData.Delay ) then
            Login.SetStage(Login.STAGE_ACCOUNTPASSWORD)
        end
    elseif( Login.CurLoginStage == Login.STAGE_SERVERSELECT ) then
        Login.CurStageData.Timer = Login.CurStageData.Timer + timePassed
        if ( Login.CurStageData.Timer > Login.CurStageData.ShardUpdateDelay ) then
            Login.UpdateServerPings()
            Login.CurStageData.Timer = 0.0
        end
    end
end

------------- SPLASH STAGE BEGIN ---------------

Login.LoginStages[Login.STAGE_SPLASH].Initialize = function ()
    WindowSetShowing("LoginBackground",false)
    WindowSetShowing("LeftBorder",false)
    WindowSetShowing("Login_QuitButton",false)
    WindowSetShowing("CreditsButton",false)  
    WindowSetShowing("AccountButton",false)
    WindowSetShowing("UOComButton",false)
    WindowSetShowing("CustomUiButton",false)

	-- set the splash image based on language
	if( Login.CurStageData.SplashImages[SystemData.Settings.Language.type] ~= nil ) then
	    Login.CurStageData.SplashImages.CurImage = Login.CurStageData.SplashImages[SystemData.Settings.Language.type]
	end
	
	local maxWidth = 2048
	local maxHeight = 1024
	DynamicImageSetTexture("Splash", Login.CurStageData.SplashImages.CurImage, 0, 0 )
	
	Login.CurStageData.Timer = 0.0
end

Login.LoginStages[Login.STAGE_SPLASH].Shutdown = function ()
	--Loads the buttons and the back ground, quit button and left dragon image
    Login.ShowCommonBackground()
end

function Login.ShowCommonBackground()
	WindowSetShowing("LoginBackground",true)
    WindowSetShowing("LeftBorder",true)
    WindowSetShowing("Login_QuitButton",true)
    WindowSetShowing("CreditsButton",true)      
    WindowSetShowing("AccountButton",true)
    WindowSetShowing("UOComButton",true)
    WindowSetShowing("CustomUiButton",true)
end

--------  ACCOUNTPASSWORD STAGE BEGIN --------

Login.LoginStages[Login.STAGE_ACCOUNTPASSWORD].Initialize = function ()
    UndoLogin()

    ButtonSetDisabledFlag("LoginWindowLoginButton", false)
    
  	if (UserData.Settings.Login.lastUserName ~= nil and
	    UserData.Settings.Login.lastUserName ~= L"" and
		TextEditBoxGetText("Username") ~= nil and
		TextEditBoxGetText("Username") ~= L"") then
		WindowAssignFocus("Password", true)
	else
	    WindowAssignFocus("Username", true)
	end
end

function Login.ToggleLogin()
    ButtonSetDisabledFlag("LoginWindowLoginButton", true)
    Login.CurStageData.Account = WStringToString(Username.Text)
    Login.CurStageData.Password = WStringToString(Password.Text)

    --Debug.Print("login request with username = "..username)
    TryLogin(Login.CurStageData.Account, Login.CurStageData.Password)
    -- login progress resumes with either HandleLoginFailed, or UpdateShardList events
end

function Login.HandleUpdateShardList()
    --Debug.Print("UpdateShardList")
    Login.SetStage(Login.STAGE_SERVERSELECT)
end

function Login.GoBackToSplash()
    Login.SetStage(Login.STAGE_SPLASH)
end

--------- SERVER SELECT STAGE BEGIN -------------

Login.LoginStages[Login.STAGE_SERVERSELECT].Initialize = function ()
    Login.CurStageData.CurShardNum = nil
    Login.CurStageData.NumShards = 0
    Login.CurStageData.Timer = 0.0
    Login.CurStageData.SortedShardList = {}
    
    WindowAssignFocus("ServerSelectWindow",true)

    ButtonSetDisabledFlag("ServerSelectWindowOKButton", true)

    for index, shard in pairs(SystemData.Login.shardList) do
    	
        local serverId = SystemData.Login.shardList[index].shardNum
        local shardName =  SystemData.Login.shardList[index].shardName
        
        if ((shardName ~= nil) and (serverId ~= -1)) then      
        	Login.CurStageData.SortedShardList[Login.CurStageData.NumShards + 1] = shard
            Login.CurStageData.NumShards = Login.CurStageData.NumShards + 1
            local currentServerListItem = "shard_"..Login.CurStageData.NumShards
            CreateWindowFromTemplate( currentServerListItem, "ServerListItemTemplate", "ServerSelectContent" )
		end
	end
	
	Login.SortByShardName() 
end


function Login.SortByShardName()
	table.sort (Login.CurStageData.SortedShardList, function (a,b) 	return (a.shardName < b.shardName) end)
	Login.DrawShardList()
end

function Login.SortByLatency()
	table.sort (Login.CurStageData.SortedShardList, function (a,b) 	ashardLatency, apacketLoss = GetShardPingInfo(a.shardNum);
															bshardLatency, bpacketLoss = GetShardPingInfo(b.shardNum);
															if (ashardLatency ~= nil and bshardLatency ~= nil) then
																return (ashardLatency < bshardLatency)
															else
																return false
															end
															end)
	Login.DrawShardList()
end

function Login.SortByPacketLoss()
	table.sort (Login.CurStageData.SortedShardList, function (a,b) 	ashardLatency, apacketLoss = GetShardPingInfo(a.shardNum);
															bshardLatency, bpacketLoss = GetShardPingInfo(b.shardNum);
															if (apacketLoss ~= nil and bpacketLoss ~= nil) then
																return (apacketLoss < bpacketLoss)
															else
																return false
															end
															end)
	Login.DrawShardList()
end

function Login.DrawShardList()
	Login.CurStageData.CurShardNum = nil
    Login.CurStageData.NumShards = 0
    Login.CurStageData.Timer = 0.0
	
	local sortedShardList = Login.CurStageData.SortedShardList
	local previousServerListItem = nil  
	local currentShardWindowName = nil
	local firstShardDisplayedInList = true
	local remainingProductionShardList = {}
	local remainingTestShardList = {}
	
    for index, shard in pairs(sortedShardList) do
        local serverId = sortedShardList[index].shardNum
        local shardName = sortedShardList[index].shardName

        if ((shardName ~= nil) and (serverId ~= -1)) then
            local shardLatency = L"-"
            local packetLoss = L"-"

            Login.CurStageData.NumShards = Login.CurStageData.NumShards + 1
            local currentServerListItem = "shard_"..Login.CurStageData.NumShards

            WindowClearAnchors(currentServerListItem)
            ButtonSetText(currentServerListItem.."Name",StringToWString(shardName) )
            ButtonSetText(currentServerListItem.."Latency",shardLatency)
            ButtonSetText(currentServerListItem.."PacketLoss",packetLoss)
            
            ButtonSetPressedFlag(currentServerListItem.."Name",false)
            ButtonSetPressedFlag(currentServerListItem.."Latency",false)
            ButtonSetPressedFlag(currentServerListItem.."PacketLoss",false)
        
        	-- If Japanese language settings on, display Japanese shards first. Otherwise, display English productions shards first.
            if ( (SystemData.Settings.Language.type == SystemData.Settings.Language.LANGUAGE_JPN) and
               	 (Login.SearchShardTimeZoneTable(Login.JapaneseProductionShardTimeZones, sortedShardList[index].timeZone))
										or
				  Login.SearchShardTimeZoneTable(Login.EnglishProductionShardTimeZones, sortedShardList[index].timeZone)) then
			
	            if (firstShardDisplayedInList) then
	            	WindowAddAnchor( currentServerListItem, "topleft", "ServerSelectContent", "topleft", 10, 5)
	            	firstShardDisplayedInList = false
	        	else
	            	WindowAddAnchor( currentServerListItem, "bottomleft", previousServerListItem, "topleft", 0, 0)
	        	end
	        	previousServerListItem = currentServerListItem
	        	
	        -- If shard is not a prod shard with language settings matching client, keep in a temporary table for display later.
	        else
	            WindowSetShowing(currentServerListItem, false)
	            if (Login.SearchShardTimeZoneTable(Login.TestShardTimeZones, sortedShardList[index].timeZone)) then
	            	remainingTestShardList[index] = currentServerListItem
	            else
	                remainingProductionShardList[index] = currentServerListItem
	            end
			end

            WindowSetId(currentServerListItem, serverId)

            if (serverId == UserData.Settings.Login.lastShardSelected) then
            	Login.CurStageData.CurShardNum = serverId
            	ButtonSetPressedFlag(currentServerListItem.."Name",true)
            	ButtonSetPressedFlag(currentServerListItem.."Latency",true)
            	ButtonSetPressedFlag(currentServerListItem.."PacketLoss",true)
            	ButtonSetDisabledFlag("ServerSelectWindowOKButton", false)	
            	
            	currentShardWindowName = currentServerListItem
			end
        end    
    end
    
    -- Display remaining production shards
    previousServerListItem = Login.DisplayRemainingShardList(remainingProductionShardList, previousServerListItem)
    
    -- Display test shards
    Login.DisplayRemainingShardList(remainingTestShardList, previousServerListItem)
    
    Login.UpdateServerPings()    
    ScrollWindowUpdateScrollRect("ServerSelectScrollWindow")
           	
    if currentShardWindowName then
		WindowUtils.ScrollToElementInScrollWindow( currentShardWindowName, "ServerSelectScrollWindow", "ServerSelectContent" )
	end
end

-- Convience method to display remaining items in shard list. Returns the last shardWindowName displayed
function Login.DisplayRemainingShardList(shardWindowNameList, previousServerListItem)
    for index, shardWindowName in pairs(shardWindowNameList) do
        WindowAddAnchor( shardWindowName, "bottomleft", previousServerListItem, "topleft", 0, 0)
        WindowSetShowing( shardWindowName, true)
        previousServerListItem = shardWindowName
    end
    return previousServerListItem
end

-- Convenience method to search ShardTimeZone tables
function Login.SearchShardTimeZoneTable(t, searchValue)
	for index, value in pairs(t) do
	    if (value == searchValue) then
	        return true
	    end
	end
	return false
end

Login.LoginStages[Login.STAGE_SERVERSELECT].Shutdown = function ()
    for i=1, Login.CurStageData.NumShards do
        local listItem = "shard_"..i
        DestroyWindow(listItem)
    end
end

function Login.UpdateServerPings()
    for i=1, Login.CurStageData.NumShards do
        local currentServerListItem = "shard_"..i
        if( DoesWindowNameExist(currentServerListItem) == true ) then
            local serverNum = WindowGetId(currentServerListItem)
            local shardLatency, packetLoss = GetShardPingInfo(serverNum)
            if( shardLatency ~= nil and packetLoss ~= nil ) then
                if( packetLoss == 100 ) then
                    ButtonSetText(currentServerListItem.."Latency",L"-")
                    ButtonSetText(currentServerListItem.."PacketLoss",L"-")                
                else
                    ButtonSetText(currentServerListItem.."Latency",L""..shardLatency)
                    ButtonSetText(currentServerListItem.."PacketLoss",L""..packetLoss..L"%")
                end
            end
        end
    end
end

function Login.ServerSelect()
    for i=1, Login.CurStageData.NumShards do
        local listItem = "shard_"..i
	    ButtonSetPressedFlag(listItem.."Name",false)
	    ButtonSetPressedFlag(listItem.."Latency",false)
	    ButtonSetPressedFlag(listItem.."PacketLoss",false)    
	end
	
	local newServerListItem = SystemData.ActiveWindow.name
	Login.CurStageData.CurShardNum = WindowGetId(newServerListItem)

	ButtonSetPressedFlag(newServerListItem.."Name",true)
	ButtonSetPressedFlag(newServerListItem.."Latency",true)
	ButtonSetPressedFlag(newServerListItem.."PacketLoss",true)
	
	ButtonSetDisabledFlag("ServerSelectWindowOKButton", false)	
end

function Login.LoginToSelectedSelect()
	ButtonSetDisabledFlag("ServerSelectWindowOKButton", true)

    SelectShard(Login.CurStageData.CurShardNum)

    -- login will continue when UpdateCharList event is received, or an error event
end

function Login.HandleUpdateCharList()
    Login.SetStage(Login.STAGE_CHARACTERSELECT)
end

function Login.GoBackToLogin()
    Login.SetStage(Login.STAGE_ACCOUNTPASSWORD)
end

--------- CHAR SELECT STAGE BEGIN -------------

Login.LoginStages[Login.STAGE_CHARACTERSELECT].Initialize = function ()
    Login.CurStageData.CurCharNum = nil
    Login.CurStageData.NumChars = 0

    WindowAssignFocus("CharacterSelectWindow",true)

	ButtonSetDisabledFlag("CharacterSelectWindowDeleteCharacterButton", true)

    local previousCharacterWindowName=nil
    
    -- Create the initial character items and hide them
    for i=1, Login.CurStageData.MaxChars do
        local currentCharacterWindowName = "Character_"..i
        WindowSetShowing(currentCharacterWindowName, false)
    end    
    
    local firstCharacter = true
    
    for index, item in pairs(SystemData.Login.charList) do
        local characterName = StringToWString(item.charName)
        local characterSlot = item.charSlot
        
		-- skip a slot if it's not in use
		if( characterSlot ~= -1 ) then
		    Login.CurStageData.NumChars = Login.CurStageData.NumChars + 1
		
            local currentCharacterWindowName = "Character_"..index
	    	
	    	WindowSetShowing(currentCharacterWindowName,true)
	        LabelSetText(currentCharacterWindowName.."TextWindowName",characterName )
	        
	        WindowClearAnchors(currentCharacterWindowName)
	        if( firstCharacter ) then
	            WindowAddAnchor( currentCharacterWindowName, "topleft", "CharacterSelectContent", "topleft", 30, 10)
	            firstCharacter = false
	        else
	        	WindowAddAnchor( currentCharacterWindowName, "bottomleft", previousCharacterWindowName, "topleft", 0, 5)
	        end

	        WindowSetId(currentCharacterWindowName, characterSlot)	        
	        previousCharacterWindowName = currentCharacterWindowName

	        if ((Login.LoginStages[Login.STAGE_SERVERSELECT].CurShardNum == UserData.Settings.Login.lastShardSelected) and
	            (characterSlot == UserData.Settings.Login.lastCharacterSelected)) then
	            Login.CurStageData.CurCharNum = characterSlot
	            ButtonSetPressedFlag(currentCharacterWindowName.."Background",true )
	            ButtonSetDisabledFlag("CharacterSelectWindowDeleteCharacterButton", false)
	        end
		end		            
    end

    -- only allow create if they dont already have the max number of character created
    -- special case for seige (you can only have one char)
    if ( Login.CurStageData.NumChars < Login.CurStageData.MaxChars and
		not( (Login.CurStageData.NumChars >= 1) and IsOneCharPerAcct() )) then

		if (HasEntitlement(Login.SEVENTH_ANNIVERSARY_ENTITLEMENT)) or ( Login.CurStageData.NumChars < 5) then
			ButtonSetDisabledFlag("CharacterSelectWindowCreateCharacterButton", false)
		end
    else
        ButtonSetDisabledFlag("CharacterSelectWindowCreateCharacterButton", true)
    end
        
    ScrollWindowUpdateScrollRect("CharacterSelectScrollWindow")
end

Login.LoginStages[Login.STAGE_CHARACTERSELECT].Shutdown = function ()
    for i=1, Login.CurStageData.MaxChars do
        local listItem = "Character_"..i
	    ButtonSetPressedFlag(listItem.."Background",false)
	end
end

function Login.CharacterSelect()
    for i=1, Login.CurStageData.MaxChars do
        local listItem = "Character_"..i
	    ButtonSetPressedFlag(listItem.."Background",false)
	end
	
	local newCharListItem = SystemData.ActiveWindow.name
	Login.CurStageData.CurCharNum = WindowGetId(newCharListItem)

	ButtonSetPressedFlag(newCharListItem.."Background",true)
	
    ButtonSetDisabledFlag("CharacterSelectWindowDeleteCharacterButton", false)
end

function Login.GoBackToServerSelect()
    UndoLogin()
    TryLogin(Login.LoginStages[Login.STAGE_ACCOUNTPASSWORD].Account, Login.LoginStages[Login.STAGE_ACCOUNTPASSWORD].Password)
end

function Login.OpenCharacterCreation()
    if( ButtonGetDisabledFlag("CharacterSelectWindowCreateCharacterButton") == false ) then
    
	    if (not HasEntitlement(CharacterCreation.MondainsLegacyEntitlement)) then
	        ButtonSetDisabledFlag( "RaceUpButton", true)
	        ButtonSetDisabledFlag( "RaceDownButton", true)
	    end
        Login.SetStage(Login.STAGE_CHARACTERCREATION)
    end
end

function Login.DeleteSelectedCharacter()
    if( ButtonGetDisabledFlag("CharacterSelectWindowDeleteCharacterButton") == false ) then
        local okayButton = { textTid=UO_StandardDialog.TID_OKAY, callback=Login.DeleteCharacterCallback }
        local cancelButton = { textTid=UO_StandardDialog.TID_CANCEL }
	    local DeleteConfirmWindow =
        {
            windowName = "DeleteConfirmWindow",
	        titleTid = Login.TID.LABEL_23,
		    bodyTid = Login.TID.LABEL_24,
		    buttons = { okayButton, cancelButton }
	    }

        UO_StandardDialog.CreateDialog(DeleteConfirmWindow)
    end
end

function Login.DeleteCharacterCallback()
    DeleteCharacter(Login.CurStageData.CurCharNum)
end

function Login.StartGameWithSelectedCharacter()
    if( Login.CurStageData.CurCharNum ~= nil ) then
        SelectCharacter(Login.CurStageData.CurCharNum)
        WindowSetShowing ( "CharacterSelectWindow", false)
    else
	    local NoCharacterWindow =
        {
            windowName = "Login",
		    bodyTid = Login.TID.LABEL_21,
	    }

        UO_StandardDialog.CreateDialog(NoCharacterWindow)        
    end
end

function Login.PlayNowMouseOut()
    ButtonSetPressedFlag("CharacterSelectWindowPlayNowButton", false)
end

-------------- CREDITS STAGE BEGIN --------------

function Login.ShowCredits()
    if( Login.CurLoginStage == Login.STAGE_CREDITS ) then
        Credits.Cleanup()
        Login.SetStage(Login.LastLoginStage)
    else
        Login.SetStage(Login.STAGE_CREDITS)
    end
end

function Login.OpenAccountPage()
	if (SystemData.Settings.Language.type == SystemData.Settings.Language.LANGUAGE_JPN) then
	    OpenWebBrowser("https://account.ea.com/myacct/uo/uo-hub.jsp?skin=uo&site=eaco&locale=ja")
	elseif (SystemData.Settings.Language.type == SystemData.Settings.Language.LANGUAGE_CHINESE_TRADITIONAL) then
	    OpenWebBrowser("https://account.ea.com/myacct/uo/uo-hub.jsp?skin=uo&site=eaco&locale=zh_TW")
	else
    	OpenWebBrowser("http://ultima-registration.com")
	end
end

function Login.OpenUOCom()
    if (SystemData.Settings.Language.type == SystemData.Settings.Language.LANGUAGE_JPN) then
	    OpenWebBrowser("http://ultimaonline.jp")
	elseif (SystemData.Settings.Language.type == SystemData.Settings.Language.LANGUAGE_CHINESE_TRADITIONAL) then
	    OpenWebBrowser("http://www.ultimaonline.com.tw")
	else
    	OpenWebBrowser("http://uo.com")
	end
end

function Login.OpenCustomUiWindow()
    WindowSetShowing("CustomUiWindow",true)
end

function Login.ResetCustomUiComboBox()
	local skinItr
	for skinItr = 1, #SystemData.CustomUIList do
		if( SystemData.Settings.Interface.customUiName == SystemData.CustomUIList[skinItr] ) then
			ComboBoxSetSelectedMenuItem("CustomUiWindowCustomSkinsCombo", skinItr )
		end		
	end   
end

function Login.OnCustomUiCancel()
    Login.ResetCustomUiComboBox()

	UO_DefaultWindow.CloseDialog()
end

function Login.OnCustomUiOk()
	local skinIndex = ComboBoxGetSelectedMenuItem( "CustomUiWindowCustomSkinsCombo" )
	local skinName = SystemData.CustomUIList[skinIndex]
	
	if( skinName ~= SystemData.Settings.Interface.customUiName ) then
	    SystemData.Settings.Interface.customUiName = skinName
	    -- update in code
	    UpdateCustomUI(skinName)
	end
	
	UO_DefaultWindow.CloseDialog()
end