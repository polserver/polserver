
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

InterfaceCore = {}

InterfaceCore.scale = 1.0
InterfaceCore.IsInGame = false

-- Todo: Rename these variables to InterfaceCore
Interface = {}
Interface.DestroyWindowOnClose = {}
Interface.OnCloseCallBack = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

local coreInitialized = false

----------------------------------------------------------------
-- Interface Core Functions
----------------------------------------------------------------

function InterfaceCore.Initialize()
	-- Load the proper font XML definitions based on the language
	if( SystemData.Settings.Language.type == SystemData.Settings.Language.LANGUAGE_JPN or
		SystemData.Settings.Language.type == SystemData.Settings.Language.LANGUAGE_CHINESE_TRADITIONAL ) then
		LoadResources( "Data/Interface/InterfaceCore", "", "Fonts/FontsJPN.xml" )
	else
		LoadResources( "Data/Interface/InterfaceCore", "", "Fonts/FontsENU.xml" )
	end

	-- Register the Window Sets
	RegisterWindowSet(0, "InterfaceCore.CreateTitleInterface" )
	RegisterWindowSet(1, "InterfaceCore.CreateLoginInterface" )
	RegisterWindowSet(2, "InterfaceCore.CreatePlayInterface" )
	
	WindowRegisterEventHandler("Root", SystemData.Events.GAMESERVER_CONNECT_FAILED, "InterfaceCore.HandleGameserverConnectFailed")
	WindowRegisterEventHandler("Root", SystemData.Events.GAMESERVER_CONNECT_LOST, "InterfaceCore.HandleGameserverConnectLost")			
end


function InterfaceCore.Update( timePassed )
    Cursor.Update( timePassed )
    WindowUtils.Update( timePassed )

    if( Interface ~= nil and Interface.Update ~= nil ) then
	    Interface.Update( timePassed )
	end

    if( InterfaceLogin ~= nil and InterfaceLogin.Update ~= nil ) then
        InterfaceLogin.Update( timePassed )
    end
end

function InterfaceCore.Shutdown()
		
	if( Interface ~= nil and Interface.Shutdown ~= nil ) then
		Interface.Shutdown()
	end

end

function InterfaceCore.OnExitGame()
	local quitButtonName = SystemData.ActiveWindow.name
    local okayButton = { textTid=UO_StandardDialog.TID_OKAY, callback=function() BroadcastEvent( SystemData.Events.EXIT_GAME ); end }
    local cancelButton = { textTid=UO_StandardDialog.TID_CANCEL, callback=function() ButtonSetPressedFlag(quitButtonName, false); end }
    local QuitConfirmWindow = 
    {
        windowName = "QuitConfirmWindow",
	    titleTid = 3000000,
		bodyTid = 3000000,
		buttons = { okayButton, cancelButton }
	}
			
    UO_StandardDialog.CreateDialog(QuitConfirmWindow)
    
    ButtonSetPressedFlag(quitButtonName, true)
end

----------------------------------------------------------------
-- Window Set Callbacks
----------------------------------------------------------------
function InterfaceCore.WindowSetCommon()
    Cursor.Initialize()
	WindowUtils.Initialize()
	
	CreateWindow( "DebugWindow", false )
	
	InterfaceCore.UpdateScale(true)
end


function InterfaceCore.CreateTitleInterface()
    InterfaceCore.WindowSetCommon()
end

function InterfaceCore.CreateLoginInterface()
	-- Load the Core Window Definitions
	LoadResources( "Data/Interface/InterfaceCore", "", "InterfaceCore.xml" )

    InterfaceCore.WindowSetCommon()

	WindowRegisterEventHandler( "Root", SystemData.Events.RESOLUTION_CHANGED, "InterfaceCore.UpdateScale")

	-- Load the Login Interface Resources from the specified interface directory
	LoadResources( "Data/Interface/Login", "", "InterfaceLogin.xml" )
	
	InterfaceLogin.CreateLoginWindowSet()
end

function InterfaceCore.CreatePlayInterface()
    local customUiPath = ""
    if( SystemData.Settings.Interface.customUiName ~= "" ) then
        customUiPath = SystemData.Directories.Interface .. "/" .. SystemData.Settings.Interface.customUiName
    end

	-- Load the Core Window Definitions
	LoadResources( "Data/Interface/InterfaceCore", customUiPath, "InterfaceCore.xml" )

    InterfaceCore.IsInGame = true

    InterfaceCore.WindowSetCommon()
    
	-- Load the In-Game Interface Resources from the specified interface directory
	--LoadResources( SystemData.Directories.Interface, "Interface.xml" )
	LoadResources( "Data/Interface/Default", customUiPath, "Interface.xml" )

	WindowRegisterEventHandler( "Root", SystemData.Events.RESOLUTION_CHANGED, "InterfaceCore.UpdateScale")	
    
	Interface.CreatePlayWindowSet()
end


function InterfaceCore.ReloadUI()

	BroadcastEvent( SystemData.Events.RELOAD_INTERFACE )
end

function InterfaceCore.UpdateScale(bIgnoreCustomScale)

	-- Set the scale of the interface according to the resolution
	
	local multiplier = 1.0
	if( bIgnoreCustomScale ~= true and SystemData.Settings.Interface.customUiScaleEnabled == true ) then
	    multiplier = SystemData.Settings.Interface.customUiScale
	end
	
    -- Default Scaling
    if( SystemData.screenResolution.y < 1024 ) then
        InterfaceCore.scale = (SystemData.screenResolution.y / 1024) * multiplier
    else
        InterfaceCore.scale = multiplier
    end
	
	-- clamp the ui scale to 0.5 (bad things happen when it gets any smaller)
	if( InterfaceCore.scale < 0.5 ) then
	    InterfaceCore.scale = 0.5
	end
	
    ScaleInterface( InterfaceCore.scale )

end

----------------------------------------------------------------
-- Network Error Handlers
----------------------------------------------------------------

function InterfaceCore.ShowNetworkErrorMessage(bodyText,focusOnClose,callback)
    local okayButton = { textTid=UO_StandardDialog.TID_OKAY, callback=callback }
    local windowData = 
    {
        windowName = "Root",
        titleTid = Login.TID.LABEL_NETWORK_ERROR,
        body = bodyText,
        focusOnClose = focusOnClose,
        buttons = { okayButton }
    }
    InterfaceCore.OnCloseCallBack["RootDialog"] = callback
    UO_StandardDialog.CreateDialog(windowData)
end

function InterfaceCore.HandleGameserverConnectFailed()
    local callback = nil
    local focusOnClose = nil
    if( InterfaceCore.IsInGame == true ) then
        callback = function () BroadcastEvent( SystemData.Events.LOG_OUT ) end
    else
        callback = function () Login.SetStage(Login.STAGE_ACCOUNTPASSWORD) end
        focusOnClose = "Username"
        ButtonSetDisabledFlag("LoginWindowLoginButton", false)
    end
    
    InterfaceCore.ShowNetworkErrorMessage(GetStringFromTid(Login.TID.LABEL_CONNECTION_FAILED),focusOnClose,callback)
end

function InterfaceCore.HandleGameserverConnectLost()
    local callback = nil
    local focusOnClose = nil
    if( InterfaceCore.IsInGame == true ) then
        callback = function () BroadcastEvent( SystemData.Events.LOG_OUT ) end
    else
        callback = function () Login.SetStage(Login.STAGE_ACCOUNTPASSWORD) end
        focusOnClose = "Username"
        ButtonSetDisabledFlag("LoginWindowLoginButton", false)
    end
    
    InterfaceCore.ShowNetworkErrorMessage(GetStringFromTid(Login.TID.LABEL_CONNECTION_LOST),focusOnClose,callback)
end

----------------------------------------------------------------
-- Window State Functions
----------------------------------------------------------------

function WindowGetState( windowName )

    local globalTable = _G

    local windowTable = globalTable[ windowName ]
    
    if ( windowTable ~= nil ) then
        
        local stateTable = windowTable[ "STATE" ]
            
        if ( stateTable ~= nil ) then
        
            return stateTable
                
        end
        
    end
    
    --DEBUG(L"WindowGetState( "..StringToWString(windowName)..L" ) == NIL" )
    return nil
    
end

function WindowGetShowing( windowName )
    
    local state = WindowGetState( windowName )
    
    if ( state ~= nil ) then
    
        return state[ "SHOWING" ]
 
    else
    
        return _WindowGetShowing( windowName )
        
    end

end

function WindowGetDimensions( windowName )
    
    local state = WindowGetState( windowName )
    
    if ( state ~= nil ) then
   
        return state[ "DIMENSION_X" ], state[ "DIMENSION_Y" ]

    else    

        return _WindowGetDimensions( windowName )
    
    end
 
end

function LabelGetTextColor( windowName )

    local state = WindowGetState( windowName )
    
    if ( state ~= nil ) then
    
        return state[ "LABEL_TEXTCOLOR_R" ], state[ "LABEL_TEXTCOLOR_G" ], state[ "LABEL_TEXTCOLOR_B" ]
    
    else
    
        return _LabelGetTextColor( windowName )
    
    end
    
end

function LabelGetLinkColor( windowName )

    return LabelGetTextColor( windowName )
    
end

function LabelGetTextDimensions( windowName )

    local state = WindowGetState( windowName )
    
    if ( state ~= nil ) then
    
        return state[ "LABEL_TEXTDIMS_X" ], state[ "LABEL_TEXTDIMS_Y" ]
    
    else
    
        return _LabelGetTextDimensions( windowName )
    
    end

end

function LabelGetText( windowName )

    local state = WindowGetState( windowName )
    
    if ( state ~= nil ) then
    
        return state[ "LABEL_TEXT" ]
    
    else
    
        return _LabelGetText( windowName )
    
    end

end

----------------------------------------------------------------
-- Misc
----------------------------------------------------------------

function InterfaceCore.BreakPoint( parm1, parm2, parm3, parm4 )

    local msg = "[" .. parm1 .. "] [" .. parm2 .. "] [" .. parm3 .. "] [ " .. parm4 .. "]"
    
    WindowBreakPoint( msg )

end