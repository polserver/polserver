----------------------------------------------------------------
-- Global functions
----------------------------------------------------------------

function ToggleWindowByName( wndName, btnName, toggleFunction, onOpenFunction, onCloseFunction )
	local showing = WindowGetShowing( wndName )
	showing = not showing	
	WindowSetShowing( wndName, showing )
	
	if (btnName ~= "") then
		ButtonSetPressedFlag( btnName, showing )
	end
	
	
	if( onOpenFunction ~= nil and showing == true ) then
	    onOpenFunction()
	elseif( onCloseFunction ~= nil and showing == false ) then
	    onCloseFunction()
	end
end

----------------------------------------------------------------
-- In-Game Interface Initialization Variables
----------------------------------------------------------------

-- In the future, this could be exposed by c++:
Interface.PLAYWINDOWSET = 2

function Interface.CreatePlayWindowSet()
	CreateWindow( "ResizeWindow", true )
	CreateWindow( "MainMenuWindow", false )
	CreateWindow( "SettingsWindow", false )
	CreateWindow( "CharacterSheet", false )
	CreateWindow( "ItemProperties", false )
	CreateWindow( "BugReportWindow", false )
	CreateWindow( "SkillsWindow", false )
	CreateWindow( "MacroWindow", false )	
	CreateWindow( "StatusWindow", true )
	CreateWindow( "MenuBarWarButton", true )
	CreateWindow( "MenuBarWindowBackground", true )
	CreateWindow( "MenuBarWindowStatusBar", true )
	CreateWindow( "TargetWindow", false )
	CreateWindow( "ContextMenu", false )
	CreateWindow( "GroupWindow", true )
	CreateWindow( "PetWindow", true )
	CreateWindow( "ActionsWindow", false )
	CreateWindow( "ActionEditText", false )
	CreateWindow( "ActionEditSlider", false )
	CreateWindow( "ActionEditMacro", false )
	CreateWindow( "ActionEditEquip", false )
	CreateWindow( "ActionEditUnEquip", false )
	CreateWindow( "ActionEditArmDisarm", false )
	CreateWindow( "ActionEditTargetByResource", false )
	CreateWindow( "MapWindow", false )
	CreateWindow( "MapOptionsWindow", false )
	CreateWindow( "RadarWindow", true )
	CreateWindow( "SkillsInfo", false )
	CreateWindow( "TrackingPointer", true )
	CreateWindow( "UserWaypointWindow", false)
			
	WindowRegisterEventHandler("Root", SystemData.Events.BUG_REPORT_SCREEN, "Interface.InitBugReport")
	WindowRegisterEventHandler( "Root", SystemData.Events.UPDATE_CHARACTER_SETTINGS, "Interface.SendCharacterSettings")
	WindowRegisterEventHandler( "Root", SystemData.Events.CHARACTER_SETTINGS_UPDATED, "Interface.RetrieveCharacterSettings")	
	
	Tooltips.Initialize()
	HotbarSystem.Initialize()
	ChatManager.Initialize()
	GGManager.Initialize()
	CGManager.Initialize()
	DamageWindow.Initialize()
	GenericQuantity.Initialize()
	EquipmentData.Initialize()
	MobileHealthBarWindow.InitializeSystem()
	ObjectHandleWindow.Initialize()
	NameWindow.InitializeEvents()
    
	WindowRegisterEventHandler( "Root", SystemData.Events.DEBUGPRINT_TO_CONSOLE, "Interface.OnDebugPrint")
	UOSetWaypointDisplayMode("RADAR")
end

function Interface.InitBugReport()
	ToggleWindowByName( "BugReportWindow", "", MainMenuWindow.ToggleBugReportWindow )
end

function Interface.Update( timePassed )
	Tooltips.Update( timePassed )
	BuffDebuff.Update( timePassed )
	
	ChatManager.Update( timePassed )
	DamageWindow.UpdateTime( timePassed )
	ResizeWindow.Update(timePassed)
	NameWindow.Update(timePassed)
	ContainerWindow.UpdatePickupTimer(timePassed)
	ContextMenu.Update(timePassed)
	MapWindow.Update(timePassed)
end

function Interface.Shutdown()
	-- If we're not shutting down the "login" windowset, then kill equipment and hotbar systems
	if SystemData.ActiveWindowSet == Interface.PLAYWINDOWSET then
		EquipmentData.Shutdown()
		HotbarSystem.Shutdown()
	end
	
	ChatManager.Shutdown()
end

function Interface.OnDebugPrint()
	Debug.PrintToDebugConsole(DebugData.DebugString)
end

function Interface.SendCharacterSettings()
	WindowUtils.SendWindowSettings()
	HotbarSystem.SendHotbarData()
end

function Interface.RetrieveCharacterSettings()
	WindowUtils.RetrieveWindowSettings()
	HotbarSystem.RetrieveHotbarData()
end
