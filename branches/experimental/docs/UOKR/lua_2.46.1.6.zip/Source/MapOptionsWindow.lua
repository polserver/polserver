----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

MapOptionsWindow = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

MapOptionsWindow.TID = {MapOptions=1078473, Waypoints=1078474, WorldMap=1077438, RadarMap=3010042, InGame=1078477,
						ReturnToMap=1078478, SelectAnIcon=1078857, WaypointNamesOn=1079397, WaypointNamesOff=1079398}
MapOptionsWindow.MapIconSelected = false
MapOptionsWindow.RadarIconSelected = false
MapOptionsWindow.DisplayTypeSelected = nil
MapOptionsWindow.DisplayWaypointNames = false
----------------------------------------------------------------
-- Functions
----------------------------------------------------------------

function MapOptionsWindow.Initialize()
	RegisterWindowData(WindowData.WaypointDisplay.Type,0)
	
	--Debug.DumpToConsole("WindowData.WaypointDisplay", WindowData.WaypointDisplay, "WindowData.WaypointDisplay")

	LabelSetText("MapOptionsWindowTitle", GetStringFromTid(MapOptionsWindow.TID.MapOptions))
	LabelSetText("WaypointsColumnTitle", GetStringFromTid(MapOptionsWindow.TID.Waypoints))
	LabelSetText("AtlasMapColumnTitle", GetStringFromTid(MapOptionsWindow.TID.WorldMap))
	LabelSetText("RadarColumnTitle", GetStringFromTid(MapOptionsWindow.TID.RadarMap))
	LabelSetText("InGameColumnTitle", GetStringFromTid(MapOptionsWindow.TID.InGame))
	ButtonSetText("ShowMapButton", GetStringFromTid(MapOptionsWindow.TID.ReturnToMap))

	local numWaypointDisplayTypes = table.getn(WindowData.WaypointDisplay.typeNames) 
	local currentWaypointDisplayOptionWindowName = nil
	local previousWaypointDisplayOptionWindowName = nil
	local mapWaypointIconId, radarWaypointIconId, gameWaypointEffectId, waypointName = nil
	
	for waypoint_display_type_index = 1, numWaypointDisplayTypes do
		
		currentWaypointDisplayOptionWindowName = "WaypointDisplayOption"..waypoint_display_type_index
		CreateWindowFromTemplate( currentWaypointDisplayOptionWindowName, "WaypointItemTemplate", "MapOptionsScrollChild" )

		waypointName = WindowData.WaypointDisplay.typeNames[waypoint_display_type_index]
		LabelSetText (currentWaypointDisplayOptionWindowName.."Name", waypointName)
		
		-- SET MAP WAYPOINT UI OPTIONS
		mapWaypointIconId = WindowData.WaypointDisplay.displayTypes.ATLAS[waypoint_display_type_index].iconId
		MapOptionsWindow.GenerateWaypointIcon(mapWaypointIconId, currentWaypointDisplayOptionWindowName.."MapWaypointIcon", "MapOptionsIconTemplate", currentWaypointDisplayOptionWindowName)
        WindowAddAnchor(currentWaypointDisplayOptionWindowName.."MapWaypointIcon", "topright", currentWaypointDisplayOptionWindowName.."ToggleMapWaypointButton", "topleft", 10, 0)
		WindowSetId(currentWaypointDisplayOptionWindowName.."MapWaypointIcon", waypoint_display_type_index)
		
		ButtonSetStayDownFlag( currentWaypointDisplayOptionWindowName.."ToggleMapWaypointButton", true )
    	ButtonSetCheckButtonFlag( currentWaypointDisplayOptionWindowName.."ToggleMapWaypointButton", true )
    	ButtonSetPressedFlag(currentWaypointDisplayOptionWindowName.."ToggleMapWaypointButton", WindowData.WaypointDisplay.displayTypes.ATLAS[waypoint_display_type_index].isDisplayed)
    	WindowSetId(currentWaypointDisplayOptionWindowName.."ToggleMapWaypointButton", waypoint_display_type_index)
		
		-- SET RADAR WAYPOINT UI OPTIONS
		radarWaypointIconId = WindowData.WaypointDisplay.displayTypes.RADAR[waypoint_display_type_index].iconId
		MapOptionsWindow.GenerateWaypointIcon(radarWaypointIconId, currentWaypointDisplayOptionWindowName.."RadarWaypointIcon", "MapOptionsIconTemplate", currentWaypointDisplayOptionWindowName)
        WindowAddAnchor(currentWaypointDisplayOptionWindowName.."RadarWaypointIcon", "topright", currentWaypointDisplayOptionWindowName.."ToggleRadarWaypointButton", "topleft", 10, 0)
		WindowSetId(currentWaypointDisplayOptionWindowName.."RadarWaypointIcon", waypoint_display_type_index)
		
		ButtonSetStayDownFlag( currentWaypointDisplayOptionWindowName.."ToggleRadarWaypointButton", true )
    	ButtonSetCheckButtonFlag( currentWaypointDisplayOptionWindowName.."ToggleRadarWaypointButton", true )
    	ButtonSetPressedFlag(currentWaypointDisplayOptionWindowName.."ToggleRadarWaypointButton", WindowData.WaypointDisplay.displayTypes.RADAR[waypoint_display_type_index].isDisplayed)		
		WindowSetId(currentWaypointDisplayOptionWindowName.."ToggleRadarWaypointButton", waypoint_display_type_index)
		
		-- SET GAME WAYPOINT UI OPTIONS
		ButtonSetStayDownFlag( currentWaypointDisplayOptionWindowName.."ToggleGameWaypointButton", true )
    	ButtonSetCheckButtonFlag( currentWaypointDisplayOptionWindowName.."ToggleGameWaypointButton", true )
    	ButtonSetPressedFlag(currentWaypointDisplayOptionWindowName.."ToggleGameWaypointButton", WindowData.WaypointDisplay.displayTypes.GAMEVIEW[waypoint_display_type_index].isDisplayed)		
		WindowSetId(currentWaypointDisplayOptionWindowName.."ToggleGameWaypointButton", waypoint_display_type_index)
		
		for index, effectName in ipairs(WindowData.WaypointDisplay.effectNames) do
			ComboBoxAddMenuItem( currentWaypointDisplayOptionWindowName.."GameWaypointCombo", effectName )
		end
		
		gameWaypointEffectId = WindowData.WaypointDisplay.displayTypes.GAMEVIEW[waypoint_display_type_index].displayIndex
		ComboBoxSetSelectedMenuItem( currentWaypointDisplayOptionWindowName.."GameWaypointCombo", gameWaypointEffectId )
		WindowSetId(currentWaypointDisplayOptionWindowName.."GameWaypointCombo", waypoint_display_type_index)	

		if (waypoint_display_type_index == 1) then
			WindowAddAnchor( currentWaypointDisplayOptionWindowName, "topleft", "MapOptionsScrollChild", "topleft", 10, 5)
		else
			WindowAddAnchor( currentWaypointDisplayOptionWindowName, "bottomleft", previousWaypointDisplayOptionWindowName, "topleft", 0, 5)
		end
		previousWaypointDisplayOptionWindowName	= currentWaypointDisplayOptionWindowName
	end
	ScrollWindowUpdateScrollRect("MapOptionsScrollWindow")
	
	-- SETUP THE WAYPOINT ICON PICKER !!! 
	CreateWindowFromTemplate( "MapOptionsIconPickerWindow", "WaypointIconPickerWindowTemplate", "Root" )
	WindowAddAnchor( "MapOptionsIconPickerWindow", "center", "Root", "center", 0, 0)
	WaypointIconPickerWindow.DrawWaypointIconTable("MapOptionsIconPickerWindow")
	WaypointIconPickerWindow.SetAfterWaypointIconSelectionFunction(MapOptionsWindow.ChangeIcon, "MapOptionsIconPickerWindow")
	LabelSetText("MapOptionsIconPickerWindowTitle", GetStringFromTid(MapOptionsWindow.TID.SelectAnIcon))
	WindowSetShowing("MapOptionsIconPickerWindow", false)

	-- SETUP WAYPOINT NAMES BUTTON
	ButtonSetText("ToggleWaypointNamesButton", GetStringFromTid(MapOptionsWindow.TID.WaypointNamesOff))
	ButtonSetStayDownFlag("ToggleWaypointNamesButton", true)
end

function MapOptionsWindow.Shutdown()
	UnregisterWindowData(WindowData.WaypointDisplay.Type,0)
end

function MapOptionsWindow.ShowMap()
	WindowSetShowing("MapWindow", true)
   	WindowSetShowing("MapOptionsWindow", false)
end

function MapOptionsWindow.ToggleMapWaypoint()
	MapOptionsWindow.ToggleWaypointIconDisplay("ATLAS")
 	MapWindow.UpdateMapLegend()
end

function MapOptionsWindow.ToggleRadarWaypoint()
	MapOptionsWindow.ToggleWaypointIconDisplay("RADAR")
end

function MapOptionsWindow.ToggleGameWaypoint()
	MapOptionsWindow.ToggleWaypointIconDisplay("GAMEVIEW")
end

-- Convenience method for toggling waypoint display icon buttons
function MapOptionsWindow.ToggleWaypointIconDisplay(displayMode)
	local waypointDisplayType = WindowGetId(SystemData.ActiveWindow.name)
	local displayIndex = nil
	
	--Debug.Print ("TOGGLING DISPLAY INDEX "..waypointDisplayType) 
	
	if (displayMode == "ATLAS") then
		displayIndex = WindowData.WaypointDisplay.displayTypes.ATLAS[waypointDisplayType].displayIndex
	elseif (displayMode == "RADAR") then
		displayIndex = WindowData.WaypointDisplay.displayTypes.RADAR[waypointDisplayType].displayIndex
	elseif (displayMode == "GAMEVIEW") then
		displayIndex = WindowData.WaypointDisplay.displayTypes.GAMEVIEW[waypointDisplayType].displayIndex
	end

	UOSetWaypointTypeDisplayInfo(waypointDisplayType, displayMode, displayIndex, ButtonGetPressedFlag(SystemData.ActiveWindow.name))
	MapWindow.UpdateDisplayModeMap()
end

function MapOptionsWindow.ChangeEffect()
	local waypointDisplayType = WindowGetId(SystemData.ActiveWindow.name)
	local effectIndex = ComboBoxGetSelectedMenuItem(SystemData.ActiveWindow.name)
	local toggleDisplayButtonName = WindowGetParent(SystemData.ActiveWindow.name).."ToggleGameWaypointButton"

	UOSetWaypointTypeDisplayInfo(waypointDisplayType, "GAMEVIEW", effectIndex, ButtonGetPressedFlag(toggleDisplayButtonName))
end

function MapOptionsWindow.OpenIconPicker()
	if string.find(SystemData.ActiveWindow.name, "Map") then
		MapOptionsWindow.MapIconSelected = true
		MapOptionsWindow.RadarIconSelected = false
	elseif string.find(SystemData.ActiveWindow.name, "Radar") then
		MapOptionsWindow.MapIconSelected = false
		MapOptionsWindow.RadarIconSelected = true
	end
	MapOptionsWindow.DisplayTypeSelected = WindowGetId(SystemData.ActiveWindow.name)
	WindowSetShowing("MapOptionsIconPickerWindow", true)	
end

function MapOptionsWindow.ChangeIcon(iconIndex, waypointTypeId)
	if (iconIndex and waypointTypeId) then
		UOSetWaypointTypeDisplayInfo(waypointTypeId, "ATLAS", iconIndex, true)
		UOSetWaypointTypeDisplayInfo(waypointTypeId, "RADAR", iconIndex, true)
		ButtonSetPressedFlag("WaypointDisplayOption"..waypointTypeId.."ToggleMapWaypointButton", true)
		ButtonSetPressedFlag("WaypointDisplayOption"..waypointTypeId.."ToggleRadarWaypointButton", true)
		MapWindow.UpdateWaypointIcon(WindowData.WaypointDisplay.iconIds[iconIndex], "WaypointDisplayOption"..waypointTypeId.."MapWaypointIcon")
		MapWindow.UpdateWaypointIcon(WindowData.WaypointDisplay.iconIds[iconIndex], "WaypointDisplayOption"..waypointTypeId.."RadarWaypointIcon")
		MapWindow.UpdateMapLegend()
	else
		if (MapOptionsWindow.MapIconSelected) then
			UOSetWaypointTypeDisplayInfo(MapOptionsWindow.DisplayTypeSelected, "ATLAS", WaypointIconPickerWindow.WaypointIconSelected["MapOptionsIconPickerWindow"], ButtonGetPressedFlag("WaypointDisplayOption"..MapOptionsWindow.DisplayTypeSelected.."ToggleMapWaypointButton"))
			MapWindow.UpdateWaypointIcon(WindowData.WaypointDisplay.iconIds[WaypointIconPickerWindow.WaypointIconSelected["MapOptionsIconPickerWindow"]], "WaypointDisplayOption"..MapOptionsWindow.DisplayTypeSelected.."MapWaypointIcon")
			MapWindow.UpdateMapLegend()
		elseif (MapOptionsWindow.RadarIconSelected) then	
			UOSetWaypointTypeDisplayInfo(MapOptionsWindow.DisplayTypeSelected, "RADAR", WaypointIconPickerWindow.WaypointIconSelected["MapOptionsIconPickerWindow"], ButtonGetPressedFlag("WaypointDisplayOption"..MapOptionsWindow.DisplayTypeSelected.."ToggleRadarWaypointButton"))
			MapWindow.UpdateWaypointIcon(WindowData.WaypointDisplay.iconIds[WaypointIconPickerWindow.WaypointIconSelected["MapOptionsIconPickerWindow"]], "WaypointDisplayOption"..MapOptionsWindow.DisplayTypeSelected.."RadarWaypointIcon")
		end
		MapOptionsWindow.MapIconSelected = false
		MapOptionsWindow.RadarIconSelected = false
		MapOptionsWindow.DisplayTypeSelected = nil
	end
	
	ScrollWindowUpdateScrollRect("MapOptionsScrollWindow")
	MapWindow.UpdateDisplayModeMap()
end

function MapOptionsWindow.GenerateWaypointIcon(waypointIconId, waypointIconWindowName, waypointTemplate, rootWindow)
	local iconTexture, x, y = GetIconData(waypointIconId)
    local waypointIconWidth, waypointIconHeight = UOGetTextureSize("icon"..waypointIconId)

	if (waypointIconWidth and waypointIconHeight) then
		CreateWindowFromTemplate(waypointIconWindowName, waypointTemplate, rootWindow )
		WindowSetDimensions(waypointIconWindowName, waypointIconWidth, waypointIconHeight)
	    WindowSetDimensions(waypointIconWindowName.."Graphic", waypointIconWidth, waypointIconHeight)
		DynamicImageSetTexture(waypointIconWindowName.."Graphic", iconTexture, x, y)
		return true
	else
		return false
	end
end

function MapOptionsWindow.ToggleWaypointNames()
	MapOptionsWindow.DisplayWaypointNames = not(MapOptionsWindow.DisplayWaypointNames)
	MapWindow.UpdateDisplayModeWaypoints()
	
	if (MapOptionsWindow.DisplayWaypointNames) then
		ButtonSetText("ToggleWaypointNamesButton", GetStringFromTid(MapOptionsWindow.TID.WaypointNamesOn))
		ButtonSetPressedFlag("ToggleWaypointNamesButton", true)
	else
	    ButtonSetText("ToggleWaypointNamesButton", GetStringFromTid(MapOptionsWindow.TID.WaypointNamesOff))
	    ButtonSetPressedFlag("ToggleWaypointNamesButton", false)
	end

end
