----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

MobileHealthBarWindow = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

--If the health bar for it is already open
MobileHealthBarWindow.hasWindow = {}
MobileHealthBarWindow.windowDisabled = {}
MobileHealthBarWindow.numHealthBar = 0

MobileHealthBarWindow.grayColor = { r= 150, g=150, b= 150 }
MobileHealthBarWindow.whiteColor = { r= 255, g=255, b= 255 }


----------------------------------------------------------------
-- Functions
----------------------------------------------------------------

function MobileHealthBarWindow.InitializeSystem()
	WindowRegisterEventHandler( "Root", SystemData.Events.CREATE_HEALTHBAR_WINDOW, "MobileHealthBarWindow.CreateHealthBar")
end

function MobileHealthBarWindow.CreateHealthBar()
	local mobileId = SystemData.ActiveMobile.Id
	local windowName = "MobileHealthBarWindow"..mobileId
	
	--Players can only have a max of 10 health bars out at a time
	if( MobileHealthBarWindow.numHealthBar >= 10 )then
		if( MobileHealthBarWindow.hasWindow[mobileId] == true ) then
			MobileHealthBarWindow.HandleAnchorWindow(windowName)
			WindowSetMoving(windowName, true)
			WindowAssignFocus(windowName, true)	
		end
		return
	end
	
	if( MobileHealthBarWindow.hasWindow[mobileId] ~= true ) then
		CreateWindowFromTemplate(windowName, "MobileHealthBarWindow", "Root")
		MobileHealthBarWindow.HandleAnchorWindow(windowName)
		
		RegisterWindowData(WindowData.MobileStatus.Type, mobileId)	
		RegisterWindowData(WindowData.MobileName.Type, mobileId)
		RegisterWindowData(WindowData.HealthBarColor.Type, mobileId)
		WindowSetId(windowName, mobileId)
		Interface.DestroyWindowOnClose[windowName] = true
		MobileHealthBarWindow.windowDisabled[mobileId] = false
		
		WindowRegisterEventHandler( windowName, WindowData.MobileStatus.Event, "MobileHealthBarWindow.UpdateStatus")
		WindowRegisterEventHandler( windowName, WindowData.MobileName.Event, "MobileHealthBarWindow.UpdateName")
		WindowRegisterEventHandler( windowName, WindowData.HealthBarColor.Event, "MobileHealthBarWindow.TintHealthBar")
		WindowRegisterEventHandler( windowName, SystemData.Events.ENABLE_HEALTHBAR_WINDOW, "MobileHealthBarWindow.UpdateHealthBarState")
		WindowRegisterEventHandler( windowName, SystemData.Events.DISABLE_HEALTHBAR_WINDOW, "MobileHealthBarWindow.UpdateHealthBarState")		
		
		MobileHealthBarWindow.TintHealthBar(mobileId)
		WindowSetShowing(windowName.."ImageDisabled", false)
		MobileHealthBarWindow.hasWindow[mobileId] = true
		MobileHealthBarWindow.UpdateStatus(mobileId)
		MobileHealthBarWindow.UpdateName(mobileId)
		MobileHealthBarWindow.numHealthBar = MobileHealthBarWindow.numHealthBar + 1
	else
		MobileHealthBarWindow.HandleAnchorWindow(windowName)
	end

	WindowSetMoving(windowName, true)
	WindowAssignFocus(windowName, true)	
end

--Sets the health window active
function MobileHealthBarWindow.UpdateHealthBarState()
	local mobileId = WindowGetId(SystemData.ActiveWindow.name)
	
	if( IsHealthBarEnabled(mobileId) == true and MobileHealthBarWindow.windowDisabled[mobileId]==true ) then
		local windowName = "MobileHealthBarWindow"..mobileId
		--Debug.Print("Enabling Window: "..mobileId)
		-- enable window
		WindowSetShowing(windowName.."ImageDisabled", false)
		WindowSetShowing(windowName.."Image", true)
		WindowSetShowing(windowName.."HealthBar", true)
		MobileHealthBarWindow.windowDisabled[mobileId] = false
		RegisterWindowData(WindowData.MobileStatus.Type, mobileId)	
		RegisterWindowData(WindowData.HealthBarColor.Type, mobileId)
	 	LabelSetTextColor(windowName.."Name", MobileHealthBarWindow.whiteColor.r, MobileHealthBarWindow.whiteColor.g, MobileHealthBarWindow.whiteColor.b)
		MobileHealthBarWindow.UpdateStatus(mobileId)
	elseif( IsHealthBarEnabled(mobileId) == false and MobileHealthBarWindow.windowDisabled[mobileId]==false ) then
		local windowName = "MobileHealthBarWindow"..mobileId
		--Debug.Print("Disabling Window: "..mobileId)
		-- disable window
		WindowSetShowing(windowName.."ImageDisabled", true)
		WindowSetShowing(windowName.."Image", false)
		WindowSetShowing(windowName.."HealthBar",false)
		MobileHealthBarWindow.windowDisabled[mobileId] = true
		UnregisterWindowData(WindowData.MobileStatus.Type, mobileId)
		UnregisterWindowData(WindowData.HealthBarColor.Type, mobileId)
		LabelSetTextColor(windowName.."Name", MobileHealthBarWindow.grayColor.r, MobileHealthBarWindow.grayColor.g, MobileHealthBarWindow.grayColor.b)
	end
end

--Sets the Window close to where the player dragged their mouse
function MobileHealthBarWindow.HandleAnchorWindow(healthWindow)
	local propWindowWidth = 180
	local propWindowHeight = 38
	local propWindowX 
	local propWindowY
	-- Set the position
	scaleFactor = 1/InterfaceCore.scale	
	
	mouseX = SystemData.MousePosition.x - 30
	if mouseX + (propWindowWidth / scaleFactor) > SystemData.screenResolution.x then
		propWindowX = mouseX - (propWindowWidth / scaleFactor)
	else
		propWindowX = mouseX
	end
		
	mouseY = SystemData.MousePosition.y - 15
	if mouseY + (propWindowHeight / scaleFactor) > SystemData.screenResolution.y then
		propWindowY = mouseY - (propWindowHeight / scaleFactor)
	else
		propWindowY = mouseY
	end

	WindowSetOffsetFromParent(healthWindow, propWindowX * scaleFactor, propWindowY * scaleFactor)
end

function MobileHealthBarWindow.UpdateName(mobileIdLua)
	local mobileId = WindowData.UpdateInstanceId
	--If mobileIdLua is not nil then we are calling this function from within Lua
	if( mobileIdLua ~= nil ) then
		mobileId = mobileIdLua
	end
	local windowName = "MobileHealthBarWindow"..mobileId
	if( (MobileHealthBarWindow.hasWindow[mobileId] == true) ) then
		if(WindowData.MobileName[mobileId] ~= nil) then
			local data = WindowData.MobileName[mobileId]
			LabelSetText(windowName.."Name", data.MobName)
			WindowUtils.FitTextToLabel(windowName.."Name", data.MobName)
		end
	end
end

function MobileHealthBarWindow.UpdateStatus(mobileIdLua)
	local mobileId = WindowData.UpdateInstanceId
	--If mobileIdLua is not nil then we are calling this function from within Lua
	if( mobileIdLua ~= nil ) then
		mobileId = mobileIdLua
	end
	
	local windowName = "MobileHealthBarWindow"..mobileId
	--Set mobiles health status bar and name if their health bar is showing and not disabled
	if( (MobileHealthBarWindow.hasWindow[mobileId] == true) ) then
		StatusBarSetCurrentValue( windowName.."HealthBar", WindowData.MobileStatus[mobileId].CurrentHealth )	
		StatusBarSetMaximumValue( windowName.."HealthBar", WindowData.MobileStatus[mobileId].MaxHealth )
	end
end

function MobileHealthBarWindow.UnRegisterVariables(healthId)
	--Only unregister window data if the window is not disabled since it was already unregistered
	if(MobileHealthBarWindow.windowDisabled[healthId] == nil or MobileHealthBarWindow.windowDisabled[healthId] == false ) then
		UnregisterWindowData(WindowData.MobileStatus.Type, healthId)
		UnregisterWindowData(WindowData.HealthBarColor.Type, healthId)
	end
	
	UnregisterWindowData(WindowData.MobileName.Type, healthId)
	MobileHealthBarWindow.hasWindow[healthId] = nil
	MobileHealthBarWindow.windowDisabled[healthId] = nil
end

function MobileHealthBarWindow.Shutdown()
	local mobileId = WindowGetId(WindowUtils.GetActiveDialog())
	MobileHealthBarWindow.UnRegisterVariables(mobileId)
	MobileHealthBarWindow.numHealthBar = MobileHealthBarWindow.numHealthBar - 1
end

function MobileHealthBarWindow.OnMobileDblClicked()
	local mobileId = WindowGetId(WindowUtils.GetActiveDialog())
	--If health window is not disabled trigger object use
	if( MobileHealthBarWindow.windowDisabled[mobileId] ~= true) then
		UserActionUseItem(mobileId,false)
	end
end

function MobileHealthBarWindow.OnItemClicked()
	local mobileId = WindowGetId(WindowUtils.GetActiveDialog())
	--If health window is not disabled do handle left single click
	if( MobileHealthBarWindow.windowDisabled[mobileId] ~= true) then
		HandleSingleLeftClkTarget(mobileId)
	end
end

function MobileHealthBarWindow.LeftClickClose()
	local mobileId = WindowGetId(WindowUtils.GetActiveDialog())
	local windowName = "MobileHealthBarWindow"..mobileId
	if( MobileHealthBarWindow.hasWindow[mobileId] == true) then
		DestroyWindow(windowName)
	end	
end

function MobileHealthBarWindow.OnRClick()
	--Debug.Print("MobileHealthBarWindow.OnItemRClick"..SystemData.ActiveMobile.Id)
	RequestContextMenu(SystemData.ActiveMobile.Id)
end

function MobileHealthBarWindow.TintHealthBar(mobileId)
	--If mobileIdLua is not nil then we are calling this function from within Lua
	if( mobileId == nil ) then
		mobileId = WindowData.UpdateInstanceId
	end
	
	local windowName = "MobileHealthBarWindow"..mobileId
	local windowTintName = windowName.."HealthBar"
	--Colors the health bar to the correct color
	HealthBarColor.UpdateHealthBarColor(windowTintName, WindowData.HealthBarColor[mobileId].VisualStateId)
end

--Steals the L Button Up when it is above this window, so that way when you drag it off a player
--it doesn't try to do another mouse click interaction with it.
function MobileHealthBarWindow.OnLButtonUp()

end