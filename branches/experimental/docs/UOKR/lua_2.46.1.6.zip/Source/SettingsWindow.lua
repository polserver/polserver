
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

SettingsWindow = {}

SettingsWindow.Modes = {}
SettingsWindow.Modes.Graphics = 1 
SettingsWindow.Modes.KeyBindings = 2 
SettingsWindow.Modes.Options = 5
SettingsWindow.Modes.NUM_MODES = 7

SettingsWindow.Modes.windows = { "SettingsGraphicsWindow",  
                                "SettingsKeyBindingsWindow",
                                "SettingsSoundWindow",
                                "SettingsOptionsWindow",
								"SettingsInterfaceWindow",
								"SettingsProfanityWindow", 
								"SettingsKeyDefaultWindow"}

SettingsWindow.FontSizes = {}
SettingsWindow.FontSizes[1] = 12
SettingsWindow.FontSizes[2] = 14
SettingsWindow.FontSizes[3] = 16
SettingsWindow.FontSizes[4] = 18
SettingsWindow.FontSizes[5] = 20
SettingsWindow.FontSizes[6] = 22
SettingsWindow.FontSizes[7] = 24
SettingsWindow.NUM_FONT_SIZES = 7

SettingsWindow.ChatFadeTime = {}
SettingsWindow.ChatFadeTime[1] = 1
SettingsWindow.ChatFadeTime[2] = 2
SettingsWindow.ChatFadeTime[3] = 3
SettingsWindow.ChatFadeTime[4] = 4
SettingsWindow.ChatFadeTime[5] = 5
SettingsWindow.NUM_FADE_TIMES = 5

SettingsWindow.Languages = {}
SettingsWindow.Languages[1] = {tid=1077459, id=SystemData.Settings.Language.LANGUAGE_ENU}
SettingsWindow.Languages[2] = {tid=1077460, id=SystemData.Settings.Language.LANGUAGE_JPN}
SettingsWindow.Languages[3] = {tid=1078516, id=SystemData.Settings.Language.LANGUAGE_CHINESE_TRADITIONAL}
SettingsWindow.NUM_LANGUAGES = 3

SettingsWindow.DelayValues = {}
SettingsWindow.DelayValues[1] = 1078334
SettingsWindow.DelayValues[2] = 1078336
SettingsWindow.DelayValues[3] = 1078337
SettingsWindow.DelayValues[4] = 1078338
SettingsWindow.DelayValues[5] = 1078339
SettingsWindow.DelayValues[6] = 1078340
SettingsWindow.NUM_DELAY_VALUES = 6

SettingsWindow.ObjectHandles = {}
SettingsWindow.ObjectHandles[1] = { id= SystemData.Settings.ObjectHandleFilter.eDynamicFilter, tid = 1079457}
SettingsWindow.ObjectHandles[2] = { id= SystemData.Settings.ObjectHandleFilter.eCorpseFilter, tid = 1078368}
SettingsWindow.ObjectHandles[3] = { id= SystemData.Settings.ObjectHandleFilter.eNPCFilter, tid = 1079458}
SettingsWindow.ObjectHandles[4] = { id= SystemData.Settings.ObjectHandleFilter.eNPCVendorFilter, tid = 1079459}
SettingsWindow.ObjectHandles[5] = { id= SystemData.Settings.ObjectHandleFilter.eMobileFilter, tid = 1075672}
SettingsWindow.NUM_OBJHANDLE_FILTERS = 5

SettingsWindow.ObjectHandleSizes = {50, 100, 200, 300, -1}


SettingsWindow.Keybindings = {}
SettingsWindow.Keybindings[1] = { name="MoveUp", tid=1077791, type="FORWARD" }
SettingsWindow.Keybindings[2] = { name="MoveDown", tid=1077792 , type="BACKWARD" }
SettingsWindow.Keybindings[3] = { name="MoveLeft", tid=1077793 , type="LEFT" }
SettingsWindow.Keybindings[4] = { name="MoveRight", tid=1077794 ,type="RIGHT" }
SettingsWindow.Keybindings[5] = { name="CharacterWin", tid=1077795 , type="PAPERDOLL_CHARACTER_WINDOW" }
SettingsWindow.Keybindings[6] = { name="BackpackWin", tid=1077796 , type="BACKPACK_WINDOW" }
SettingsWindow.Keybindings[7] = { name="SkillsWin", tid=1078992 , type="SKILLS_WINDOW" }
SettingsWindow.Keybindings[8] = { name="ToggleMap", tid=1078993 , type="WORLD_MAP_WINDOW" }
SettingsWindow.Keybindings[9] = { name="QuestLogWin", tid=1077799 , type="QUEST_LOG_WINDOW" }
--SettingsWindow.Keybindings[10] = { name="Cancel", tid=1077800 , type="CANCEL" }
SettingsWindow.Keybindings[10] = { name="TargetSelf", tid=1077801 , type="TARGET_SELF" }
SettingsWindow.Keybindings[11] = { name="TargetG1", tid=1077802 , type="TARGET_GROUP_MEMBER_1" }
SettingsWindow.Keybindings[12] = { name="TargetG2", tid=1077803 , type="TARGET_GROUP_MEMBER_2" }
SettingsWindow.Keybindings[13] = { name="TargetG3", tid=1077804 , type="TARGET_GROUP_MEMBER_3" }
SettingsWindow.Keybindings[14] = { name="TargetG4", tid=1077805 , type="TARGET_GROUP_MEMBER_4" }
SettingsWindow.Keybindings[15] = { name="TargetG5", tid=1077806 , type="TARGET_GROUP_MEMBER_5" }
SettingsWindow.Keybindings[16] = { name="TargetG6", tid=1079147 , type="TARGET_GROUP_MEMBER_6" }
SettingsWindow.Keybindings[17] = { name="TargetG7", tid=1079148 , type="TARGET_GROUP_MEMBER_7" }
SettingsWindow.Keybindings[18] = { name="TargetG8", tid=1079149 , type="TARGET_GROUP_MEMBER_8" }
SettingsWindow.Keybindings[19] = { name="TargetG9", tid=1079150 , type="TARGET_GROUP_MEMBER_9" }
SettingsWindow.Keybindings[20] = { name="NextEnemy", tid=1077807 , type="NEXT_ENEMY_TARGET" }
--SettingsWindow.Keybindings[18] = { name="PrevEnemy", tid=1077808 , type="PREVIOUS_ENEMY_TARGET" }
SettingsWindow.Keybindings[21] = { name="NextFriend", tid=1077809 , type="NEXT_FRIENDLY_TARGET" }
--SettingsWindow.Keybindings[20] = { name="PrevFriend", tid=1077810 , type="PREVIOUS_FRIENDLY_TARGET" }
SettingsWindow.Keybindings[22] = { name="NearestEnemy", tid=1077811 , type="NEAREST_ENEMY_TARGET" }
SettingsWindow.Keybindings[23] = { name="NearestFriend", tid=1077812 , type="NEAREST_FRIENDLY_TARGET" }
SettingsWindow.Keybindings[24] = { name="AttackMode", tid=1077813 , type="MELEE_ATTACK" }
SettingsWindow.Keybindings[25] = { name="BugReportScreen", tid=1079151 , type="BUG_REPORT_SCREEN" }
SettingsWindow.Keybindings[26] = { name="UserPreference", tid=1079152 , type="USER_PREFERENCE" }
SettingsWindow.Keybindings[27] = { name="PrimaryAttack", tid=1079153 , type="USE_PRIMARY_ATTACK" }
SettingsWindow.Keybindings[28] = { name="SecondaryAttack", tid=1079154 , type="USE_SECONDARY_ATTACK" }
SettingsWindow.Keybindings[29] = { name="NextGroupTarget", tid=1079155 , type="NEXT_GROUP_TARGET" }
SettingsWindow.Keybindings[30] = { name="ZoomIn", tid=1079288 , type="ZOOM_IN" }
SettingsWindow.Keybindings[31] = { name="ZoomOut", tid=1079289 , type="ZOOM_OUT" }
SettingsWindow.Keybindings[32] = { name="ZoomReset", tid=1079290 , type="ZOOM_RESET" }

SettingsWindow.TID = {UserSetting= 1077814, Graphics=1077815 , KeyBindings=1077816, Options=1015326, Resolution=1077817,
					 WindowRes=1077818, FullRes=1077819, ShowFrame=1077820, UseFull=1077821, EnableSound=1077823 , SoundVol=1077822,
					 Language=1077824, Okay=3000093 , Apply=3000090 , Reset=1077825, Cancel=1006045, Quarter=1078023, Full=1074240,
					 FlexibleDesktop=1078024, Sound=3000390, Interface=3000395, PlayFootsteps=1078077,
					 Pathfinding=3000064, AlwaysRun=1078078, Movie=3000190, ObjectHandles=1062947, CircleOfTransparency=1078079,
					 QueryBeforeCriminalActions=1078080, FilterObscenity=3000460, ChatWindowFadeDelay=1078082, ChatTextFadeDelay=1079291, OverheadChatFadeDelay=1078084,
					 OverheadChat=1078083, Tooltips=1078085, TooltipDelay=1078086, PlayerNameColors=1078087, None=1011051, Approaching=1078090,
					 All=1078091 , ShowNames=1078093, Filter=3000173, IgnorePlayers=3000462, MusicVolume=1078578, EnableMusic=1078577, Animation=1079368,
					 EffectsVolume=1078576, EnableEffects=1078575, AlwaysAttack=1078858, ShowStrLabel=1079171, LegacyChat=1079172, PlayIdleAnimation = 1079367,
					 UiScale=1079205, EnableUiScale=1079206, MobAnimCache=1079207, DiskCache=1079480, MinFreeSystemMemory=1079481, Gamma=3000166, ParticleLOD=1079213 , ShowShadows=1079286, ShowChatWindow=1079299, Bindings=1079337, }
					 
SettingsWindow.MobAnimCacheMin = 8
SettingsWindow.MobAnimCacheMax = 128
SettingsWindow.DiskCacheMin = 20
SettingsWindow.DiskCacheMax = 256
SettingsWindow.MinFreeSystemMemoryMin = 1
SettingsWindow.MinFreeSystemMemoryMax = 128

SettingsWindow.MobAnimCacheRange = SettingsWindow.MobAnimCacheMax - SettingsWindow.MobAnimCacheMin
SettingsWindow.DiskCacheRange = SettingsWindow.DiskCacheMax - SettingsWindow.DiskCacheMin
SettingsWindow.MinFreeSystemMemoryRange = SettingsWindow.MinFreeSystemMemoryMax - SettingsWindow.MinFreeSystemMemoryMin

					 
SettingsWindow.TID_BINDING_CONFLICT_TITLE = 1079169
SettingsWindow.TID_BINDING_CONFLICT_BODY = 1079170
SettingsWindow.TID_YES = 1049717
SettingsWindow.TID_NO = 1049718
SettingsWindow.TID_INFO = 1011233
SettingsWindow.TID_RESETLEGACYBINDINGS = 1079400

SettingsWindow.TID_DETAILS = { 1079210, 1079211, 1079212 }

SettingsWindow.TID_ANIMATION = {1079369, 1079370, 1079371, 1079372}

SettingsWindow.RecordingKey = false

SettingsWindow.PreviousBadWordCount = 0
SettingsWindow.PreviousIgnoreListCount = 0
SettingsWindow.CurIgnoreListIdx = -1

--SettingsWindow.ENABLE_CUSTOM_SKINS = false -- enable this element? search for this tag to find all uses of this element also!
--SettingsWindow.TID_CUSTOM_SKINS_TEXT = 1011012 -- "Cancel" (placeholder) -- Label on the right of the combo box
--SettingsWindow.CustomSkins = {} -- table containing data for the different skins, may need to be initalized before use
--SettingsWindow.CustomSkins[1] = { tid = 3006115, id=1 } -- "Resign (placeholder) -- Fist listed element in combo box
--SettingsWindow.CustomSkins[2] = { tid = 1078056, id=2 } -- "MORE" (placeholder)
--SettingsWindow.CustomSkins[3] = { tid = 1011011, id=3 } -- "CONTINUE" (placeholder) -- Last listed element in combo box

----------------------------------------------------------------
-- LoginWindow Functions
----------------------------------------------------------------

-- OnInitialize Handler()
function SettingsWindow.Initialize()
	
	Interface.OnCloseCallBack["SettingsWindow"] = SettingsWindow.OnCancelButton
	
	WindowRegisterEventHandler( "Root", SystemData.Events.PROFANITYLIST_UPDATED, "SettingsWindow.ProfanityListUpdated")
	
    WindowUtils.SetWindowTitle("SettingsWindow", GetStringFromTid(SettingsWindow.TID.UserSetting) )

	-- Tab Buttons
	ButtonSetText( "SettingsWindowGraphicsTabButton", GetStringFromTid(SettingsWindow.TID.Graphics ) )
	ButtonSetText( "SettingsWindowKeyBindingsTabButton", GetStringFromTid(SettingsWindow.TID.Bindings ) )
--	ButtonSetText( "SettingsWindowKeyBindingsTabButton", GetStringFromTid(SettingsWindow.TID.KeyBindings ) )
	ButtonSetText( "SettingsWindowOptionsTabButton", GetStringFromTid(SettingsWindow.TID.Options ) )
	ButtonSetText( "SettingsWindowSoundTabButton", GetStringFromTid(SettingsWindow.TID.Sound ) )
	ButtonSetText( "SettingsWindowInterfaceTabButton", GetStringFromTid(SettingsWindow.TID.Interface ) )
	ButtonSetText( "SettingsWindowProfanityTabButton", GetStringFromTid(SettingsWindow.TID.Filter ) )
	
	ButtonSetStayDownFlag( "SettingsWindowGraphicsTabButton", true )
	ButtonSetStayDownFlag( "SettingsWindowKeyBindingsTabButton", true )
	ButtonSetStayDownFlag( "SettingsWindowOptionsTabButton", true )
	
	-- Start with graphics window open
	SettingsWindow.OpenGraphicsTab()
	-- Call the function to do it, don't try yourself!
	--SettingsWindow.ClearTabStates()
	--ButtonSetPressedFlag( "SettingsWindowGraphicsTabButton", true )	
	--WindowSetShowing( "SettingsGraphicsWindow",  true )
	
	-- Resolution
--	LabelSetText( "SettingsResolutionTitle", GetStringFromTid(SettingsWindow.TID.Resolution ) ) -- This label has been removed
	LabelSetText( "SettingsResolutionFullScreenResLabel", GetStringFromTid(SettingsWindow.TID.FullRes ) )
	LabelSetText( "SettingsResolutionShowFrameLabel", GetStringFromTid(SettingsWindow.TID.ShowFrame))
	ButtonSetCheckButtonFlag( "SettingsResolutionShowFrameButton", true )
	LabelSetText( "SettingsResolutionShowShadowsLabel", GetStringFromTid(SettingsWindow.TID.ShowShadows))
	ButtonSetCheckButtonFlag( "SettingsResolutionShowShadowsButton", true )
	LabelSetText( "SettingsResolutionUseFullscreenLabel", GetStringFromTid(SettingsWindow.TID.UseFull ) )
	ButtonSetCheckButtonFlag( "SettingsResolutionUseFullscreenButton", true )
	LabelSetText( "SettingsResolutionPlayIdleAnimationLabel", GetStringFromTid(SettingsWindow.TID.PlayIdleAnimation))
	ButtonSetCheckButtonFlag( "SettingsResolutionPlayIdleAnimationButton", true )
	
	LabelSetText( "GammaText", GetStringFromTid(SettingsWindow.TID.Gamma ) )
	LabelSetText( "MobAnimCacheText", GetStringFromTid(SettingsWindow.TID.MobAnimCache) )	
	LabelSetText( "DiskCacheText", GetStringFromTid(SettingsWindow.TID.DiskCache) )	
	LabelSetText( "MinFreeSystemMemoryText", GetStringFromTid(SettingsWindow.TID.MinFreeSystemMemory) )	
	
	
	for res = 1, table.getn(SystemData.AvailableResolutions.widths) do
	    ComboBoxAddMenuItem( "SettingsResolutionFullScreenResCombo", L""..SystemData.AvailableResolutions.widths[res]..L" x "..SystemData.AvailableResolutions.heights[res] )
	end
	
	for key = 1, table.getn(SettingsWindow.Keybindings) do
		LabelSetText( "SettingsKeyBindings"..SettingsWindow.Keybindings[key].name.."Action", GetStringFromTid(SettingsWindow.Keybindings[key].tid) )
	end	

    LabelSetText( "SettingsResolutionViewportLabel",  GetStringFromTid(SettingsWindow.TID.FlexibleDesktop))
    ButtonSetStayDownFlag( "SettingsResolutionViewportButton", true )
	ButtonSetCheckButtonFlag ( "SettingsResolutionViewportButton", true )

    LabelSetText( "SettingsResolutionParticleLODLabel", GetStringFromTid(SettingsWindow.TID.ParticleLOD))
	for index, tid in ipairs(SettingsWindow.TID_DETAILS) do
		ComboBoxAddMenuItem( "SettingsResolutionParticleLODCombo", GetStringFromTid(tid) )
	end

	LabelSetText( "SettingsResolutionAnimationLabel", GetStringFromTid(SettingsWindow.TID.Animation))
	for index, tid in ipairs(SettingsWindow.TID_ANIMATION) do
		ComboBoxAddMenuItem( "SettingsResolutionAnimationCombo", GetStringFromTid(tid) )
	end

	-- Key Binding
	--"UOKR setup"
	LabelSetText("SettingsKeyDefaultWindowDefaultKeysName", GetStringFromTid(1079162))
	--"Legacy setup"
	LabelSetText("SettingsKeyDefaultWindowLegacyKeysName", GetStringFromTid(1079163))

	-- Sound
	
	-- MASTER VOLUME
    ButtonSetStayDownFlag( "MasterVolumeToggleButton", true )
    ButtonSetCheckButtonFlag( "MasterVolumeToggleButton", true )
        
    LabelSetText( "MasterVolumeText",  GetStringFromTid(SettingsWindow.TID.SoundVol) )
    LabelSetText( "MasterVolumeVal", L""..(math.floor(SystemData.Settings.Sound.master.volume*100)) )
    LabelSetText( "MasterVolumeToggleLabel",  GetStringFromTid(SettingsWindow.TID.EnableSound) )
    
	-- EFFECTS VOLUME
    --Debug.Print("EFFECTS VOLUME = "..SystemData.Settings.Sound.effects.volume)
    ButtonSetStayDownFlag( "EffectsVolumeToggleButton", true )
    ButtonSetCheckButtonFlag( "EffectsVolumeToggleButton", true )
    
    LabelSetText( "EffectsVolumeText", GetStringFromTid(SettingsWindow.TID.EffectsVolume) )
    LabelSetText( "EffectsVolumeVal", L""..(math.floor(SystemData.Settings.Sound.effects.volume*100)) )
    LabelSetText( "EffectsVolumeToggleLabel", GetStringFromTid(SettingsWindow.TID.EnableEffects))
    
	-- MUSIC VOLUME
    --Debug.Print("MUSIC VOLUME = "..SystemData.Settings.Sound.music.volume)
    ButtonSetStayDownFlag( "MusicVolumeToggleButton", true )
    ButtonSetCheckButtonFlag( "MusicVolumeToggleButton", true )
    
	LabelSetText( "MusicVolumeText", GetStringFromTid(SettingsWindow.TID.MusicVolume) )
    LabelSetText( "MusicVolumeVal", L""..(math.floor(SystemData.Settings.Sound.music.volume*100)) )
    LabelSetText( "MusicVolumeToggleLabel", GetStringFromTid(SettingsWindow.TID.EnableMusic) )

    ButtonSetStayDownFlag( "PlayFootstepsToggleButton", true )
    ButtonSetCheckButtonFlag( "PlayFootstepsToggleButton", true )
	LabelSetText( "PlayFootstepsToggleLabel", GetStringFromTid(SettingsWindow.TID.PlayFootsteps))
	
	--Temporarily disable slider bar for effects and music
	WindowSetShowing("EffectsVolumeText", false)
	WindowSetShowing("EffectsVolumeVal", false)
	WindowSetShowing("EffectsVolumeSliderBar", false)
	WindowSetShowing("MusicVolumeText", false)
	WindowSetShowing("MusicVolumeVal", false)
	WindowSetShowing("MusicVolumeSliderBar", false)
	

	-- Language
	LabelSetText( "SettingsOptionsLanguageLabel", GetStringFromTid(SettingsWindow.TID.Language) )
	
	for lan = 1, SettingsWindow.NUM_LANGUAGES do
		local text = GetStringFromTid(SettingsWindow.Languages[lan].tid)
		ComboBoxAddMenuItem( "SettingsOptionsLanguageCombo", L""..text )
	end
	
	ButtonSetText( "SettingsWindowOkayButton", GetStringFromTid(SettingsWindow.TID.Okay ) )
	ButtonSetText( "SettingsWindowApplyButton", GetStringFromTid(SettingsWindow.TID.Apply) )
	ButtonSetText( "SettingsWindowResetButton", GetStringFromTid(SettingsWindow.TID.Reset ) )
	ButtonSetText( "SettingsWindowCancelButton", GetStringFromTid(SettingsWindow.TID.Cancel ) )
	
	-- Options
--	LabelSetText( "SettingsOptionsTitle", GetStringFromTid(SettingsWindow.TID.Options ) )
--	LabelSetText( "PathfindingLabel", GetStringFromTid(SettingsWindow.TID.Pathfinding ) )
	LabelSetText( "AlwaysRunLabel", GetStringFromTid(SettingsWindow.TID.AlwaysRun ) )
--	LabelSetText( "MovieLabel", GetStringFromTid(SettingsWindow.TID.Movie ) )
	LabelSetText( "ShowNamesLabel", GetStringFromTid(SettingsWindow.TID.ShowNames ) )
	LabelSetText( "ShowAllNamesLabel", GetStringFromTid(SettingsWindow.TID.All ) )
	LabelSetText( "ShowApproachingNamesLabel", GetStringFromTid(SettingsWindow.TID.Approaching ) )
	LabelSetText( "ShowNoNamesLabel", GetStringFromTid(SettingsWindow.TID.None ) )
	LabelSetText( "CircleOfTransparencyLabel", GetStringFromTid(SettingsWindow.TID.CircleOfTransparency ) )
	LabelSetText( "QueryBeforeCriminalActionsLabel", GetStringFromTid(SettingsWindow.TID.QueryBeforeCriminalActions ) )
--	LabelSetText( "ObjectHandlesLabel", GetStringFromTid(SettingsWindow.TID.ObjectHandles ) )
	LabelSetText( "AlwaysAttackLabel", GetStringFromTid(SettingsWindow.TID.AlwaysAttack ) )
	LabelSetText( "ShowStrLabelLabel", GetStringFromTid(SettingsWindow.TID.ShowStrLabel ) )
	
	-- CUSTOM UI COMBOBOX
	LabelSetText( "CustomSkinsLabel", GetStringFromTid(1079523) ) -- "Use Custom UI:"
	local skinItr
	for skinItr = 1, #SystemData.CustomUIList do
		local text = SystemData.CustomUIList[skinItr]
		if text == "" then
			ComboBoxAddMenuItem( "CustomSkinsCombo", GetStringFromTid(3000094) ) -- "Default"
		else
			ComboBoxAddMenuItem( "CustomSkinsCombo", StringToWString(text) )
		end
	end
	
	ButtonSetStayDownFlag( "AlwaysRunButton", true )
	ButtonSetCheckButtonFlag ( "AlwaysRunButton", true )

	ButtonSetStayDownFlag( "CircleOfTransparencyButton", true )
	ButtonSetCheckButtonFlag("CircleOfTransparencyButton", true)
	
	ButtonSetStayDownFlag( "QueryBeforeCriminalActionsButton", true )
	ButtonSetCheckButtonFlag("QueryBeforeCriminalActionsButton", true)
    	
	ButtonSetStayDownFlag( "AlwaysAttackButton", true )
	ButtonSetCheckButtonFlag("AlwaysAttackButton", true)

	ButtonSetStayDownFlag( "ShowStrLabelButton", true )
	ButtonSetCheckButtonFlag("ShowStrLabelButton", true)
	
	-- Object Handle Filter
	--" Object Handle Filter"
	LabelSetText( "SettingsOptionsObjHandleFilterLabel", L""..GetStringFromTid(1079461) )
	
	local filter
	for filter = 1, SettingsWindow.NUM_OBJHANDLE_FILTERS do
		local text = GetStringFromTid(SettingsWindow.ObjectHandles[filter].tid)
		ComboBoxAddMenuItem( "SettingsOptionsObjHandleFilterCombo", L""..text )
	end
	
	-- Object Handle Size
	-- "Amount Shown"
	LabelSetText( "SettingsOptionsObjHandleSizeLabel", L""..GetStringFromTid(1079460) )
	
	local indexSize
	local objHandleSize
	for indexSize, objHandleSize in pairs (SettingsWindow.ObjectHandleSizes) do
		-- (-1) is considered max size
		local text = SettingsWindow.ObjectHandleSizes[indexSize]
		if( objHandleSize == -1 ) then
			text = GetStringFromTid(1077866) -- "All"
		end
		ComboBoxAddMenuItem( "SettingsOptionsObjHandleSizeCombo", L""..text )
	end
	
	-- Interface
    ButtonSetStayDownFlag( "UiScaleToggleButton", true )
    ButtonSetCheckButtonFlag( "UiScaleToggleButton", true )	
    LabelSetText( "UiScaleToggleLabel", GetStringFromTid(SettingsWindow.TID.EnableUiScale ) )
    LabelSetText( "UiScaleText", GetStringFromTid(SettingsWindow.TID.UiScale ) )
	
	LabelSetText( "ShowChatWindowLabel", GetStringFromTid(SettingsWindow.TID.ShowChatWindow) )
	ButtonSetStayDownFlag( "ShowChatWindowButton", true )
	ButtonSetCheckButtonFlag("ShowChatWindowButton", true)

	LabelSetText( "ChatWindowFadeDelayLabel", GetStringFromTid(SettingsWindow.TID.ChatWindowFadeDelay ) )
	for delay = 1, SettingsWindow.NUM_DELAY_VALUES do
		local text = GetStringFromTid(SettingsWindow.DelayValues[delay])
	   	ComboBoxAddMenuItem( "ChatWindowFadeDelayCombo", L""..text )
	end

	LabelSetText( "ChatTextFadeDelayLabel", GetStringFromTid(SettingsWindow.TID.ChatTextFadeDelay ) )
	for delay = 1, SettingsWindow.NUM_DELAY_VALUES do
		local text = GetStringFromTid(SettingsWindow.DelayValues[delay])
	   	ComboBoxAddMenuItem( "ChatTextFadeDelayCombo", L""..text )
	end

	LabelSetText( "OverheadChatLabel", GetStringFromTid(SettingsWindow.TID.OverheadChat ) )
	ButtonSetStayDownFlag( "OverheadChatButton", true )
	ButtonSetCheckButtonFlag("OverheadChatButton", true)

	LabelSetText( "OverheadChatFadeDelayLabel", GetStringFromTid(SettingsWindow.TID.OverheadChatFadeDelay ) )
	for delay = 1, SettingsWindow.NUM_DELAY_VALUES do
		local text = GetStringFromTid(SettingsWindow.DelayValues[delay])
	   	ComboBoxAddMenuItem( "OverheadChatFadeDelayCombo", L""..text )
	end

	LabelSetText( "TooltipsLabel", GetStringFromTid(SettingsWindow.TID.Tooltips ) )
--	LabelSetText( "TooltipDelayLabel", GetStringFromTid(SettingsWindow.TID.TooltipDelay ) )
	
	LabelSetText ("LegacyChatLabel", GetStringFromTid(SettingsWindow.TID.LegacyChat ) )
	ButtonSetStayDownFlag( "LegacyChatButton", true )
	ButtonSetCheckButtonFlag("LegacyChatButton", true)

	ButtonSetStayDownFlag( "TooltipsButton", true )
	ButtonSetCheckButtonFlag("TooltipsButton", true)
		
	SettingsWindow.UpdateSettings()
			
    -- Update the scroll window
	ScrollWindowSetOffset( "SettingsGraphicsWindow", 0 )
	ScrollWindowUpdateScrollRect( "SettingsGraphicsWindow" )
	ScrollWindowSetOffset( "SettingsKeyBindingsWindow", 0 )
	ScrollWindowUpdateScrollRect( "SettingsKeyBindingsWindow" )
	ScrollWindowSetOffset( "SettingsSoundWindow", 0 )
	ScrollWindowUpdateScrollRect( "SettingsSoundWindow" )
	ScrollWindowSetOffset( "SettingsOptionsWindow", 0 )
	ScrollWindowUpdateScrollRect( "SettingsOptionsWindow" )
	ScrollWindowSetOffset( "SettingsInterfaceWindow", 0 )
	ScrollWindowUpdateScrollRect( "SettingsInterfaceWindow" )
	
	-- Call backs
	WindowRegisterEventHandler("SettingsWindow", SystemData.Events.USER_SETTINGS_UPDATED, "SettingsWindow.UpdateSettings" )
	WindowRegisterEventHandler("SettingsWindow", SystemData.Events.INTERFACE_KEY_RECORDED, "SettingsWindow.KeyRecorded" )
	WindowRegisterEventHandler("SettingsWindow", SystemData.Events.TOGGLE_USER_PREFERENCE, "SettingsWindow.ToggleSettingsWindow" )
	
	-- profanity
	LabelSetText( "BadWordFilterOptionLabel", GetStringFromTid(SettingsWindow.TID.FilterObscenity ) )
	ButtonSetStayDownFlag( "BadWordFilterOptionButton", true )
	ButtonSetCheckButtonFlag ( "BadWordFilterOptionButton", true )

	LabelSetText( "IgnoreListOptionLabel", GetStringFromTid(SettingsWindow.TID.IgnorePlayers ) )
	ButtonSetStayDownFlag( "IgnoreListOptionButton", true )
	ButtonSetCheckButtonFlag ( "IgnoreListOptionButton", true )

	ButtonSetText( "IgnoreListAddButton", L"Add" )
	ButtonSetText( "IgnoreListDeleteButton", L"Delete" )

	SettingsWindow.PopulateProfanityList()

	-- THESE ELEMENTS ARE NOT READY FOR THIS MILESTONE 3/23/2007. RESTORE THE FOLLOWING LINES AS THEY BECOME AVAILABLE!
	-- YOU WILL ALSO HAVE TO UNCOMMENT AND RE-ANCHOR THINGS IN THE XML!
	-- And you'll also need to restore the commeneted out LabelSetText functions for them
--    WindowSetShowing("Pathfinding", false)
--    WindowSetShowing("Movie", false)
--    WindowSetShowing("ObjectHandles", false)
--    WindowSetShowing("ChatWindowFadeDelaySliderBar", false)
--    WindowSetShowing("OverheadChatFadeDelaySliderBar", false)
--    WindowSetShowing("TooltipDelayLabel", false)
--    WindowSetShowing("TooltipDelayDelaySliderBar", false)
	
end

function SettingsWindow.ToggleSettingsWindow()	
	ToggleWindowByName( "SettingsWindow", "", MainMenuWindow.ToggleSettingsWindow )	
end

function SettingsWindow.UpdateSoundSettings()
    --Debug.PrintToDebugConsole(L"SettingsWindow.UpdateSoundSettings()!")
    local masterVolume = math.floor(100 * SliderBarGetCurrentPosition("MasterVolumeSliderBar"))
    local effectsVolume = math.floor(100 * SliderBarGetCurrentPosition("EffectsVolumeSliderBar"))
    local musicVolume = math.floor(100 * SliderBarGetCurrentPosition("MusicVolumeSliderBar"))

    LabelSetText( "MasterVolumeVal", L""..masterVolume)
    LabelSetText( "EffectsVolumeVal", L""..effectsVolume)
    LabelSetText( "MusicVolumeVal", L""..musicVolume)
    
    -- using the same template for ui scale so update it in here
    local uiScale = (SliderBarGetCurrentPosition("UiScaleSliderBar")/2) + 0.5
    LabelSetText( "UiScaleVal", wstring.format(L"%2.2f",uiScale) )
end

function SettingsWindow.UpdateSettings()
    
    --Debug.Print("SettingsWindow.UpdateSettings")
    
    local text
    
    -- Resolution
    
	for res = 1, table.getn(SystemData.AvailableResolutions.widths) do    
        if( SystemData.Settings.Resolution.fullScreen.width == SystemData.AvailableResolutions.widths[res] and 
            SystemData.Settings.Resolution.fullScreen.height == SystemData.AvailableResolutions.heights[res]) then
            ComboBoxSetSelectedMenuItem( "SettingsResolutionFullScreenResCombo", res )    
        end       
	end
	
	ComboBoxSetSelectedMenuItem( "SettingsResolutionParticleLODCombo", SystemData.Settings.Resolution.particleLOD )
	ComboBoxSetSelectedMenuItem( "SettingsResolutionAnimationCombo", SystemData.Settings.Optimization.frameSetRestriction+1 )
	
	ButtonSetPressedFlag( "SettingsResolutionViewportButton", SystemData.Settings.Resolution.viewportEnabled)
    ButtonSetPressedFlag( "SettingsResolutionShowFrameButton", SystemData.Settings.Resolution.showWindowFrame )
    ButtonSetPressedFlag( "SettingsResolutionShowShadowsButton", SystemData.Settings.Resolution.showShadows )
    ButtonSetPressedFlag( "SettingsResolutionUseFullscreenButton", SystemData.Settings.Resolution.useFullScreen )
    ButtonSetPressedFlag( "SettingsResolutionPlayIdleAnimationButton", SystemData.Settings.Optimization.idleAnimation )
    
    SliderBarSetCurrentPosition("GammaSliderBar",SystemData.Settings.Resolution.gamma)
    LabelSetText( "GammaVal", wstring.format(L"%2.2f",SystemData.Settings.Resolution.gamma) )
 
    SliderBarSetCurrentPosition("MobAnimCacheSliderBar",(SystemData.Settings.Resolution.mobAnimCache - SettingsWindow.MobAnimCacheMin)/SettingsWindow.MobAnimCacheRange)
    LabelSetText( "MobAnimCacheVal", L""..SystemData.Settings.Resolution.mobAnimCache )
    SliderBarSetCurrentPosition("DiskCacheSliderBar",(SystemData.Settings.Resolution.diskCache - SettingsWindow.DiskCacheMin)/SettingsWindow.DiskCacheRange)
    LabelSetText( "DiskCacheVal", L""..SystemData.Settings.Resolution.diskCache )
    SliderBarSetCurrentPosition("MinFreeSystemMemorySliderBar",(SystemData.Settings.Resolution.minFreeSystemMemory - SettingsWindow.MinFreeSystemMemoryMin)/SettingsWindow.MinFreeSystemMemoryRange)
    LabelSetText( "MinFreeSystemMemoryVal", L""..SystemData.Settings.Resolution.minFreeSystemMemory )
    
    --Language
	for lan = 1, SettingsWindow.NUM_LANGUAGES do    
		if( SystemData.Settings.Language.type == SettingsWindow.Languages[lan].id) then
			ComboBoxSetSelectedMenuItem( "SettingsOptionsLanguageCombo", lan )
		end
	end

	local filter
	for filter = 1, SettingsWindow.NUM_OBJHANDLE_FILTERS do
		if( SystemData.Settings.GameOptions.objectHandleFilter == SettingsWindow.ObjectHandles[filter].id) then
			ComboBoxSetSelectedMenuItem("SettingsOptionsObjHandleFilterCombo", filter )
		end
	end

	local skinItr
	for skinItr = 1, #SystemData.CustomUIList do
		if( SystemData.Settings.Interface.customUiName == SystemData.CustomUIList[skinItr] ) then
			ComboBoxSetSelectedMenuItem("CustomSkinsCombo", skinItr )
		end
	end
	
	local indexSize
	local objHandleSize
	for indexSize, objHandleSize in pairs (SettingsWindow.ObjectHandleSizes) do
		if( SystemData.Settings.GameOptions.objectHandleSize == objHandleSize) then
			ComboBoxSetSelectedMenuItem( "SettingsOptionsObjHandleSizeCombo", indexSize )
		end
	end
	
    if( SystemData.Settings.Interface.ChatWindowFadeDelay ~= nil ) then
	    ComboBoxSetSelectedMenuItem( "ChatWindowFadeDelayCombo", SystemData.Settings.Interface.ChatWindowFadeDelay )
	end
    if( SystemData.Settings.Interface.ChatTextFadeDelay ~= nil ) then
	    ComboBoxSetSelectedMenuItem( "ChatTextFadeDelayCombo", SystemData.Settings.Interface.ChatTextFadeDelay )
	end
	if( SystemData.Settings.Interface.OverheadChatFadeDelay ~= nil ) then
	    ComboBoxSetSelectedMenuItem( "OverheadChatFadeDelayCombo", SystemData.Settings.Interface.OverheadChatFadeDelay )
	end
	
    ButtonSetPressedFlag("UiScaleToggleButton", SystemData.Settings.Interface.customUiScaleEnabled)  
	SliderBarSetCurrentPosition( "UiScaleSliderBar", ((SystemData.Settings.Interface.customUiScale - 0.5)*2 ) )
	LabelSetText( "UiScaleVal", wstring.format(L"%2.2f",SystemData.Settings.Interface.customUiScale) )
    
    ButtonSetPressedFlag("BadWordFilterOptionButton", SystemData.Settings.Profanity.BadWordFilter)
	ButtonSetPressedFlag("IgnoreListOptionButton", SystemData.Settings.Profanity.IgnoreListFilter)
    
    ButtonSetPressedFlag("AlwaysRunButton", SystemData.Settings.GameOptions.alwaysRun)	
	ButtonSetPressedFlag("CircleOfTransparencyButton", SystemData.Settings.GameOptions.circleOfTransEnabled)
	ButtonSetPressedFlag("QueryBeforeCriminalActionsButton", SystemData.Settings.GameOptions.queryBeforeCriminalAction)	
	ButtonSetPressedFlag("AlwaysAttackButton", SystemData.Settings.GameOptions.alwaysAttack)
	ButtonSetPressedFlag("TooltipsButton", SystemData.Settings.Interface.showTooltips)
	ButtonSetPressedFlag("ShowStrLabelButton", SystemData.Settings.GameOptions.showStrLabel)
	ButtonSetPressedFlag("LegacyChatButton", SystemData.Settings.Interface.LegacyChat)
	ButtonSetPressedFlag("OverheadChatButton", SystemData.Settings.Interface.OverheadChat)
	ButtonSetPressedFlag("ShowChatWindowButton", SystemData.Settings.Interface.ShowChatWindow)
	
	if (SystemData.Settings.GameOptions.showNames == SystemData.Settings.GameOptions.SHOWNAMES_ALL) then
		ButtonSetPressedFlag("ShowAllNamesButton", true)
	elseif (SystemData.Settings.GameOptions.showNames == SystemData.Settings.GameOptions.SHOWNAMES_APPROACHING) then
        ButtonSetPressedFlag("ShowApproachingNamesButton", true)
    else
        ButtonSetPressedFlag("ShowNoNamesButton", true)
    end
    
    ButtonSetPressedFlag("MasterVolumeToggleButton", SystemData.Settings.Sound.master.enabled)        
    ButtonSetPressedFlag("EffectsVolumeToggleButton", SystemData.Settings.Sound.effects.enabled)  
    ButtonSetPressedFlag("MusicVolumeToggleButton", SystemData.Settings.Sound.music.enabled)  
    ButtonSetPressedFlag("PlayFootstepsToggleButton", SystemData.Settings.Sound.footsteps.enabled)  
    SliderBarSetCurrentPosition( "MasterVolumeSliderBar", SystemData.Settings.Sound.master.volume )    
    SliderBarSetCurrentPosition( "EffectsVolumeSliderBar", SystemData.Settings.Sound.effects.volume )    
    SliderBarSetCurrentPosition( "MusicVolumeSliderBar", SystemData.Settings.Sound.music.volume )
    
	SettingsWindow.UpdateKeyBindings()
end

function SettingsWindow.UpdateKeyBindings()
	for key = 1, table.getn(SettingsWindow.Keybindings) do
		if( SettingsWindow.Keybindings[key].type ~= nil ) then
		    local value = SystemData.Settings.Keybindings[SettingsWindow.Keybindings[key].type]
		    if( SettingsWindow.Keybindings[key].newValue ~= nil ) then
		        value = SettingsWindow.Keybindings[key].newValue
		    end
			LabelSetText( "SettingsKeyBindings"..SettingsWindow.Keybindings[key].name.."ActionValue", value )
		end
	end	

end

--When the Default or Legacy Key Binding button has been selected, update the key binding to reflect the change
function SettingsWindow.OnDefaultKeyPressed()
	local buttonId = WindowGetId(WindowGetParent(SystemData.ActiveWindow.name))
	--Default Key Bindings have been selected
	if(buttonId == 1)then
		SettingsWindow.ResetDefaultKeyBindings()
		return
	end
	--Legacy Key Bindings have been selected
	if(buttonId == 2)then
		SettingsWindow.ResetLegacyKeyBindings()
		return
	end
	
end

--Set the key bindings to KR default
function SettingsWindow.ResetDefaultKeyBindings()
	ResetDefaultKeyBinding()
	
	for key = 1, table.getn(SettingsWindow.Keybindings) do
		if( SettingsWindow.Keybindings[key].type ~= nil ) then
		    local value = SystemData.Settings.DefaultKeybindings[SettingsWindow.Keybindings[key].type]
			if( value ~= nil) then
				SettingsWindow.Keybindings[key].newValue = value
				LabelSetText( "SettingsKeyBindings"..SettingsWindow.Keybindings[key].name.."ActionValue", value )
			end
		end
	end	
end

--Set the key bindings to use the Legacy keys
function SettingsWindow.ResetLegacyKeyBindings()
	ResetLegacyKeyBinding()
	
	for key = 1, table.getn(SettingsWindow.Keybindings) do
		if( SettingsWindow.Keybindings[key].type ~= nil ) then
		    local value = SystemData.Settings.DefaultKeybindings[SettingsWindow.Keybindings[key].type]
			if( value ~= nil) then
				SettingsWindow.Keybindings[key].newValue = value
				LabelSetText( "SettingsKeyBindings"..SettingsWindow.Keybindings[key].name.."ActionValue", value )
			end
		end
	end	
end

function SettingsWindow.OnOkayButton()
    SettingsWindow.OnApplyButton()

	-- Close the window		
	ToggleWindowByName( "SettingsWindow", "", nil )
end

function SettingsWindow.ToggleShowNames()
    --Debug.PrintToDebugConsole(L"Active Window: ".. StringToWString( SystemData.ActiveWindow.name ))
    local buttonName = SystemData.ActiveWindow.name
    
    ButtonSetPressedFlag("ShowAllNamesButton", false)
    ButtonSetPressedFlag("ShowApproachingNamesButton", false)
    ButtonSetPressedFlag("ShowNoNamesButton", false)
    
    if (buttonName == "ShowAllNamesButton") then
         ButtonSetPressedFlag("ShowAllNamesButton", true)
    elseif (buttonName == "ShowApproachingNamesButton") then
        ButtonSetPressedFlag("ShowApproachingNamesButton", true)
    elseif (buttonName == "ShowNoNamesButton") then
        ButtonSetPressedFlag("ShowNoNamesButton", true)
    end
end

function SettingsWindow.OnApplyButton()

    -- Set the Options
        
    local fullScreenRes = ComboBoxGetSelectedMenuItem( "SettingsResolutionFullScreenResCombo" ) 
    SystemData.Settings.Resolution.fullScreen.width = SystemData.AvailableResolutions.widths[fullScreenRes]
    SystemData.Settings.Resolution.fullScreen.height = SystemData.AvailableResolutions.heights[fullScreenRes]
    
    SystemData.Settings.Resolution.showWindowFrame = ButtonGetPressedFlag( "SettingsResolutionShowFrameButton" )
    SystemData.Settings.Resolution.showShadows = ButtonGetPressedFlag( "SettingsResolutionShowShadowsButton" )
    SystemData.Settings.Resolution.useFullScreen = ButtonGetPressedFlag( "SettingsResolutionUseFullscreenButton" )
    SystemData.Settings.Optimization.idleAnimation = ButtonGetPressedFlag( "SettingsResolutionPlayIdleAnimationButton" )

    SystemData.Settings.Resolution.viewportEnabled = ButtonGetPressedFlag( "SettingsResolutionViewportButton" )

    SystemData.Settings.Resolution.gamma = SliderBarGetCurrentPosition( "GammaSliderBar" )
    SystemData.Settings.Resolution.mobAnimCache = (SliderBarGetCurrentPosition( "MobAnimCacheSliderBar" ) * SettingsWindow.MobAnimCacheRange) + SettingsWindow.MobAnimCacheMin
    SystemData.Settings.Resolution.diskCache = (SliderBarGetCurrentPosition( "DiskCacheSliderBar" ) * SettingsWindow.DiskCacheRange) + SettingsWindow.DiskCacheMin
    SystemData.Settings.Resolution.minFreeSysetmMemory = (SliderBarGetCurrentPosition( "MinFreeSystemMemorySliderBar" ) * SettingsWindow.MinFreeSystemMemoryRange) + SettingsWindow.MinFreeSystemMemoryMin

    SystemData.Settings.Resolution.particleLOD = ComboBoxGetSelectedMenuItem( "SettingsResolutionParticleLODCombo" ) 

    SystemData.Settings.Optimization.frameSetRestriction = ComboBoxGetSelectedMenuItem( "SettingsResolutionAnimationCombo" ) -1

	-- Language
	local languageIndex = ComboBoxGetSelectedMenuItem( "SettingsOptionsLanguageCombo" )
    SystemData.Settings.Language.type = SettingsWindow.Languages[languageIndex].id
    
    -- Sound    
    SystemData.Settings.Sound.master.enabled = ButtonGetPressedFlag( "MasterVolumeToggleButton")
    SystemData.Settings.Sound.master.volume = SliderBarGetCurrentPosition( "MasterVolumeSliderBar" )
    
    SystemData.Settings.Sound.effects.enabled = ButtonGetPressedFlag( "EffectsVolumeToggleButton" )
    SystemData.Settings.Sound.effects.volume = SliderBarGetCurrentPosition( "EffectsVolumeSliderBar" )
    
    SystemData.Settings.Sound.music.enabled = ButtonGetPressedFlag( "MusicVolumeToggleButton" )
    SystemData.Settings.Sound.music.volume = SliderBarGetCurrentPosition( "MusicVolumeSliderBar" )

    SystemData.Settings.Sound.footsteps.enabled = ButtonGetPressedFlag( "PlayFootstepsToggleButton" )
	
	--if SystemData.Settings.Sound.master.enabled then
    --Debug.Print("master enabled: ".."1")
    --else
    --Debug.Print("master enabled: ".."0")
	--end    
    
    --if SystemData.Settings.Sound.effects.enabled then
    --Debug.Print("effects enabled: ".."1")
    --else
    --Debug.Print("effects enabled: ".."0")
    --end
    
	-- Options
	SystemData.Settings.GameOptions.alwaysRun = ButtonGetPressedFlag("AlwaysRunButton")
	SystemData.Settings.GameOptions.circleOfTransEnabled = ButtonGetPressedFlag("CircleOfTransparencyButton")
	SystemData.Settings.GameOptions.queryBeforeCriminalAction = ButtonGetPressedFlag("QueryBeforeCriminalActionsButton")
	SystemData.Settings.GameOptions.alwaysAttack = ButtonGetPressedFlag("AlwaysAttackButton")
	SystemData.Settings.GameOptions.showStrLabel = ButtonGetPressedFlag("ShowStrLabelButton")

	if( ButtonGetPressedFlag("ShowAllNamesButton")) then
		SystemData.Settings.GameOptions.showNames =  SystemData.Settings.GameOptions.SHOWNAMES_ALL
	elseif (ButtonGetPressedFlag("ShowApproachingNamesButton")) then
		SystemData.Settings.GameOptions.showNames = SystemData.Settings.GameOptions.SHOWNAMES_APPROACHING
	else
		SystemData.Settings.GameOptions.showNames = SystemData.Settings.GameOptions.SHOWNAMES_NONE
	end
	
	-- Object Handle Filter
	local filterIndex = ComboBoxGetSelectedMenuItem( "SettingsOptionsObjHandleFilterCombo" )
    SystemData.Settings.GameOptions.objectHandleFilter = SettingsWindow.ObjectHandles[filterIndex].id
    
	local skinIndex = ComboBoxGetSelectedMenuItem( "CustomSkinsCombo" )
	SystemData.Settings.Interface.customUiName = SystemData.CustomUIList[skinIndex]
	
	local objHandleSize = ComboBoxGetSelectedMenuItem( "SettingsOptionsObjHandleSizeCombo" )
    SystemData.Settings.GameOptions.objectHandleSize = SettingsWindow.ObjectHandleSizes[objHandleSize]
	
	-- Interface
	SystemData.Settings.Interface.showTooltips = ButtonGetPressedFlag("TooltipsButton")
	SystemData.Settings.Interface.ShowChatWindow = ButtonGetPressedFlag("ShowChatWindowButton")

	SystemData.Settings.Interface.LegacyChat = ButtonGetPressedFlag("LegacyChatButton")
	SystemData.Settings.Interface.OverheadChat = ButtonGetPressedFlag("OverheadChatButton")
	SystemData.Settings.Interface.ChatWindowFadeDelay = ComboBoxGetSelectedMenuItem( "ChatWindowFadeDelayCombo" )
	SystemData.Settings.Interface.ChatTextFadeDelay = ComboBoxGetSelectedMenuItem( "ChatTextFadeDelayCombo" )
	SystemData.Settings.Interface.OverheadChatFadeDelay = ComboBoxGetSelectedMenuItem( "OverheadChatFadeDelayCombo" )

    -- only update the scale if necesary
    local uiScale = (SliderBarGetCurrentPosition( "UiScaleSliderBar" )/2) + 0.5
    local scaleEnabled = ButtonGetPressedFlag( "UiScaleToggleButton")    
    SystemData.Settings.Interface.customUiScaleEnabled = scaleEnabled
    SystemData.Settings.Interface.customUiScale = uiScale

	-- Profanity
	SystemData.Settings.Profanity.BadWordFilter = ButtonGetPressedFlag("BadWordFilterOptionButton")
	SystemData.Settings.Profanity.IgnoreListFilter = ButtonGetPressedFlag("IgnoreListOptionButton")
    
	for key = 1, table.getn(SettingsWindow.Keybindings) do
		if( SettingsWindow.Keybindings[key].newValue ~= nil ) then
			SystemData.Settings.Keybindings[SettingsWindow.Keybindings[key].type] = SettingsWindow.Keybindings[key].newValue
			SettingsWindow.Keybindings[key].newValue = nil
		end
	end
    
    StatusWindow.ToggleStrLabel()
    BroadcastEvent( SystemData.Events.USER_SETTINGS_CHANGED )
end

function SettingsWindow.ClearTempKeybindings()
	for key = 1, table.getn(SettingsWindow.Keybindings) do
		SettingsWindow.Keybindings[key].newValue = nil
	end
end

function SettingsWindow.OnResetButton()
    local okayButton = { textTid=UO_StandardDialog.TID_OKAY, callback=function() SettingsWindow.ClearTempKeybindings(); BroadcastEvent( SystemData.Events.RESET_SETTINGS_TO_DEFAULT ); end }
    local cancelButton = { textTid=UO_StandardDialog.TID_CANCEL }
    local ResetConfirmWindow = 
    {
        windowName = "SettingsWindow",
	    titleTid = 1078994,
		bodyTid = 1078995,
		buttons = { okayButton, cancelButton }
	}
			
    UO_StandardDialog.CreateDialog(ResetConfirmWindow)    
end

function SettingsWindow.OnCancelButton()

    -- Reload the current settings
    SettingsWindow.ClearTempKeybindings()
    SettingsWindow.UpdateSettings()
	
	-- Close the window		
	ToggleWindowByName( "SettingsWindow", "", nil )
end

function SettingsWindow.ClearTabStates()
	-- The pressed flag isn't being used for these tabs to decide color anymore
	ButtonSetPressedFlag( "SettingsWindowGraphicsTabButton", false )
	ButtonSetPressedFlag( "SettingsWindowKeyBindingsTabButton", false )
	ButtonSetPressedFlag( "SettingsWindowSoundTabButton", false )
	ButtonSetPressedFlag( "SettingsWindowOptionsTabButton", false )
	ButtonSetPressedFlag( "SettingsWindowInterfaceTabButton", false )
	ButtonSetPressedFlag( "SettingsWindowProfanityTabButton", false )
	
	ButtonSetDisabledFlag( "SettingsWindowGraphicsTabButton", false )
	ButtonSetDisabledFlag( "SettingsWindowKeyBindingsTabButton", false )
	ButtonSetDisabledFlag( "SettingsWindowSoundTabButton", false )
	ButtonSetDisabledFlag( "SettingsWindowOptionsTabButton", false )
	ButtonSetDisabledFlag( "SettingsWindowInterfaceTabButton", false )
	ButtonSetDisabledFlag( "SettingsWindowProfanityTabButton", false )
	
	WindowSetShowing( "SettingsWindowGraphicsTabButtonTab", true )
	WindowSetShowing( "SettingsWindowKeyBindingsTabButtonTab", true )
	WindowSetShowing( "SettingsWindowSoundTabButtonTab", true )
	WindowSetShowing( "SettingsWindowOptionsTabButtonTab", true )
	WindowSetShowing( "SettingsWindowInterfaceTabButtonTab", true )
	WindowSetShowing( "SettingsWindowProfanityTabButtonTab", true )
	
--	WindowSetShowing("SettingsWindowGraphicsTabButtonTab", true)
	
	for index = 1, SettingsWindow.Modes.NUM_MODES do
	    WindowSetShowing( SettingsWindow.Modes.windows[index],  false )   
	end	
end

function SettingsWindow.OpenGraphicsTab()
	SettingsWindow.ClearTabStates()
--	ButtonSetPressedFlag( "SettingsWindowGraphicsTabButton", true )
	ButtonSetDisabledFlag( "SettingsWindowGraphicsTabButton", true )
	WindowSetShowing( "SettingsWindowGraphicsTabButtonTab", false )
	WindowSetShowing( "SettingsGraphicsWindow",  true )
end

function SettingsWindow.OpenKeyBindingsTab()
	SettingsWindow.ClearTabStates()
--	ButtonSetPressedFlag( "SettingsWindowKeyBindingsTabButton", true )
	ButtonSetDisabledFlag( "SettingsWindowKeyBindingsTabButton", true )
	WindowSetShowing( "SettingsWindowKeyBindingsTabButtonTab", false )
	WindowSetShowing( "SettingsKeyBindingsWindow",  true )
	WindowSetShowing( "SettingsKeyDefaultWindow", true)
end

function SettingsWindow.OpenSoundTab()
	SettingsWindow.ClearTabStates()
--	ButtonSetPressedFlag( "SettingsWindowSoundTabButton", true )
	ButtonSetDisabledFlag( "SettingsWindowSoundTabButton", true )
	WindowSetShowing( "SettingsWindowSoundTabButtonTab", false )
	WindowSetShowing( "SettingsSoundWindow",  true )
end

function SettingsWindow.OpenOptionsTab()
	SettingsWindow.ClearTabStates()
--	ButtonSetPressedFlag( "SettingsWindowOptionsTabButton", true )
	ButtonSetDisabledFlag( "SettingsWindowOptionsTabButton", true )
	WindowSetShowing( "SettingsWindowOptionsTabButtonTab", false )
	WindowSetShowing( "SettingsOptionsWindow",  true )
end

function SettingsWindow.OpenInterfaceTab()
	SettingsWindow.ClearTabStates()
--	ButtonSetPressedFlag( "SettingsWindowInterfaceTabButton", true )
	ButtonSetDisabledFlag( "SettingsWindowInterfaceTabButton", true )
	WindowSetShowing( "SettingsWindowInterfaceTabButtonTab", false )
	WindowSetShowing( "SettingsInterfaceWindow",  true )
end

function SettingsWindow.OpenProfanityTab()
	SettingsWindow.ClearTabStates()
--	ButtonSetPressedFlag( "SettingsWindowProfanityTabButton", true )
	ButtonSetDisabledFlag( "SettingsWindowProfanityTabButton", true )
	WindowSetShowing( "SettingsWindowProfanityTabButtonTab", false )
	WindowSetShowing( "SettingsProfanityWindow",  true )
end

function SettingsWindow.OnKeyPicked()
	--Debug.PrintToDebugConsole(L"Active Window: ".. StringToWString( SystemData.ActiveWindow.name ))
	LabelSetTextColor( SystemData.ActiveWindow.name .. "Action", 250, 250, 0 )
	LabelSetTextColor( SystemData.ActiveWindow.name .. "ActionValue", 250, 250, 0 )
	
	for key = 1, table.getn(SettingsWindow.Keybindings) do
		if( SystemData.ActiveWindow.name == "SettingsKeyBindings"..SettingsWindow.Keybindings[key].name ) then
			SettingsWindow.CurKeyIndex = key
		else
			LabelSetTextColor( "SettingsKeyBindings"..SettingsWindow.Keybindings[key].name .. "Action", 255, 255, 255 )
			LabelSetTextColor( "SettingsKeyBindings"..SettingsWindow.Keybindings[key].name .. "ActionValue", 255, 255, 255 )
			--break
		end
	end
	
	WindowClearAnchors("AssignHotkeyInfo")
	WindowAddAnchor("AssignHotkeyInfo","topleft",SystemData.ActiveWindow.name.."ActionValue","bottomleft",0,-6)
	WindowSetShowing("AssignHotkeyInfo",true)	
	
	SettingsWindow.RecordingKey = true
	
	SystemData.IsRecordingSettings = true
	BroadcastEvent( SystemData.Events.INTERFACE_RECORD_KEY )
end

function SettingsWindow.KeyRecorded()	
	if( SettingsWindow.RecordingKey == true ) then
	    local key = SettingsWindow.CurKeyIndex	
	    
	    WindowSetShowing("AssignHotkeyInfo",false)
	    
	    LabelSetTextColor( "SettingsKeyBindings"..SettingsWindow.Keybindings[key].name .. "Action", 255, 255, 255 )
	    LabelSetTextColor( "SettingsKeyBindings"..SettingsWindow.Keybindings[key].name .. "ActionValue", 255, 255, 255 )	    
	
	    if( SystemData.RecordedKey ~= L"" ) then
	        for index = 1, table.getn(SettingsWindow.Keybindings) do
		        if( SettingsWindow.Keybindings[key].type ~= nil ) then
		            local value = SystemData.Settings.Keybindings[SettingsWindow.Keybindings[index].type]
		            if( SettingsWindow.Keybindings[index].newValue ~= nil ) then
		                value = SettingsWindow.Keybindings[index].newValue
		            end
    			    
			        if( value == SystemData.RecordedKey ) then
			            SystemData.BindingActionString = SystemData.BindingActionString..GetStringFromTid(SettingsWindow.Keybindings[index].tid)..L"\n"
			        end
		        end
	        end		
	    end
	
	    if( SystemData.BindingActionString ~= L"" ) then
	        body = GetStringFromTid(SettingsWindow.TID_BINDING_CONFLICT_BODY)..L"\n\n"..SystemData.BindingActionString
	        local BindingConfirmWindow =
            {
                windowName = "SettingsWindow",
	            titleTid = SettingsWindow.TID_BINDING_CONFLICT_TITLE,
		        body = body,
	        }

            UO_StandardDialog.CreateDialog(BindingConfirmWindow)
	    else	
		    SettingsWindow.Keybindings[key].newValue = SystemData.RecordedKey
		    SettingsWindow.UpdateKeyBindings()
		end
		
		SystemData.IsRecordingSettings = false
		SettingsWindow.RecordingKey = false
	end
end

function SettingsWindow.OnIgnoreListAddButton()
	StartIgnoreListAdd()

	--hide the settings window and main menu window so player can pick something on screen	
	WindowSetShowing("SettingsWindow", false)
	WindowSetShowing("MainMenuWindow", false)
end

function SettingsWindow.ProfanityListUpdated()
	--the player has picked something, show the main menu and settings window
--	WindowSetShowing("MainMenuWindow", true)
	WindowSetShowing("SettingsWindow", true)

	SettingsWindow.PopulateProfanityList()
end

function SettingsWindow.PopulateProfanityList()
	-- local previousListItem -- Is there a reason this isn't in here?

	-- don't show the bad words for now
	local b = false -- NOTE: Due to layout changes on this gump, the bad words list will need re-anchoring if you set it to display!
	if b then
		-- clear bad words
	        for i=1, SettingsWindow.PreviousBadWordCount do
	--	        Debug.PrintToDebugConsole(L"destroy BadWord"..i)
			--hide instead of destroy because destroyWindow dosen't actually destroy it, it just puts it into the destroy queue
	        	WindowSetShowing("BadWord"..i, false)
		end
		
		-- list all bad words
	        local first = true
	        SettingsWindow.PreviousBadWordCount = WindowData.BadWordListCount
	        for i=1, WindowData.BadWordListCount do
	--	    Debug.PrintToDebugConsole(L"create BadWord"..i)
	            CreateWindowFromTemplate( "BadWord"..i, "BadWord", "SettingsBadWordFilter" )
	            WindowSetShowing("BadWord"..i, true)
	            LabelSetText("BadWord"..i, L"- "..WindowData.BadWordList[i] )
	            if (first)  then
	                first = false
	                WindowAddAnchor( "BadWord"..i, "topleft", "SettingsBadWordFilter", "topleft", 80, 110)
	            else
	                WindowAddAnchor( "BadWord"..i, "bottomleft", previousListItem, "topleft", 0, 0)
	            end
	
	            previousListItem = "BadWord"..i
	        end
	end
	
	-- clear ignore list
        for i=1, SettingsWindow.PreviousIgnoreListCount do
--	        Debug.PrintToDebugConsole(L"destroy IgnoreListItem"..i)
--	        Debug.PrintToDebugConsole(LabelGetText("IgnoreListItem"..i))
		--hide instead of destroy because destroyWindow dosen't actually destroy it, it just puts it into the destroy queue
        	WindowSetShowing("IgnoreListItem"..i, false)
	end
	
	-- list all player in the ignore list
        first = true
        for i=1, WindowData.IgnoreListCount do
--	    Debug.PrintToDebugConsole(L"create IgnoreListItem"..i)
--	    Debug.PrintToDebugConsole(L""..WindowData.IgnoreIdList[i]..L" "..WindowData.IgnoreNameList[i])
            if i > SettingsWindow.PreviousIgnoreListCount then
	        CreateWindowFromTemplate( "IgnoreListItem"..i, "IgnoreListItem", "SettingsBadWordFilter" )
	    else
	        WindowClearAnchors( "IgnoreListItem"..i )
	    end
            WindowSetShowing("IgnoreListItem"..i, true)
            LabelSetText("IgnoreListItem"..i, L"- "..WindowData.IgnoreNameList[i] )
            if (first)  then
                first = false
                WindowAddAnchor( "IgnoreListItem"..i, "bottomleft", "IgnoreListAddButton", "topleft", 0, 10)
            else
                WindowAddAnchor( "IgnoreListItem"..i, "bottomleft", previousListItem, "topleft", 0, 0)
            end

            previousListItem = "IgnoreListItem"..i
        end
        SettingsWindow.PreviousIgnoreListCount = WindowData.IgnoreListCount

        ScrollWindowUpdateScrollRect("SettingsProfanityWindow")	
end

function SettingsWindow.OnIgnoreListDeleteButton()
	if SettingsWindow.CurIgnoreListIdx == -1 then
		return
	end

	local idx = SettingsWindow.CurIgnoreListIdx
	Debug.PrintToDebugConsole(L"current idx "..idx)
	local id = WindowData.IgnoreIdList[idx]
	Debug.PrintToDebugConsole(L"id at idx "..id)
	DeleteFromIgnoreList(id)
	SettingsWindow.CurIgnoreListIdx = -1
	SettingsWindow.PopulateProfanityList()
end

function SettingsWindow.OnIgnoreListItemClicked()
	for i=1, WindowData.IgnoreListCount do
		LabelSetTextColor( "IgnoreListItem"..i, 255, 255, 255 )
		if( SystemData.ActiveWindow.name == "IgnoreListItem"..i ) then
			SettingsWindow.CurIgnoreListIdx = i
		end
	end

	LabelSetTextColor( SystemData.ActiveWindow.name, 250, 250, 0 )
end

function SettingsWindow.UpdateGammaVal()
    local gamma = SliderBarGetCurrentPosition("GammaSliderBar")
    LabelSetText( "GammaVal", wstring.format(L"%2.2f",gamma) )
end

function SettingsWindow.UpdateMobAnimCacheVal()
    local mobAnimCache = math.floor((SliderBarGetCurrentPosition("MobAnimCacheSliderBar") * SettingsWindow.MobAnimCacheRange) + SettingsWindow.MobAnimCacheMin)
    LabelSetText( "MobAnimCacheVal", L""..mobAnimCache )
end

function SettingsWindow.UpdateDiskCacheVal()
    local diskCache = math.floor((SliderBarGetCurrentPosition("DiskCacheSliderBar") * SettingsWindow.DiskCacheRange) + SettingsWindow.DiskCacheMin)
    LabelSetText( "DiskCacheVal", L""..diskCache )
end

function SettingsWindow.UpdateMinFreeSystemMemoryVal()
    local minFreeSystemMemory = math.floor((SliderBarGetCurrentPosition("MinFreeSystemMemorySliderBar") * SettingsWindow.MinFreeSystemMemoryRange) + SettingsWindow.MinFreeSystemMemoryMin)
    LabelSetText( "MinFreeSystemMemoryVal", L""..minFreeSystemMemory )
end


function SettingsWindow.OnShowResetLegacyDialog()
    if( ButtonGetPressedFlag("LegacyChatButton") == true ) then
        local yesButton = { textTid=SettingsWindow.TID_YES, callback=function() SettingsWindow.ResetLegacyKeyBindings() end }
        local noButton = { textTid=SettingsWindow.TID_NO }
        local windowData = 
        {
            windowName = "Root",
            titleTid = SettingsWindow.TID_INFO,
            bodyTid = SettingsWindow.TID_RESETLEGACYBINDINGS,
            buttons = { yesButton, noButton }
        }
        UO_StandardDialog.CreateDialog(windowData)	    
	end
end
