----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

CourseMapWindow = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

CourseMapWindow.TOP_PADDING = 10
CourseMapWindow.X_PADDING = 16
CourseMapWindow.Y_PADDING = 16

CourseMapWindow.NumPointsCreated = {}
CourseMapWindow.MapPoints = {}
----------------------------------------------------------------
-- Functions
----------------------------------------------------------------

function CourseMapWindow.Initialize()
    local windowName = SystemData.ActiveWindow.name
    local mapId = SystemData.ActiveObject.Id
    
    CourseMapWindow.NumPointsCreated[mapId] = 0
    CourseMapWindow.MapPoints[mapId] = {}
    
    Interface.DestroyWindowOnClose[windowName] = true
    
    WindowSetId(windowName,mapId)
    WindowRegisterEventHandler(windowName,SystemData.Events.COURSE_MAP_DATA_UPDATED,"CourseMapWindow.UpdatePoints")
    
    local width, height, textureScale = GetCourseMapWindowDimensions(mapId)
    
    if( width ~= nil and height ~= nil and textureScale ~= nil ) then
        WindowSetDimensions(windowName, width + CourseMapWindow.X_PADDING, height + CourseMapWindow.Y_PADDING)
        WindowSetDimensions(windowName.."Texture",width,height)
        DynamicImageSetTextureScale(windowName.."Texture",textureScale)
        DynamicImageSetTexture(windowName.."Texture","CourseMap"..mapId,0,0)
        
        local topWidth, topHeight = WindowGetDimensions(windowName.."Top")
        topWidth = width + CourseMapWindow.X_PADDING + CourseMapWindow.TOP_PADDING
        WindowSetDimensions(windowName.."Top",topWidth,topHeight)
        
        local bottomWidth, bottomHeight = WindowGetDimensions(windowName.."Bottom")
        bottomWidth = width + CourseMapWindow.X_PADDING
        WindowSetDimensions(windowName.."Bottom",bottomWidth,bottomHeight)        
    end
end

function CourseMapWindow.Shutdown()
    mapId = WindowGetId(SystemData.ActiveWindow.name)
    ReleaseCourseMap(mapId)
    CourseMapWindow.MapPoints[mapId] = nil
    CourseMapWindow.NumPointsCreated[mapId] = nil
end

function CourseMapWindow.UpdatePoints()
    Debug.Print("CourseMapWindow.UpdatePoints")

    local windowName = SystemData.ActiveWindow.name
    local mapId = WindowGetId(windowName)
    
    for i=1, CourseMapWindow.NumPointsCreated[mapId] do
        local mapPointName = windowName..mapId.."Point"..i
        WindowSetShowing(mapPointName,false)
    end

    CourseMapWindow.MapPoints[mapId] = {}
    local xPosVec, yPosVec = GetCourseMapData(mapId)
    if( xPosVec ~= nil and yPosVec ~= nil ) then
        for i=1, table.getn(xPosVec) do
            local mapPointName = windowName..mapId.."Point"..i
            
            CourseMapWindow.MapPoints[mapId][i] = {}
            CourseMapWindow.MapPoints[mapId][i].x = xPosVec[i]
            CourseMapWindow.MapPoints[mapId][i].y = yPosVec[i]
            
            if( i > CourseMapWindow.NumPointsCreated[mapId] ) then
                CreateWindowFromTemplate(mapPointName,"MapPoint",windowName)
                CourseMapWindow.NumPointsCreated[mapId] = CourseMapWindow.NumPointsCreated[mapId] + 1
            end
            
            WindowClearAnchors(mapPointName)
            WindowAddAnchor(mapPointName,"topleft",windowName.."Texture","center",xPosVec[i],yPosVec[i])
            WindowSetShowing(mapPointName,true)
        end
    end
end