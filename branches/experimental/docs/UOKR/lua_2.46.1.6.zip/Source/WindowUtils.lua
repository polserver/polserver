----------------------------------------------------------------
-- WindowUtil Global Variables
----------------------------------------------------------------
WindowUtils = {}


WindowUtils.resizing = false
WindowUtils.resizeWindow = nil
WindowUtils.resizeAnchor = ""
WindowUtils.resizeEndCallback = nil
WindowUtils.resizeMin = { x=0, y=0 }


WindowUtils.openWindows = {}
WindowUtils.trackSize = {}

WindowUtils.FONT_DEFAULT_TEXT_LINESPACING = 20
WindowUtils.FONT_DEFAULT_SUB_HEADING_LINESPACING = 22

----------------------------------------------------------------
-- WindowUtil Functions
----------------------------------------------------------------


function WindowUtils.Initialize()

	-- Create the Util Windows
	
	CreateWindow( "ResizingWindowFrame", false )
	
	WindowRegisterEventHandler( "ResizingWindowFrame", SystemData.Events.L_BUTTON_UP_PROCESSED, "WindowUtils.OnLButtonUp")	
end


function WindowUtils.Update( timePassed )

	-- Update the resize frame
	if( WindowUtils.resizing ) then
		local x, y = WindowGetDimensions( "ResizingWindowFrame" )
		local resize = false;
		
		if( x < WindowUtils.resizeMin.x  ) then
			x = WindowUtils.resizeMin.x
			resize = true
		end
		if( y < WindowUtils.resizeMin.y ) then
			y = WindowUtils.resizeMin.y
			resize = true
		end
		
		if( resize ) then
			--Debug.PrintToDebugConsole(L"Resizing: "..x..L", "..y )
			WindowSetDimensions( "ResizingWindowFrame", x, y )
		end

	end
end

function WindowUtils.BeginResize( windowName, anchorCorner, minX, minY, lockRatio, endCallback )

	-- Anchor the resizing frame to the window
	local width, height = WindowGetDimensions( windowName )
	
	WindowSetDimensions( "ResizingWindowFrame", width, height )
	
	
	WindowAddAnchor( "ResizingWindowFrame", anchorCorner, windowName, anchorCorner, 0, 0 )
	
	WindowSetResizing( "ResizingWindowFrame", true, anchorCorner, lockRatio );
	WindowSetShowing( "ResizingWindowFrame", true )
	
	WindowUtils.resizing = true
	WindowUtils.resizeWindow = windowName
	WindowUtils.resizeAnchor = anchorCorner
	WindowUtils.resizeMin.x = minX
	WindowUtils.resizeMin.y = minY
	WindowUtils.resizeEndCallback = endCallback
	--Debug.PrintToDebugConsole(L"BeginResize: "..minX..L", "..minY )
	
end 

function WindowUtils.OnLButtonUp( flags, x, y )

	-- End the resize
	if( WindowUtils.resizing ) then
	
		curWindow = WindowUtils.resizeWindow
		local width, height = WindowGetDimensions( "ResizingWindowFrame" )
		
		WindowSetResizing( "ResizingWindowFrame", false, "", false );
		WindowClearAnchors( "ResizingWindowFrame" )
		WindowSetShowing( "ResizingWindowFrame", false )	
			
		WindowSetDimensions( curWindow, width, height )		
		
		WindowUtils.resizing = false
		WindowUtils.resizeWindow = nil
		WindowUtils.resizeAnchor = nil
		
		if( WindowUtils.resizeEndCallback ~= nil ) then
		    WindowUtils.resizeEndCallback(curWindow)
		end
		WindowUtils.resizeEndCallback = nil
	end
end

function WindowUtils.GetTopmostDialog(wndName)
	if( wndName == nil ) or (wndName == "") then 
		Debug.Print("WindowUtils.GetTopmostDialog: Active dialog is nil or empty!") 
        return 
    end
	parent = wndName
	repeat
		wnd = parent
		parent = WindowGetParent(wnd)
		if( parent == nil ) then
		    Debug.Print("WindowUtils.GetTopmostDialog: someone's parent is nil or empty!") 
		    return
		end
	until (parent == "Root") 
	
    return wnd
end

function WindowUtils.GetActiveDialog()
	return WindowUtils.GetTopmostDialog(SystemData.ActiveWindow.name)
end

function WindowUtils.SetActiveDialogTitle(title)
	if( WindowUtils.GetActiveDialog() == nil ) then
		Debug.Print("WindowUtils.SetActiveDialogTitle: Active dialog is nil!")
		return
	end

	WindowUtils.SetWindowTitle(WindowUtils.GetActiveDialog(),title)
end

function WindowUtils.SetWindowTitle(window,title)
    --Debug.Print("WindowUtils.SetWindowTitle: "..tostring(window).." title: "..tostring(title))
    
	if not title or not window  or title == "" then
		return
	end

	title = wstring.upper(title)
	

	-- *** TESTING
	if type(title) ~= "wstring" then
		Debug.Print("*** ERROR: window title is of type " .. type(title))
	end
	-- *** END TESTING
	
	if type(title) == "string" then
	    title = StringToWString(title)	
	end	
	
	
	--local label = window.."Chrome_UO_TitleBar_WindowTitle"
	--LabelSetText(label, title)
	WindowUtils.FitTextToLabel(window, title, true)
end

function WindowUtils.RetrieveWindowSettings()
	-- update the positions for any window thats currently open
	for window, type in pairs(WindowUtils.openWindows) do
		WindowUtils.RestoreWindowPosition(window, false)
	end
end

function WindowUtils.SendWindowSettings()
	-- save the positions for any window thats currently open
	for window, type in pairs(WindowUtils.openWindows) do
		WindowUtils.SaveWindowPosition(window, false)
	end
end

function WindowUtils.RestoreWindowPosition(window, trackSize, alias)
	local windowPositions = SystemData.Settings.Interface.WindowPositions
	local index = nil

	--if no explicit alias, then use actual window name:
	if not alias then
		alias = window
	end
	
	for i, windowName in pairs(SystemData.Settings.Interface.WindowPositions.Names) do
		if( alias == windowName ) then
			index = i
			break
		end
	end
	
	if( index ~= nil ) then
		local x = SystemData.Settings.Interface.WindowPositions.WindowPosX[index]
		local y = SystemData.Settings.Interface.WindowPositions.WindowPosY[index]
		
		-- make sure this window is on screen!
	    local winWidth, winHeight = WindowGetDimensions(window)
	    local resy = SystemData.screenResolution.y / InterfaceCore.scale
	    local resx = SystemData.screenResolution.x / InterfaceCore.scale
	    if( x + winWidth < 0 ) then
	        x = 0
	    elseif( x > resx ) then
	        x = resx - winWidth
	    end
	    
	    if( y + winHeight < 0 ) then
	        y = 0
	    elseif( y > resy ) then
	        y = resy - winHeight
	    end
	    
		if( x ~= nil and y ~= nil ) then
			--Debug.Print("RestoreWindowPosition: " .. alias)
			WindowClearAnchors(window)
			WindowAddAnchor(window, "topleft","Root" , "topleft", x, y)	
		end
		
		if( trackSize == true ) then
			local width = SystemData.Settings.Interface.WindowPositions.WindowWidth[index]
			local height = SystemData.Settings.Interface.WindowPositions.WindowHeight[index]
			if( width ~= nil and height ~= nil and width ~= 0 and height ~= 0 ) then
				WindowSetDimensions(window,width,height)
			end
		end
	end
		
	WindowUtils.openWindows[alias] = true
	WindowUtils.trackSize[alias] = trackSize
end

function WindowUtils.SaveWindowPosition(window, closing, alias)

	--if no explicit alias, then use actual window name:
	if not alias then
		alias = window
	end
	
	-- always save the position if its in the list
	if( WindowUtils.openWindows[alias] == true) then
		local x, y = WindowGetOffsetFromParent(window)
		local width, height = WindowGetDimensions(window)
		local windowPositions = SystemData.Settings.Interface.WindowPositions
		
		local index = nil
		for i, windowName in pairs(windowPositions.Names) do
			if( alias == windowName ) then
				index = i
				break
			end
		end
		
		-- if it doesnt exist yet then add it
		if( index == nil ) then
			index = table.getn(windowPositions.Names) + 1
			windowPositions.Names[index] = alias
		end	
		
		windowPositions.WindowPosX[index] = x
		windowPositions.WindowPosY[index] = y
		
		if( WindowUtils.trackSize[alias] == true ) then
			windowPositions.WindowWidth[index] = width
			windowPositions.WindowHeight[index] = height
		else
			windowPositions.WindowWidth[index] = 0
			windowPositions.WindowHeight[index] = 0
		end
		
		--Debug.Print("SAVING POSITION: x="..x.." y="..y)
		
		-- the closing bool is true by default
		if( closing == true or closing == nil ) then
			WindowUtils.openWindows[alias] = nil
			WindowUtils.trackSize[alias] = nil
		end
	end
end

function WindowUtils.ClearWindowPosition(window)
	local windowPositions = SystemData.Settings.Interface.WindowPositions

	local index = nil
	for i, windowName in pairs(windowPositions.Names) do
		if( window == windowName ) then
			index = i
			break
		end
	end	
	
	if( index ~= nil ) then
		-- shift all the elements up
		local lastElement = table.getn(windowPositions.Names)
		for index2 = index + 1, lastElement do
			local previous = index2 - 1
			windowPositions.Names[previous] = windowPositions.Names[index2]
			windowPositions.WindowWidth[previous] = windowPositions.WindowWidth[index2]
			windowPositions.WindowHeight[previous] = windowPositions.WindowHeight[index2]
			windowPositions.WindowWidth[previous] = windowPositions.WindowWidth[index2]
			windowPositions.WindowHeight[previous] = windowPositions.WindowHeight[index2]
		end
		windowPositions.Names[lastElement] = nil
		windowPositions.WindowWidth[lastElement] = nil
		windowPositions.WindowHeight[lastElement] = nil
		windowPositions.WindowWidth[lastElement] = nil
		windowPositions.WindowHeight[lastElement] = nil		
	end
	
	WindowUtils.openWindows[window] = nil
	WindowUtils.trackSize[window] = nil
end

-- replaces HTML markup tags where possible
--   and strips out all others
-- 
-- str is  of type wstring
--
-- Current substitutions are:
--   <BR>  -->  single carriage return
--   <P>  -->  double carriage return
--   <center>-----</center>  -->  deleted 
--   anything else between < >  -->  deleted 
--
-- NOTE: LuaPlus has some bugginess with wstring routines, e.g. gsub returning
--    the string as ASCII instead of unicode, particularly if the return string is empty
--
function WindowUtils.translateMarkup(str)

	--gsub function doesn't work on empty source strings.
	if(str == L"" or str == "") then 
		return L""
	end	
	str = wstring.gsub(str, L"<[Bb][Rr]>", L"\n")
	if str == L"" or str == "" then 
		return L""
	end	
	str = wstring.gsub(str, L"<[Pp]>", L"\n\n")
	if str == L"" or str == "" then 
		return L""
	end	
	str = wstring.gsub(str, L"<center>-----</center>", L"\n\n")
--	str = wstring.gsub(str, L"<center>-----</center>", L"\n     ___________________\n")
	if str == L"" or str == "" then 
		return L""
	end	
	
	str = WindowUtils.translateLinkTag(str)
	
	str = wstring.gsub(str, L"<.->", L"")

	if str == L"" or str == "" then 
		return L""
	end	

	-- *** NOTE: this is the correct replaced of the above line once wstring.gsub works with captures. 
	--   For now we use KLUDGE2a and KLUDGE2b
	--[[
	str = wstring.gsub(str, L"<(.-)>", function(tag) 
											if wstring.sub(tag,1,4) == L"LINK" then 
												return  L"<"..tag..L">"
											else
												return  L""
											end
										end
						)
	--]]
	
	-- *** KLUDGE2b - because the above gsub isn't properly returning any value other than ""
	-- we used KLUDGE2a in translateLinkTag to surrounded the LINK tag with {}.  So here we change it back
	--
	local KLUDGED_LINK_TAG = L"{LINK(.-)}"
	
	local linkBody = wstring.match(str, KLUDGED_LINK_TAG)
	if type(linkBody) == "wstring" then
		str = wstring.gsub(str, KLUDGED_LINK_TAG, L"<LINK"..linkBody..L">" )
	end
	-- END KLUDGE2b
	
	if str == "" then 
		return L""
	end	
	
	return str 
end


-- WindowUtils.translateLinkTag
--   Translates our legacy code link tag to the KR link tag
--
-- the legacy client uses something like <A HREF="some url">text</A> for it's link tag 
--
-- our new style of link tags is currently NEW_LINK_TAG = L"<LINK=%1,%2>", but
-- in the future it may change to L"<LINK data=\"%1\" text=\"%2\" />"
--
function WindowUtils.translateLinkTag(str)

	local LEGACY_LINK_TAG = L"<[Aa]%s+[Hh][Rr][Ee][Ff]%s*=%s*\"(.-)\">(.-)</[Aa]>"
	
	-- *** KLUDGE - wstring.gsub is not setting the captures corrrectly, so I'm extracting the captures
	--  with  wstring.match and manually inserting them into NEW_LINK_TAG
	--
	local dataCapture, textCapture = wstring.match(str, LEGACY_LINK_TAG)
	if type(dataCapture) ~= "wstring" or type(textCapture) ~= "wstring" then
		return str
	end

	-- *** KLUDGE2a - because we do a final wstring.gsub(str, L"<.->", L"") and using a function as the
	-- third argument isn't working, we use {} instead of <> to surroudn the link tag and change them later
	--local NEW_LINK_TAG = L"{LINK data=\""..dataCapture..L"\" text=\""..textCapture..L"\" /}"
	local NEW_LINK_TAG = L"{LINK="..dataCapture..L","..textCapture..L"}"
	-- END KLUDGE2a
	
	-- END KLUDGE
	
	str = wstring.gsub(str, LEGACY_LINK_TAG, NEW_LINK_TAG)
	if str == "" then 
		return L""
	end	
	
	return str 
end



-- Add commas to a number : i.e. 1000000 becomes 1,000,000
--
-- str needs to be a wstring 
-- returns a wstring
-- 
function WindowUtils.AddCommasToNumber (str)
  local str2 = tostring(tonumber(str))
  local formatted = str2
  while true do  
    formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
    if (k==0) then
      break
    end
  end
  return (StringToWString(formatted))
end


-- currently only handles the case of http links bringing up the web browser but
--	 we could add other generic cases, e.g. opening a help gump or a generic gump or whatever
--
-- linkParam is of type wstring
--
function WindowUtils.ProcessLink( linkParam )
	
    if( wstring.sub(linkParam, 1, 4) == L"http" ) then
       local url = WStringToString( linkParam )
       OpenWebBrowser( url)
    else
		Debug.PrintToDebugConsole(L"WindowUtils.ProcessLink: Link type not known for "..linkParam )
    end
    
end

-- Note that if you are dynamically adding elements to the ScrollWindow, you should be done adding elements and have 
-- called ScrollWindowUpdateScrollRect before using this function
--
function WindowUtils.ScrollToElementInScrollWindow( element, scrollWindow, scrollChild )

	if (not DoesWindowNameExist(element)) or (not DoesWindowNameExist(scrollChild)) then
		Debug.Print("WindowUtils.GotoElementInScrollChild: Window does not exist!")
		return
	end
	
	local elementX,elementY = WindowGetScreenPosition(element)
	local parentX,parentY = WindowGetScreenPosition(scrollChild)
	local dontCare, maxOffset = WindowGetDimensions(scrollChild)
	local scrollOffset = elementY - parentY
	
	-- sanity checks
	if( scrollOffset < 0 ) then
	    scrollOffset = 0
	end
	if( scrollOffset > maxOffset ) then
	    scrollOffset = maxOffset
	end
	
	ScrollWindowSetOffset(scrollWindow, scrollOffset)
end

-- Note that if you are dynamically adding elements to the ScrollWindow, you should be done adding elements and have 
-- called HorizontalScrollWindowUpdateScrollRect before using this function
--
function WindowUtils.ScrollToElementInHorizontalScrollWindow( element, scrollWindow, scrollChild )

	if (not DoesWindowNameExist(element)) or (not DoesWindowNameExist(scrollChild)) then
		Debug.Print("WindowUtils.GotoElementInScrollChild: Window does not exist!")
		return
	end
	
	local elementX,elementY = WindowGetScreenPosition(element)
	local parentX,parentY = WindowGetScreenPosition(scrollChild)
	local maxOffset = WindowGetDimensions(scrollChild)
	local scrollOffset = elementX - parentX
	
	-- sanity checks
	if( scrollOffset < 0 ) then
	    scrollOffset = 0
	end
	if( scrollOffset > maxOffset ) then
	    scrollOffset = maxOffset
	end
	
	HorizontalScrollWindowSetOffset(scrollWindow, scrollOffset)
end

-- Append label text with ellipsis (...) if label text width exceeds label width
-- Used by the function that sets window titles too, so that all titles don't extend beyond the window that contains them
function WindowUtils.FitTextToLabel(labelName, labelText, isTitle )
	
local DEBUG = false -- enable for verbose debugging of this function

	local labelWindowName = labelName
	if isTitle then
		labelText = wstring.upper(labelText)
		labelWindowName = labelName.."Chrome_UO_TitleBar_WindowTitle"	
if DEBUG then Debug.Print( L"Called WindowUtils.FitTextToLabel() to set the title for window ''"..StringToWString(labelName)..L"'' to ''"..labelText..L"''" ) end
	else
if DEBUG then Debug.Print( L"Called WindowUtils.FitTextToLabel( "..StringToWString(labelWindowName)..L", "..labelText..L" )" ) end
	end

	if labelWindowName == nil or labelText == nil or labelWindowName == "" or labelText == "" or labelText == L"" then
	   Debug.Print("ERROR in WindowUtils.FitTextToLabel()! Window name or text is bad")
	   return 0
	end

    LabelSetWordWrap(labelWindowName, false)
	local labelX, labelY = WindowGetDimensions(labelName)
	if isTitle then
		labelX = labelX - 55 -- The window has about 55 pixels of spacing on both ends total that the title shouldn't use.
	end
	LabelSetText( labelWindowName, labelText )
	local textX, textY = LabelGetTextDimensions(labelWindowName)
	
if DEBUG then Debug.Print( L"The space allowed for this label is "..labelX..L" pixels." ) end
if DEBUG then Debug.Print( L"The current text size is "..textX..L" pixels." ) end

    local text = labelText

	while (textX  > labelX) and (text:len() > 1) do
		text = wstring.sub(text, 1, -2)
if DEBUG then Debug.Print( L"The text width ("..textX..L") is still greater than the label width ("..labelX..L"), so we're changing the text to ''"..text..L"...''" ) end		
		LabelSetText(labelWindowName, text..L"...")
		textX, textY = LabelGetTextDimensions(labelWindowName)
if DEBUG then Debug.Print( L"The new text size is width="..textX..L" height="..textY ) end
	end
if DEBUG then Debug.Print( L"The text width ("..textX..L") is less than the label width ("..labelX..L"), so we are done." ) end		
end
