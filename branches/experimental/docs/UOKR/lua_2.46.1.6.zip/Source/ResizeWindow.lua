----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

ResizeWindow = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

ResizeWindow.UpdateCounter = 0

ResizeWindow.HANDLE_SIZE = 5
ResizeWindow.UPDATE_FREQ = 0.1
ResizeWindow.IsMoving = false

----------------------------------------------------------------
-- Functions
----------------------------------------------------------------

function ResizeWindow.Initialize()
	WindowRegisterEventHandler( "ResizeWindow", SystemData.Events.VIEWPORT_CHANGED, "ResizeWindow.OnViewportChanged" )
	
	ResizeWindow.UpdateWindow()	
end

function ResizeWindow.Shutdown()

end

function ResizeWindow.Update(timePassed)
	if( ResizeWindow.IsMoving == true or WindowUtils.resizeWindow == "ResizeWindow" ) then
		ResizeWindow.UpdateCounter = ResizeWindow.UpdateCounter + timePassed
		if( ResizeWindow.UpdateCounter > ResizeWindow.UPDATE_FREQ ) then
			local windowWidth, windowHeight
			if( WindowUtils.resizeWindow == "ResizeWindow" ) then
				windowWidth, windowHeight = WindowGetDimensions("ResizingWindowFrame")				
			else
				windowWidth, windowHeight = WindowGetDimensions("ResizeWindow")
			end
			ResizeWindow.SendViewportData(windowWidth, windowHeight)
			ResizeWindow.UpdateCounter = 0
			
			if( WindowGetMoving("ResizeWindow") == false ) then
				ResizeWindow.IsMoving = false
			end
		end
	end
end

function ResizeWindow.StartMoving()
	ResizeWindow.UpdateCounter = 0
	ResizeWindow.IsMoving = true
	WindowSetMoving("ResizeWindow",true)
end

function ResizeWindow.OnResizeBegin()
	ResizeWindow.UpdateCounter = 0
	WindowSetShowing("ResizeWindow",false)
    WindowUtils.BeginResize( "ResizeWindow", "topleft", 300, 200, true, ResizeWindow.OnResizeEnd )
end

function ResizeWindow.OnResizeEnd()
	local windowWidth, windowHeight = WindowGetDimensions("ResizeWindow")

	WindowSetShowing("ResizeWindow",true)
	ResizeWindow.UpdateHandles(windowWidth,windowHeight)
	ResizeWindow.SendViewportData(windowWidth,windowHeight)
end

function ResizeWindow.UpdateHandles(windowWidth,windowHeight)
	if( windowWidth == nil or windowHeight == nil ) then
		windowWidth, windowHeight = WindowGetDimensions("ResizeWindow")
	end
	
	WindowSetDimensions("TopHandle",windowWidth,ResizeWindow.HANDLE_SIZE)
	WindowSetDimensions("BottomHandle",windowWidth,ResizeWindow.HANDLE_SIZE)
	WindowSetDimensions("LeftHandle",ResizeWindow.HANDLE_SIZE,windowHeight)
	WindowSetDimensions("RightHandle",ResizeWindow.HANDLE_SIZE,windowHeight)
	
end

function ResizeWindow.SendViewportData(windowWidth, windowHeight)
	local windowPosX, windowPosY = WindowGetOffsetFromParent("ResizeWindow")

	viewportSize = (windowHeight * InterfaceCore.scale) / SystemData.screenResolution.y
	viewportPosX = (windowPosX  * InterfaceCore.scale) / SystemData.screenResolution.x
	viewportPosY = (windowPosY * InterfaceCore.scale) / SystemData.screenResolution.y
	
	UpdateViewport(viewportSize,viewportPosX,viewportPosY)
end

function ResizeWindow.UpdateWindow()
	if( SystemData.Settings.Resolution.viewportEnabled == false ) then
		WindowSetShowing("ResizeWindow",false)
	else
		WindowSetShowing("ResizeWindow",true)
		
		local scaleFactor = 1/InterfaceCore.scale

		local posx = SystemData.Settings.Resolution.viewportPos.x * SystemData.screenResolution.x * scaleFactor
		local posy = SystemData.Settings.Resolution.viewportPos.y * SystemData.screenResolution.y * scaleFactor
		
		WindowClearAnchors("ResizeWindow")
		WindowAddAnchor("ResizeWindow","topleft","Root","topleft",posx,posy)
		
		local modifier = (SystemData.screenResolution.y*4)/(3*SystemData.screenResolution.x)
		if( modifier > 1 ) then
		    modifier = 1
		end
		
		local windowPercentY = SystemData.Settings.Resolution.viewportSize
		local windowPercentX = SystemData.Settings.Resolution.viewportSize * modifier
		
		local windowWidth = (scaleFactor * windowPercentX * SystemData.screenResolution.x)
		local windowHeight = (scaleFactor * windowPercentY * SystemData.screenResolution.y)	

		WindowSetDimensions("ResizeWindow",windowWidth,windowHeight)
		
		ResizeWindow.UpdateHandles(windowWidth,windowHeight)
	end
end

function ResizeWindow.OnViewportChanged()
	ResizeWindow.UpdateWindow()
end