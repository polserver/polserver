----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

Cursor = {}

Cursor.TYPE_ITEM = 1
Cursor.TYPE_ACTION = 2
Cursor.TYPE_HEALTH_BAR = 3

Cursor.Data = nil
Cursor.PendingData = nil
Cursor.PickupTimer = 0
Cursor.PICKUP_TIME = 3 -- 3 Seconds
Cursor.LButtonDown = false
Cursor.PickupWindow = ""

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Functions Variables
----------------------------------------------------------------

function Cursor.Initialize()

	WindowRegisterEventHandler( "Root", SystemData.Events.L_BUTTON_DOWN_PROCESSED, "Cursor.OnLButtonDownProcessed")	
	WindowRegisterEventHandler( "Root", SystemData.Events.L_BUTTON_UP_PROCESSED, "Cursor.OnLButtonUpProcessed")
	
	WindowRegisterEventHandler( "Root", SystemData.Events.R_BUTTON_DOWN_PROCESSED, "Cursor.OnRButtonDownProcessed")
	
	WindowRegisterEventHandler( "Root", SystemData.Events.DRAGSLOT_SET_UI, "Cursor.OnItemPickedUp")
	WindowRegisterEventHandler( "Root", SystemData.Events.DRAGSLOT_CLEAR_UI, "Cursor.OnItemDropped")
end

function Cursor.IconOnCursor()
	if( Cursor.Data ~= nil ) then
		return true
	end

	return false
end

-- CursorData Table Parameters:
--
--VarName:	|Required For: ([] optional)		|Description
-------------------------------------------------------------------------------------------------------------------
--Type:		items,actions,healthbar,chatTab		Cursor.TYPE_ITEM, Cursor.TYPE_ACTION, Cursor.TYPE_HEALTH_BAR, Cursor.TYPE_CHATTAB
--ItemId:	items,[actions],healthbar,chatTab	Id of item being dragged, tabId
--IconId:	actions					Icon of item being dragged
--SourceType:	items					SystemData.DragItem.SOURCETYPE_X
--SourceId:	[items]					ID of source container
--SourceSlot:	[items]					Position in source container
--SourcePos:	[items]					X,Y Position in source container (only for containers)
--Quantity:	[items]					Quantity for generic items
--ObjectType: [items]				Only used for items
function Cursor.Pickup( cursorData )

	--Debug.Print( "Setting Pending Cursor Data: SourceType = "..objectSource.." SourceSlot = "..sourceSlot.." SourceId = "..sourceId.." ItemId = "..itemId.."ObjectType = "..ObjectType)
	
	-- set default parameters
	if( cursorData.SourcePos == nil ) then
		cursorData.SourcePos = {x=0,y=0}
	end
	if( cursorData.SourceSlot == nil ) then
		cursorData.SourceSlot = 0
	end
	if( cursorData.Quantity == nil ) then
		cursorData.Quantity = 1
	end
	if( cursorData.ItemId == nil ) then
		cursorData.ItemId = 0
	end
	if( cursorData.IconId == nil ) then
		cursorData.IconId = cursorData.ItemId
	end
	if( cursorData.ObjectType == nil ) then
		cursorData.ObjectType = -1 --Defaults to -1
	end
	
	Cursor.PendingData			  = cursorData
	Cursor.PickupTimer			  = Cursor.PICKUP_TIME	
	Cursor.MouseX				  = SystemData.MousePosition.x
	Cursor.MouseY				  = SystemData.MousePosition.y
	Cursor.AutoOnLButtonUp		  = autoOnLButtonUp

	--Sound.Play( Sound.ICON_PICKUP )	
end


function Cursor.DropIcon( dynamicImg )

	--Debug.PrintToDebugConsole( L"Dropping Icon on "..StringToWString(dynamicImg) )

	if( Cursor.Data ~= nil and dynamicImg ~= nil ) then
	
		local texture, x, y = GetIconData( Cursor.Data.ItemId )
		DynamicImageSetTexture( dynamicImg, texture, x, y )
	end
	
	Cursor.Clear()

	--Sound.Play( Sound.ICON_DROP )
end

function Cursor.Clear()
	if( Cursor.IconOnCursor() ) then	
		ClearCursor() 
		--Sound.Play( Sound.ICON_CLEAR )
	end
	
	Cursor.Data = nil
	Cursor.PendingData = nil
	
	SetItemDragging(false)
end

function Cursor.OnLButtonDownProcessed()
	Cursor.LButtonDown = true
end

function Cursor.OnLButtonUpProcessed()
	Cursor.LButtonDown = false
	
    if( Cursor.PendingData ~= nil)  then
		--Debug.Print("Clearing Cursor!")
	    Cursor.Clear()
	end
end

function Cursor.OnRButtonDownProcessed()
	if( SystemData.InputProcessed.RButtonDown == false) then
		Cursor.Clear()
	end
end

function Cursor.Update( timePassed )
	
	----TextLogAddEntry( "Lua", 1, "Cursor Update" )
	
	-- Place the pending data on the cursor if...
	-- 1) The cursor has moved off the source window or
	-- 2) More than 3 seconds have passed with the mouse down
	
	--local text
	--
	
	local pendingData = "false"
	local data = "false"
	if( Cursor.Data ~= nil) then data = "true" end
	if( Cursor.PendingData ~= nil) then pendingData = "true" end
	
	----TextLogAddEntry( "Lua", 1, "Data = "..data..",  PendingData = "..pendingData..", PickupWindow = "..Cursor.PickUpWindow )
		
	if( (Cursor.Data == nil) and (Cursor.PendingData ~= nil) and (Cursor.LButtonDown == true) ) then
		
		Cursor.PickupTimer = Cursor.PickupTimer - timePassed
			
		mouseDistanceX = math.abs(Cursor.MouseX - SystemData.MousePosition.x)
		mouseDistanceY = math.abs(Cursor.MouseY - SystemData.MousePosition.y)
		if( Cursor.PickupTimer <= 0 or mouseDistanceX > 3 or mouseDistanceY > 3 ) then
			--Debug.Print("Picking up item: "..Cursor.PendingData.ItemId)
		
			local itemPickedUp = true
			
			Cursor.Data = Cursor.PendingData
			Cursor.PendingData = nil
			
			if( Cursor.Data.Type == Cursor.TYPE_ITEM ) then
				if( (Cursor.Data.SourceType == SystemData.DragItem.SOURCETYPE_CONTAINER) and (Cursor.Data.Quantity > 1) and IsShiftDown() ) then
					GenericQuantity.Create(Cursor.Data.ItemId, Cursor.Data.Quantity, Cursor.Data.SourceId, Cursor.Data.SourcePos)
					Cursor.Clear()
					itemPickedUp = false
				else
					SystemData.ActiveObject.PickUpSourceType = Cursor.Data.SourceType
					SystemData.ActiveObject.SourceId = Cursor.Data.SourceId
					SystemData.ActiveObject.Id = Cursor.Data.ItemId
					SystemData.ActiveObject.Quantity = Cursor.Data.Quantity
					SystemData.ActiveObject.SourcePos.x = Cursor.Data.SourcePos.x
					SystemData.ActiveObject.SourcePos.y = Cursor.Data.SourcePos.y				
					SystemData.ActiveObject.ObjectType = Cursor.Data.ObjectType
					BroadcastEvent(SystemData.Events.OBJECT_PICKUP_UI)
				end
			elseif( Cursor.Data.Type == Cursor.TYPE_ACTION ) then
				if( Cursor.Data.ItemId ) then	
					local texture, x, y = GetIconData( Cursor.Data.IconId )
					SetCursor( texture, x, y )
				end				
			elseif( Cursor.Data.Type == Cursor.TYPE_HEALTH_BAR ) then 
				SystemData.ActiveMobile.Id = Cursor.Data.ItemId
				BroadcastEvent(SystemData.Events.CREATE_HEALTHBAR_WINDOW)
				-- need to clear the cursor data and set picked up item is false
				Cursor.Clear()
				itemPickedUp = false
			elseif Cursor.Data.Type == Cursor.TYPE_CHATTAB then
				ChatManager.DragStart(Cursor.Data.ItemId)
				Cursor.Clear()
				itemPickedUp = false
			end
			
			SetItemDragging(itemPickedUp)
		end		
	
	end
end

function Cursor.OnItemDragQuantity(source, containerId, sourcePos, objectItemId, numQuantity, objectType)
	SystemData.ActiveObject.PickUpSourceType = source
	SystemData.ActiveObject.SourceId = containerId
	SystemData.ActiveObject.Id = objectItemId
	SystemData.ActiveObject.Quantity = numQuantity
	SystemData.ActiveObject.SourcePos.x = sourcePos.x
	SystemData.ActiveObject.SourcePos.y = sourcePos.y
	SystemData.ActiveObject.ObjectType = objectType

	Cursor.Data = 
	{
		Type = Cursor.TYPE_ITEM,
		ItemId = objectItemId,
		SourceType = source,
		SourceId = containerId,
		Quantity = numQuantity,
		SourcePos = sourcePos,
		ObjectType = objectType
	}
	
	BroadcastEvent(SystemData.Events.OBJECT_PICKUP_UI)
	
	SetItemDragging(true)
end

-- This function is called when an object is put in the dragslot from code
function Cursor.OnItemPickedUp()
	Cursor.Data = 
	{
		Type = Cursor.TYPE_ITEM,
		ItemId = SystemData.ActiveObject.Id,
		SourceType = SystemData.ActiveObject.PickUpSourceType,
		SourceId = SystemData.ActiveObject.SourceId,
		SourcePos = SystemData.ActiveObject.SourcePos,
		ObjectType = SystemData.ActiveObject.ObjectType,
	}

	SetItemDragging(true)
end

function Cursor.OnItemDropped()
	--Debug.Print("Cursor.OnItemDropped")
	Cursor.Data = nil
	
	SetItemDragging(false)
end
