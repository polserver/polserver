----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

ContainerWindow = {}
ContainerWindow.OpenContainers = {}
ContainerWindow.RegisteredItems = {}
ContainerWindow.ViewModes = {}

ContainerWindow.DEFAULT_START_POSITION = { x=100,y=100 }
ContainerWindow.MAX_VALUES = { x=1280, y=1024 }
ContainerWindow.POSITION_OFFSET = 30
ContainerWindow.CurPosition = {}
ContainerWindow.CurPosition.x = ContainerWindow.DEFAULT_START_POSITION.x
ContainerWindow.CurPosition.y = ContainerWindow.DEFAULT_START_POSITION.y
ContainerWindow.TimePassedSincePickUp = 0
ContainerWindow.CanPickUp = true

ContainerWindow.TID_GRID_MODE = 1079439
ContainerWindow.TID_FREEFORM_MODE = 1079440
ContainerWindow.TID_LIST_MODE = 1079441
----------------------------------------------------------------
-- ContainerWindow Functions
----------------------------------------------------------------

-- Helper function
function ContainerWindow.ReleaseRegisteredObjects(id)
	if( ContainerWindow.RegisteredItems[id] ~= nil ) then
		for id, value in pairs(ContainerWindow.RegisteredItems[id]) do
			UnregisterWindowData(WindowData.ObjectInfo.Type, id)
		end
	end
	ContainerWindow.RegisteredItems[id] = {}
end

-- OnInitialize Handler
function ContainerWindow.Initialize()
	this = SystemData.ActiveWindow.name
	id = SystemData.DynamicWindowId
	WindowSetId(this, id)
	
	Interface.DestroyWindowOnClose[this] = true

	ContainerWindow.OpenContainers[id] = true

	RegisterWindowData(WindowData.ContainerWindow.Type, id)
	RegisterWindowData(WindowData.PlayerEquipmentSlot.Type, EquipmentData.EQPOS_BACKPACK)
	WindowRegisterEventHandler(this, WindowData.ContainerWindow.Event, "ContainerWindow.MiniModelUpdate")
	WindowRegisterEventHandler(this, WindowData.ObjectInfo.Event, "ContainerWindow.UpdateObject")

	-- determine view mode
	local playerBackpack = WindowData.PlayerEquipmentSlot[EquipmentData.EQPOS_BACKPACK].objectId
	if( WindowData.ContainerWindow[id].isCorpse == true ) then
		ContainerWindow.ViewModes[id] = SystemData.Settings.Interface.defaultCorpseMode
    elseif( WindowData.ContainerWindow[id].isSnooped == true ) then
        ContainerWindow.ViewModes[id] = "Freeform"
	elseif( id == playerBackpack ) then
		ContainerWindow.ViewModes[id] = SystemData.Settings.Interface.inventoryMode
	else
		ContainerWindow.ViewModes[id] = SystemData.Settings.Interface.defaultContainerMode
	end

	ContainerWindow.CreateGridViewSockets(this, id)

	WindowData.ContainerWindow[id].numCreatedSlots = 0
	
	DynamicImageSetTexture(this.."FreeformView","freeformcontainer_texture"..id,0,0)
	DynamicImageSetTextureScale(this.."FreeformView",SystemData.FreeformInventory.Scale)
	
	-- position window
	
	local playerBackpack = WindowData.PlayerEquipmentSlot[EquipmentData.EQPOS_BACKPACK].objectId
	-- if this is the players backpack then use the saved position
	if( id == playerBackpack ) then
		WindowUtils.RestoreWindowPosition(this)
		ButtonSetPressedFlag("MenuBarWindowStatusBarToggleInventory",true)
		local my_paperdoll = "PaperdollWindow"..WindowData.PlayerStatus.PlayerId
		local my_paperdoll_backpackicon = "PaperdollWindow"..WindowData.PlayerStatus.PlayerId.."ToggleInventory"
		if DoesWindowNameExist(my_paperdoll) and WindowGetShowing(my_paperdoll) then
			ButtonSetPressedFlag( my_paperdoll_backpackicon, true )
		end	
	-- else tile them like the old client
	else
		WindowClearAnchors(this)
		WindowAddAnchor(this, "topleft","Root" , "topleft", ContainerWindow.CurPosition.x, ContainerWindow.CurPosition.y)
		ContainerWindow.CurPosition.x = ContainerWindow.CurPosition.x + ContainerWindow.POSITION_OFFSET
		ContainerWindow.CurPosition.y = ContainerWindow.CurPosition.y + ContainerWindow.POSITION_OFFSET

		local winX, winY = WindowGetDimensions(this)
		--Debug.Print("CurPosX: "..ContainerWindow.CurPosition.x.." WinWidth: "..winX.." ScreenWidth: "..SystemData.screenResolution.x)
		if( (ContainerWindow.CurPosition.x + winX) >= ContainerWindow.MAX_VALUES.x ) then
			ContainerWindow.CurPosition.x = ContainerWindow.DEFAULT_START_POSITION.x
		end
		--Debug.Print("CurPosY: "..ContainerWindow.CurPosition.y.." WinHeight: "..winY.." ScreenHeight: "..SystemData.screenResolution.y)
		if( (ContainerWindow.CurPosition.y + winY) >= ContainerWindow.MAX_VALUES.y ) then
			ContainerWindow.CurPosition.y = ContainerWindow.DEFAULT_START_POSITION.y
		end
	end

end

function ContainerWindow.Shutdown()
	--Debug.Print("ContainerWindow.Shutdown: "..WindowUtils.GetActiveDialog())

	id = WindowGetId(WindowUtils.GetActiveDialog())
	this = "ContainerWindow_"..id
	
	local playerBackpack = WindowData.PlayerEquipmentSlot[EquipmentData.EQPOS_BACKPACK].objectId
	-- if this is the players backpack then use the saved position
	if( id == playerBackpack ) then
		WindowUtils.SaveWindowPosition(this)
		-- save inventory view mode
		SystemData.Settings.Interface.inventoryMode = ContainerWindow.ViewModes[id]
		ButtonSetPressedFlag("MenuBarWindowStatusBarToggleInventory",false)
		local my_paperdoll = "PaperdollWindow"..WindowData.PlayerStatus.PlayerId
		local my_paperdoll_backpackicon = "PaperdollWindow"..WindowData.PlayerStatus.PlayerId.."ToggleInventory"
		if DoesWindowNameExist(my_paperdoll) and WindowGetShowing(my_paperdoll) then
			ButtonSetPressedFlag( my_paperdoll_backpackicon, false )
		end		
	end
	
	ContainerWindow.ReleaseRegisteredObjects(id)
	
	-- clear view mode
	ContainerWindow.ViewModes[id] = nil
	
	UnregisterWindowData(WindowData.ContainerWindow.Type, id)
	UnregisterWindowData(WindowData.PlayerEquipmentSlot.Type, EquipmentData.EQPOS_BACKPACK)
	
	ContainerWindow.OpenContainers[id] = nil
	
	if( ItemProperties.GetCurrentWindow() == this ) then
		ItemProperties.ClearMouseOverItem()
	end
	
	GumpManagerOnCloseContainer(id)
end

function ContainerWindow.HideAllContents(parent, numItems)
	for i=1,125 do
		DynamicImageSetTexture(parent.."GridViewSocket"..i.."Icon", "", 0, 0);
		LabelSetText(parent.."GridViewSocket"..i.."Quantity", L"")
		if i <= numItems then
			WindowSetShowing(parent.."ListViewScrollChildItem"..i, false)
		end
	end
end

function ContainerWindow.CreateSlots(dialog, low, high)
	-- TODO: Create other views as well/instead
	parent = dialog.."ListViewScrollChild"
	for i=low, high do
		slotName = parent.."Item"..i
		CreateWindowFromTemplate(slotName, "ContainerItemTemplate", parent)
		WindowSetId(slotName,i)
		WindowSetId(slotName.."Icon", i)
		
		if i == 1 then
			WindowAddAnchor(slotName, "topleft", parent, "topleft", 0, 0)
		else
			WindowAddAnchor(slotName, "bottomleft", parent.."Item"..i-1, "topleft", 0, 0)
		end
	end
end

function ContainerWindow.CreateGridViewSockets(dialog, windowId)
	GRID_WIDTH = 5
	parent = dialog.."GridViewScrollChild"
	for i = 1, 125 do
		socketName = dialog.."GridViewSocket"..i 
		CreateWindowFromTemplate(socketName, "GridViewSocketTemplate", parent)
		WindowSetId(socketName, i)
		if i == 1 then
			WindowAddAnchor(socketName, "topleft", parent, "topleft", 0, 0)
		elseif (i % GRID_WIDTH) == 1 then
			WindowAddAnchor(socketName, "bottomleft", dialog.."GridViewSocket"..i-GRID_WIDTH, "topleft", 0, 1)
		else
			WindowAddAnchor(socketName, "topright", dialog.."GridViewSocket"..i-1, "topleft", 1, 0)
		end

		WindowSetShowing(socketName, true)
	end

	ScrollWindowUpdateScrollRect(dialog.."GridView") 
	WindowSetShowing(dialog.."GridView", false)
end

function ContainerWindow.MiniModelUpdate()
	local id = WindowData.UpdateInstanceId
	
	if( id == WindowGetId(SystemData.ActiveWindow.name) ) then
		ContainerWindow.UpdateContents(id)
	end
end

function ContainerWindow.UpdateContents(id)
	this = "ContainerWindow_"..id
	list_view_this = this.."ListView"        
	grid_view_this = this.."GridView"
	freeform_view_this = this.."FreeformView"
	
	data = WindowData.ContainerWindow[id]
	
	-- store the scrollbar offset so we can restore it when we are done
	local listOffset = ScrollWindowGetOffset(list_view_this)
	local gridOffset = ScrollWindowGetOffset(grid_view_this)
	
	-- Create any contents slots we need
	contents = data.ContainedItems
	numItems = data.numItems
	numCreatedSlots = data.numCreatedSlots or 0
	if numItems > numCreatedSlots then
		ContainerWindow.CreateSlots(this, numCreatedSlots+1, numItems)
		data.numCreatedSlots = numItems
	end
	
	-- Turn off all contents to start
	ContainerWindow.HideAllContents(this, numCreatedSlots)

	if ContainerWindow.ViewModes[id] == "List" then
		WindowSetShowing(list_view_this , true)
		WindowSetShowing(grid_view_this, false)
		WindowSetShowing(freeform_view_this, false)
	elseif ContainerWindow.ViewModes[id] == "Grid" then
		WindowSetShowing(list_view_this, false)
		WindowSetShowing(grid_view_this, true)
		WindowSetShowing(freeform_view_this, false)
	elseif ContainerWindow.ViewModes[id] == "Freeform" then
		WindowSetShowing(list_view_this, false)
		WindowSetShowing(grid_view_this, false)
		WindowSetShowing(freeform_view_this, true)	
	end
	
	LabelSetText(this.."Title", data.containerName)
	if (data.containerName and data.containerName ~= L"" and data.containerName ~= "") then
		WindowUtils.FitTextToLabel(this.."Title", data.containerName)
	end
	
	ContainerWindow.ReleaseRegisteredObjects(id)
	
	if( ContainerWindow.ViewModes[id] ~= "Freeform" ) then
		for i = 1, numItems do
			item = data.ContainedItems[i]
			ContainerWindow.RegisteredItems[id][item.objectId] = true
			RegisterWindowData(WindowData.ObjectInfo.Type, item.objectId)
			-- perform the initial update of this object
			WindowData.UpdateInstanceId = item.objectId
			ContainerWindow.UpdateObject(this)
			WindowSetShowing(this.."ListViewScrollChildItem"..i,true)
		end
		
		-- Update the scroll windows
		ScrollWindowUpdateScrollRect( list_view_this )   	
		local maxOffset = VerticalScrollbarGetMaxScrollPosition(list_view_this.."Scrollbar")
		if( listOffset > maxOffset ) then
		    listOffset = maxOffset
		end
		ScrollWindowSetOffset(list_view_this,listOffset)

		ScrollWindowUpdateScrollRect(grid_view_this) 
		maxOffset = VerticalScrollbarGetMaxScrollPosition(grid_view_this.."Scrollbar")
		if( gridOffset > maxOffset ) then
		    gridOffset = maxOffset
		end
		ScrollWindowSetOffset(grid_view_this,gridOffset)		
		
	end

end

function ContainerWindow.UpdateObject(windowName)
	if( windowName == nil ) then
		windowName = SystemData.ActiveWindow.name
	end

	local updateId = WindowData.UpdateInstanceId
	
	if( WindowData.ObjectInfo[updateId] ~= nil ) then
	    local containerId = WindowData.ObjectInfo[updateId].containerId
    	
	    -- if this object is in my container
	    if( containerId == WindowGetId(windowName) ) then
		    -- find the slot index
		    containedItems = WindowData.ContainerWindow[containerId].ContainedItems
		    numItems = WindowData.ContainerWindow[containerId].numItems
		    listIndex = 0
		    for i=1, numItems do
			    if( containedItems[i].objectId == updateId ) then
				    listIndex = i
				    gridIndex = (containedItems[i].gridIndex)
				    break
			    end
		    end
		    item = WindowData.ObjectInfo[updateId]

		    -- Name
		    ElementName = windowName.."ListViewScrollChildItem"..listIndex.."Name"
		    LabelSetText(ElementName, item.name )
		    WindowSetShowing(ElementName, true)

		    -- Icon
		    elementIcon = windowName.."ListViewScrollChildItem"..listIndex.."Icon"
		    if( item.iconName ~= "" ) then

			    WindowSetDimensions(elementIcon, item.newWidth, item.newHeight)		
			    DynamicImageSetTexture(elementIcon, item.iconName, 0, 0 )
    			DynamicImageSetCustomShader(elementIcon, "UOSpriteUIShader", {item.hueId})
			    DynamicImageSetTextureScale(elementIcon, item.iconscale)
			    WindowSetTintColor(elementIcon,item.hue.r,item.hue.g,item.hue.b)
			    WindowSetAlpha(elementIcon,item.hue.a/255)
    			
			    parent = WindowGetParent(elementIcon)
			    WindowClearAnchors(elementIcon)
			    WindowAddAnchor(elementIcon, "topleft", parent, "topleft", 15+((45-item.newWidth)/2), 15+((45-item.newHeight)/2))
    			
			    WindowSetShowing(elementIcon, true)
		    else
			    WindowSetShowing(elementIcon, false)
		    end

		    -- Grid View Icon & Quantity Label
		    if( item.iconName ~= "" ) then
			    elementGridIcon = windowName.."GridViewSocket"..gridIndex.."Icon"

			    WindowSetDimensions(elementGridIcon, item.newWidth, item.newHeight)		
			    DynamicImageSetTexture(elementGridIcon, item.iconName, 0, 0 )
			    DynamicImageSetCustomShader(elementGridIcon, "UOSpriteUIShader", {item.hueId})
    			
			    WindowSetTintColor(elementGridIcon,item.hue.r,item.hue.g,item.hue.b)
			    WindowSetAlpha(elementGridIcon,item.hue.a)			
    			
			    DynamicImageSetTextureScale(elementGridIcon, item.iconscale)
			    
			    local gridViewItemLabel = windowName.."GridViewSocket"..gridIndex.."Quantity"
			    LabelSetText(gridViewItemLabel, L"")
			    if( item.quantity ~= nil and item.quantity > 1 ) then 
				    LabelSetText(gridViewItemLabel, L""..item.quantity)
				end
		    end
	    end
	end
end

function ContainerWindow.ToggleView()
	id = WindowGetId(WindowUtils.GetActiveDialog())
	
	if( WindowData.ContainerWindow[id].isSnooped == false ) then
        if (ContainerWindow.ViewModes[id] == "List") then
		    ContainerWindow.ViewModes[id] = "Grid"
        elseif( ContainerWindow.ViewModes[id] == "Grid" ) then 
    	    ContainerWindow.ViewModes[id] = "Freeform"
        elseif( ContainerWindow.ViewModes[id] == "Freeform" ) then
		    ContainerWindow.ViewModes[id] = "List"
	    end

	    local this = WindowUtils.GetActiveDialog()
	    local id = WindowGetId(this)
        ContainerWindow.UpdateContents(id)
    end
end

function ContainerWindow.GetSlotNumFromGridIndex(containerId, gridIndex)
    local slotNum = nil
    
    if( ContainerWindow.ViewModes[containerId] == "Grid" ) then
        local containedItems = WindowData.ContainerWindow[containerId].ContainedItems
        
        if( WindowData.ContainerWindow[containerId].ContainedItems ) then
            for index, item in ipairs(WindowData.ContainerWindow[containerId].ContainedItems) do
                --Debug.Print("Comparing to: "..tostring(item.gridIndex))
	            if( item.gridIndex == gridIndex ) then
		            slotNum = index
		            break
	            end
            end
        end
    else
        slotNum = gridIndex
    end
    
    return slotNum
end

function ContainerWindow.OnItemClicked()
	local containerId = WindowGetId(WindowUtils.GetActiveDialog())
	local slotNum = WindowGetId(SystemData.ActiveWindow.name)
	
	slotNum = ContainerWindow.GetSlotNumFromGridIndex(containerId, slotNum)

    if( slotNum ~= nil ) then
	    if( WindowData.Cursor ~= nil and WindowData.Cursor.target == true ) then
		        local objectId = WindowData.ContainerWindow[containerId].ContainedItems[slotNum].objectId
    		
		        SystemData.ActiveObject.Id = objectId
		        BroadcastEvent(SystemData.Events.TARGET_SEND_ID)
	    elseif( Cursor.IconOnCursor() == false ) then
		        local objectId = WindowData.ContainerWindow[containerId].ContainedItems[slotNum].objectId
        		
		        selectedNum = WindowData.ObjectInfo[objectId]
        		
		        local cursorData = 
		        {
			        Type = Cursor.TYPE_ITEM,
			        ItemId = objectId,
			        SourceType = SystemData.DragItem.SOURCETYPE_CONTAINER,
			        SourceId = containerId,
			        SourceSlot = slotNum,
			        Quantity = selectedNum.quantity,
			        ObjectType = selectedNum.objectType
		        }
		        Cursor.Pickup(cursorData)
	    end
	end
end

function ContainerWindow.OnItemRelease()
	if( Cursor.IconOnCursor() and Cursor.Data.Type == Cursor.TYPE_ITEM ) then
	    local containerId = WindowGetId(WindowUtils.GetActiveDialog())
		local gridIndex = WindowGetId(SystemData.ActiveWindow.name)
		
		slotNum = ContainerWindow.GetSlotNumFromGridIndex(containerId, gridIndex)
		
		local slot = nil
	
        if( WindowData.ContainerWindow[containerId].ContainedItems ~= nil and slotNum ~= nil) then
            slot = WindowData.ContainerWindow[containerId].ContainedItems[slotNum]
        end
        
		-- This happens when you drop an item onto an empty grid socket
		if (not slot) then
		    SystemData.ActiveObject.SourceId = containerId
		    SystemData.ActiveObject.DropSourceType = SystemData.DragItem.SOURCETYPE_CONTAINER
		    SystemData.ActiveObject.GridIndex = gridIndex
		    BroadcastEvent(SystemData.Events.OBJECT_DROP_UI)
			return
		end
		
		local clickedObjId = slot.objectId

		SystemData.ActiveObject.SourceId = clickedObjId
		SystemData.ActiveObject.DropSourceType = SystemData.DragItem.SOURCETYPE_OBJECT
		SystemData.ActiveObject.SourcePos.x = Cursor.Data.SourcePos.x
		SystemData.ActiveObject.SourcePos.y = Cursor.Data.SourcePos.y
		SystemData.ActiveObject.GridIndex = slotNum
		BroadcastEvent(SystemData.Events.OBJECT_DROP_UI)
	end
end

function ContainerWindow.OnContainerRelease(slotNum)
	if( Cursor.IconOnCursor() and Cursor.Data.Type == Cursor.TYPE_ITEM ) then
		local containerId = WindowGetId(WindowUtils.GetActiveDialog())
		SystemData.ActiveObject.SourceId = containerId
		SystemData.ActiveObject.DropSourceType = SystemData.DragItem.SOURCETYPE_CONTAINER
		SystemData.ActiveObject.GridIndex = 0
		BroadcastEvent(SystemData.Events.OBJECT_DROP_UI)
	end
end

function ContainerWindow.OnItemDblClicked()
	local containerId = WindowGetId(WindowUtils.GetActiveDialog())
	local slotNum = WindowGetId(SystemData.ActiveWindow.name)
	
	slotNum = ContainerWindow.GetSlotNumFromGridIndex(containerId, slotNum)
	if( slotNum ~= nil ) then
	    local objectId = WindowData.ContainerWindow[containerId].ContainedItems[slotNum].objectId
    	
	    UserActionUseItem(objectId,false)
	end
end

function ContainerWindow.ItemMouseOver()
	local this = SystemData.ActiveWindow.name
	local index = WindowGetId(this)
	local dialog = WindowUtils.GetActiveDialog()
	local containerId = WindowGetId(dialog)
	local containedItems = WindowData.ContainerWindow[containerId].ContainedItems

    local slotNum = ContainerWindow.GetSlotNumFromGridIndex(containerId, index)
    
    if( slotNum ~= nil and containedItems and containedItems[slotNum] ~= nil ) then
	    objectId = containedItems[slotNum].objectId
    	
	    if objectId then
		    local itemData = { windowName = dialog,
						       itemId = objectId,
		    			       itemType = ItemProperties.type.TYPE_ITEM }
		    ItemProperties.SetActiveItem(itemData)
	    end
	end
end

function ContainerWindow.OnItemGet()
	local index = WindowGetId(SystemData.ActiveWindow.name)
	local containerId = WindowGetId(WindowUtils.GetActiveDialog())
	local slotNum = ContainerWindow.GetSlotNumFromGridIndex(containerId, index)
	local objectId = WindowData.ContainerWindow[containerId].ContainedItems[slotNum].objectId
	local selectedNum = WindowData.ObjectInfo[objectId]
	local playerBackpackId = WindowData.PlayerEquipmentSlot[EquipmentData.EQPOS_BACKPACK].objectId
	
	-- If player is trying to get objects from a container that is not from the players backpack have it dropped
	-- into the players backpack
	if(WindowData.ContainerWindow[containerId].isCorpse == true) then
		if( ContainerWindow.CanPickUp == true) then
			--Pickup item being right clicked and put in drag slot
			SystemData.ActiveObject.PickUpSourceType = SystemData.DragItem.SOURCETYPE_CONTAINER
			SystemData.ActiveObject.SourceId = containerId 
			SystemData.ActiveObject.Id = objectId
			SystemData.ActiveObject.Quantity = selectedNum.quantity			
		
			BroadcastEvent(SystemData.Events.OBJECT_PICKUP_UI)
			SetItemDragging(true)
			
			--Drop clicked item into players backpack
			SystemData.ActiveObject.SourceId = playerBackpackId
			SystemData.ActiveObject.DropSourceType = SystemData.DragItem.SOURCETYPE_OBJECT
			BroadcastEvent(SystemData.Events.OBJECT_DROP_UI)
			ContainerWindow.TimePassedSincePickUp = 0
			ContainerWindow.CanPickUp = false
		else
			PrintTidToChatWindow(1045157,WindowData.ChannelColor[1])
		end
	else
		RequestContextMenu(objectId)
	end
end

function ContainerWindow.UpdatePickupTimer(timePassed)
	if(ContainerWindow.CanPickUp == false) then
		ContainerWindow.TimePassedSincePickUp = ContainerWindow.TimePassedSincePickUp + timePassed
		if(ContainerWindow.TimePassedSincePickUp >= 1) then
			ContainerWindow.CanPickUp = true	
		end
	end
end

function ContainerWindow.ViewButtonMouseOver()
	local messageText = L""
	local containerId = WindowGetId(WindowUtils.GetActiveDialog())
	
	if (ContainerWindow.ViewModes[containerId] == "Grid" ) then
        messageText = GetStringFromTid(ContainerWindow.TID_FREEFORM_MODE)
	elseif (ContainerWindow.ViewModes[containerId] == "List" ) then
        messageText = GetStringFromTid(ContainerWindow.TID_GRID_MODE)
    elseif (ContainerWindow.ViewModes[containerId] == "Freeform" ) then
        messageText = GetStringFromTid(ContainerWindow.TID_LIST_MODE)
    end
    
	local itemData = { windowName = SystemData.ActiveWindow.name,
						itemId = containerId,
						itemType = ItemProperties.type.TYPE_WSTRINGDATA,
						binding = L"",
						detail = nil,
						title =	messageText,
						body = L""}

	ItemProperties.SetActiveItem(itemData)
end