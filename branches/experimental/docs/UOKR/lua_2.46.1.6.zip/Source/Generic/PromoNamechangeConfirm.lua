----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

PromoNamechangeConfirm = TwoButtonDialog:new()

----------------------------------------------------------------
-- PromoNamechangeConfirm Functions
----------------------------------------------------------------

function PromoNamechangeConfirm:parseData()
	
	--self.title = --GGManager.translateTID( -- put title TID here )
	self.subtitle = GGManager.translateTID( self.descData[1] )
	self.text = self.localizedData[1]

	self.leftButtonName = GGManager.translateTID( GGManager.OKAY_TID )
	self.rightButtonName = GGManager.translateTID( self.descData[2] )
	self.leftButtonID = self.buttonIDs[2]
	self.rightButtonID = self.buttonIDs[1]	
end

-- OnInitialize Handler
function PromoNamechangeConfirm.Initialize()
	local newWindow = PromoNamechangeConfirm:new()
	newWindow.setDataFunction = PromoNamechangeConfirm.parseData
	newWindow:Init()
end
