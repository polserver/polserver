----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

ConfirmCrystal = TwoButtonDialog:new()

----------------------------------------------------------------
-- ConfirmCrystal Functions
----------------------------------------------------------------

function ConfirmCrystal:parseData()
	-- self.subtitle = L"" -- GGManager.translateTID( self.descData[5] )..L"   "..GGManager.translateTID( self.descData[6] )
	self.text = GGManager.translateTID( self.descData[1] )..L" "..self.stringData[1] -- GGManager.stripMarkup( self.stringData[1] )
	self.leftButtonName = GGManager.translateTID( GGManager.OKAY_TID )
	self.rightButtonName = GGManager.translateTID( GGManager.CANCEL_TID)
	self.leftButtonID = self.buttonIDs[1]
	self.rightButtonID = self.buttonIDs[2]
end

-- OnInitialize Handler
function ConfirmCrystal.Initialize()
	local newWindow = ConfirmCrystal:new()
	newWindow.setDataFunction = ConfirmCrystal.parseData
	newWindow:Init()
end