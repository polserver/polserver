

----------------------------------------------------------------
-- Global GuildWindow (metawindow) Variables/Functions
----------------------------------------------------------------

GuildWindow = {}


function GuildWindow.ToggleGuildWindow()

	if not GuildWindow.getShowing() then
		BroadcastEvent( SystemData.Events.REQUEST_OPEN_GUILD_WINDOW)
		return true
	end
	
	GuildWindowManager.closeAllShowing()
	
	return false
end

function GuildWindow.getShowing()
	return( next(GuildWindowManager.windowsShowing) ~= nil )
end



----------------------------------------------------------------
-- Local GuildWindowManager Variables/Functions
----------------------------------------------------------------

GuildWindowManager = 
{
	windowsShowing = {}
}

function GuildWindowManager.registerWindow(windowName, windowData)
	GuildWindowManager.windowsShowing[windowName] = windowData
	ButtonSetPressedFlag("MenuBarWindowStatusBarToggleGuild",true)
end

function GuildWindowManager.unregisterWindow(windowName)
	GuildWindowManager.windowsShowing[windowName] = nil
	ButtonSetPressedFlag("MenuBarWindowStatusBarToggleGuild",GuildWindow.getShowing())
end

function GuildWindowManager.closeAllShowing()
	for windowName,windowData in pairs(GuildWindowManager.windowsShowing) do
		UO_GenericGump.debug( L"GuildWindow.ToggleGuildWindow closing "..StringToWString(windowName) )
		windowData:OnCloseWindow()
	end
end



function GuildWindowManager.getActiveWindowData()
	if not SystemData.ActiveWindow.name then
		return nil
	end

	local windowName = WindowUtils.GetActiveDialog()
	
	return GuildWindowManager.windowsShowing[windowName]
end


----------------------------------------------------------------
-- Local GuildWindow (metawindow) Variables/Functions
----------------------------------------------------------------


function GuildWindow:new( newWindow )
	newWindow = newWindow or {}
	setmetatable(newWindow, self)
	self.__index = self
	
	return newWindow
end



function GuildWindow:Init()
	
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end
	
	if self.setFields then
		self:setFields()
	end

	GuildWindowManager.registerWindow(self.windowName, self)
	WindowSetId( self.windowName.."Chrome_UO_WindowCloseButton", UO_GenericGump.DEFAULT_CLOSE_BUTTON_ID )	
	Interface.OnCloseCallBack[self.windowName] = self.ButtonPressed
	
	GGManager.registerWindow(self.windowName, self)
	
	Debug.PrintToDebugConsole( L"Initialize "..self.name )
end



function GuildWindow:setFields()

	WindowUtils.SetActiveDialogTitle( GGManager.translateTID( 1062939 ) ) -- "GUILD MENU"

	-- set tab labels and IDs
	ButtonSetText(self.windowName.."MyGuildTabButton", GGManager.translateTID(1063014) ) -- My Guild
	WindowSetId( self.windowName.."MyGuildTabButton", 100 )	
	
	ButtonSetText(self.windowName.."GuildRosterTabButton", GGManager.translateTID(1062974) ) -- Guild Roster
	WindowSetId( self.windowName.."GuildRosterTabButton", 110 )	
	
	ButtonSetText(self.windowName.."DiplomacyTabButton", GGManager.translateTID(1062978) ) -- Diplomacy
	WindowSetId( self.windowName.."DiplomacyTabButton", 120 )	

	-- bottom button used by all of them
	ButtonSetText(self.windowName.."CancelButton", GGManager.translateTID(1006045) ) -- Cancel
	WindowSetId( self.windowName.."CancelButton", 0 )	
	
	-- Deselect all the tabs
	ButtonSetDisabledFlag( self.windowName.."MyGuildTabButton", false )
	ButtonSetDisabledFlag( self.windowName.."GuildRosterTabButton", false )
	ButtonSetDisabledFlag( self.windowName.."DiplomacyTabButton", false )
	WindowSetShowing( self.windowName.."MyGuildTabButtonTab", true )
	WindowSetShowing( self.windowName.."GuildRosterTabButtonTab", true )
	WindowSetShowing( self.windowName.."DiplomacyTabButtonTab", true )

end

function GuildWindow.ToggleCheckButton()

	ButtonSetStayDownFlag( SystemData.ActiveWindow.name, not ButtonGetPressedFlag(SystemData.ActiveWindow.name) )
	ButtonSetPressedFlag( SystemData.ActiveWindow.name, not ButtonGetPressedFlag(SystemData.ActiveWindow.name) )
	
	-- *** KLUDGE - this is actually specific to toggling the guild title
	-- but currently that's the only button using this
	GuildMyInfo.GuildTitleChanged = not GuildMyInfo.GuildTitleChanged 
	
end
	

function GuildWindow.ButtonPressed()
	
	local self = GuildWindowManager.getActiveWindowData()
	
	self:DefaultButtonFunction()
end
	

function GuildWindow:DefaultButtonFunction()
	
	local buttonID = WindowGetId( SystemData.ActiveWindow.name )
	
	-- NOTE: this may need to be changed. Currently WindowGetId seems to return 0,
	--  if a value is not set (and 0 is a valid value). May change C++ to return negative value
	--  when no value is set
	if not buttonID or buttonID < 0 then	
		Debug.PrintToDebugConsole( L"ERROR in TwoButtonDialog:DefaultButtonFunction: no ID set for button pressed." )
		return
	end

	if self.GuildTitleChanged  then
		-- sending selection list with 400 (which is what the server expectes for when the Guild Title changes)
		UO_GenericGump.broadcastSelections( buttonID, { 400 }, self )
		self.GuildTitleChanged = false
	else
		UO_GenericGump.broadcastButtonPress( buttonID, self )
	end
	
	self:OnCloseWindow()
end



function GuildWindow:OnCloseWindow()

	local self = self or GuildWindowManager.getActiveWindowData()
	UO_GenericGump.debug( L"called GuildWindow:OnCloseWindow(). Destroying "..self.name )
	
	GuildWindowManager.unregisterWindow( self.windowName )
	GGManager.destroyWindow( self.windowName )
end

----------------------------------------------------------------
-- Global Variables/Functions
----------------------------------------------------------------


GuildPlrDetail = ChoiceList:new()

GuildMyInfo = GuildWindow:new()

GuildPlrRoster = GuildWindow:new()

GuildDiplomacy = GuildWindow:new()




----------------------------------------------------------------
-- GuildPlrDetail Functions
----------------------------------------------------------------



-- OnInitialize Handler
function GuildPlrDetail.Initialize()
	GuildPlrDetail:Init()
end


function GuildPlrDetail:setFields()

	WindowUtils.SetActiveDialogTitle(  GGManager.translateTID( 1078996 ) ) -- Guild Member Details

    LabelSetText( self.windowName.."TopPlayerNameLabel", GGManager.translateTID(self.descData[2]) )
    LabelSetText( self.windowName.."TopPlayerName", self.stringData[3] )
    LabelSetText( self.windowName.."TopRankLabel", GGManager.translateTID(self.descData[3]) )
    LabelSetText( self.windowName.."TopRank", GGManager.translateTID(self.descData[4]) )
    LabelSetText( self.windowName.."TopGuildTitleLabel", GGManager.translateTID(self.descData[5]) )
    LabelSetText( self.windowName.."TopGuildTitle", self.stringData[4] )
    
	-- first element anchored differently    
    local relativeWindow =self:CreateChoiceListSelectableText( self.buttonIDs[1], GGManager.translateTID(self.descData[6]), "topleft", self.windowName.."ScrollChild", "topleft", 0, 0 )
	for i=2,5 do
		relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[i], GGManager.translateTID(self.descData[5+i]), "bottomleft", relativeWindow, "topleft", 0, 10 )
	end

end

function GuildPlrDetail:TextSelectedFunction()

	local buttonID = WindowGetId( SystemData.ActiveWindow.name )
	if buttonID == 104 then
		GuildPlrDetail.OnKick()
	else
		ChoiceList.DefaultTextSelectedFunction( GuildPlrDetail )
	end	
end

function GuildPlrDetail.OnKick()
    local kickButton = { text=GGManager.translateTID(1062997), callback=GuildPlrDetail.OnKickConfirmed, param=106} -- 106 Remove from Guild (confirmed)
    local cancelButton = { textTid=UO_StandardDialog.TID_CANCEL }
	local windowData = 
	{
		body = GGManager.translateTID(1063152), -- "Are you sure you wish to kick this member from the guild?"
		buttons = { kickButton, cancelButton },
		windowName = GuildPlrDetail.windowName.."ConfirmKick",
	}

	UO_StandardDialog.CreateDialog( windowData )
end


function GuildPlrDetail.OnKickConfirmed( buttonID )

	UO_GenericGump.broadcastButtonPress( buttonID, GuildPlrDetail )	
	GGManager.destroyWindow(GuildPlrDetail.windowName)
end


----------------------------------------------------------------
-- GuildMyInfo Functions
----------------------------------------------------------------

GuildMyInfo.SHOW_GUILD_TITLE_ON_ID = 211
GuildMyInfo.SHOW_GUILD_TITLE_OFF_ID = 210


-- OnInitialize Handler
function GuildMyInfo.Initialize()
	GuildMyInfo:Init()
end


function GuildMyInfo:setFields()

	GuildWindow.setFields(self)
--	ButtonSetPressedFlag( self.windowName.."MyGuildTabButton", true )
	ButtonSetDisabledFlag( self.windowName.."MyGuildTabButton", true )
	WindowSetShowing( self.windowName.."MyGuildTabButtonTab", false )


	local itr 
	local CanHasAlliance = false --= (200)
	local CanEditCharter = false --= (self.buttonIDs[4] ~= nil and self.buttonIDs[4] == 210) or (self.buttonIDs[5] ~= nil and self.buttonIDs[5] == 210)
	local CanEditWebsite = false --= (self.buttonIDs[5] ~= nil and self.buttonIDs[5] == 215) or (self.buttonIDs[6] ~= nil and self.buttonIDs[6] == 215)

	for itr = 1,self.buttonCount do
		if self.buttonIDs[itr] == 200 then
			CanHasAlliance = true
		end
		if self.buttonIDs[itr] == 210 then
			CanEditCharter = true
		end
		if self.buttonIDs[itr] == 215 then
			CanEditWebsite = true
		end
	end

    LabelSetText( self.windowName.."TopGuildNameLabel", GGManager.translateTID(self.descData[4]) )
    LabelSetText( self.windowName.."TopGuildName", self.stringData[1] )
    LabelSetText( self.windowName.."TopAllianceLabel", GGManager.translateTID(self.descData[5]) )
    LabelSetText( self.windowName.."TopAlliance", self.stringData[2] )
    LabelSetText( self.windowName.."TopFactionLabel", GGManager.translateTID(self.descData[6]) )
    LabelSetText( self.windowName.."TopFaction", self.stringData[3] )
    
    -- The Alliance RosterButton
    WindowSetId( self.windowName.."TopAllianceRosterButton", 200 )	
	-- only show the button if that buttonID was passed in
	WindowSetShowing( self.windowName.."TopAllianceRosterButton", CanHasAlliance )	
    
	-- Guild Charter
	LabelSetText( self.windowName.."BottomCharterLabel", GGManager.translateTID(1078094) ) --Guild Charter 
	LabelSetText( self.windowName.."BottomCharterTextBox", self.stringData[4] )
	ButtonSetText( self.windowName.."BottomCharterEditButton", GGManager.translateTID(3005101) ) -- "Edit"
	WindowSetId( self.windowName.."BottomCharterEditButton", 210 )	
	-- only show the Edit button if that buttonID was passed in
	WindowSetShowing( self.windowName.."BottomCharterEditButton", CanEditCharter )	
	
	-- Guild Website
	LabelSetText( self.windowName.."BottomWebsiteLabel", GGManager.translateTID(1078095) ) --Guild Website
	LabelSetText( self.windowName.."BottomWebsiteTextBox", self.stringData[5] )
	ButtonSetText( self.windowName.."BottomWebsiteEditButton", GGManager.translateTID(3005101) ) -- "Edit"
	WindowSetId( self.windowName.."BottomWebsiteEditButton", 215 )	
	-- only show the Edit button if that buttonID was passed in
	WindowSetShowing( self.windowName.."BottomWebsiteEditButton", CanEditWebsite )	

	-- check box and label
	LabelSetText( self.windowName.."ShowGuildTitleToggleLabel", GGManager.translateTID(self.descData[7]) )
	ButtonSetPressedFlag( self.windowName.."ShowGuildTitleToggleButton", (self.portImgData[8] ~= nil and self.portImgData[8] == GuildMyInfo.SHOW_GUILD_TITLE_ON_ID) )
	ButtonSetStayDownFlag(  self.windowName.."ShowGuildTitleToggleButton", ButtonGetPressedFlag(self.windowName.."ShowGuildTitleToggleButton") )
	WindowSetId( self.windowName.."ShowGuildTitleToggleButton", 400 )
	self.GuildTitleChanged = false
	
	-- set bottom button labels and IDs
	ButtonSetText(self.windowName.."ResignButton", GGManager.translateTID(self.descData[8]) ) -- 3006115 Resign
	
	-- don't send this ID - instead we'll pop a  confirmation gump 
	WindowSetId( self.windowName.."ResignButton", -1 )	-- 500 // Resign (unconfirmed)
														-- 501 // Resign (confirmed)

end

function GuildMyInfo.OnResign()
	
    local resignButton = { text=GGManager.translateTID(3006115), callback=GuildMyInfo.OnResignConfirmed, param=501} -- 501 // Resign (confirmed)
    local cancelButton = { textTid=UO_StandardDialog.TID_CANCEL }
	local windowData = 
	{
		body = GGManager.translateTID(1063332), -- "Are you sure you wish to resign from your guild?"
		buttons = { resignButton, cancelButton },
		windowName = GuildMyInfo.windowName.."ConfirmResign"
	}

	UO_StandardDialog.CreateDialog(windowData)
	
end

function GuildMyInfo.OnResignConfirmed( buttonID )

	UO_GenericGump.broadcastButtonPress( buttonID, GuildMyInfo )
	GuildMyInfo:OnCloseWindow()
end




----------------------------------------------------------------
-- UO_Table Data / Functions
----------------------------------------------------------------

UO_Table_Column_Metadata = 
{
	type = "nil", 
	
	-- compare should be overriden based on the columns "type"
	-- returns 0 if equivalent, a positive number if value1 is greater than value2, and a negative number if value1 is less than value2
	compare = function(value1, value2) Debug.PrintToDebugConsole( L"ERROR: UO_Table_Column_Metadata.compare must be overriden to work" ) return 0 end,

}

function UO_Table_Column_Metadata:new( newTable )
	local newTable = newTable or {}
	setmetatable(newTable, self)
	self.__index = self
	
	return newTable
end



UO_Table = 
{
	numColumns = 0,
	numRows = 0,
	
	headers = {},
	row = {},

}

function UO_Table:new( newTable )
	local newTable = newTable or {}
	setmetatable(newTable, self)
	self.__index = self
	
	return newTable
end


----------------------------------------------------------------
-- GuildPlrRoster Functions
----------------------------------------------------------------


-- OnInitialize Handler
function GuildPlrRoster.Initialize()
	GuildPlrRoster:Init()
end


function GuildPlrRoster:setDataFunction()
	
	self:setPlayerData()
end


function GuildPlrRoster:setPlayerData()
	
	GuildPlrRoster.players = UO_Table:new()
	GuildPlrRoster.players.row = {}
	
    --local displayOrder = {}
    
	local rowNum = 1
	local strNum = 2
	local descNum = 8 
	while strNum <= self.stringDataCount do
	
		GuildPlrRoster.players.row[rowNum] = {}
		GuildPlrRoster.players.row[rowNum].name = GGManager.stripMarkup( self.stringData[strNum], true )
		strNum = strNum + 1
		GuildPlrRoster.players.row[rowNum].rank = GGManager.translateTID( self.descData[descNum] )
		descNum = descNum + 1
		
		-- see if lastOn is in descData or stringData
		if GuildPlrRoster.descData[descNum] == 1063015 then 
			GuildPlrRoster.players.row[rowNum].lastOn = GGManager.translateTID( GuildPlrRoster.descData[descNum] ) 
			descNum = descNum + 1
		else
			GuildPlrRoster.players.row[rowNum].lastOn = GGManager.stripMarkup( GuildPlrRoster.stringData[strNum], true )
			strNum = strNum + 1
		end
		
		GuildPlrRoster.players.row[rowNum].guildTitle = GGManager.stripMarkup( GuildPlrRoster.stringData[strNum], true )
		strNum = strNum + 1
		
        --table.insert( displayOrder, rowNum )
		rowNum=rowNum+1
	end
	
	--ListSetDisplayOrder (self.windowName.."PlayerTable",displayOrder);

end


function GuildPlrRoster:CreateGuildPlrRosterSelectable( choiceNum, wText1, wText2, wText3, wText4, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset, uniqueID )

	-- Create unique IDs for the window, use the unique ID if specified
	local mainName = ""
	if uniqueID then
		mainName = self.windowName.."Choice"..uniqueID
	else
		mainName = self.windowName.."Choice"..choiceNum
	end

	-- Create unique IDs for the window's button, window's icon, and window's text
	local buttonName = mainName.."Button"
	local iconName   = mainName.."Icon"
	local text1Name  = mainName.."Text1"
	local text2Name  = mainName.."Text2"
	local text3Name  = mainName.."Text3"
	local text4Name  = mainName.."Text4"

	-- Define some locals used for resizing things
	local text1Xsize
	local text1Ysize
	local text2Xsize
	local text2Ysize
	local text3Xsize
	local text3Ysize
	local text4Xsize
	local text4Ysize
	local buttonXsize
	local mainXsize
	local mainYsize
	
	-- if no value is set for containerWindow (controls where the selectable text appears),
	local containerWindow = self.windowName.."ScrollChild"
	
	-- Set the name of the template to use
	local mainTemplateName = "GuildPlrRosterSelectable"

	-- Create the main window
	CreateWindowFromTemplate( mainName, mainTemplateName, containerWindow )
	-- Attach the main window to where it was told to be attached
	WindowAddAnchor( mainName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	-- Set the window to have it's ID
	WindowSetId( mainName, choiceNum )
	
	-- Set the text and then get it's dimensions
	LabelSetText( text1Name, wText1 ) -- Hardcode a long wide string here if you want to see this thing in action
	text1Xsize, text1Ysize = LabelGetTextDimensions( text1Name )
	LabelSetText( text2Name, wText2 ) -- Hardcode a long wide string here if you want to see this thing in action
	text2Xsize, text2Ysize = LabelGetTextDimensions( text2Name )
	LabelSetText( text3Name, wText3 ) -- Hardcode a long wide string here if you want to see this thing in action
	text3Xsize, text3Ysize = LabelGetTextDimensions( text3Name )
	LabelSetText( text4Name, wText4 ) -- Hardcode a long wide string here if you want to see this thing in action
	text4Xsize, text4Ysize = LabelGetTextDimensions( text4Name )
	
	-- Also save the size of the button and window
	buttonXsize = WindowGetDimensions( buttonName )
	mainXsize, mainYsize = WindowGetDimensions( mainName )
	
	if text1Ysize < text2Ysize then
		text1Ysize = text2Ysize
	end
	
	if text1Ysize < text3Ysize then
		text1Ysize = text3Ysize
	end

	if text1Ysize < text4Ysize then
		text1Ysize = text4Ysize
	end
	
	-- use the maximum Y dimension, use the defualt value from the XML if the text doesn't line wrap.
	if mainYsize < text1Ysize then
		mainYsize = text1Ysize+19 -- fudge it 9.5 pixels above and below
	end
	
	-- Set the size of the window and the size of the background to the same thing
	-- One shows where to click, the other handles the click!
	WindowSetDimensions( mainName, mainXsize, mainYsize )
	WindowSetDimensions( buttonName, mainXsize, mainYsize )

	return mainName
end


function GuildPlrRoster:setFields()

	GuildWindow.setFields(self)
--	ButtonSetPressedFlag( self.windowName.."GuildRosterTabButton", true )
	ButtonSetDisabledFlag( self.windowName.."GuildRosterTabButton", true )
	WindowSetShowing( self.windowName.."GuildRosterTabButtonTab", false )
	
	
	local relativeWindow
	
	local rowNum	
	for rowNum=1, table.getn( GuildPlrRoster.players.row ) do
		if rowNum == 1 then
			relativeWindow = self:CreateGuildPlrRosterSelectable(
							self.buttonIDs[12],
							GuildPlrRoster.players.row[rowNum].name,
							GuildPlrRoster.players.row[rowNum].rank,
							GuildPlrRoster.players.row[rowNum].lastOn,
							GuildPlrRoster.players.row[rowNum].guildTitle,
				"topleft", self.windowName.."ScrollChild", "topleft", 0, 0 , rowNum )
		else
			relativeWindow = self:CreateGuildPlrRosterSelectable(
							self.buttonIDs[rowNum+11],
							GuildPlrRoster.players.row[rowNum].name,
							GuildPlrRoster.players.row[rowNum].rank,
							GuildPlrRoster.players.row[rowNum].lastOn,
							GuildPlrRoster.players.row[rowNum].guildTitle,
				"bottomleft", relativeWindow, "topleft", 0, 0 , rowNum )
		end
	end

	-- Display current status text (Disabled in this gump)
	LabelSetText( self.windowName.."ShowText", L" " ) -- GGManager.translateTID( self.descData[self.descDataCount-2] ) )

	-- And the current headers text
	LabelSetText( self.windowName.."TitlesSection1Text", GGManager.translateTID( self.descData[4] ) )
	LabelSetText( self.windowName.."TitlesSection2Text", GGManager.translateTID( self.descData[5] ) )
	LabelSetText( self.windowName.."TitlesSection3Text", GGManager.translateTID( self.descData[6] ) )
	LabelSetText( self.windowName.."TitlesSection4Text", GGManager.translateTID( self.descData[7] ) )

	-- Display the button to change current status
	ButtonSetText(self.windowName.."InviteButton", GGManager.translateTID( self.descData[self.descDataCount-1] ) ) -- GGManager.translateTID( 3000127 ) ) -- L"Options" )	
	WindowSetId( self.windowName.."InviteButton", self.buttonIDs[self.buttonCount] )

	-- Display the button to submit the search text
	ButtonSetText(self.windowName.."SubmitButton", GGManager.translateTID( 3006134 ) ) -- L"Search" )
	WindowSetId( self.windowName.."SubmitButton", self.buttonIDs[7] )
	
	-- Display the next and previous page buttons
	ButtonSetText(self.windowName.."NextButton", GGManager.translateTID( 1011066 ) ) -- L"Next Page" )
	WindowSetId( self.windowName.."NextButton", self.buttonIDs[5] )
	ButtonSetText(self.windowName.."PreviousButton", GGManager.translateTID( 1061028 ) ) -- L"Previous Page" )
	WindowSetId( self.windowName.."PreviousButton", self.buttonIDs[4] )

	-- Disable them if they aren't to be seen
	if  self.buttonIDs[4] == 0 then
		WindowSetShowing( self.windowName.."PreviousButton", false)
	end
	if  self.buttonIDs[5] == 0 then
		WindowSetShowing( self.windowName.."NextButton", false)
	end
	
	WindowSetId( self.windowName.."TitlesSection1", self.buttonIDs[8] ) 
	WindowSetId( self.windowName.."TitlesSection2", self.buttonIDs[9] ) 
	WindowSetId( self.windowName.."TitlesSection3", self.buttonIDs[10] ) 
	WindowSetId( self.windowName.."TitlesSection4", self.buttonIDs[11] ) 

	local case = -self.descData[self.descDataCount]
	if case == 0 then -- Show U in col 1
		WindowSetShowing( self.windowName.."TitlesSection1IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconDown", false )
	elseif case == 1 then -- Show U in col 2
		WindowSetShowing( self.windowName.."TitlesSection2IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconDown", false )
	elseif case == 2 then -- Show U in col 3
		WindowSetShowing( self.windowName.."TitlesSection3IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconDown", false )
	elseif case == 3 then -- Show U in col 4
		WindowSetShowing( self.windowName.."TitlesSection4IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
	elseif case == 4 then -- Show D in col 1
		WindowSetShowing( self.windowName.."TitlesSection1IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconDown", false )
	elseif case == 5 then -- Show D in col 2
		WindowSetShowing( self.windowName.."TitlesSection2IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconDown", false )
	elseif case == 6 then -- Show D in col 3
		WindowSetShowing( self.windowName.."TitlesSection3IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconDown", false )
	elseif case == 7 then -- Show D in col 4
		WindowSetShowing( self.windowName.."TitlesSection4IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection4IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
	else

	end
	
	TextEditBoxSetText( self.windowName.."SearchBox", self.stringData[1] )
	WindowAssignFocus(  self.windowName.."SearchBox", true)

--------------------------------
	-- set bottom button labels and IDs
--	ButtonSetText(self.windowName.."InviteButton", GGManager.translateTID(1062992) ) -- Invite Player
--	WindowSetId( self.windowName.."InviteButton", 900 )	
	
	--ButtonSetText(self.windowName.."KickButton", GGManager.translateTID(1062997) ) -- Kick
	--WindowSetId( self.windowName.."KickButton", 104 )	-- 104 // Remove from Guild (unconfirmed)
														-- 106 Remove from Guild (confirmed)

	--GuildPlrRoster.UpdateList()
end

function GuildPlrRoster.TextSelected() -- This function is only used for the search text broadcast

	local selectedWindow = SystemData.ActiveWindow.name
	local buttonID = WindowGetId( selectedWindow )
	local self = GuildWindowManager.getActiveWindowData()
	
	-- Wipe it to avoid getting duplicate data in the newer one
	--local rowNum
	--for rowNum=1, table.getn( GuildPlrRoster.players.row ) do
	--	DestroyWindow( self.windowName.."Choice"..rowNum )
	--end
	--GuildPlrRoster.players = nil
	
	UO_GenericGump.debug( L"Called GP.TextSelected() with buttonID = "..buttonID )
	
	if buttonID == 750 then
		self:OnSubmit()
	end	
		self:OnCloseWindow()
end

function GuildPlrRoster:OnSubmit() 

	local self = GuildWindowManager.getActiveWindowData()	
	local buttonID = WindowGetId( self.windowName.."SubmitButton" )

	UO_GenericGump.debug(L"Called GP:OnSubmit with self = "..StringToWString(self.windowName) )
		
	local textEntries = {}
		local textBoxName = self.windowName.."SearchBox"
		local text = TextEditBoxGetText( textBoxName )
		local id = self.buttonIDs[6] -- WindowGetId( textBoxName )

		if text ~= nil and id ~= nil  then -- and text ~= ""
			UO_GenericGump.debug( L"textbox 1 has string = "..text..L", ID = "..id)		
			textEntries[id] = text
		end
	
	UO_GenericGump.broadcastTextEntries( buttonID, textEntries, self )
	self:OnCloseWindow()
end

--[[ -- Deprecated
function GuildPlrRoster:CreateRow( choiceNum, rowTable, 
		anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	
	UO_GenericGump.debug( L"called GuildPlrRoster:CreateRow for name = "..rowTable.name..L" and ID = "..choiceNum )

	local choiceName = self.windowName.."Row"..choiceNum
	local scrollParent = self.windowName.."ScrollChild"

	UO_GenericGump.debug( L"called GuildPlrRoster:CreateChoiceListSelectableText. choiceName = "..StringToWString(choiceName) )
	
	CreateWindowFromTemplate( choiceName, "GuildPlrRosterPlayerRow", scrollParent )       
	
	if rowTable.name == GuildPlrRoster.username then        
		WindowSetTintColor("LoadingWindowScenarioFramePlayerListRow"..rowIndex.."Background", color.r, color.g, color.b);
	end
	LabelSetText( choiceName.."Name", rowTable.name )
	LabelSetText( choiceName.."Rank", rowTable.rank )
	LabelSetText( choiceName.."LastOn", rowTable.lastOn )
	LabelSetText( choiceName.."GuildTitle", rowTable.guildTitle )
	
	WindowAddAnchor( choiceName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	WindowSetId( choiceName, choiceNum )	
	
	return choiceName
end
--]]

--[[ -- Deprecated
function GuildPlrRoster.UpdateList()
	UO_GenericGump.debug( L"GuildPlrRoster.UpdateList" )

	local PLAYER_BUTTON_IDS_BASE_INDEX = 11

	-- first row anchors to top of ScrollChild. 
	local relativeWindow = GuildPlrRoster:CreateRow( GuildPlrRoster.buttonIDs[PLAYER_BUTTON_IDS_BASE_INDEX+1], GuildPlrRoster.players.row[1],
			"topleft", GuildPlrRoster.windowName.."ScrollChild", "topleft", 0, 0 )

	-- rows after first anchor to row above them
	for rowNum=2, table.getn( GuildPlrRoster.players.row ) do
		relativeWindow = GuildPlrRoster:CreateRow( GuildPlrRoster.buttonIDs[PLAYER_BUTTON_IDS_BASE_INDEX+rowNum], GuildPlrRoster.players.row[rowNum],
				"bottom", relativeWindow, "top", 0, 5 )
	end

	--ListUpdateContents( self.windowName.."PlayerTable")
	--ListSetDataTable( self.windowName.."PlayerTable", GuildPlrRoster.players.row)
end
--]]

--[[ -- Deprecated
function GuildPlrRoster.RowSelected()
	UO_GenericGump.debug( L"GuildPlrRoster.RowSelected called" )
	
	local buttonID = WindowGetId( SystemData.ActiveWindow.name )
	UO_GenericGump.debug( L"   selected window = "..StringToWString(SystemData.ActiveWindow.name)..L"  ID = "..buttonID )

end
--]]

--[[
-- Callback from the <List> that updates a single row.
function GuildPlrRoster.UpdatePlayerRow()    
    for rowIndex, dataIndex in ipairs (ScenarioSummaryWindowPlayerList.PopulatorIndices) do
        local playerData = GameData.ScenarioData.Players[ dataIndex ]
        local color = DataUtils.GetRealmColor( playerData.realm )
        WindowSetTintColor("ScenarioSummaryWindowPlayerListRow"..rowIndex.."Background", color.r, color.g, color.b);
    end        
end
--]]


----------------------------------------------------------------
-- GuildDiplomacy Functions
----------------------------------------------------------------



-- OnInitialize Handler
function GuildDiplomacy.Initialize()
	GuildDiplomacy:Init()
end



function GuildDiplomacy:setFields()

	GuildWindow.setFields(self)
--	ButtonSetPressedFlag( self.windowName.."DiplomacyTabButton", true )
	ButtonSetDisabledFlag( self.windowName.."DiplomacyTabButton", true )
	WindowSetShowing( self.windowName.."DiplomacyTabButtonTab", false )
	
	-- set bottom button labels and IDs
	--[[
	ButtonSetText(self.windowName.."InviteButton", GGManager.translateTID(1062992) ) -- Invite Player
	WindowSetId( self.windowName.."InviteButton", 900 )	
	ButtonSetText(self.windowName.."ResignButton", GGManager.translateTID(3006115) ) -- Resign
	WindowSetId( self.windowName.."ResignButton", 500 )	-- 500 // Resign (unconfirmed)
														-- 501 // Resign (confirmed)
	ButtonSetText(self.windowName.."KickButton", GGManager.translateTID(1062997) ) -- Kick
	WindowSetId( self.windowName.."KickButton", 104 )	-- 104 // Remove from Guild (unconfirmed)
														-- 106 Remove from Guild (confirmed)
	--]]
end


-- Expects the following values to be set in the calling object:
-- 		self.windowName (both of type string)
-- Inputs:
-- 		choiceNum should be of type number
-- 		wText should be of type WString
-- 
-- Returns: name of the choice text (window) created
--
-- THIS FUNCTION HAS BEEN DEPRECIATED.- IT IS NOT USED FOR GUMP_GUILD_DIPLOMACY!
function GuildDiplomacy:CreateChoiceListSelectableText( choiceNum, wText, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )

	--local choiceName = self.windowName..choiceNum
	local choiceName = self.windowName.."Desc"..choiceNum
	local scrollParent = self.windowName.."ScrollChild"
	--local labelName = choiceName.."Desc"
	local labelName = choiceName
	local templateName = "GuildSelectableText"

	CreateWindowFromTemplate( choiceName, templateName, scrollParent )       
	LabelSetText( labelName, wText )
	WindowAddAnchor( choiceName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	WindowSetId( choiceName, choiceNum )	
	
	
	UO_GenericGump.debug( L"called GuildDiplomacy:CreateChoiceListSelectableText with wText = "..wText..L" and ID = "..choiceNum )
	UO_GenericGump.debug( L"called GuildDiplomacy:CreateChoiceListSelectableText. choiceName = "..StringToWString(choiceName) )

	return choiceName
end


function GuildDiplomacy:CreateGuildDiplomacySelectable( choiceNum, wText1, wText2, wText3, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset, uniqueID )

	-- Create unique IDs for the window, use the unique ID if specified
	local mainName = ""
	if uniqueID then
		mainName = self.windowName.."Choice"..uniqueID
	else
		mainName = self.windowName.."Choice"..choiceNum
	end

-- UO_GenericGump.debug( L"Creating a choice: "..StringToWString(mainName) )

	-- Create unique IDs for the window's button, window's icon, and window's text
	local buttonName = mainName.."Button"
	local iconName   = mainName.."Icon"
	local text1Name  = mainName.."Text1"
	local text2Name  = mainName.."Text2"
	local text3Name  = mainName.."Text3"

	-- Define some locals used for resizing things
	local text1Xsize
	local text1Ysize
	local text2Xsize
	local text2Ysize
	local text3Xsize
	local text3Ysize
	local buttonXsize
	local mainXsize
	local mainYsize
	
	-- if no value is set for containerWindow (controls where the selectable text appears),
	local containerWindow = self.windowName.."ScrollChild"
	
	-- Set the name of the template to use
	local mainTemplateName = "GuildDiplomacySelectable"

	-- Create the main window
	CreateWindowFromTemplate( mainName, mainTemplateName, containerWindow )
	-- Attach the main window to where it was told to be attached
	WindowAddAnchor( mainName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	-- Set the window to have it's ID
	WindowSetId( mainName, choiceNum )
	
	-- Set the text and then get it's dimensions
	LabelSetText( text1Name, wText1 ) -- Hardcode a long wide string here if you want to see this thing in action
	text1Xsize, text1Ysize = LabelGetTextDimensions( text1Name )
	LabelSetText( text2Name, wText2 ) -- Hardcode a long wide string here if you want to see this thing in action
	text2Xsize, text2Ysize = LabelGetTextDimensions( text2Name )
	LabelSetText( text3Name, wText3 ) -- Hardcode a long wide string here if you want to see this thing in action
	text3Xsize, text3Ysize = LabelGetTextDimensions( text3Name )
	
	-- Also save the size of the button and window
	buttonXsize = WindowGetDimensions( buttonName )
	mainXsize, mainYsize = WindowGetDimensions( mainName )
	
	if text1Ysize < text2Ysize then
		text1Ysize = text2Ysize
	end
	
	if text1Ysize < text3Ysize then
		text1Ysize = text3Ysize
	end
	
	-- use the maximum Y dimension, use the defualt value from the XML if the text doesn't line wrap.
	if mainYsize < text1Ysize then
		mainYsize = text1Ysize+19 -- fudge it 9.5 pixels above and below
	end
	
	-- Set the size of the window and the size of the background to the same thing
	-- One shows where to click, the other handles the click!
	WindowSetDimensions( mainName, mainXsize, mainYsize )
	WindowSetDimensions( buttonName, mainXsize, mainYsize )

	return mainName
end


function GuildDiplomacy:setDataFunction()
	
	local relativeWindow
	local case = -self.descData[self.descDataCount]
	local limit = self.stringDataCount-1
	if case == 8 then
		limit = limit - 1 
	end
	
	local stringItr	
	for stringItr=2, limit, 2 do
		if stringItr == 2 then
			relativeWindow = self:CreateGuildDiplomacySelectable(
							self.buttonIDs[(stringItr/2)+10],
							GGManager.stripMarkup( self.stringData[stringItr] ),
							GGManager.stripMarkup( self.stringData[stringItr+1] ),
							GGManager.translateTID( self.descData[6 + (stringItr/2) ] ),
				"topleft", self.windowName.."ScrollChild", "topleft", 0, 0 , stringItr )
		else
			relativeWindow = self:CreateGuildDiplomacySelectable(
							self.buttonIDs[(stringItr/2)+10],
							GGManager.stripMarkup( self.stringData[stringItr] ),
							GGManager.stripMarkup( self.stringData[stringItr+1] ),
							GGManager.translateTID( self.descData[6 + (stringItr/2) ] ),
				"bottomleft", relativeWindow, "topleft", 0, 0 , stringItr )
		end
	end

	-- Display current status text
	if case == 8 then
		LabelSetText( self.windowName.."ShowText", GGManager.stripMarkup( self.stringData[self.stringDataCount] ) )
	else
		LabelSetText( self.windowName.."ShowText", GGManager.translateTID( self.descData[self.descDataCount-2] ) )
	end

	-- And the current headers text
	LabelSetText( self.windowName.."TitlesSection1Text", GGManager.translateTID( self.descData[4] ) )
	LabelSetText( self.windowName.."TitlesSection2Text", GGManager.translateTID( self.descData[5] ) )
	LabelSetText( self.windowName.."TitlesSection3Text", GGManager.translateTID( self.descData[6] ) )

	-- Display the button to change current status
	ButtonSetText(self.windowName.."ChangeButton", GGManager.translateTID( 3000127 ) ) -- L"Options" )	
	WindowSetId( self.windowName.."ChangeButton", self.buttonIDs[self.buttonCount] )

	-- Display the button to submit the search text
	ButtonSetText(self.windowName.."SubmitButton", GGManager.translateTID( 3006134 ) ) -- L"Search" )
	WindowSetId( self.windowName.."SubmitButton", self.buttonIDs[7] )
	
	-- Display the next and previous page buttons
	ButtonSetText(self.windowName.."NextButton", GGManager.translateTID( 1011066 ) ) -- L"Next Page" )
	WindowSetId( self.windowName.."NextButton", self.buttonIDs[5] )
	ButtonSetText(self.windowName.."PreviousButton", GGManager.translateTID( 1061028 ) ) -- L"Previous Page" )
	WindowSetId( self.windowName.."PreviousButton", self.buttonIDs[4] )

	-- Disable them if they aren't to be seen
	if  self.buttonIDs[4] == 0 then
		WindowSetShowing( self.windowName.."PreviousButton", false)
	end
	if  self.buttonIDs[5] == 0 then
		WindowSetShowing( self.windowName.."NextButton", false)
	end
	
	WindowSetId( self.windowName.."TitlesSection1", self.buttonIDs[8] ) 
	WindowSetId( self.windowName.."TitlesSection2", self.buttonIDs[9] ) 
	WindowSetId( self.windowName.."TitlesSection3", self.buttonIDs[10] ) 

	if case == 0 then -- Show U in col 0
		WindowSetShowing( self.windowName.."TitlesSection1IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
	elseif case == 1 then -- Show U in col 1
		WindowSetShowing( self.windowName.."TitlesSection2IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
	elseif case == 2 then -- Show U in col 2
		WindowSetShowing( self.windowName.."TitlesSection3IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
	elseif case == 3 then -- Show D in col 0
		WindowSetShowing( self.windowName.."TitlesSection1IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
	elseif case == 4 then -- Show D in col 1
		WindowSetShowing( self.windowName.."TitlesSection2IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
	elseif case == 5 then -- Show D in col 2
		WindowSetShowing( self.windowName.."TitlesSection3IconRound", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
	else
		WindowSetShowing( self.windowName.."TitlesSection1IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection1IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection2IconDown", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconUp", false )
		WindowSetShowing( self.windowName.."TitlesSection3IconDown", false )
	end
	
	TextEditBoxSetText( self.windowName.."SearchBox", self.stringData[1] )
	WindowAssignFocus(  self.windowName.."SearchBox", true)
	
end


function GuildDiplomacy.TextSelected() -- This function is only used for the search text broadcast

	local selectedWindow = SystemData.ActiveWindow.name
	local buttonID = WindowGetId( selectedWindow )
	local self = GuildWindowManager.getActiveWindowData()
	
	UO_GenericGump.debug( L"Called GD.TextSelected() with buttonID = "..buttonID )
	
	if buttonID == 750 then
		self:OnSubmit()
	end	
		self:OnCloseWindow()
end

function GuildDiplomacy:OnSubmit() 

	local self = GuildWindowManager.getActiveWindowData()	
	local buttonID = WindowGetId( self.windowName.."SubmitButton" )

	UO_GenericGump.debug(L"Called GD:OnSubmit with self = "..StringToWString(self.windowName) )
		
	local textEntries = {}
		local textBoxName = self.windowName.."SearchBox"
		local text = TextEditBoxGetText( textBoxName )
		local id = self.buttonIDs[6] -- WindowGetId( textBoxName )

		if text ~= nil and id ~= nil  then -- and text ~= ""
UO_GenericGump.debug( L"textbox 1 has string = "..text..L", ID = "..id)		
			textEntries[id] = text
		end
	
	UO_GenericGump.broadcastTextEntries( buttonID, textEntries, self )
	self:OnCloseWindow()
end
