----------------------------------------------------------------
-- AquariumContents.lua
----------------------------------------------------------------

AquariumContents = MasterGUMP:new()

function AquariumContents.Initialize()

	local newWindow					= AquariumContents:new()
	newWindow.setData				= AquariumContents.mySetData
	newWindow.SetIcon				= AquariumContents.mySetIcon
	newWindow:Init()
end

function AquariumContents:mySetData()
	self.Page = {}
	self.IsStandardHeight = true

	local itr
	local pageText
	if self.buttonCount > 0 then
		self.CreatePrevNextButtons = true
		for itr = 1, self.buttonCount / 3 do
			self.Page[itr] = {}
			self.Page[itr].Title = GGManager.translateTID( 1073837 ) -- "AQUARIUM CONTENTS"
			pageText = GGManager.stripMarkup( self.stringData[itr] )..L"\n\n"
			if self.descData[(5 * (itr - 1)) + 3] > 0 then
				pageText = pageText..GGManager.translateTID( self.descData[(5 * (itr - 1)) + 3] )..L"\n\n"
			end
			if self.descData[(5 * (itr - 1)) + 4] > 0 then
				pageText = pageText..GGManager.translateTID( self.descData[(5 * (itr - 1)) + 4] )
			end
			self.Page[itr].ScrollText = pageText
			if self.descData[5 * itr] > 0 then -- Show a remove button
				self.Page[itr].LeftButtonId	= self.buttonIDs[3 * itr]
				self.Page[itr].LeftButtonText = GGManager.translateTID( self.descData[5 * itr] )
				self.Page[itr].RightButtonId = 0
				self.Page[itr].RightButtonText = GGManager.translateTID( 1061046 ) -- "Close"
			else
				self.Page[itr].MiddleButtonId = 0
				self.Page[itr].MiddleButtonText = GGManager.translateTID( 1061046 ) -- "Close"
			end

			self.Page[itr].SelectionTemplate = "AquariumSelectable"
			self.Page[itr].Selections = {}
			self.Page[itr].Selections[1] = {}
			self.Page[itr].Selections[1].Icon = self.ImageNum[itr]
			self.Page[itr].Selections[1].Port = self.portImgData[1]
		end
	else -- NO FISH!
		self.Page[1] = {}
		self.Page[1].Title = GGManager.translateTID( 1073837 ) -- "AQUARIUM CONTENTS"
		self.Page[1].ScrollText = GGManager.translateTID( 1079215 )
		self.Page[1].MiddleButtonId = 0
		self.Page[1].MiddleButtonText = GGManager.translateTID( 1061046 ) -- "Close"
		self.Page[1].SelectionTemplate = "AquariumSelectable"
		self.Page[1].Selections = {}
		self.Page[1].Selections[1] = {}
		self.Page[1].Selections[1].Icon = 0
		self.Page[1].Selections[1].Port = self.portImgData[1]
	end
end


function AquariumContents:mySetIcon( selection, choiceName )

-- Some variables!
	local texture, x, y, scale, newWidth, newHeight = "0000", 0, 0, 1, 0, 0

-- The tank!
	self.RequestedTextures = self.RequestedTextures or {}
	texture, x, y, scale, newWidth, newHeight = RequestTexture( selection.Port, 280, 200 )
	self.RequestedTextures[table.getn( self.RequestedTextures ) + 1] = selection.Port	
	UO_GenericGump.debug( L"     tank texture = "..StringToWString( tostring( texture ) ) )
	WindowSetDimensions( choiceName.."IconHolderTwoIcon", newWidth, newHeight )
	DynamicImageSetTexture( choiceName.."IconHolderTwoIcon", texture, x, y )
	DynamicImageSetTextureScale( choiceName.."IconHolderTwoIcon", scale )	

-- The fish!
	if selection.Icon > 0 then
		self.RequestedTileArt = self.RequestedTileArt or {}
		texture, x, y, scale, newWidth, newHeight = RequestTileArt( selection.Icon, 280, 200 )
		UO_GenericGump.debug( L"     fish texture = "..StringToWString( tostring( texture ) ) )
		self.RequestedTileArt[table.getn( self.RequestedTileArt ) + 1] = selection.Icon
		WindowSetDimensions( choiceName.."IconHolderIcon", newWidth, newHeight )
		DynamicImageSetTexture( choiceName.."IconHolderIcon", texture, x, y )
		DynamicImageSetTextureScale( choiceName.."IconHolderIcon", scale )
	else -- NO FISH
		WindowSetShowing( choiceName.."IconHolderIcon", false )
	end
end
