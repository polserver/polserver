----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

VRConfirm = TwoButtonDialog:new()

----------------------------------------------------------------
-- VRConfirm Functions
----------------------------------------------------------------

function VRConfirm:parseData()
	self.text = GGManager.translateTID( self.descData[1] )..L"\n"..GGManager.translateTID( self.descData[6] )
				..L"\n\n"..GGManager.translateTID( self.descData[2] )..L"\n"..self.stringData[1]
				..L"\n\n"..GGManager.translateTID( self.descData[3] )

	self.leftButtonName = GGManager.translateTID( GGManager.OKAY_TID )
	self.rightButtonName = GGManager.translateTID( GGManager.CANCEL_TID )
	self.leftButtonID = self.buttonIDs[2]
	self.rightButtonID = self.buttonIDs[1]	
end

-- OnInitialize Handler
function VRConfirm.Initialize()
	local newWindow = VRConfirm:new()
	newWindow.setDataFunction = VRConfirm.parseData
	newWindow:Init()
end
