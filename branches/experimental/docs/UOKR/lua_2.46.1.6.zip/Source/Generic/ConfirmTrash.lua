
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

ConfirmTrash = { }


----------------------------------------------------------------
-- ConfirmTrash Functions
----------------------------------------------------------------

-- OnInitialize Handler
function ConfirmTrash.Initialize()
	-- setDataFunction is called in TwoButtonDialog:init(), 
	--   most TwoButtonDialogs can use  either parseDescAsTextAndTwoButtons or parseDescAsTitleTextAndTwoButtons
	ConfirmTrash.setDataFunction = TwoButtonDialog.parseDescAsTitleTextAndTwoButtons
	TwoButtonDialog.Init(ConfirmTrash)
end
	


