
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

ValidateTeleport = { 

	LEFT_BUTTON_ID = 1, --yes
	RIGHT_BUTTON_ID = 0, -- no
	-- BUTTON_ID = 7, -- server may expect 7 for OKAY button too
}


----------------------------------------------------------------
-- ValidateTeleport Functions
----------------------------------------------------------------

-- OnInitialize Handler
function ValidateTeleport.Initialize()
	-- setDataFunction is called in TwoButtonDialog.Init, 
	--   most TwoButtonDialogs can use  either parseDescAsTextAndTwoButtons or parseDescAsTitleTextAndTwoButtons
	ValidateTeleport.setDataFunction = TwoButtonDialog.parseDescAsTitleTextAndTwoButtons
	TwoButtonDialog.Init(ValidateTeleport)
end
	


