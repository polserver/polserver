
----------------------------------------------------------------
-- SpecialDyes
----------------------------------------------------------------

SpecialDyes = { }

SpecialDyesManager = GGManager


-- OnInitialize Handler
function SpecialDyes.Initialize()

	local dyes = SpecialDyes:new()
	dyes:Init()
end

function SpecialDyes:new( dyes )

	dyes = dyes or {}
	setmetatable( dyes, self )
	self.__index = self
	
	dyes.rightChildren = {}

	return dyes
end

function SpecialDyes:Init()
		
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end

	if self.setFields then
		self:setFields()
	end
	
	SpecialDyesManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end


function SpecialDyes:setDataFunction()
		
	--Cancel button
	local buttonName = self.windowName.."BottomButton"
	ButtonSetText( buttonName, GGManager.translateTID( GGManager.CANCEL_TID))
	WindowSetId( buttonName, 0 ) -- Cancel id magic number since 0 isn't passed in

	-- descData[1] is text for the subtitle 
	LabelSetText( self.windowName.."Subtitle", GGManager.translateTID( self.descData[1] ) )

	-- Page 0 = "Left Page"
	relativeWindow = self.windowName.."ScrollChild"
	
	local descItr		= self.buttonPageIndex[1] + 2 -- Skip over buttons' labels and Subject
	local descItrEnd	= self.buttonPageIndex[2]
	local pageItr		= -1
	
	relativeWindow = SpecialDyes:CreateSelectableText1( pageItr, GGManager.translateTID( self.descData[descItr] ), "top", relativeWindow, "top", 0, 10 )
	pageItr = pageItr - 1
	
	for descItr=descItr+1, descItrEnd do
		relativeWindow = SpecialDyes:CreateSelectableText1( pageItr, GGManager.translateTID( self.descData[descItr] ), "bottom", relativeWindow, "top", 0, 10 )
		pageItr = pageItr - 1
	end
	
	-- Page 1+ = right side pages
	pageItr = -1
	
	for page=2, table.getn( self.buttonPageIndex ) do
	
		local descItr		= self.buttonPageIndex[page]
		local descItrEnd	= self.buttonCount
		
		if page < table.getn( self.buttonPageIndex ) then
			descItrEnd	= self.buttonPageIndex[page+1] - 1
		end
		
		buttonItr = self.buttonPageIndex[page]
		
		local rightScroll		= self.windowName.."Scroll"..page
		local rightScrollChild	= rightScroll.."Child"

		CreateWindowFromTemplate( rightScroll,	"SpecialDyesRightScroll", self.windowName )
		WindowAddAnchor( rightScroll, "bottom", self.windowName.."Subtitle", "top", 0, 10 )
		
		UO_GenericGump.debug( L"SpecialDyes:SetDataFunction() Hues = "..self.buttonIDs[buttonItr])
			
		relativeWindow = SpecialDyes:CreateSelectableText2( self.buttonIDs[buttonItr],  L"     ",  "top", rightScrollChild, "top", 0, 10, page, true )
		buttonItr = buttonItr + 1

		for descItr=descItr+1, descItrEnd do
			relativeWindow = SpecialDyes:CreateSelectableText2( self.buttonIDs[buttonItr], L"     " , "bottom", relativeWindow, "top", 0, 10, page, true )
			buttonItr = buttonItr + 1
		end

		WindowSetShowing( rightScroll, false )
		self.rightChildren[pageItr] = rightScroll
		pageItr = pageItr - 1
	end
end	

function SpecialDyes:CreateSelectableText1( choiceNum, wText, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset, myPage, isRight )

	local windowName	= WindowUtils.GetActiveDialog()
	local choiceName	= windowName.."Choice"..choiceNum
	local parentName	= windowName.."ScrollChild"
		
	if isRight then
		parentName	= windowName.."Scroll"..myPage.."Child"
	end
	
	if	myPage
	and myPage ~= ""
	and not isRight then
		parentName	= parentName..myPage
	end
		
	CreateWindowFromTemplate( choiceName, "SpecialDyesSelectable", parentName )
	WindowAddAnchor( choiceName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	WindowSetId( choiceName, choiceNum )
	LabelSetText( choiceName.."Text" , wText )
		
	return choiceName
end

function SpecialDyes:CreateSelectableText2( choiceNum, wText, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset, myPage, isRight )

	local windowName	= WindowUtils.GetActiveDialog()
	local choiceName	= windowName.."Choice"..choiceNum
	local parentName	= windowName.."ScrollChild"
		
	if isRight then
		parentName	= windowName.."Scroll"..myPage.."Child"
	end
	
	if	myPage
	and myPage ~= ""
	and not isRight then
		parentName		= parentName..myPage
	end
		
	CreateWindowFromTemplate( choiceName, "SpecialDyesSelectable2", parentName )
	WindowAddAnchor( choiceName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	WindowSetId( choiceName, choiceNum )
	LabelSetText( choiceName.."Text2" , wText )
								
	local r, g, b, a = HueRGBAValue( choiceNum)
	WindowSetTintColor( choiceName.."Icon", r, g, b )
	
	return choiceName
end

function SpecialDyes.TextPressed()

	local self = SpecialDyesManager.knownWindows[WindowUtils.GetActiveDialog()]
	self:TextSelected()
end

function SpecialDyes:TextSelected()

	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	UO_GenericGump.debug( L"SpecialDyes:TextSelected() choiceNum = "..choiceNum )

	if choiceNum == 0 then -- cancel button
		UO_GenericGump.broadcastSelections( 0, { }, self )
		self.OnCloseWindow()
		return
	end
	
	if choiceNum > 0 then -- dye selection
		UO_GenericGump.broadcastSelections( self.buttonIDs[1], { choiceNum }, self )
		self.OnCloseWindow()
		return
	end

	local pageItr = -1
	local pageItrEnd = -SpecialDyes.getTableSize( self.rightChildren )
	
	while pageItr >= pageItrEnd do
		WindowSetShowing( self.rightChildren[pageItr], (pageItr == choiceNum) )
		pageItr = pageItr - 1
	end
end

function SpecialDyes.OnCloseWindow()

	UO_GenericGump.debug( L"SpecialDyes.OnCloseWindow() called." )
	
	GGManager.destroyActiveWindow()
end

function SpecialDyes.getTableSize( table )

	local count = 0
	
	for _, _ in pairs( table ) do
		count = count + 1
	end
	
	return count
end
