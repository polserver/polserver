----------------------------------------------------------------
-- MadmageAndrewsCard.lua
----------------------------------------------------------------

MadmageAndrewsCard = {}
MadmageAndrewsCardManager = GGManager

function MadmageAndrewsCard.Initialize()
	local fortune = MadmageAndrewsCard:new()
	fortune:Init()
end

function MadmageAndrewsCard:new( fortune )
	fortune = fortune or {}
	setmetatable( fortune, self )
	self.__index = self
	return fortune
end

function MadmageAndrewsCard:Init()
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	if self.setDataFunction then
		self:setDataFunction()
	end
	MadmageAndrewsCardManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end

function MadmageAndrewsCard:setDataFunction()
	texture, x, y, scale, newWidth, newHeight = RequestTexture( tonumber( self.portImgData[1] ), 256, 256 )
	DynamicImageSetTexture( self.windowName.."MiddleIcon", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."MiddleIcon", scale )
end

function MadmageAndrewsCard.OnShutdown()
	local self = MadmageAndrewsCardManager.knownWindows[WindowUtils.GetActiveDialog()]
	if self == nil then
		UO_GenericGump.debug( StringToWString( "Shutdown hander called for "..SystemData.ActiveWindow.name.." but data already deleted" ) )
		return
	end	
	
	ReleaseTexture( tonumber( self.portImgData[1] ) )
	
	GGManager.unregisterActiveWindow()
end

function MadmageAndrewsCard.OnCloseWindow()
	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )
end
