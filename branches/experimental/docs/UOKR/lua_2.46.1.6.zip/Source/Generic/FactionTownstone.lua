----------------------------------------------------------
-- FactionTownstone.lua
----------------------------------------------------------------

FactionTownstone = MasterGUMP:new()

function FactionTownstone.Initialize()

	local newWindow					= FactionTownstone:new()
	newWindow.setData				= FactionTownstone.setDataFunc
	newWindow:Init()
end

function FactionTownstone:setDataFunc()

	self.Page[1] = {}
	
	self.Page[1].Subtitle			= GGManager.translateTID( self.descData[1] )

	self.Page[1].Selections	= {}

	-- Hire Sheriff
	self.Page[1].Selections[1]			= {}
	self.Page[1].Selections[1].Id		= self.buttonIDs[1]
	self.Page[1].Selections[1].Text		= GGManager.translateTID( self.descData[2] )
	-- Hire Finance Minister
	self.Page[1].Selections[2]			= {}
	self.Page[1].Selections[2].Id		= self.buttonIDs[2]
	self.Page[1].Selections[2].Text		= GGManager.translateTID( self.descData[3] )
	-- Fire Sheriff
	self.Page[1].Selections[3]			= {}
	self.Page[1].Selections[3].Id		= self.buttonIDs[3]
	self.Page[1].Selections[3].Text		= GGManager.translateTID( self.descData[4] )
	-- Fire Finance Minister
	self.Page[1].Selections[4]			= {}
	self.Page[1].Selections[4].Id		= self.buttonIDs[4]
	self.Page[1].Selections[4].Text		= GGManager.translateTID( self.descData[5] )
	
	
	self.Page[1].MiddleButtonId		= self.buttonIDs[5]
	self.Page[1].MiddleButtonText	= GGManager.translateTID( self.descData[6] )
end
