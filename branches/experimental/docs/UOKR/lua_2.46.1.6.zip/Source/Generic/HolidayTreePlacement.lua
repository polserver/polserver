--------------------------------------------------------------------------
-- HolidayTreePlacement.lua
--------------------------------------------------------------------------

HolidayTreePlacement = MasterGUMP:new()

function HolidayTreePlacement.Initialize()
	local newWindow					= HolidayTreePlacement:new()
	newWindow.setData				= HolidayTreePlacement.mySetData
	newWindow:Init()
end

function HolidayTreePlacement:mySetData()
	self.Page				= {}
	self.Page[1]			= {}
	self.Page[1].Selections	= {}

	self.Page[1].Selections[1]			= {}
	self.Page[1].Selections[1].Id		= self.buttonIDs[1]
	self.Page[1].Selections[1].Text		= GGManager.translateTID( self.descData[1] )
	
	self.Page[1].Selections[2]			= {}
	self.Page[1].Selections[2].Id		= self.buttonIDs[2]
	self.Page[1].Selections[2].Text		= GGManager.translateTID( self.descData[2] )
	
	self.Page[1].MiddleButtonId			= 0
	self.Page[1].MiddleButtonText		= GGManager.translateTID( GGManager.CANCEL_TID )
end
