----------------------------------------------------------
-- VaCloakQuest.lua
----------------------------------------------------------------

VaCloakQuest = MasterGUMP:new()



function VaCloakQuest.Initialize()

	local newWindow					= VaCloakQuest:new()
	newWindow.setData				= VaCloakQuest.mySetData
	newWindow:Init()
end

function VaCloakQuest:finalize()
	MasterGUMP.finalize(self)
	
	
end



function VaCloakQuest:mySetData()

	self.Page	= {}
	

	for pageNum, _ in ipairs( self.stringPageIndex )
	do
		self.Page[pageNum] = {}
		
		self.Page[pageNum].Title = GGManager.translateTID( self.descData[1] )
		if self.descDataCount > 4 then
			if self.buttonCount ==1 then
					self.Page[pageNum].Subtitle =  GGManager.translateTID( self.descData[5] )
					self.Page[pageNum].ScrollText = GGManager.translateTID( self.descData[2] )
			elseif self.buttonCount ==2 then
					self.Page[pageNum].Subtitle =  GGManager.translateTID( self.descData[6] )
					self.Page[pageNum].ScrollText = GGManager.translateTID( self.descData[2] )
			end
		else
			self.Page[pageNum].ScrollText = GGManager.translateTID( self.descData[2] )	
		end
		

		if self.buttonCount == 0 then
			self.Page[pageNum].MiddleButtonId = 1
			self.Page[pageNum].MiddleButtonText = GGManager.translateTID( 1011036)	
		elseif self.buttonCount == 1 then
			self.Page[pageNum].MiddleButtonId = self.buttonIDs[1]
			self.Page[pageNum].MiddleButtonText = GGManager.translateTID(  self.descData[3])
		elseif self.buttonCount == 2 then
			self.Page[pageNum].LeftButtonId = self.buttonIDs[1]
			self.Page[pageNum].LeftButtonText = GGManager.translateTID(  self.descData[3])
			self.Page[pageNum].RightButtonId = self.buttonIDs[2]
			self.Page[pageNum].RightButtonText = GGManager.translateTID(  self.descData[4])
		end

		
	end
end
