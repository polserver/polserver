
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

Multipage = {}

MultipageManager = GGManager


----------------------------------------------------------------
-- Multipage (Manager) Functions
----------------------------------------------------------------


function Multipage:SetCurrentPage(pageNum)

	for i=1, table.getn(self.Page) do
		WindowSetShowing( self.Page[i].pageName, (i == pageNum) )	
	end
	
	self.currentPage = pageNum
end

function Multipage:Init()
	
	UO_GenericGump.debug( L"called Multipage.Init(self)" )
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	
	if self.setDataFunction then
		self:setDataFunction()
	end
	
	self:setFields()
	
	MultipageManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
	
	Debug.PrintToDebugConsole( L"Initialize "..self.name )
end


function Multipage:setFields()

	for pageNum=1, table.getn(self.Page) do
	
		local pageName = self.Page[pageNum].pageName
		UO_GenericGump.debug( L"Multipage:setFields: setting values for "..StringToWString(pageName))
		
		if self.Page[pageNum].title then
			WindowUtils.SetActiveDialogTitle( self.Page[pageNum].title )
		--	LabelSetText(pageName.."Chrome_UO_WindowTitle", self.Page[pageNum].title)
		end
		if self.Page[pageNum].subtitle then
			LabelSetText( pageName.."Subtitle", self.Page[pageNum].subtitle )
		end
		LabelSetText( pageName.."ScrollChildText", self.Page[pageNum].text )
		ButtonSetText( pageName.."LeftButton", self.Page[pageNum].leftButtonName )
		WindowSetId( pageName.."LeftButton", self.Page[pageNum].leftButtonID )	
		ButtonSetText( pageName.."RightButton", self.Page[pageNum].rightButtonName )
		WindowSetId(  pageName.."RightButton", self.Page[pageNum].rightButtonID )	
		
		WindowSetId( pageName.."PrevButton", self.Page[pageNum].prevButtonID )	
		WindowSetId( pageName.."NextButton", self.Page[pageNum].nextButtonID )	
		
		-- *** KLUDGE - the size of the subtitle was causing the text to not scroll
		--   to the bottom.
		local subtitle_width, subtitle_height = WindowGetDimensions( pageName.."Subtitle" )
		local text_width, text_height = WindowGetDimensions( pageName.."ScrollChildText" )	
		WindowSetDimensions( pageName.."ScrollChildText", text_width, text_height+subtitle_height )
	end
	
	-- hide previous button for first page
	--WindowSetShowing( self.Page[1].pageName.."PrevButton", false )
	
	-- disable previous button for first page
	ButtonSetDisabledFlag( self.Page[1].pageName.."PrevButton", true )
	
	-- hide next button for last page
	--WindowSetShowing( self.Page[ table.getn(self.Page) ].pageName.."NextButton", false )
	
	-- disable next button for last page
	ButtonSetDisabledFlag( self.Page[ table.getn(self.Page) ].pageName.."NextButton", true )
	
	--WindowSetShowing( self.windowName, false )
	Multipage.SetCurrentPage(self, 1)
end


function Multipage.getActiveWindowData()
	--WindowName = WindowGetParent(WindowGetParent(SystemData.ActiveWindow.name))
	WindowName = WindowUtils.GetActiveDialog()
	
	--UO_GenericGump.debug( L"Multipage.getActiveWindowData() returning data for: "..StringToWString(WindowName))
	return MultipageManager.knownWindows[WindowName]
end



----------------------------------------------------------------
-- Multipage Functions
----------------------------------------------------------------

-- returns a table containing NumOfPages of inner tables as .Page[1] to .Page[NumOfPages]
function Multipage:new(NumOfPages)

	local NewDialog = {}
	setmetatable(NewDialog, self)
	self.__index = self

	NewDialog.Page = {}
	
	for i=1, NumOfPages do
		local NewPage = {}
		NewDialog.Page[i] = NewPage
	end
	
	return NewDialog
end


function Multipage.LeftButtonPressed()
	
	self = Multipage.getActiveWindowData()
	
	-- specialized windows can declare their own LeftButtonFunction() or else just
	--   make sure to set or inherit button IDs to be returned
	if  self.LeftButtonFunction then
		self:LeftButtonFunction()
	else
		self:DefaultButtonFunction()
	end	
end


--
function Multipage.RightButtonPressed()
	
	self = Multipage.getActiveWindowData()
	
	
	-- specialized windows can declare their own RightButtonFunction() or else just
	--   make sure to set or inherit button IDs to be returned
	if  self.RightButtonFunction then
		self:RightButtonFunction()
	else
		--UO_GenericGump.debug( L"ERROR in Multipage.RightButtonPressed(): could not determine window for button pressed.")
		self:DefaultButtonFunction()
	end	
end



function Multipage:DefaultButtonFunction()
	
	self = Multipage.getActiveWindowData()
	buttonID = WindowGetId( SystemData.ActiveWindow.name )
	if not buttonID then	
		Debug.PrintToDebugConsole( L"ERROR in Multipage.DefaultButtonFunction: no ID set for button pressed." )
		return
	end
	UO_GenericGump.debug( L"called Multipage.DefaultButtonFunction(). Sending button value of "..buttonID )
	UO_GenericGump.debug( L"called Multipage.DefaultButtonFunction(). Sending data for window  "..self.name )

	UO_GenericGump.broadcastButtonPress( buttonID, self )
	self.OnCloseWindow()
end



function Multipage.PrevNextButtonPressed()
	if ButtonGetDisabledFlag( SystemData.ActiveWindow.name ) then
		UO_GenericGump.debug( L"Multipage.PrevNextButtonPressed: clicked on disabled button.")
		return
	end
	buttonID = WindowGetId( SystemData.ActiveWindow.name )
	if not buttonID then	
		Debug.PrintToDebugConsole( L"ERROR in Multipage.DefaultButtonFunction: no ID set for button pressed." )
		return
	end
	--UO_GenericGump.debug( L"called Multipage.PrevNextButtonPressed. Changing to Page: "..buttonID )

	local self = Multipage.getActiveWindowData()
	self:SetCurrentPage( buttonID )
end


--
function Multipage.OnCloseWindow()
	UO_GenericGump.debug( L"Multipage.OnCloseWindow.")
	GGManager.destroyActiveWindow()
end



