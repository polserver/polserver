
----------------------------------------------------------------
-- CommunityCollections
----------------------------------------------------------------

ConfirmPic = {}

ConfirmPicManager = GGManager

function ConfirmPic.Initialize()

	local confirmPic = ConfirmPic:new()
	confirmPic:Init()
end

function ConfirmPic:new( confirmPic )

	confirmPic = confirmPic or {}
	setmetatable( confirmPic, self )
	self.__index = self

	return confirmPic
end

function ConfirmPic:Init()

	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end
	
	ConfirmPicManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end

function ConfirmPic:setDataFunction()
	
	-- descData[1] is the title
	WindowUtils.SetActiveDialogTitle( GGManager.translateTID( self.descData[1] ) )
	
	-- the subtitle
	LabelSetText( self.windowName.."Subtitle", GGManager.translateTID( self.descData[2] ) )

	-- the pic
	local texture, x, y, scale, newWidth, newHeight = RequestTileArt( self.ImageNum[1], 64, 64 )

	if scale == 1 then
		scale = 1.28
		newWidth = newWidth * scale
		newHeight = newHeight * scale
	end
	
	WindowSetDimensions( self.windowName.."Icon", newWidth, newHeight )
	
	DynamicImageSetTexture     ( self.windowName.."Icon", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."Icon", scale )
	
	local hue = self.textHueData[1]
	if hue ~= 0 then
	
		local r, g, b, a = HueRGBAValue(hue)
		WindowSetTintColor( self.windowName.."Icon", r, g, b )
	end
	
	self.Tooltips = self.Tooltips or {}
	self.Tooltips[self.windowName.."Icon"] = self.toolTipData[1]

	-- yes button
	ButtonSetText( self.windowName.."LeftButton", GGManager.translateTID( self.descData[3] ) )
	WindowSetId( self.windowName.."LeftButton", self.buttonIDs[1] )
	
	-- no button
	ButtonSetText( self.windowName.."RightButton", GGManager.translateTID( self.descData[4] ) )
	WindowSetId( self.windowName.."RightButton", self.buttonIDs[2] )
end

function ConfirmPic.LRButtonPressed()

	local self = ConfirmPicManager.knownWindows[WindowUtils.GetActiveDialog()]
	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	
	UO_GenericGump.debug( L"ConfirmPic:TextSelected() choiceNum = "..choiceNum )
	
	UO_GenericGump.broadcastSelections( self.buttonIDs[3], { choiceNum }, self )
	self.OnCloseWindow()
end

function ConfirmPic.OnCloseWindow()

	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )	
end

function ConfirmPic.OnShutdown()

	local self = GGManager.knownWindows[SystemData.ActiveWindow.name]	
	if self == nil then
		UO_GenericGump.debug( StringToWString( "Shutdown hander called for "..SystemData.ActiveWindow.name.." but data already deleted" ) )
		return
	end	
	
	if self.ImageNum and self.ImageNum[1] then
		ReleaseTileArt( self.ImageNum[1] )
	end
	
	GGManager.unregisterActiveWindow()
end

function ConfirmPic.OnMouseOver()

	local self = ConfirmPicManager.knownWindows[WindowUtils.GetActiveDialog()]
	local name = SystemData.ActiveWindow.name
	
	if self ~= nil then
		Tooltips.CreateTextOnlyTooltip( name, GGManager.translateTID( self.Tooltips[name] ) )
		Tooltips.Finalize()
		Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_TOP )
	end 
end
