----------------------------------------------------------
-- SelectPetition.lua
----------------------------------------------------------------

SelectPetition = MasterGUMP:new()



function SelectPetition.Initialize()

	local newWindow					= SelectPetition:new()
	newWindow.setData				= SelectPetition.mySetData
	newWinow.NextButtonPressed		= SelectPetition.NextButtonPressed
	newWindow:Init()
end

function SelectPetition:finalize()
	MasterGUMP.finalize(self)
	
	Interface.OnCloseCallBack[self.windowName] = SelectPetition.RightButtonPressed
	
	--Creates Prev Button if needed
	if self.buttonIDs[8] == 2 then
	
		ButtonSetDisabledFlag( self.windowName.."PrevButton", false )
		CreateWindowFromTemplate( self.windowName.."PrevButton", "selectPrevButton", self.windowName )
		WindowSetId( self.windowName.."PrevButton", 2 )
		
	else
		ButtonSetDisabledFlag( self.windowName.."PrevButton", true )
		UO_GenericGump.debug( L"Prev button doesn't work")
	end
	
	--Creates Next Button if needed
	if self.buttonIDs[9] == 3 then
	
		CreateWindowFromTemplate( self.windowName.."NextButton", "selectNextButton", self.windowName )
		WindowSetId( self.windowName.."NextButton", 3 )
		ButtonSetDisabledFlag( self.windowName.."NextButton", false )
		
	else
		ButtonSetDisabledFlag( self.windowName.."NextButton", true )
	end
	


end

function SelectPetition.PrevButtonPressed()
	UO_GenericGump.debug( L"SelectPetition:Prev   ButtonPressed()")
	SelectPetition.PNButtonPressed()
end

function SelectPetition.NextButtonPressed()
	UO_GenericGump.debug( L"SelectPetition:Next   ButtonPressed()")
	SelectPetition.PNButtonPressed()
end

function SelectPetition.PNButtonPressed()

	UO_GenericGump.debug( L"SelectPetition:PNButtonPressed()")

	local self = MasterGUMPManager.knownWindows[WindowUtils.GetActiveDialog()]
	local choiceId	= WindowGetId( SystemData.ActiveWindow.name )
	
	if  choiceId
	and choiceId > -1 then
	--	UO_GenericGump.debug( L"Select Petition:LMRButtonPressed() choiceId = "..StringToWString( tostring( choiceId ) ) )
		UO_GenericGump.broadcastButtonPress( choiceId, self )
		self.OnCloseWindow()
	end
	

end


function SelectPetition:mySetData()

	UO_GenericGump.debug( L"In mySetData function")
		
	self.Page	= {}
	
	self.IsStandardHeight = true
	
	--self.CreatePrevNextButtons = true

	for pageNum, _ in ipairs( self.stringPageIndex )
	do
		self.Page[pageNum] = {}
		
		local strItr	= self.stringPageIndex[pageNum]
		local strItrEnd	= self.stringDataCount
		if pageNum ~= table.getn( self.descPageIndex )
		then
			strItrEnd = self.stringPageIndex[pageNum + 1] - 1
		end
		
		self.Page[pageNum].Subtitle = GGManager.translateTID( self.descData[1] )
		self.Page[pageNum].ScrollText = GGManager.translateTID( self.descData[2] )
	
		self.Page[pageNum].Selections	= {}
		
		local index = 1
		while strItr <= strItrEnd
		do
			self.Page[pageNum].Selections[index]		= {}
			self.Page[pageNum].Selections[index].Id		= self.buttonIDs[strItr+2]
			self.Page[pageNum].Selections[index].Text	= self.stringData[strItr] --GGManager.translateTID( self.descData[strItr] )
			
			index = index + 1
			strItr = strItr + 1
		end

		self.Page[pageNum].LeftButtonId = self.buttonIDs[1]
		self.Page[pageNum].LeftButtonText = GGManager.translateTID( 1011036 )
	
		
		self.Page[pageNum].RightButtonId = self.buttonIDs[2]
		self.Page[pageNum].RightButtonText = GGManager.translateTID( 1011012 )



	--	ButtonSetDisabledFlag( self.windowName.."PrevButton", true )
		--ButtonSetDisabledFlag( self.windowName.."NextButton", true )
--[[
	if self.stringDataCount >5 then
		UO_GenericGump.debug( L"Setting PrevNext button StringDataCount is:"..self.stringDataCount)

		ButtonSetDisabledFlag( self.windowName.."PrevButton", false )
		ButtonSetDisabledFlag( self.windowName.."NextButton", false )
	else
		ButtonSetDisabledFlag( self.windowName.."PrevButton", true )
		ButtonSetDisabledFlag( self.windowName.."NextButton", true )
	end
]]--
		
	end
end
