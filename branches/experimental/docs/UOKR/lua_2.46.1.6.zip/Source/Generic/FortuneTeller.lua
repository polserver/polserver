----------------------------------------------------------------
-- FortuneTeller.lua
----------------------------------------------------------------

FortuneTeller = TextEntry:new()

function FortuneTeller.Initialize()

	local newWindow = FortuneTeller:new()
	newWindow:Init()
end

function FortuneTeller:setDataFunction()

	-- the title
	WindowUtils.SetActiveDialogTitle( GGManager.translateTID( self.descData[1] ) )

	-- the subtitle
	LabelSetText( self.windowName.."Subtitle", GGManager.translateTID( self.descData[2] ) )

	-- the textbox
--	TextEditBoxSetText( self.windowName.."TextBox", "" )
	WindowSetId( self.windowName.."TextBox", self.buttonIDs[1] )	

	-- left button
	ButtonSetText( self.windowName.."LeftButton", GGManager.translateTID( self.descData[4] ) )
	WindowSetId( self.windowName.."LeftButton", self.buttonIDs[3] )

	-- right button
	ButtonSetText( self.windowName.."RightButton", GGManager.translateTID( self.descData[3] ) )
	WindowSetId( self.windowName.."RightButton", self.buttonIDs[2] )
end

function FortuneTeller:setFields()
end

function FortuneTeller.LRButtonPressed()

	local self		= TextEntryManager.knownWindows[WindowUtils.GetActiveDialog()]
	local buttonID	= WindowGetId( SystemData.ActiveWindow.name )
	
	UO_GenericGump.debug( L"buttonID = "..buttonID )
	
	local textEntries = {}
	textEntries[self.buttonIDs[1]] = TextEditBoxGetText( self.windowName.."TextBox" )
	
	UO_GenericGump.broadcastTextEntries( buttonID, textEntries, self )
	self.OnCloseWindow()
end

function FortuneTeller.OnCloseWindow()
	GGManager.destroyActiveWindow()
end
