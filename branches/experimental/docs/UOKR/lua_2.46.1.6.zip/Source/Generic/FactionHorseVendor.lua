----------------------------------------------------------
-- FactionElect.lua
----------------------------------------------------------------

HorseVendor = TwoButtonDialog:new()

HorseVendorManager = GGManager

function HorseVendor.Initialize()

	local newWindow = HorseVendor:new()
	newWindow.setDataFunction = HorseVendor.mySetDataFunc
	newWindow:Init()
end

function HorseVendor:mySetDataFunc()

	self.subtitle			= GGManager.translateTID( self.descData[1] )
	self.text				= GGManager.translateTID( self.descData[2] )
	self.leftButtonName		= GGManager.translateTID( self.descData[3] )
	self.leftButtonID		= self.buttonIDs[1]
	self.rightButtonName	= GGManager.translateTID( self.descData[4] )
	self.rightButtonID		= self.buttonIDs[2]
	self.RequestedTileArt	= {}
	
	CreateWindowFromTemplate( self.windowName.."Horse", "Horse4Sale", self.windowName.."ScrollChild" )
	WindowAddAnchor( self.windowName.."Horse", "bottomleft", self.windowName.."ScrollChildText", "topleft", 0, 10 )
	
	local textureH, xH, yH, scaleH, widthH, heightH = RequestTileArt( tonumber( self.ImageNum[3] ), 96, 96 )
	self.RequestedTileArt[#self.RequestedTileArt + 1] = textureH

--	WindowSetDimensions( self.windowName.."HorseHorseIcon", widthH * 1.5, heightH * 1.5 )
	DynamicImageSetTexture( self.windowName.."HorseHorseIcon", textureH, xH, yH )
--	DynamicImageSetTextureScale( self.windowName.."HorseHorseIcon", scaleH * 1.5 )
	DynamicImageSetTextureScale( self.windowName.."HorseHorseIcon", 0.75 )
	
	local textureS, xS, yS, scaleS, widthS, heightS = RequestTileArt( tonumber( self.ImageNum[1] ), 45, 45 )
	self.RequestedTileArt[#self.RequestedTileArt + 1] = textureS

--	WindowSetDimensions( self.windowName.."HorseSilverIcon", widthS, heightS )
	DynamicImageSetTexture( self.windowName.."HorseSilverIcon", textureS, xS, yS )
--	DynamicImageSetTextureScale( self.windowName.."HorseSilverIcon", scaleS )
	LabelSetText( self.windowName.."HorseSilverText", self.stringData[1] )
	
	local textureG, xG, yG, scaleG, widthG, heightG = RequestTileArt( tonumber( self.ImageNum[2] ), 45, 45 )
	self.RequestedTileArt[#self.RequestedTileArt + 1] = textureG

--	WindowSetDimensions( self.windowName.."HorseGoldIcon", widthG, heightG )
	DynamicImageSetTexture( self.windowName.."HorseGoldIcon", textureG, xG, yG )
--	DynamicImageSetTextureScale( self.windowName.."HorseGoldIcon", scaleG )
	LabelSetText( self.windowName.."HorseGoldText", self.stringData[2] )
end

function HorseVendor.Shutdown()
	UO_GenericGump.debug( L"HorseVendor.Shutdown() called." )
	
	local self = HorseVendorManager.knownWindows[WindowUtils.GetActiveDialog()]	
	if self == nil then
		UO_GenericGump.debug( StringToWString( "Shutdown hander called for "..SystemData.ActiveWindow.name.." but data already deleted" ) )
		return
	end	
	
	-- Delete any requested Tile Art
	if self.RequestedTileArt then
		for _, art in pairs( self.RequestedTileArt ) do
			ReleaseTileArt( tonumber( art ) )
		end
	end
		
	GGManager.unregisterActiveWindow()
end

function HorseVendor.OnCloseWindow()
	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )
end
