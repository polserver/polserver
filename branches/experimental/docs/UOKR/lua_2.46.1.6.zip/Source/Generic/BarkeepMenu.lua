----------------------------------------------------------
-- BarkeepMenu.lua
----------------------------------------------------------------

BarkeepMenu = MasterGUMP:new()

function BarkeepMenu.Initialize()

	local newWindow					= BarkeepMenu:new()
	newWindow.setData				= BarkeepMenu.mySetData
	newWindow:Init()
end

function BarkeepMenu:mySetData()

	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Subtitle = GGManager.translateTID( self.descData[1] )
	self.Page[1].Selections = {}
	self.Page[1].Selections[1] = {}
	self.Page[1].Selections[1].Id = -2
	self.Page[1].Selections[1].Text = GGManager.translateTID( self.descData[2] )
	self.Page[1].Selections[2] = {}
	self.Page[1].Selections[2].Id = -8
	self.Page[1].Selections[2].Text = GGManager.translateTID( self.descData[3] )
	self.Page[1].Selections[3] = {}
	self.Page[1].Selections[3].Id = -3
	self.Page[1].Selections[3].Text = GGManager.translateTID( self.descData[4] )
	self.Page[1].MiddleButtonId = self.buttonIDs[4]
	self.Page[1].MiddleButtonText = GGManager.translateTID( GGManager.CANCEL_TID )

	self.Page[2] = {}
	self.Page[2].Subtitle = GGManager.translateTID( self.descData[1] )
	self.Page[2].Selections = {}
	self.Page[2].Selections[1] = {}
	self.Page[2].Selections[1].Id = -4
	self.Page[2].Selections[1].Text = GGManager.translateTID( self.descData[6] )
	self.Page[2].Selections[2] = {}
	self.Page[2].Selections[2].Id = -5
	self.Page[2].Selections[2].Text = GGManager.translateTID( self.descData[7] )
	self.Page[2].Selections[3] = {}
	self.Page[2].Selections[3].Id = -6
	self.Page[2].Selections[3].Text = GGManager.translateTID( self.descData[8] )
	self.Page[2].Selections[4] = {}
	self.Page[2].Selections[4].Id = -7
	self.Page[2].Selections[4].Text = GGManager.translateTID( self.descData[9] )
	self.Page[2].MiddleButtonId = -1
	self.Page[2].MiddleButtonText = GGManager.translateTID( self.descData[5] )

	self.Page[3] = {}
	self.Page[3].Subtitle = GGManager.translateTID( self.descData[1] )
	self.Page[3].ScrollText = GGManager.translateTID( self.descData[11] )
	self.Page[3].Selections = {}
	self.Page[3].Selections[1] = {}
	self.Page[3].Selections[1].Id = self.buttonIDs[10]
	self.Page[3].Selections[1].Text = GGManager.translateTID( self.descData[12] )
	self.Page[3].Selections[2] = {}
	self.Page[3].Selections[2].Id = -1
	self.Page[3].Selections[2].Text = GGManager.translateTID( self.descData[13] )

	self.Page[4] = {}
	self.Page[4].Subtitle = GGManager.translateTID( self.descData[1] )
	self.Page[4].ScrollText = GGManager.translateTID( 1078839 )
	self.Page[4].Selections = {}
	self.Page[4].Selections[1] = {}
	self.Page[4].Selections[1].Id = self.buttonIDs[13]
	self.Page[4].Selections[1].Text = GGManager.translateTID( self.descData[17] )..L": "..GGManager.stripMarkup( self.stringData[2] )..L"\n"..GGManager.translateTID( self.descData[16] )..L": "..GGManager.stripMarkup( self.stringData[1] )
	self.Page[4].Selections[2] = {}
	self.Page[4].Selections[2].Id = self.buttonIDs[14]
	self.Page[4].Selections[2].Text = GGManager.translateTID( self.descData[19] )..L": "..GGManager.stripMarkup( self.stringData[4] )..L"\n"..GGManager.translateTID( self.descData[18] )..L": "..GGManager.stripMarkup( self.stringData[3] )
	self.Page[4].Selections[3] = {}
	self.Page[4].Selections[3].Id = self.buttonIDs[15]
	self.Page[4].Selections[3].Text = GGManager.translateTID( self.descData[21] )..L": "..GGManager.stripMarkup( self.stringData[6] )..L"\n"..GGManager.translateTID( self.descData[20] )..L": "..GGManager.stripMarkup( self.stringData[5] )
	self.Page[4].MiddleButtonId = -2
	self.Page[4].MiddleButtonText = GGManager.translateTID( self.descData[5] )

	self.Page[5] = {}
	self.Page[5].Subtitle = GGManager.translateTID( self.descData[1] )
	self.Page[5].ScrollText = GGManager.translateTID( 1078840 )
	self.Page[5].Selections = {}
	self.Page[5].Selections[1] = {}
	self.Page[5].Selections[1].Id = self.buttonIDs[17]
	self.Page[5].Selections[1].Text = GGManager.translateTID( self.descData[25] )..L": "..GGManager.stripMarkup( self.stringData[2] )..L"\n"..GGManager.translateTID( self.descData[24] )..L": "..GGManager.stripMarkup( self.stringData[1] )
	self.Page[5].Selections[2] = {}
	self.Page[5].Selections[2].Id = self.buttonIDs[18]
	self.Page[5].Selections[2].Text = GGManager.translateTID( self.descData[27] )..L": "..GGManager.stripMarkup( self.stringData[4] )..L"\n"..GGManager.translateTID( self.descData[26] )..L": "..GGManager.stripMarkup( self.stringData[3] )
	self.Page[5].Selections[3] = {}
	self.Page[5].Selections[3].Id = self.buttonIDs[19]
	self.Page[5].Selections[3].Text = GGManager.translateTID( self.descData[29] )..L": "..GGManager.stripMarkup( self.stringData[6] )..L"\n"..GGManager.translateTID( self.descData[28] )..L": "..GGManager.stripMarkup( self.stringData[5] )
	self.Page[5].MiddleButtonId = -2
	self.Page[5].MiddleButtonText = GGManager.translateTID( self.descData[5] )

-- TODO: Rewrite this so it asks a Yes/no question
	self.Page[6] = {}
	self.Page[6].Subtitle = GGManager.translateTID( self.descData[1] )
	self.Page[6].ScrollText = GGManager.translateTID( self.descData[31] )
	self.Page[6].Selections = {}
	self.Page[6].Selections[1] = {}
	self.Page[6].Selections[1].Id = self.buttonIDs[21]
	self.Page[6].Selections[1].Text = GGManager.translateTID( self.descData[24] )..L": "..GGManager.stripMarkup( self.stringData[7] )
	self.Page[6].MiddleButtonId = -2
	self.Page[6].MiddleButtonText = GGManager.translateTID( self.descData[5] )

-- TODO: Same for this one
	self.Page[7] = {}
	self.Page[7].Subtitle = GGManager.translateTID( self.descData[1] )
	self.Page[7].ScrollText = GGManager.translateTID( self.descData[34] )
	self.Page[7].Selections = {}
	self.Page[7].Selections[1] = {}
	self.Page[7].Selections[1].Id = self.buttonIDs[23]
	self.Page[7].Selections[1].Text = GGManager.translateTID( self.descData[35] )..L": "..GGManager.stripMarkup( self.stringData[7] )
	self.Page[7].MiddleButtonId = -2
	self.Page[7].MiddleButtonText = GGManager.translateTID( self.descData[36] )

	self.Page[8] = {}
	self.Page[8].Subtitle = GGManager.translateTID( self.descData[1] )
	self.Page[8].Selections = {}
	self.Page[8].Selections[1] = {}
	self.Page[8].Selections[1].Id = self.buttonIDs[25]
	self.Page[8].Selections[1].Text = GGManager.translateTID( self.descData[37] )
	self.Page[8].Selections[2] = {}
	self.Page[8].Selections[2].Id = self.buttonIDs[26]
	self.Page[8].Selections[2].Text = GGManager.translateTID( self.descData[38] )
	self.Page[8].Selections[3] = {}
	self.Page[8].Selections[3].Id = self.buttonIDs[27]
	self.Page[8].Selections[3].Text = GGManager.translateTID( self.descData[39] )
	self.Page[8].MiddleButtonId = -1
	self.Page[8].MiddleButtonText = GGManager.translateTID( self.descData[36] )

end
