
----------------------------------------------------------------
-- Global Variables/Functions
----------------------------------------------------------------

PuzzleBox = {}
PuzzleBox.Radio = 1
PuzzleBox.Colors = {}
PuzzleBoxManager = GGManager


function PuzzleBox.Initialize()
	local newWindow = PuzzleBox:new()
	newWindow:Init()
end 


function PuzzleBox:new( newWindow )
	newWindow = newWindow or {}
	setmetatable(newWindow, self)
	self.__index = self
	return newWindow
end


function PuzzleBox:Init()
	
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end

	if self.setFields then
		self:setFields()
	end

	PuzzleBoxManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end


function PuzzleBox:setDataFunction()

	-- Variables for looping and indexing
	local itr
	local index
		
	-- Default the selected Slot to the first one, then find the real one
	PuzzleBox.Radio = 91
	for itr = 15,19 do
		if self.buttonIDs[itr] == 1 then
			PuzzleBox.Radio = itr+76
		end
	end

	-- Set the title's text
	self.title = GGManager.translateTID( self.descData[1] )
	
	-- Based on the data from the server, decide what the colors of the Slot's Stones are
	for itr=1,5 do
		index = 8 + ( 6 * itr )
		if self.ImageNum[index] == 0 then
			PuzzleBox.Colors[itr] = 0
		elseif self.ImageNum[index] == 6249 then
			PuzzleBox.Colors[itr] = 1
		elseif self.ImageNum[index] == 6250 then
			PuzzleBox.Colors[itr] = 2
		elseif self.ImageNum[index] == 6251 then
			PuzzleBox.Colors[itr] = 3
		elseif self.ImageNum[index] == 6252 then
			PuzzleBox.Colors[itr] = 4
		elseif self.ImageNum[index] == 6253 then
			PuzzleBox.Colors[itr] = 5
		elseif self.ImageNum[index] == 6254 then
			PuzzleBox.Colors[itr] = 6
		elseif self.ImageNum[index] == 6255 then
			PuzzleBox.Colors[itr] = 7
		elseif self.ImageNum[index] == 6256 then
			PuzzleBox.Colors[itr] = 8
		end	
	end	
end


function PuzzleBox:setFields()
	
	-- Variables for looping and indexing
	local itr
	local index
	
	-- Variable for telling which Slot is selected
	local lit = PuzzleBox.Radio - 90
	
	-- Set the title
	WindowUtils.SetActiveDialogTitle( self.title )
	
	-- Tint the Slot's Stones
	for itr = 1, 5 do
		    if self.Colors[itr] == 0 then -- Not set yet
			WindowSetTintColor( self.windowName.."Slot"..itr.."Tintable" , 0 , 0 , 0 ) -- Blackened out
		elseif self.Colors[itr] == 1 then
			WindowSetTintColor( self.windowName.."Slot"..itr.."Tintable" , 255 , 0 , 0 ) -- Red
		elseif self.Colors[itr] == 2 then
			WindowSetTintColor( self.windowName.."Slot"..itr.."Tintable" , 0 , 255 , 0 ) -- Green
		elseif self.Colors[itr] == 3 then
			WindowSetTintColor( self.windowName.."Slot"..itr.."Tintable" , 0 , 0 , 255 ) -- Blue
		elseif self.Colors[itr] == 4 then
			WindowSetTintColor( self.windowName.."Slot"..itr.."Tintable" , 255 , 0 , 255 ) -- Purple
		elseif self.Colors[itr] == 5 then
			WindowSetTintColor( self.windowName.."Slot"..itr.."Tintable" , 255 , 255 , 0 ) -- Yellow
		elseif self.Colors[itr] == 6 then
			WindowSetTintColor( self.windowName.."Slot"..itr.."Tintable" , 0 , 255 , 255 ) -- Cyan
		elseif self.Colors[itr] == 7 then
			WindowSetTintColor( self.windowName.."Slot"..itr.."Tintable" , 255 , 255 , 255 ) -- White
		elseif self.Colors[itr] == 8 then
			WindowSetTintColor( self.windowName.."Slot"..itr.."Tintable" , 128 , 128 , 128 ) -- Grey
		else -- Bad value, so black it out.
			WindowSetTintColor( self.windowName.."Slot"..itr.."Tintable" , 0 , 0 , 0 ) -- Blackened out
		end
	end
	
	-- Tint all the Stones
--	WindowSetTintColor( self.windowName.."Stone1Tintable" , 255 , 255 , 255 ) -- No need to re-tint a white stone!
	WindowSetTintColor( self.windowName.."Stone2Tintable" , 0 , 255 , 0 ) -- Green
	WindowSetTintColor( self.windowName.."Stone3Tintable" , 0 , 0 , 255 ) -- Blue
	WindowSetTintColor( self.windowName.."Stone4Tintable" , 255 , 0 , 255 ) -- Purple
	WindowSetTintColor( self.windowName.."Stone5Tintable" , 255 , 255 , 0 ) -- Yellow
	WindowSetTintColor( self.windowName.."Stone6Tintable" , 0 , 255 , 255 ) -- Cyan
	WindowSetTintColor( self.windowName.."Stone7Tintable" , 255 , 0 , 0 ) -- Red
	WindowSetTintColor( self.windowName.."Stone8Tintable" , 128 , 128 , 128 ) -- Grey
	
	-- Set the button IDs for the Stones
	for itr = 1, 8 do	
		WindowSetId( self.windowName.."Stone"..itr , self.buttonIDs[itr] )
	end
	
	-- Set the button IDs for the Slots, hide all the lit ones...
	for itr = 1, 5 do
		WindowSetId( self.windowName.."Slot"..itr , self.buttonIDs[itr+8] )
		WindowSetShowing( self.windowName.."Slot"..itr.."IconLit" , false )
	end
	-- ...then unhide the selected one.
	WindowSetShowing( self.windowName.."Slot"..lit.."IconLit" , true )
	
	-- Set the button ID and text for the Submit Button
	WindowSetId( self.windowName.."Submit" , self.buttonIDs[14] )
	ButtonSetText( self.windowName.."Submit", L"SUBMIT" )

	-- Set the button ID and name for the Cancel Button
	WindowSetId( self.windowName.."Cancel" , 0 )
	ButtonSetText( self.windowName.."Cancel", L"CANCEL" ) 
	
	-- Set the top text
	LabelSetText( self.windowName.."TopText" , GGManager.translateTID( 1079146 ) ) -- GGManager.translateTID( self.descData[2] ) )

	-- Previous Guess Text
	if self.descData[3] and self.descData[3] ~=-1 then -- There is previous guess data!
		LabelSetText( self.windowName.."PrevText" , GGManager.translateTID( self.descData[3] ) )
		for itr = 1, 5 do
			index = itr + 38
		    if self.ImageNum[index] == 3699 then -- Was blank when submitted!
				WindowSetTintColor( self.windowName.."Prev"..itr.."Tintable" , 0 , 0 , 0 ) -- Blackened out
			elseif self.ImageNum[index] == 6249 then
				WindowSetTintColor( self.windowName.."Prev"..itr.."Tintable" , 255 , 0 , 0 ) -- Red
			elseif self.ImageNum[index] == 6250 then
				WindowSetTintColor( self.windowName.."Prev"..itr.."Tintable" , 0 , 255 , 0 ) -- Green
			elseif self.ImageNum[index] == 6251 then
				WindowSetTintColor( self.windowName.."Prev"..itr.."Tintable" , 0 , 0 , 255 ) -- Blue
			elseif self.ImageNum[index] == 6252 then
				WindowSetTintColor( self.windowName.."Prev"..itr.."Tintable" , 255 , 0 , 255 ) -- Purple
			elseif self.ImageNum[index] == 6253 then
				WindowSetTintColor( self.windowName.."Prev"..itr.."Tintable" , 255 , 255 , 0 ) -- Yellow
			elseif self.ImageNum[index] == 6254 then
				WindowSetTintColor( self.windowName.."Prev"..itr.."Tintable" , 0 , 255 , 255 ) -- Cyan
			elseif self.ImageNum[index] == 6255 then
				WindowSetTintColor( self.windowName.."Prev"..itr.."Tintable" , 255 , 255 , 255 ) -- White
			elseif self.ImageNum[index] == 6256 then
				WindowSetTintColor( self.windowName.."Prev"..itr.."Tintable" , 128 , 128 , 128 ) -- Grey
			else -- Bad value, so black it out.
				WindowSetTintColor( self.windowName.."Prev"..itr.."Tintable" , 0 , 0 , 0 ) -- Blackened out
			end
		end
	else
		for itr = 1,5 do
			WindowSetShowing( self.windowName.."Prev"..itr , false )
		end
		LabelSetText( self.windowName.."PrevText" , L" " )
	end

	-- Just to be safe	
	WindowSetShowing( self.windowName.."Tight1" , true )
	WindowSetShowing( self.windowName.."Loose1" , true )
	WindowSetShowing( self.windowName.."Loose2" , true )
	WindowSetShowing( self.windowName.."Loose3" , true )

	local nextDD = 7
	local nextTile = 44
	if self.descData[4] == -1 then -- No clues
		-- Hide all the clue stuff
		LabelSetText( self.windowName.."TightText" , L" " )			
		LabelSetText( self.windowName.."LooseText" , L" " )
		WindowSetShowing( self.windowName.."Tight1" , false )
		WindowSetShowing( self.windowName.."Loose1" , false )
		WindowSetShowing( self.windowName.."Loose2" , false )
		WindowSetShowing( self.windowName.."Loose3" , false )
	else -- CLUES! (ignore descData[4] = "Lockpicking Hints:"?)
		if self.descData[5] == -1 then -- showing the first spot answer!
			LabelSetText( self.windowName.."TightText" , GGManager.translateTID( self.descData[6] ) )			
			LabelSetText( self.windowName.."LooseText" , GGManager.translateTID( self.descData[7] ) )
			nextDD = 8
			itr = 1
			if self.ImageNum[nextTile] == 6249 then
				WindowSetTintColor( self.windowName.."Tight"..itr.."Tintable" , 255 , 0 , 0 ) -- Red
			elseif self.ImageNum[nextTile] == 6250 then
				WindowSetTintColor( self.windowName.."Tight"..itr.."Tintable" , 0 , 255 , 0 ) -- Green
			elseif self.ImageNum[nextTile] == 6251 then
				WindowSetTintColor( self.windowName.."Tight"..itr.."Tintable" , 0 , 0 , 255 ) -- Blue
			elseif self.ImageNum[nextTile] == 6252 then
				WindowSetTintColor( self.windowName.."Tight"..itr.."Tintable" , 255 , 0 , 255 ) -- Purple
			elseif self.ImageNum[nextTile] == 6253 then
				WindowSetTintColor( self.windowName.."Tight"..itr.."Tintable" , 255 , 255 , 0 ) -- Yellow
			elseif self.ImageNum[nextTile] == 6254 then
				WindowSetTintColor( self.windowName.."Tight"..itr.."Tintable" , 0 , 255 , 255 ) -- Cyan
			elseif self.ImageNum[nextTile] == 6255 then
				WindowSetTintColor( self.windowName.."Tight"..itr.."Tintable" , 255 , 255 , 255 ) -- White
			elseif self.ImageNum[nextTile] == 6256 then
				WindowSetTintColor( self.windowName.."Tight"..itr.."Tintable" , 128 , 128 , 128 ) -- Grey
			else -- Bad value, so bail on the whole clue. Should never happen! Might want to do this for "POLISH"s below.
				LabelSetText( self.windowName.."TightText" , L" " )			
				WindowSetShowing( self.windowName.."Tight1" , false )
			end
			nextTile = nextTile + 1
		else -- not showing the first spot answer
			LabelSetText( self.windowName.."TightText" , L" " )			
			WindowSetShowing( self.windowName.."Tight1" , false )
			LabelSetText( self.windowName.."LooseText" , GGManager.translateTID( self.descData[6] ) )
			itr = 2
			if self.descData[nextDD] == -1 then -- There will be 2 looses
				itr = 3
				WindowSetShowing( self.windowName.."Loose2" , false )
			else
				WindowSetShowing( self.windowName.."Loose1" , false )
				WindowSetShowing( self.windowName.."Loose3" , false )
			end				
			if self.ImageNum[nextTile] == 6249 then
				WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 255 , 0 , 0 ) -- Red
			elseif self.ImageNum[nextTile] == 6250 then
				WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 0 , 255 , 0 ) -- Green
			elseif self.ImageNum[nextTile] == 6251 then
				WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 0 , 0 , 255 ) -- Blue
			elseif self.ImageNum[nextTile] == 6252 then
				WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 255 , 0 , 255 ) -- Purple
			elseif self.ImageNum[nextTile] == 6253 then
				WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 255 , 255 , 0 ) -- Yellow
			elseif self.ImageNum[nextTile] == 6254 then
				WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 0 , 255 , 255 ) -- Cyan
			elseif self.ImageNum[nextTile] == 6255 then
				WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 255 , 255 , 255 ) -- White
			elseif self.ImageNum[nextTile] == 6256 then
				WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 128 , 128 , 128 ) -- Grey
			else -- Bad value, so black it out. Should never happen! POLISH: Adjust this to hide clue
				WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 0 , 0 , 0 ) -- Blackened out
			end
			nextTile = nextTile + 1
		end
		if self.descData[nextDD] ~= -4 then -- There are more loose tiles!
			if self.descData[nextDD] == -3 then
				for itr = 1, -self.descData[nextDD] do
					if self.ImageNum[nextTile] == 6249 then
						WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 255 , 0 , 0 ) -- Red
					elseif self.ImageNum[nextTile] == 6250 then
						WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 0 , 255 , 0 ) -- Green
					elseif self.ImageNum[nextTile] == 6251 then
						WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 0 , 0 , 255 ) -- Blue
					elseif self.ImageNum[nextTile] == 6252 then
						WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 255 , 0 , 255 ) -- Purple
					elseif self.ImageNum[nextTile] == 6253 then
						WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 255 , 255 , 0 ) -- Yellow
					elseif self.ImageNum[nextTile] == 6254 then
						WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 0 , 255 , 255 ) -- Cyan
					elseif self.ImageNum[nextTile] == 6255 then
						WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 255 , 255 , 255 ) -- White
					elseif self.ImageNum[nextTile] == 6256 then
						WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 128 , 128 , 128 ) -- Grey
					else -- Bad value, so black it out. Should never happen! POLISH: Adjust this to hide clue
						WindowSetTintColor( self.windowName.."Loose"..itr.."Tintable" , 0 , 0 , 0 ) -- Blackened out
					end
					nextTile = nextTile + 1
				end
			elseif self.descData[nextDD] == -2 then
				if self.ImageNum[nextTile] == 6249 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 255 , 0 , 0 ) -- Red
				elseif self.ImageNum[nextTile] == 6250 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 0 , 255 , 0 ) -- Green
				elseif self.ImageNum[nextTile] == 6251 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 0 , 0 , 255 ) -- Blue
				elseif self.ImageNum[nextTile] == 6252 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 255 , 0 , 255 ) -- Purple
				elseif self.ImageNum[nextTile] == 6253 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 255 , 255 , 0 ) -- Yellow
				elseif self.ImageNum[nextTile] == 6254 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 0 , 255 , 255 ) -- Cyan
				elseif self.ImageNum[nextTile] == 6255 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 255 , 255 , 255 ) -- White
				elseif self.ImageNum[nextTile] == 6256 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 128 , 128 , 128 ) -- Grey
				else -- Bad value, so black it out. Should never happen! POLISH: Adjust this to hide clue
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 0 , 0 , 0 ) -- Blackened out
				end
				nextTile = nextTile + 1
				WindowSetShowing( self.windowName.."Loose2" , false )
				if self.ImageNum[nextTile] == 6249 then
					WindowSetTintColor( self.windowName.."Loose3Tintable" , 255 , 0 , 0 ) -- Red
				elseif self.ImageNum[nextTile] == 6250 then
					WindowSetTintColor( self.windowName.."Loose3Tintable" , 0 , 255 , 0 ) -- Green
				elseif self.ImageNum[nextTile] == 6251 then
					WindowSetTintColor( self.windowName.."Loose3Tintable" , 0 , 0 , 255 ) -- Blue
				elseif self.ImageNum[nextTile] == 6252 then
					WindowSetTintColor( self.windowName.."Loose3Tintable" , 255 , 0 , 255 ) -- Purple
				elseif self.ImageNum[nextTile] == 6253 then
					WindowSetTintColor( self.windowName.."Loose3Tintable" , 255 , 255 , 0 ) -- Yellow
				elseif self.ImageNum[nextTile] == 6254 then
					WindowSetTintColor( self.windowName.."Loose3Tintable" , 0 , 255 , 255 ) -- Cyan
				elseif self.ImageNum[nextTile] == 6255 then
					WindowSetTintColor( self.windowName.."Loose3Tintable" , 255 , 255 , 255 ) -- White
				elseif self.ImageNum[nextTile] == 6256 then
					WindowSetTintColor( self.windowName.."Loose3Tintable" , 128 , 128 , 128 ) -- Grey
				else -- Bad value, so black it out. Should never happen! POLISH: Adjust this to hide clue
					WindowSetTintColor( self.windowName.."Loose3Tintable" , 0 , 0 , 0 ) -- Blackened out
				end
			elseif self.descData[nextDD] == -1 then
				if self.ImageNum[nextTile] == 6249 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 255 , 0 , 0 ) -- Red
				elseif self.ImageNum[nextTile] == 6250 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 0 , 255 , 0 ) -- Green
				elseif self.ImageNum[nextTile] == 6251 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 0 , 0 , 255 ) -- Blue
				elseif self.ImageNum[nextTile] == 6252 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 255 , 0 , 255 ) -- Purple
				elseif self.ImageNum[nextTile] == 6253 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 255 , 255 , 0 ) -- Yellow
				elseif self.ImageNum[nextTile] == 6254 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 0 , 255 , 255 ) -- Cyan
				elseif self.ImageNum[nextTile] == 6255 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 255 , 255 , 255 ) -- White
				elseif self.ImageNum[nextTile] == 6256 then
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 128 , 128 , 128 ) -- Grey
				else -- Bad value, so black it out. Should never happen! POLISH: Adjust this to hide clue
					WindowSetTintColor( self.windowName.."Loose1Tintable" , 0 , 0 , 0 ) -- Blackened out
				end
				if self.ImageNum[nextTile] == 6249 then
					WindowSetTintColor( self.windowName.."Loose2Tintable" , 255 , 0 , 0 ) -- Red
				elseif self.ImageNum[nextTile] == 6250 then
					WindowSetTintColor( self.windowName.."Loose2Tintable" , 0 , 255 , 0 ) -- Green
				elseif self.ImageNum[nextTile] == 6251 then
					WindowSetTintColor( self.windowName.."Loose2Tintable" , 0 , 0 , 255 ) -- Blue
				elseif self.ImageNum[nextTile] == 6252 then
					WindowSetTintColor( self.windowName.."Loose2Tintable" , 255 , 0 , 255 ) -- Purple
				elseif self.ImageNum[nextTile] == 6253 then
					WindowSetTintColor( self.windowName.."Loose2Tintable" , 255 , 255 , 0 ) -- Yellow
				elseif self.ImageNum[nextTile] == 6254 then
					WindowSetTintColor( self.windowName.."Loose2Tintable" , 0 , 255 , 255 ) -- Cyan
				elseif self.ImageNum[nextTile] == 6255 then
					WindowSetTintColor( self.windowName.."Loose2Tintable" , 255 , 255 , 255 ) -- White
				elseif self.ImageNum[nextTile] == 6256 then
					WindowSetTintColor( self.windowName.."Loose2Tintable" , 128 , 128 , 128 ) -- Grey
				else -- Bad value, so black it out. Should never happen! POLISH: Adjust this to hide clue
					WindowSetTintColor( self.windowName.."Loose2Tintable" , 0 , 0 , 0 ) -- Blackened out
				end
				if self.descData[5] == -1 then -- dealing with the case where the middle should show and the LR should hide
					WindowSetShowing( self.windowName.."Loose1" , false )
					WindowSetShowing( self.windowName.."Loose3" , false )
				else -- hide the middle one
					WindowSetShowing( self.windowName.."Loose2" , false )
				end
			end						
		end
	end
	-- If you could follow all that, I applaud you - and ask that you write a seperate function to tint the stones based on an ImageNum. 
end


function PuzzleBox.getActiveWindowData()
	local windowName = WindowUtils.GetActiveDialog()
	return PuzzleBoxManager.knownWindows[windowName]
end

function PuzzleBox.DefaultButtonFunction()

	-- Grab the buttonID and a self reference
	local buttonID = WindowGetId( SystemData.ActiveWindow.name )
	local self = PuzzleBox.getActiveWindowData()
	
	-- Validate buttonID
	if not buttonID and buttonID ~= 0 then	
		Debug.PrintToDebugConsole( L"ERROR in PuzzleBox.DefaultButtonFunction: No ID set for button pressed." )
		return
	end

	-- A slot was picked
	if buttonID > 90 and buttonID < 96 then
		PuzzleBox.Radio = buttonID
		local itr
		local lit = buttonID - 90
		for itr = 1, 5 do
			WindowSetShowing( self.windowName.."Slot"..itr.."IconLit" , false )
		end
		WindowSetShowing( self.windowName.."Slot"..lit.."IconLit" , true )
		return -- Bail out now, as we don't want to close the window
	end

	-- The answer was submitted
	if buttonID == 89 then
		UO_GenericGump.broadcastSelections( buttonID, { 91 },  self )
	end
	
	-- A color was picked
	if buttonID > 6248 then
		UO_GenericGump.broadcastSelections( buttonID, { PuzzleBox.Radio },  self )
	end

	-- The cancel button just closes the gump
	self.OnCloseWindow()
end


function PuzzleBox.OnCloseWindow()
	GGManager.destroyActiveWindow()
end
