
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

AnimalContainerConfirm = { 
	LEFT_BUTTON_ID = 0,
	RIGHT_BUTTON_ID = 1,
	--RIGHT_BUTTON_ID = 7, -- server script is confusing so this could be the expected value
}


----------------------------------------------------------------
-- AnimalContainerConfirm Functions
----------------------------------------------------------------

-- OnInitialize Handler
function AnimalContainerConfirm.Initialize()
	-- setDataFunction is called in TwoButtonDialog:init(), 
	--   most TwoButtonDialogs can use  either parseDescAsTextAndTwoButtons or parseDescAsTitleTextAndTwoButtons
	AnimalContainerConfirm.setDataFunction = TwoButtonDialog.parseDescAsTitleTextAndTwoButtons
	TwoButtonDialog.Init(AnimalContainerConfirm)
end
	
	
--
function AnimalContainerConfirm.OnCloseWindow()
	UO_GenericGump.debug( L"AnimalContainerConfirm.OnCloseWindow called. ")
	UO_DefaultWindow.CloseDialog()
end



