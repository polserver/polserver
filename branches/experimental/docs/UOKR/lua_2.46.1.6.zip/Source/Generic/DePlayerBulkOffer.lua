----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

DePlayerBulkOffer = TwoButtonDialog:new()

----------------------------------------------------------------
-- DePlayerBulkOffer Functions
----------------------------------------------------------------

function DePlayerBulkOffer:parseData()
	-- The window title
	self.title = GGManager.translateTID( self.descData[6] )

	-- The main text
	self.text = -- "Ah! Thanks for the goods!" + blank line
				GGManager.translateTID( self.descData[1] )..L"\n\n"..				
				-- "Amount to make:"
				GGManager.translateTID( self.descData[2] )..L"\n"..
				-- The amount + blank line
				self.stringData[1]..L"\n\n"..
				-- "Item(s) to make:"
				GGManager.translateTID( self.descData[7] )
				local i
				-- for each item
				for	i=12, self.descDataCount do
					-- add the item name
					self.text = self.text..L"\n"..GGManager.translateTID( self.descData[i] )
				end
				self.text = self.text..L"\n\n"
				-- for each additional req
				local needExtraSpace = false
				for	i=8,11 do
					-- validate it is to be displayed
					if self.descData[i] > 0 then
						-- display it
						needExtraSpace = true
						self.text = self.text..GGManager.translateTID( self.descData[i] )..L"\n"
					end
				end
				if needExtraSpace == true then
					self.text = self.text..L"\n"
				end
				-- Add the question
				self.text = self.text..GGManager.translateTID( self.descData[3] )

	-- Buttons
	self.leftButtonName = GGManager.translateTID( self.descData[4] )
	self.rightButtonName = GGManager.translateTID( self.descData[5] )
	self.leftButtonID = self.buttonIDs[1]
	self.rightButtonID = self.buttonIDs[2]	
end

-- OnInitialize Handler
function DePlayerBulkOffer.Initialize()
	local newWindow = DePlayerBulkOffer:new()
	newWindow.setDataFunction = DePlayerBulkOffer.parseData
	newWindow:Init()
end
