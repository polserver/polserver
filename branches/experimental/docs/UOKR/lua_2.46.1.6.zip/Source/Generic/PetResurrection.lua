
PetResurrection = MasterGUMP:new()

function PetResurrection.Initialize()
	local newWindow	= PetResurrection:new()
	newWindow.setData = PetResurrection.mySetData
	newWindow:Init()
end

function PetResurrection:mySetData()
	self.Page = {}
	self.Page[1] = {}
	self.Page[1].ScrollText = GGManager.translateTID( self.descData[1] )..L"\n\n"..GGManager.stripMarkup( self.stringData[1] )
	self.Page[1].LeftButtonId = self.buttonIDs[1]
	self.Page[1].LeftButtonText = GGManager.translateTID( GGManager.OKAY_TID )	
	self.Page[1].RightButtonId = self.buttonIDs[2]
	self.Page[1].RightButtonText = GGManager.translateTID( GGManager.CANCEL_TID )	
end	
