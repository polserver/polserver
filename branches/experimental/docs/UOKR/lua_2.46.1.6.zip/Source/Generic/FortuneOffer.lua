----------------------------------------------------------------
-- FortuneOffer.lua
----------------------------------------------------------------

FortuneOffer = ChoiceButtons:new()

function FortuneOffer.Initialize()
	local newWindow = ChoiceButtons:new()
	newWindow.setDataFunction = FortuneOffer.setDataFunction
	newWindow:Init()
end

function FortuneOffer:setDataFunction()

	-- last button ID is not used in KR other than to send back to say a choice was selected
	self.actionID = self.buttonIDs[self.buttonCount]
	self.buttonCount = self.buttonCount-1

	self.buttonName = {}
	for i=1, self.buttonCount do
		-- the first buttonCount of descData are the choice labels 
		self.buttonName[i] = GGManager.translateTID( self.descData[i] )
	end		

	
	--self.title	= GGManager.translateTID( self.descData[1] )
	--self.subtitle	= GGManager.translateTID( self.descData[2] )
	self.text		=   GGManager.translateTID( self.descData[self.buttonCount + 1] )..L"\n\n"
					  ..self.stringData[1]..L" "
					  ..GGManager.translateTID( self.descData[self.buttonCount + 2] )..L"\n\n"
					  ..GGManager.translateTID( self.descData[self.buttonCount + 3] )
end
