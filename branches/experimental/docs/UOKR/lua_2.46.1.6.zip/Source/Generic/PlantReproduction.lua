
----------------------------------------------------------------
-- Plant.lua
----------------------------------------------------------------

PlantReproduction = { }

PlantReproductionManager = GGManager

function PlantReproduction.Initialize()

	local newWindow = PlantReproduction:new()
	newWindow:Init()
end

function PlantReproduction:new( newWindow )

	newWindow = newWindow or {}
	setmetatable( newWindow, self )
	self.__index = self

	return newWindow
end

function PlantReproduction:Init()

	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
	
	if self.setDataFunction then
		self:setDataFunction()
	end
	
	PlantReproductionManager.knownWindows[self.windowName] = self
end

function PlantReproduction:setDataFunction()

	self.RequestedTileArt	= {}
	self.ToolTips			= {}
	
	-- The subtitle
	LabelSetText( self.windowName.."Subtitle", GGManager.translateTID( self.descData[1] ) )	-- "Reproduction"
	
	ButtonSetText( self.windowName.."BackButton", GGManager.translateTID(1011447) )
	WindowSetId( self.windowName.."BackButton", self.buttonIDs[1] )
	
	-- Pollen
	local textureP, xP, yP, scaleP, widthP, heightP = RequestTileArt( tonumber( self.ImageNum[6] ), 32, 32 )
	self.RequestedTileArt[#self.RequestedTileArt + 1] = textureP
	
	DynamicImageSetTexture( self.windowName.."PollenIcon", textureP, xP, yP )
	DynamicImageSetTextureScale( self.windowName.."PollenIcon", scaleP )
	LabelSetText( self.windowName.."PollenText", self.stringData[4] )
	
	WindowSetDimensions( self.windowName.."ScrollChildGetPollenIconHolderIcon", widthP, heightP )
	DynamicImageSetTexture( self.windowName.."ScrollChildGetPollenIconHolderIcon", textureP, xP, yP )
	DynamicImageSetTextureScale( self.windowName.."ScrollChildGetPollenIconHolderIcon", scaleP )
	LabelSetText( self.windowName.."ScrollChildGetPollenText", GGManager.translateTID( 1078853 ) ) -- "Get pollen"
	
	-- Resource
	local textureR, xR, yR, scaleR, widthR, heightR = RequestTileArt( tonumber( self.ImageNum[7] ), 32, 32 )
	self.RequestedTileArt[#self.RequestedTileArt + 1] = textureR
	
	DynamicImageSetTexture( self.windowName.."ResourceIcon", textureR, xR, yR )
	DynamicImageSetTextureScale( self.windowName.."ResourceIcon", scaleR )
	LabelSetText( self.windowName.."ResourceText", self.stringData[3] )
	
	WindowSetDimensions( self.windowName.."ScrollChildGetResourcesIconHolderIcon", widthR, heightR )
	DynamicImageSetTexture( self.windowName.."ScrollChildGetResourcesIconHolderIcon", textureR, xR, yR )
	DynamicImageSetTextureScale( self.windowName.."ScrollChildGetResourcesIconHolderIcon", scaleR )
	LabelSetText( self.windowName.."ScrollChildGetResourcesText", GGManager.translateTID( 1078854 ) ) -- "Get resources"
	
	-- Seed
	local textureS, xS, yS, scaleS, widthS, heightS = RequestTileArt( tonumber( self.ImageNum[8] ), 32, 32 )
	self.RequestedTileArt[#self.RequestedTileArt + 1] = textureS
	
	DynamicImageSetTexture( self.windowName.."SeedIcon", textureS, xS, yS )
	DynamicImageSetTextureScale( self.windowName.."SeedIcon", scaleS )
	LabelSetText( self.windowName.."SeedText", self.stringData[2] )
	
	WindowSetDimensions( self.windowName.."ScrollChildGetSeedsIconHolderIcon", widthS, heightS )
	DynamicImageSetTexture( self.windowName.."ScrollChildGetSeedsIconHolderIcon", textureS, xS, yS )
	DynamicImageSetTextureScale( self.windowName.."ScrollChildGetSeedsIconHolderIcon", scaleS )
	LabelSetText( self.windowName.."ScrollChildGetSeedsText", GGManager.translateTID( 1078855 ) ) -- "Get seeds"

	-- Decorative mode
	if self.stringData[5] ~= nil
	then
		local textureD, xD, yD, scaleD, widthD, heightD = RequestTileArt( 3169, 32, 32 )
		self.RequestedTileArt[#self.RequestedTileArt + 1] = textureD

		DynamicImageSetTexture( self.windowName.."DecIcon", textureD, xD, yD )
		DynamicImageSetTextureScale( self.windowName.."DecIcon", scaleD )
		self.Tooltips = self.Tooltips or {}
		self.Tooltips[self.windowName.."DecButton"] = 3010194
	else
		ButtonSetDisabledFlag( self.windowName.."DecButton", true )
		DestroyWindow( self.windowName.."DecButton" )
	end
end	

function PlantReproduction.ButtonPressed()

	local self = PlantReproductionManager.knownWindows[WindowUtils.GetActiveDialog()]
	self:ButtonSelected()
end

function PlantReproduction:ButtonSelected()

	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	
	if choiceNum ~= -1 then
		UO_GenericGump.broadcastButtonPress( choiceNum, self )
		self.OnCloseWindow()
	end
end

function PlantReproduction.Shutdown()
	if self.RequestedTileArt then
		for _, art in pairs( self.RequestedTileArt ) do
			ReleaseTileArt( art )
		end
	end

	GGManager.unregisterActiveWindow()
end

function PlantReproduction.OnCloseWindow()
	UO_GenericGump.debug( L"Plant.OnCloseWindow() called." )
	
	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )
end

function PlantReproduction.OnMouseOver()

	local self = PlantReproductionManager.knownWindows[WindowUtils.GetActiveDialog()]
	local name = SystemData.ActiveWindow.name

	if  self.Tooltips		~= nil
	and self.Tooltips[name]	~= nil
	then
		Tooltips.CreateTextOnlyTooltip( name, GGManager.translateTID( self.Tooltips[name] ) )
		Tooltips.Finalize()
		Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_TOP )
	end 
end
