----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

Promo7thConfirm = TwoButtonDialog:new()

----------------------------------------------------------------
-- Promo7thConfirm Functions
----------------------------------------------------------------

function Promo7thConfirm:setDataFunction()
	self.title = GGManager.translateTID( self.descData[1] )
	self.subtitle = GGManager.translateTID( self.descData[2] )
	self.text = GGManager.translateTID( self.descData[3] )--..L"\n"..self.stringData[1] -- removed weblink
	self.leftButtonName = GGManager.translateTID( GGManager.OKAY_TID )
	self.rightButtonName = GGManager.translateTID( self.descData[5] )
	
	self.leftButtonID = self.buttonIDs[2]
	self.rightButtonID = self.buttonIDs[3]	
end

-- OnInitialize Handler
function Promo7thConfirm.Initialize()
	local newWindow = Promo7thConfirm:new()
	newWindow.setDataFunction = Promo7thConfirm.setDataFunction
	newWindow:Init()
end
