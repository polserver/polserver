----------------------------------------------------------
-- DeItemBulkdeed.lua
----------------------------------------------------------------

DeItemBulkdeed = MasterGUMP:new()

function DeItemBulkdeed.Initialize()

	local newWindow					= DeItemBulkdeed:new()
	newWindow.setData				= DeItemBulkdeed.mySetData
	newWindow:Init()
end

function DeItemBulkdeed:mySetData()
	self.Page				= {}
	self.Page[1]			= {}
	self.Page[1].Title		= GGManager.translateTID( self.descData[4] )
	local scrolltext		= GGManager.translateTID( self.descData[1] )..L" "..self.stringData[1]..L"\n\n" -- amount to make
							..GGManager.translateTID( self.descData[2] )..L"\n" -- amount finished

	for i = 2, self.stringDataCount do -- items requested
		scrolltext = scrolltext..GGManager.translateTID( self.descData[i + 4] )..L": "..self.stringData[i]..L"\n"
	end
	
	for i = self.stringDataCount + 5, self.stringDataCount + 8 do -- special requirements
		if self.descData[i] > 0 then
			scrolltext = scrolltext..L"\n"..GGManager.translateTID( self.descData[i] )
		end
	end
		
	self.Page[1].ScrollText = scrolltext
	
	self.Page[1].Selections = {}
	if self.buttonCount == 2 then -- deed in player's backpack
		self.Page[1].Selections[1]		= {} -- combine
		self.Page[1].Selections[1].Id	= self.buttonIDs[2]
		self.Page[1].Selections[1].Text = GGManager.translateTID( self.descData[self.descDataCount] )
		
		self.Page[1].Selections[2]		= {}
		self.Page[1].Selections[2].Id	= self.buttonIDs[1]
		self.Page[1].Selections[2].Text = GGManager.translateTID( self.descData[3] )
	else -- deed not in player's backpack
		self.Page[1].Selections[1]		= {} -- exit
		self.Page[1].Selections[1].Id	= self.buttonIDs[1]
		self.Page[1].Selections[1].Text = GGManager.translateTID( self.descData[3] )
	end
end
