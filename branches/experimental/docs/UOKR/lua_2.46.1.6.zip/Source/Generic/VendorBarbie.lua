
----------------------------------------------------------------
-- VendorBarbie
----------------------------------------------------------------

VendorBarbie = { }--rightChildren = {} }

VendorBarbieManager = GGManager


-- OnInitialize Handler
function VendorBarbie.Initialize()

	local vendorBarbie = VendorBarbie:new()
	vendorBarbie:Init()
end

function VendorBarbie:new( vendorBarbie )

	vendorBarbie = vendorBarbie or {}
	setmetatable( vendorBarbie, self )
	self.__index = self
	
	vendorBarbie.rightChildren = {}

	return vendorBarbie
end

function VendorBarbie:Init()
		
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end

	if self.setFields then
		self:setFields()
	end
	
	VendorBarbieManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end


function VendorBarbie:CreateBlankSpace( pixels, relativeToow, uniqueID, scrollParent )

	local choiceName = self.windowName.."BlankSpace-"..uniqueID
	
	CreateWindowFromTemplate(choiceName, "VendorBarbieBaseText", scrollParent)
	LabelSetText( choiceName, L" "  )
	WindowAddAnchor( choiceName, "bottomleft", relativeToow, "topleft", 0, pixels)

	return choiceName
end


function VendorBarbie:setDataFunction()
	
	-- descData[2] is the label for an ok button which is no longer needed
	
	-- descData[3] is label for cancel button
	local buttonName = self.windowName.."BottomButton"
	ButtonSetText( buttonName, GGManager.translateTID( self.descData[3] ) )
	WindowSetId( buttonName, self.buttonIDs[2] ) -- Cancel id is the second button id passed in

	-- descData[1] is text for the subtitle 
	LabelSetText( self.windowName.."Subtitle", GGManager.translateTID( self.descData[1] ) )

	-- Page 0 = "Left Page"
	local relativeWindow = self.windowName.."ScrollChild"
	
	local descItr		= self.descPageIndex[1] + 3 -- Skip over buttons' labels and Subject
	local descItrEnd	= self.descPageIndex[2] - 1
	local pageItr		= -1
	
	relativeWindow = VendorBarbie:CreateSelectableText( pageItr, GGManager.translateTID( self.descData[descItr] ), "top", relativeWindow, "top", 0, 10 )
	pageItr = pageItr - 1
	
	for descItr=descItr+1, descItrEnd do
		relativeWindow = VendorBarbie:CreateSelectableText( pageItr, GGManager.translateTID( self.descData[descItr] ), "bottom", relativeWindow, "top", 0, 10 )
		pageItr = pageItr - 1
	end
	
	-- fake some space	
	self:CreateBlankSpace( 10, relativeWindow, 0, self.windowName.."ScrollChild" )
	
---[[
	-- Page 1+ = right side pages
	pageItr = -1

	-- the current page
	local page
	local uniqueID = 1

	for page=2, table.getn( self.descPageIndex ) do
	
		local descItr		= self.descPageIndex[page] -- + 1 -- Skip over the title
		local descItrEnd	= self.descDataCount
		
		if page < table.getn( self.descPageIndex ) then
			descItrEnd	= self.descPageIndex[page+1] - 1
		end
		
		local buttonItr = self.buttonPageIndex[page]
		-- if page < 4 then
		--	buttonItr = buttonItr + 1	-- Dirty hack! For some reason the 2nd and 3rd pages have an extra button at the begining
		-- end
		
		local rightScroll		= self.windowName.."Scroll"..page
		local rightScrollChild	= rightScroll.."Child"

		CreateWindowFromTemplate( rightScroll,	"VendorBarbieRightScroll", self.windowName )
		WindowAddAnchor( rightScroll, "bottom", self.windowName.."Subtitle", "top", 0, 10 )
		
		-- local subtitle_width, subtitle_height = WindowGetDimensions( self.windowName.."Subtitle" )
		--local text_width, text_height = WindowGetDimensions( rightScrollChild )	
		--WindowSetDimensions( rightScrollChild, text_width, text_height + 100 )
		
		--CreateWindowFromTemplate( rightScrollChild,	"MoongateRightScrollChild", rightScroll )
		relativeWindow = VendorBarbie:CreateSelectableText( self.buttonIDs[buttonItr], GGManager.translateTID( self.descData[descItr] ), "top", rightScrollChild, "top", 0, 10, page, true )
		buttonItr = buttonItr + 1


		for descItr=descItr+1, descItrEnd do
			relativeWindow = VendorBarbie:CreateSelectableText( self.buttonIDs[buttonItr], GGManager.translateTID( self.descData[descItr] ), "bottom", relativeWindow, "top", 0, 10, page, true, uniqueID)
			buttonItr = buttonItr + 1
			uniqueID = uniqueID + 1
		end
			
		-- fake some space	
		self:CreateBlankSpace( 10, relativeWindow, page, rightScrollChild )

		WindowSetShowing( rightScroll, false )
		self.rightChildren[pageItr] = rightScroll
		pageItr = pageItr - 1
	end
--]]
end	

function VendorBarbie:CreateSelectableText( choiceNum, wText, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset, myPage, isRight, uniqueID )

	local windowName	= WindowUtils.GetActiveDialog()
	local choiceName	= windowName.."Choice"..choiceNum

	if uniqueID then
		choiceName = windowName.."Choice"..choiceNum.."Unique"..uniqueID
	end

	local parentName	= windowName.."ScrollChild"
	
	if isRight then
		parentName	= windowName.."Scroll"..myPage.."Child"
	end
	
	if	myPage
	and myPage ~= ""
	and not isRight then
		parentName = parentName..myPage
	end
	
	-- TODO: Adjust icons here!? - TF
	
	CreateWindowFromTemplate( choiceName, "VendorBarbieSelectable", parentName )
	Debug.Print( L"Created choice: "..StringToWString( choiceName ) )
	WindowAddAnchor( choiceName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	WindowSetId( choiceName, choiceNum )
	LabelSetText( choiceName.."Text" , wText )
	
	return choiceName
end

function VendorBarbie.TextPressed()

	local self = VendorBarbieManager.knownWindows[WindowUtils.GetActiveDialog()]
	self:TextSelected()
end

function VendorBarbie:TextSelected()

	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	UO_GenericGump.debug( L"VendorBarbie:TextSelected() choiceNum = "..choiceNum )

	if choiceNum == 0 then
		UO_GenericGump.broadcastSelections( self.buttonIDs[2], { choiceNum }, self )	-- Cancel id is the second button id passed in
		self.OnCloseWindow()
		return
	end
	
	if choiceNum > 0 then
		UO_GenericGump.broadcastSelections( self.buttonIDs[1], { choiceNum }, self )	-- Okay id is the first button id passed in
		self.OnCloseWindow()
		return
	end

	local pageItr = -1
	local pageItrEnd = -VendorBarbie.getTableSize( self.rightChildren )
	
	while pageItr >= pageItrEnd do
	
--		UO_GenericGump.debug( L"VendorBarbie:TextSelected() Setting "..StringToWString( self.rightChildren[pageItr] )..L"'s visibility to "..StringToWString( tostring( pageItr == choiceNum ) ) )
		WindowSetShowing( self.rightChildren[pageItr], (pageItr == choiceNum) )
		pageItr = pageItr - 1
	end
end


function VendorBarbie.OnCloseWindow()
	UO_GenericGump.debug( L"VendorBarbie.OnCloseWindow() called." )
	
	GGManager.destroyActiveWindow()
end

function VendorBarbie.getTableSize( table )

	local count = 0
	
	for _, _ in pairs( table ) do
		count = count + 1
	end
	
	return count
end

function VendorBarbie:toString()
	--local str = L"outputting table = "..self.name..L"\n\n"
	local str = L"outputting table = "..L"\n\n"
	for k, v in pairs( self ) do
		if type( v ) == "wstring" or type( v ) == "number" or type( v ) == "boolean" then
				str = str..StringToWString( tostring( k ) )..L" = "..v..L"\n"
		elseif type( v ) == "table" then
			for i, value in pairs( v ) do
				str = str..StringToWString( tostring( k ) )..L"["..StringToWString(tostring(i))..L"]"..L" = "..StringToWString(tostring(v[i]))..L"\n"
			end
		end
	end
	return str
end

function VendorBarbieManager:toString()
	--local str = L"outputting table = "..self.name..L"\n\n"
	local str = L"outputting table = "..L"\n\n"
	for k, v in pairs( self ) do
		if type( v ) == "wstring" or type( v ) == "number" or type( v ) == "boolean" then
				str = str..StringToWString( tostring( k ) )..L" = "..v..L"\n"
		elseif type( v ) == "table" then
			for i, value in pairs( v ) do
				str = str..StringToWString( tostring( k ) )..L"["..StringToWString(tostring(i))..L"]"..L" = "..StringToWString(tostring(v[i]))..L"\n"
			end
		end
	end
	return str
end