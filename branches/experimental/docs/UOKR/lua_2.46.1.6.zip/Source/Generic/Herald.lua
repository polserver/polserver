----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

Herald = ChoiceList:new()

----------------------------------------------------------------
-- Herald Functions
----------------------------------------------------------------

function Herald:setDataFunction()

	-- not wide
	local isWide = false
	-- scrolls if needed
	local relativeWindow = self.windowName.."ScrollChild"

	-- Set title
	WindowUtils.SetActiveDialogTitle( GGManager.translateTID( self.descData[2] ) ) -- GGManager.translateTID( self.descData[3] ) )
	
	-- Create bottom cancel button
	ChoiceList.CreateBottomButton( self, GGManager.translateTID( self.descData[1] ), self.buttonIDs[1] )

	-- Create the top choice
	relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
		self.buttonIDs[2], GGManager.translateTID( self.descData[3] ),
		"top", relativeWindow, "top", 0, 0, isWide, 2 )
		
	-- creat the other choices if their button ids aren't -1's	
	for i=4, self.descDataCount do
		if self.buttonIDs[i-1] >= 0 then 
			relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
				self.buttonIDs[i-1], GGManager.translateTID( self.descData[i] ),
				"bottomleft", relativeWindow, "topleft", 0, 0, isWide, i )
		end 
	end
	
end

-- Standard OnInitialize Handler
function Herald.Initialize()
	local newWindow = Herald:new()
	newWindow.setDataFunction = Herald.setDataFunction
	newWindow:Init()
end
