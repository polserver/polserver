
----------------------------------------------------------------
-- Global Variables/Functions
----------------------------------------------------------------

BulkOrderBook = {}

BulkOrderBookManager = GGManager

-- Maybe someday
-- TableCellManager = 
-- {
--	knownCells = {},
-- }

function BulkOrderBook:new( newWindow )
	newWindow = newWindow or {}
	setmetatable(newWindow, self)
	self.__index = self
	
	return newWindow
end


-- Init does the following:
--   1. retrieves data from the server
--   2. calls the object specific setDataFunction() to put the server data into standard fields
--   3. assigns those fields to the actual button/window names in setFields
--
-- BulkOrderBook have a default setDataFunction and setFields functions, but
--   either or both can be overwritten for different behavior. In some cases you may
--   wish to ignore the setFields function, e.g. set "self:setFields = nil" and
--   directly set the incoming data to the windows in the self:setDataFunction
--
function BulkOrderBook:Init()
	UO_GenericGump.debug( L"called BulkOrderBook:Init()" )
	
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end

	if self.setFields then
		self:setFields()
	end

	BulkOrderBookManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
	
	Debug.PrintToDebugConsole( L"Initialize "..self.name )
end


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

-- This is a very smart function!
function BulkOrderBook:CreateCell( xPos, yPos, wText, buttonID )
	-- UO_GenericGump.debug( L"Called BulkOrderBook:CreateCell() with params xPos = "..xPos..L", yPos = "..yPos..L", and wText = "..wText )

	if ( xPos <= 0 ) then
		UO_GenericGump.debug( L"xPos is negative or 0, bailing out." )
		return nil;
	elseif ( yPos <= 0 ) then
		UO_GenericGump.debug( L"yPos is negative or 0, bailing out." )
		return nil;
	end

	-- Create unique IDs for the cell
	local cellName = self.windowName.."CellX"..xPos.."Y"..yPos

	-- Create unique IDs for the window's button, window's icon, and window's text
	--local buttonName = mainName.."Button"
	--local iconName = mainName.."Icon"
	--local textName = mainName.."Text"

	-- Define some locals used for resizing things
	local cellXsize
	local cellYsize
	--local buttonXsize
	--local mainXsize
	--local mainYsize
	
	-- Create an ID for the scroll window
	local scrollParent = self.windowName.."ScrollChild"

	-- Create the cell
--	if buttonID then
--		CreateWindowFromTemplate( cellName, "ButtonCell", scrollParent )
--	else
		CreateWindowFromTemplate( cellName, "BlankCell", scrollParent )
--	end

	if xPos == 1 and yPos == 1 then -- New table starting here, anchor to something near the top
		WindowAddAnchor( cellName, "topleft", self.windowName.."ScrollChild" --[[.."Subtitle" --]] , "topleft", 0, 0 ) -- KLUDGE: Find some better way to anchor the table!
	elseif xPos == 1 then -- New row starting here, anchor to the first of the row above
		local prevY = yPos - 1
		WindowAddAnchor( cellName, "bottomleft", self.windowName.."CellX"..xPos.."Y"..prevY, "topleft", 0, 0 )
	else -- Common cell, anchor to the left
		local prevX = xPos - 1
		WindowAddAnchor( cellName, "topright", self.windowName.."CellX"..prevX.."Y"..yPos, "topleft", 0, 0 )
	end

	if wText and wText ~= L"" then
		LabelSetText( cellName.."Text", wText )
	else
--		LabelSetText( cellName.."Text", L"X" )
--		DestroyWindow( cellName.."Text" ) -- destroy the Text Label
	end
	
	local testX, testY
	
	if buttonID then -- and buttonID ~= 0 then

		CreateWindowFromTemplate( cellName.."Button", "CellButton", cellName.."Text" ) -- scrollParent )
--[[		
		testX, testY = WindowGetDimensions( cellName.."Button" ) -- , 23, 23 )
	UO_GenericGump.debug( L"X="..testX..L" Y="..testY ) -- StringToWString( cellName )..L"Button" )
		WindowSetDimensions( cellName.."Button", 23, 23 )
	UO_GenericGump.debug( L"Values updating to 23, 23" )
		testX, testY = WindowGetDimensions( cellName.."Button" ) -- , 23, 23 )
	UO_GenericGump.debug( L"X="..testX..L" Y="..testY ) -- StringToWString( cellName )..L"Button" )
	UO_GenericGump.debug( L" " )
--]]
		-- WindowSetDimensions( cellName.."Text", 24, 24 )	
		-- WindowSetDimensions( cellName, 25, 25 )	
		-- Testing space
		WindowAddAnchor( cellName.."Button", "topleft", cellName.."Text", "topleft", 0, 0 )
--		WindowAddAnchor( cellName.."Button", "topleft", cellName, "topleft", 0, 0 ) -- Was this
		WindowSetId( cellName.."Button", buttonID ) 
	-- UO_GenericGump.debug( L"Set an ID for a button: "..buttonID )
	end
	
--	cellXsize, cellYsize = LabelGetTextDimensions( cellName.."Text" )
--	WindowSetDimensions( cellName, cellXsize+20, cellYsize+10 ) -- 100, 80 )

	-- Also save the size of the button and window
	--buttonXsize = WindowGetDimensions( buttonName )
	--mainXsize, mainYsize = WindowGetDimensions( mainName )
	
	-- use the maximum Y dimension, use the defualt value from the XML if the text doesn't line wrap.
	--if mainYsize < textYsize then
	--	mainYsize = textYsize+19 -- fudge it 9.5 pixels above and below
	--end
	
	-- Set the size of the window and the size of the background to the same thing
	-- One shows where to click, the other handles the click!
	--WindowSetDimensions( mainName, mainXsize, mainYsize )
	--WindowSetDimensions( buttonName, buttonXsize, mainYsize )

	return cellName

end


function BulkOrderBook:neatenTable( totalRows, totalCols )
	-- unique IDs for cells done like this
	-- local CellName = self.windowName.."CellX"..xPos.."Y"..yPos

	local thisCellW
	local thisCellH
	local thisColW
	local thisRowH
	local curRow
	local curCol
	local junk
	local totalWidth = 0
	
	for curRow=1,totalRows do
		-- Start the max for each row at -1
		thisRowH = -1
		-- for each cell in this row
		for curCol=1,totalCols do
			-- get it's size
			junk, thisCellH = LabelGetTextDimensions( self.windowName.."CellX"..curCol.."Y"..curRow.."Text" )
			-- if it is wider than the current max
			if thisRowH < thisCellH then
				-- update the current max
				thisRowH = thisCellH
			end
		end
		thisRowH = thisRowH + 5
		-- for all the cells in this row
		for curCol=1,totalCols do
			-- get their size again
	--		thisCellW, junk = LabelGetTextDimensions( self.windowName.."CellX"..curCol.."Y"..curRow.."Text" )
			-- thisColW, junk = LabelGetTextDimensions( self.windowName.."CellX"..curCol.."Y"..curRow )
			-- set their width to the column max
			WindowSetDimensions( self.windowName.."CellX"..curCol.."Y"..curRow, 10, thisRowH )
		end
	end	
	
	for curCol=1,totalCols do
		-- Start the max for each row at -1
		thisColW = -1
		-- for each cell in this column
		for curRow=1,totalRows do
			-- get it's size
			thisCellW, junk = LabelGetTextDimensions( self.windowName.."CellX"..curCol.."Y"..curRow.."Text" )
			-- if it is wider than the current max
			if thisColW < thisCellW then
				-- update the current max
				thisColW = thisCellW
			end
		end		
		
		thisColW = thisColW + 5
		totalWidth = totalWidth + thisColW

		-- for all the cells in this column
		for curRow=1,totalRows do
			-- get their size again, this time from the set window so we keep the preset heights!
			junk, thisCellH = WindowGetDimensions( self.windowName.."CellX"..curCol.."Y"..curRow )
			-- set their width to the column max
			WindowSetDimensions( self.windowName.."CellX"..curCol.."Y"..curRow, thisColW, thisCellH )		
			--WindowSetDimensions( self.windowName.."CellX"..curCol.."Y"..curRow.."Text", thisColW, thisCellH )		
		end
	end	
	
	-- One more adjustment to fill out the space!	
	for curCol=1,totalCols do
		for curRow=1,totalRows do
			thisCellW, thisCellH = WindowGetDimensions( self.windowName.."CellX"..curCol.."Y"..curRow )
			thisCellW = thisCellW + ( ( 760 - totalWidth ) / totalCols ) -- 780?
			if thisCellW > 0 then
				WindowSetDimensions( self.windowName.."CellX"..curCol.."Y"..curRow, thisCellW, thisCellH )		
			end
		end
	end		

end

----------------------------------------------------------------
-- TwoButtonDialog (Manager) Functions
----------------------------------------------------------------

-- requires that gumpData.descData is already set and contains at least 5 values
--
function BulkOrderBook.parseDescAsTitleSubtitleTextAndTwoButtons(gumpData)
--[[ Make this go away. Rename it too.
	UO_GenericGump.debug( L"parseDescAsTitleTextAndTwoButtons - setting data for = "..gumpData.name )
	gumpData.title = GGManager.translateTID(gumpData.descData[1])
	gumpData.subtitle = GGManager.translateTID(gumpData.descData[2])
	gumpData.text = GGManager.translateTID(gumpData.descData[3])
	gumpData.leftButtonName = GGManager.translateTID(gumpData.descData[4])
	gumpData.rightButtonName = GGManager.translateTID(gumpData.descData[5])
	
	gumpData.leftButtonID = gumpData.buttonIDs[1]
	gumpData.rightButtonID = gumpData.buttonIDs[2]
--]]	
end


function BulkOrderBook:parseData(gumpData)

--
-- There have been cases where a next button appears on this gump, but no data is displayed on the next page.
-- The problem is not in this function - the issue is with the data being sent by the Wombat script.
-- So, if you happen to be trying to fix a DevTrack issue related to blank tables appearing in Bulk Order Book gumps, don't look here. 
-- This is not the code you're looking for. *waves hand*
--

	-- Set the title 
	WindowUtils.SetActiveDialogTitle(
		GGManager.translateTID( self.descData[1] )..L"  -  "..GGManager.translateTID( self.descData[8] ) )
	-- There is no subtitle

	-- Local variables
	local i -- for looping
	local nextX = 6 -- keeps track of the nextX value for the cell
	local nextString = 1 -- keeps track of what the next string is
	local nextDesc = 13 -- keeps track of what the next descData is

	-- Determine if we are showing the drop column, add header if we are
	local showingDrop = false
	if self.descData[10] ~= 1015313 then
		showingDrop = true
		BulkOrderBook.CreateCell( self, 1, 1, GGManager.translateTID( self.descData[10] ) )	
		nextX = nextX + 1
	end

	-- Show the headers that always appear 
	for i=2, 6 do
		if showingDrop then
			BulkOrderBook.CreateCell( self, i, 1, GGManager.translateTID( self.descData[i] ) ) -- 1 to 5
		else
			BulkOrderBook.CreateCell( self, i-1, 1, GGManager.translateTID( self.descData[i] ) ) -- 2 to 6
		end
	end 
	
	-- Determine if we are showing the price column, add header if we are
	local showingPrice = false
	if self.descData[11] ~= 1015313 then
		showingPrice = true
		BulkOrderBook.CreateCell( self, nextX, 1, GGManager.translateTID( self.descData[11] ) ) -- either 6 or 7
		nextX = nextX + 1
	end

	-- Determine if we are showing the set column, add header if we are
	local showingSet = false
	if self.descData[12] ~= 1015313 then
		showingSet = true
		BulkOrderBook.CreateCell( self, nextX, 1, GGManager.translateTID( self.descData[12] ) ) -- either 6, 7 or 8
		nextX = nextX + 1
	end

	local numCols = nextX - 1 

-- There, that should handle all the header data cases - now I just need to worry about the rest of the data!

	local headsUp = false
	local thisRow = 2
	local nextButton = 3

	-- A row of space looks good here
	for i=1, numCols do
		BulkOrderBook.CreateCell( self, i, thisRow, L"" )
	end
	thisRow = thisRow + 1
	
	while nextDesc < self.descDataCount-1 do
		nextX = 1
		headsUp = false
		-- Check if we're starting a new group
		-- if so:
		-- add a button now (if showingDrop)
		-- add the group type now or show a blank space
		-- remember to add price string and set button later (set headsUp) (Also offset the nextString by 1) 
		if self.descData[nextDesc] == -1 then
			nextDesc = nextDesc + 1			
			headsUp = true
			if showingDrop then
				BulkOrderBook.CreateCell( self, nextX, thisRow, L"", self.buttonIDs[nextButton] )
				nextButton = nextButton + 1
				nextX = nextX + 1	
			end
				BulkOrderBook.CreateCell( self, nextX, thisRow, GGManager.translateTID( self.descData[nextDesc] ) )
				nextDesc = nextDesc + 1
				nextX = nextX + 1
			if showingPrice then
				nextString = nextString + 1
			end		
		else
			if showingDrop then
				BulkOrderBook.CreateCell( self, nextX, thisRow, L"" ) -- L"_DROP" )
				nextX = nextX + 1
			end	
			BulkOrderBook.CreateCell( self, nextX, thisRow, L"" ) -- L"_TYPE" )
			nextX = nextX + 1
		end
		
		-- Add all the standard data for this row
		for i=3,5 do
			BulkOrderBook.CreateCell( self, nextX, thisRow, GGManager.translateTID( self.descData[nextDesc] ) )
			nextDesc = nextDesc + 1
			nextX = nextX + 1
		end 

		-- Add the string that's always there
			BulkOrderBook.CreateCell( self, nextX, thisRow, GGManager.stripMarkup( self.stringData[nextString] ) )
			nextString = nextString + 1
			nextX = nextX + 1

		if showingPrice then
			if headsUp then
				BulkOrderBook.CreateCell( self, nextX, thisRow, GGManager.stripMarkup( self.stringData[nextString-2] ) )
			else
				BulkOrderBook.CreateCell( self, nextX, thisRow, L"" ) -- L"_PRICE" )
			end
			nextX = nextX + 1
		end

		if showingSet then
			if headsUp then
				BulkOrderBook.CreateCell( self, nextX, thisRow, L"", self.buttonIDs[nextButton] )
				nextButton = nextButton + 1
			else
				BulkOrderBook.CreateCell( self, nextX, thisRow, L"" ) -- L"_SET" )
			end
			nextX = nextX + 1
		end

		-- Got to the next row	
		thisRow = thisRow + 1

		if self.descData[nextDesc] == -1 then
			for i=1, numCols do
				BulkOrderBook.CreateCell( self, i, thisRow, L"" )
			end
			thisRow = thisRow + 1
		end
	end -- while

	thisRow = thisRow - 1
	
	-- Now the data is all in the table, we neaten it up!
	BulkOrderBook.neatenTable( self, thisRow, numCols )
	-- Wasn't that easy?

	-- other buttons
--[[ Hardcoded, looks nice
	ButtonSetText(self.windowName.."PrevButtonName", L" PREV" ) -- self.leftButtonName )
	WindowSetId( self.windowName.."PrevButtonName", 3 ) -- self.leftButtonID )	
	ButtonSetText(self.windowName.."NextButtonName", L"NEXT" ) -- self.rightButtonName )
	WindowSetId( self.windowName.."NextButtonName", 1 ) -- self.rightButtonID )	
	ButtonSetText(self.windowName.."ExitButtonName", L"EXIT" ) -- self.leftButtonName )
	WindowSetId( self.windowName.."ExitButtonName", 4 ) -- self.leftButtonID )	
	ButtonSetText(self.windowName.."FilterButtonName", L"FILTER" ) -- self.rightButtonName )
	WindowSetId( self.windowName.."FilterButtonName", 2 ) -- self.rightButtonID )
--]]

	ButtonSetText(self.windowName.."FilterButtonName", GGManager.translateTID( self.descData[7] ) ) -- "Set Filter"
	WindowSetId( self.windowName.."FilterButtonName", self.buttonIDs[1] )
	ButtonSetText(self.windowName.."ExitButtonName", GGManager.translateTID( self.descData[9] ) ) -- "EXIT"
	WindowSetId( self.windowName.."ExitButtonName", self.buttonIDs[2] )

	-- if there should be a next button, make one.
	if self.buttonIDs[self.buttonCount-1] ~= -1 then
		ButtonSetText(self.windowName.."NextButtonName", GGManager.translateTID( self.descData[self.descDataCount-1] ) ) -- L"NEXT" ) -- self.rightButtonName )
		WindowSetId( self.windowName.."NextButtonName", self.buttonIDs[self.buttonCount-1] ) -- self.rightButtonID )	
	else
		-- resize it to 0 size to hide it
		WindowSetDimensions( self.windowName.."NextButtonName", 0, 0 )
	end
	
	-- if there should be a prev button, make one. 
	if self.buttonIDs[self.buttonCount] ~= -1 then
		ButtonSetText(self.windowName.."PrevButtonName", GGManager.translateTID( self.descData[self.descDataCount] ) ) -- L"PREV" ) -- IOUS" ) -- self.leftButtonName )
		WindowSetId( self.windowName.."PrevButtonName", self.buttonIDs[self.buttonCount] )	
	else
		-- resize it to 0 size to hide it
		WindowSetDimensions( self.windowName.."PrevButtonName", 0, 0 )
	end



end


function BulkOrderBook:setFields()
--[[ once parse, use this to set data?
	if self.title then
		WindowUtils.SetActiveDialogTitle( self.title )
    end
	if self.subtitle then
		LabelSetText( self.windowName.."Subtitle", self.subtitle )
    end
    LabelSetText( self.windowName.."ScrollChildText", self.text )
	ButtonSetText(self.windowName.."LeftButtonName", self.leftButtonName )
	WindowSetId( self.windowName.."LeftButtonName", self.leftButtonID )	
	ButtonSetText(self.windowName.."RightButtonName", self.rightButtonName )
	WindowSetId( self.windowName.."RightButtonName", self.rightButtonID )	
	
	-- *** KLUDGE - the size of the subtitle was causing the text to not scroll
	--   to the bottom.
	local subtitle_width, subtitle_height = WindowGetDimensions( self.windowName.."Subtitle" )
	local text_width, text_height = WindowGetDimensions( self.windowName.."ScrollChildText" )	
	WindowSetDimensions( self.windowName.."ScrollChildText", text_width, text_height+subtitle_height )
--]]
end

function BulkOrderBook.getActiveWindowData()
	--local windowName = WindowGetParent(SystemData.ActiveWindow.name)
	local windowName = WindowUtils.GetActiveDialog()
	return BulkOrderBookManager.knownWindows[windowName]
end


----------------------------------------------------------------
-- BulkOrderBook Functions
----------------------------------------------------------------

-- OnInitialize Handler
function BulkOrderBook.Initialize()
	local newWindow = BulkOrderBook:new()
	newWindow.setDataFunction = BulkOrderBook.parseData
	newWindow:Init()
end 

function BulkOrderBook.LeftButtonPressed()
	
	local self = BulkOrderBook.getActiveWindowData()
	if  self.LeftButtonFunction then
		self:LeftButtonFunction()
	else
		self:DefaultButtonFunction()
	end	
end

function BulkOrderBook.RightButtonPressed()
	
	local self = BulkOrderBook.getActiveWindowData()
	if  self.RightButtonFunction then
		self:RightButtonFunction()
	else
		self:DefaultButtonFunction()
	end	
end


function BulkOrderBook.FilterButtonPressed()
	
	local self = BulkOrderBook.getActiveWindowData()
	if  self.FilterButtonFunction then
		self:FilterButtonFunction()
	else
		self:DefaultButtonFunction()
	end	
end


function BulkOrderBook.ExitButtonPressed()
	
	local self = BulkOrderBook.getActiveWindowData()
	if  self.ExitButtonFunction then
		self:ExitButtonFunction()
	else
		self:DefaultButtonFunction()
	end	
end

function BulkOrderBook.OtherButtonPressed()
	UO_GenericGump.debug( L"Amazing! You called OtherButtonPressed()!!!")
	local self = BulkOrderBook.getActiveWindowData()
	if  self.OtherButtonFunction then
		self:OtherButtonFunction()
	else
		self:DefaultButtonFunction()
	end	
end


function BulkOrderBook:DefaultButtonFunction()
	UO_GenericGump.debug( L"BulkOrderBook:DefaultButtonFunction called. ")
	
	local buttonID = WindowGetId( SystemData.ActiveWindow.name )

	-- NOTE: this may need to be changed. Currently WindowGetId seems to return 0,
	--  if a value is not set (and 0 is a valid value). May change C++ to return negative value
	--  when no value is set
	if not buttonID then	
		Debug.PrintToDebugConsole( L"ERROR in BulkOrderBook.DefaultButtonFunction: no ID set for button pressed." )
		return
	end

	UO_GenericGump.debug( L"called BulkOrderBook.DefaultButtonFunction(). Sending button value of "..buttonID )

	UO_GenericGump.broadcastButtonPress( buttonID, self )
	self.OnCloseWindow()
end


-- OnClose Handler
-- Will call DestroyWindow automatically, supposedly.
function BulkOrderBook.OnCloseWindow()
	UO_GenericGump.debug( L"BulkOrderBook.OnCloseWindow called. ")

	GGManager.destroyActiveWindow()
	
	-- Maybe someday...
	--TableCellManager.knownWindows = nil
	--UO_DefaultWindow.CloseDialog()
end



