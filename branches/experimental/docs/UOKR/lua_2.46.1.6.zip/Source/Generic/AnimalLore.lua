
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

AnimalLore = OneButtonDialog:new()

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- AnimalLore Functions
----------------------------------------------------------------

function AnimalLore:setDataFunction()

	-- set title
	self.title = GGManager.stripMarkup(self.stringData[9])
	
	-- This is going to get ugly	
	self.text =
					GGManager.translateTID(self.descData[1])..
	L"\n   "..			GGManager.translateTID(self.descData[2]).. L": ".. GGManager.stripMarkup(self.stringData[11])..
	L"\n   "..			GGManager.translateTID(self.descData[3]).. L": ".. GGManager.stripMarkup(self.stringData[13])..
	L"\n   "..			GGManager.translateTID(self.descData[4]).. L": ".. GGManager.stripMarkup(self.stringData[15])..
	L"\n   "..			GGManager.translateTID(self.descData[5]).. L": ".. GGManager.stripMarkup(self.stringData[10])..
	L"\n   "..			GGManager.translateTID(self.descData[6]).. L": ".. GGManager.stripMarkup(self.stringData[12])..
	L"\n   "..			GGManager.translateTID(self.descData[7]).. L": ".. GGManager.stripMarkup(self.stringData[14])..
	L"\n   "..			GGManager.translateTID(self.descData[8]).. L": ".. GGManager.stripMarkup(self.stringData[16])..
	L"\n"..
	L"\n"..			GGManager.translateTID(self.descData[9])..
	L"\n   "..			GGManager.translateTID(self.descData[10])..
	L"\n"..
	L"\n"..			GGManager.translateTID(self.descData[11])..
	L"\n   "..			GGManager.translateTID(self.descData[12]).. L": ".. GGManager.stripMarkup(self.stringData[17])..
	L"\n   "..			GGManager.translateTID(self.descData[13]).. L": ".. GGManager.stripMarkup(self.stringData[18])..
	L"\n   "..			GGManager.translateTID(self.descData[14]).. L": ".. GGManager.stripMarkup(self.stringData[19])..
	L"\n   "..			GGManager.translateTID(self.descData[15]).. L": ".. GGManager.stripMarkup(self.stringData[20])..
	L"\n   "..			GGManager.translateTID(self.descData[16]).. L": ".. GGManager.stripMarkup(self.stringData[21])..
	L"\n"..
	L"\n"..			GGManager.translateTID(self.descData[17])..
	L"\n   "..			GGManager.translateTID(self.descData[18]).. L": ".. GGManager.stripMarkup(self.stringData[22])..
	L"\n   "..			GGManager.translateTID(self.descData[19]).. L": ".. GGManager.stripMarkup(self.stringData[23])..
	L"\n   "..			GGManager.translateTID(self.descData[20]).. L": ".. GGManager.stripMarkup(self.stringData[24])..
	L"\n   "..			GGManager.translateTID(self.descData[21]).. L": ".. GGManager.stripMarkup(self.stringData[25])..
	L"\n   "..			GGManager.translateTID(self.descData[22]).. L": ".. GGManager.stripMarkup(self.stringData[26])..
	L"\n   "..			GGManager.translateTID(self.descData[23]).. L": ".. GGManager.stripMarkup(self.stringData[27])..
	L"\n"..
	L"\n"..			GGManager.translateTID(self.descData[24])..
	L"\n   "..			GGManager.translateTID(self.descData[25]).. L": ".. GGManager.stripMarkup(self.stringData[5])..
	L"\n   "..			GGManager.translateTID(self.descData[26]).. L": ".. GGManager.stripMarkup(self.stringData[4])..
	L"\n   "..			GGManager.translateTID(self.descData[27]).. L": ".. GGManager.stripMarkup(self.stringData[3])..
	L"\n   "..			GGManager.translateTID(self.descData[28]).. L": ".. GGManager.stripMarkup(self.stringData[1])..
	L"\n   "..			GGManager.translateTID(self.descData[29]).. L": ".. GGManager.stripMarkup(self.stringData[2])..
	L"\n"..
	L"\n"..			GGManager.translateTID(self.descData[30])..
	L"\n   "..			GGManager.translateTID(self.descData[31]).. L": ".. GGManager.stripMarkup(self.stringData[7])..
	L"\n   "..			GGManager.translateTID(self.descData[32]).. L": ".. GGManager.stripMarkup(self.stringData[6])..
	L"\n   "..			GGManager.translateTID(self.descData[33]).. L": ".. GGManager.stripMarkup(self.stringData[8])..
	L"\n"..
	L"\n"..			GGManager.translateTID(self.descData[34])..
	L"\n   "..			GGManager.translateTID(self.descData[35])..
	L"\n"..
	L"\n"..			GGManager.translateTID(self.descData[36])..
	L"\n   "..			GGManager.translateTID(self.descData[37])
--]]


	self.buttonName = GGManager.translateTID(GGManager.OKAY_TID)
	--self.buttonID = gumpData.buttonIDs[1]
	self.buttonID = 0
end


-- OnInitialize Handler
function AnimalLore.Initialize()
	local NewWindow = AnimalLore:new()
	NewWindow:Init()
end

