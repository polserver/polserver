----------------------------------------------------------------
-- ThiefDisguiseKit.lua
----------------------------------------------------------------

ThiefDisguiseKit = MasterGUMP:new()

function ThiefDisguiseKit.Initialize()
	local newWindow					= ThiefDisguiseKit:new()
	
	UOBuildTableFromCSV( "Data/GameData/maleelfhairstyle.csv", "MaleElfHairstylesCSV" )
	UOBuildTableFromCSV( "Data/GameData/femaleelfhairstyle.csv", "FemaleElfHairstylesCSV" )
	
	newWindow.setData				= ThiefDisguiseKit.mySetData
	newWindow:Init()
end

function ThiefDisguiseKit:mySetData()
	-- these are used to differentiate between different sets of data coming in from the server
	local HUMAN_MALE, HUMAN_FEMALE, ELF	= -1, -2, -3
	local case							= self.descData[self.descDataCount]
	
	-- stores the names of elf hairstyles, since the server doesn't send these
	local tidTable						= ThiefDisguiseKit.CreateTidTable( WindowData.MaleElfHairstylesCSV, WindowData.FemaleElfHairstylesCSV )
	
	self.Page						= {}
	
	-- hair styles
	self.Page[1]					= {}
	self.Page[1].Title				= GGManager.translateTID( self.descData[1] )
	self.Page[1].Selections			= {}
	self.Page[1].RadioId			= self.buttonIDs[2]

	local buttonOffset, descOffset, imageOffset, range

	if case == HUMAN_MALE or case == HUMAN_FEMALE then
		buttonOffset	= self.buttonPageIndex[2] - 1
		descOffset		= self.descPageIndex[2] - 1
		imageOffset		= 0
		range			= self.descPageIndex[3] - self.descPageIndex[2]
	else -- elves
		buttonOffset	= 2
		descOffset		= 3
		imageOffset		= 0
		range			= self.buttonCount - 2
	end

	for i = 1, range do
		self.Page[1].Selections[i]		= {}
		self.Page[1].Selections[i].Id	= self.buttonIDs[i + buttonOffset]
		
		if case == HUMAN_MALE or case == HUMAN_FEMALE then
			self.Page[1].Selections[i].Text = GGManager.translateTID( self.descData[i + descOffset] )
		else -- elves
			self.Page[1].Selections[i].Text = GGManager.translateTID( tidTable[self.buttonIDs[i + buttonOffset]] ) -- if there is a hairstyle name
		end

		
		if i < range then -- no art for "none" option
			-- disabling code to create hairstyle icons, as the art is being handled differently than expected
			--self.Page[1].Selections[i].Port = self.portImgData[i + imageOffset]
		elseif case == ELF then
			self.Page[1].Selections[i].Text = GGManager.translateTID( self.descData[4] ) -- "None"
		end
	end

	if case == HUMAN_MALE then
		range = range + 1
		self.Page[1].Selections[range]			= {}
		self.Page[1].Selections[range].Id		= -2
		self.Page[1].Selections[range].Text		= GGManager.translateTID( self.descData[self.descDataCount - 1] ) -- switch to facial hair
		self.Page[1].Selections[range].Bottom	= true
	end

	self.Page[1].MiddleButtonId				= self.buttonIDs[1]
	self.Page[1].MiddleButtonText			= GGManager.translateTID( self.descData[2] ) -- Okay
	
	-- facial hair
	if case == HUMAN_MALE then
		self.Page[2]			= {}
		self.Page[2].Title		= GGManager.translateTID( self.descData[1] )
		self.Page[2].Selections	= {}
		self.Page[2].RadioId	= self.buttonIDs[2]
		
		buttonOffset	= self.buttonPageIndex[3] - 1
		descOffset		= self.descPageIndex[3] - 1
		imageOffset		= self.portImgPageIndex[3] - 1
		range			= self.descPageIndex[4] - self.descPageIndex[3] - 1

		for i = 1, range do
			self.Page[2].Selections[i]		= {}
			self.Page[2].Selections[i].Id	= self.buttonIDs[i + buttonOffset]
			self.Page[2].Selections[i].Text = GGManager.translateTID( self.descData[i + descOffset] )
			
			--[[ disabling code to create hairstyle icons, as the art is being handled differently than expected
			if i < range then -- no art for "none" option
				self.Page[2].Selections[i].Port = self.portImgData[i + imageOffset]
			end
			--]]
		end

		range = range + 1
		self.Page[2].Selections[range]			= {}
		self.Page[2].Selections[range].Id		= -1
		self.Page[2].Selections[range].Text		= GGManager.translateTID( self.descData[self.descDataCount - 2] ) -- switch to hair styles
		self.Page[2].Selections[range].Bottom	= true
		
		self.Page[2].MiddleButtonId				= self.buttonIDs[1]
		self.Page[2].MiddleButtonText			= GGManager.translateTID( self.descData[2] ) -- Okay
	end
end

-- create a table of hairstyle names, indexed by button ID
function ThiefDisguiseKit.CreateTidTable( CSVTable1, CSVTable2 )
	local tidTable = {}

	for i = 1, table.getn( CSVTable1 ) do
		-- HACKY IF STATEMENT CHECK BECAUSE CSV TABLE SEEMS TO CONTAIN NIL VALUES
	    if not ( ( CSVTable1[i].TileArtId == 0 ) and ( CSVTable1[i].StringId == 0 ) ) then
			tidTable[CSVTable1[i].TileArtId] = CSVTable1[i].StringId
		end
	end

	for i = 1, table.getn( CSVTable2 ) do
		-- HACKY IF STATEMENT CHECK BECAUSE CSV TABLE SEEMS TO CONTAIN NIL VALUES
	    if not ( ( CSVTable2[i].TileArtId == 0 ) and ( CSVTable2[i].StringId == 0 ) ) then
			tidTable[CSVTable2[i].TileArtId] = CSVTable2[i].StringId
		end
	end
	
	return tidTable
end

-- overriding this function to display a smaller piece of the art
function ThiefDisguiseKit:SetIcon( selection, choiceName )
	local texture, x, y, scale = "0000", 0, 0, 1
	local inSize, outSize	= 352, 64
	local xOffset, yOffset	= 212, 68

	if  selection.Port
	and selection.Port > 0
	then
		self.RequestedTextures = self.RequestedTextures or {}
		texture, x, y, scale, newWidth, newHeight = RequestTexture( selection.Port, inSize, inSize )
		self.RequestedTextures[#self.RequestedTextures + 1] = selection.Port
		UO_GenericGump.debug( L"    Portrait = "..StringToWString( tostring( selection.Port ) ) )
	end
	
	WindowSetDimensions( choiceName.."IconHolderIcon", outSize, outSize )
	DynamicImageSetTexture( choiceName.."IconHolderIcon", texture, xOffset, yOffset )
	DynamicImageSetTextureScale( choiceName.."IconHolderIcon", scale )
end

function ThiefDisguiseKit.Shutdown()
	UO_GenericGump.debug( L"ThiefDisguiseKit.Shutdown() called." )
	
	UOUnloadCSVTable ("MaleElfHairstylesCSV")
	UOUnloadCSVTable ("FemaleElfHairstylesCSV")
	
	MasterGUMP.Shutdown()
end
