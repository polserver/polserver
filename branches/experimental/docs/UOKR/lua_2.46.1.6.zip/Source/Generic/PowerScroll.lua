----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

PowerScroll = TwoButtonDialog:new()

----------------------------------------------------------------
-- PowerScroll Functions
----------------------------------------------------------------

function PowerScroll:parseData()
	self.subtitle = GGManager.translateTID( self.descData[5] )..L"   "..GGManager.translateTID( self.descData[6] )
	self.text = GGManager.translateTID( self.descData[1] )..L"\n\n"..GGManager.translateTID( self.descData[2] )
	self.leftButtonName = GGManager.translateTID( self.descData[3] )
	self.rightButtonName = GGManager.translateTID( self.descData[4] )		
	self.leftButtonID = self.buttonIDs[1]
	self.rightButtonID = self.buttonIDs[2]
end

-- OnInitialize Handler
function PowerScroll.Initialize()
	local newWindow = PowerScroll:new()
	newWindow.setDataFunction = PowerScroll.parseData
	newWindow:Init()
end
