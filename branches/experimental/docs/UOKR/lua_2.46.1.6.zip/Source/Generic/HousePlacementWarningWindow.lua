
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

HousePlacementWarningWindow = TwoButtonDialog:new()

HousePlacementWarningWindow_GumpData = {}

local HousePlacementWarning_ValidClose = 0
local WindowName
----------------------------------------------------------------
--  Functions
----------------------------------------------------------------


-- custom data set function
function HousePlacementWarningWindow:parseDescAsOneStringTextAndTwoButtons()
	local warning_string = GetStringFromTid(1049583)  -- house placement warning stuff
	
	self.text = WindowUtils.translateMarkup(warning_string)
	
	self.leftButtonName = L"Ok"
	self.rightButtonName = L"Cancel"
	
	self.leftButtonID = 1 -- ok
	self.rightButtonID = 0 -- cancel

end


-- OnInitialize Handler
function HousePlacementWarningWindow.Initialize()
	--Debug.PrintToDebugConsole(L"HousePlacementWarningWindow.Initialize")
	local NewWindow = HousePlacementWarningWindow:new()



	-- setDataFunction is called in TwoButtonDialog:init()
	NewWindow.setDataFunction = HousePlacementWarningWindow.parseDescAsOneStringTextAndTwoButtons
	NewWindow.OnCloseWindow = HousePlacementWarningWindow.OnCloseWindow
	NewWindow.LeftButtonFunction = HousePlacementWarningWindow.LeftButtonFunction
	NewWindow.RightButtonFunction = HousePlacementWarningWindow.RightButtonFunction

	NewWindow:Init()

	UO_GenericGump.retrieveWindowData (HousePlacementWarningWindow_GumpData)

	WindowName = HousePlacementWarningWindow_GumpData.windowName

	WindowUtils.SetWindowTitle( WindowName, L"Warning" )

	Interface.OnCloseCallBack[WindowName] = HousePlacementWarningWindow.UserClosedGump
end
	
function HousePlacementWarningWindow.DoNothing()
	local donothing = 0

end

function HousePlacementWarningWindow.LeftButtonFunction()
	-- ok button
	UO_GenericGump.broadcastButtonPress( 1, HousePlacementWarningWindow_GumpData )
	HousePlacementWarning_ValidClose = 1
	HousePlacementWarningWindow.OnCloseWindow()
end

function HousePlacementWarningWindow.RightButtonFunction()
	-- cancel button
	UO_GenericGump.broadcastButtonPress( 0, HousePlacementWarningWindow_GumpData )
	HousePlacementWarning_ValidClose = 1
	HousePlacementWarningWindow.OnCloseWindow()
end

function HousePlacementWarningWindow.UserClosedGump()
	--Debug.PrintToDebugConsole(L"HousePlacementWarningWindow.UserClosedGump")

	if (HousePlacementWarning_ValidClose == 0) then
		UO_GenericGump.broadcastButtonPress( 0, HousePlacementWarningWindow_GumpData )
	end
	HousePlacementWarningWindow.OnCloseWindow()
end

function HousePlacementWarningWindow.OnCloseWindow()
	--Debug.PrintToDebugConsole(L"HousePlacementWarningWindow.OnCloseWindow")
	
	GGManager.destroyWindow (WindowName)
end


