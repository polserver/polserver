----------------------------------------------------------------
-- BannerDeed.lua
----------------------------------------------------------------

BannerChoice = MasterGUMP:new()

function BannerChoice.Initialize()
	local newWindow					= BannerChoice:new()
	newWindow.setData				= BannerChoice.mySetData
	newWindow.SetIcon				= BannerChoice.mySetIcon
	newWindow:Init()
end

function BannerChoice:mySetData()
	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Selections = {}
	if self.ImageCount > 2 then
		self.Page[1].SelectionTemplate = "BannerChoiceDuelIconSelectable"
	end
	self.Page[1].Selections[1] = {}
	self.Page[1].Selections[2] = {}
	if self.ImageCount > 2 then
		self.Page[1].Selections[1].Id = self.buttonIDs[1]
		self.Page[1].Selections[1].Icon = self.ImageNum[1]
		self.Page[1].Selections[1].IconTwo = self.ImageNum[2]
		self.Page[1].Selections[2].Id = self.buttonIDs[2]
		self.Page[1].Selections[2].Icon = self.ImageNum[3]
		self.Page[1].Selections[2].IconTwo = self.ImageNum[4]
	else
		self.Page[1].Selections[1].Id = self.buttonIDs[1]
		self.Page[1].Selections[1].Icon = self.ImageNum[1]
		self.Page[1].Selections[2].Id = self.buttonIDs[2]
		self.Page[1].Selections[2].Icon = self.ImageNum[2]
	end
	--self.Page[1].MiddleButtonId = self.buttonIDs[1]
	--self.Page[1].MiddleButtonText = GGManager.translateTID( GGManager.CANCEL_TID )
end


---[[
function BannerChoice:mySetIcon( selection, choiceName )
	local texture, x, y, scale, newWidth, newHeight = "0000", 0, 0, 1, 0, 0
	
	if  selection.Icon
	and selection.Icon > 0
	then
		self.RequestedTileArt = self.RequestedTileArt or {}
		texture, x, y, scale, newWidth, newHeight = RequestTileArt( selection.Icon, 64, 64 )
		self.RequestedTileArt[#self.RequestedTileArt + 1] = selection.Icon
		UO_GenericGump.debug( L"    TileArt = "..StringToWString( tostring( selection.Icon ) ) )
	end
	
	WindowSetDimensions( choiceName.."IconHolderIcon", newWidth, newHeight )
	DynamicImageSetTexture( choiceName.."IconHolderIcon", texture, x, y )
	DynamicImageSetTextureScale( choiceName.."IconHolderIcon", scale )

	if  selection.IconTwo
	and selection.IconTwo > 0
	then
		self.RequestedTileArt = self.RequestedTileArt or {}
		texture, x, y, scale, newWidth, newHeight = RequestTileArt( selection.IconTwo, 64, 64 )
		self.RequestedTileArt[#self.RequestedTileArt + 1] = selection.IconTwo
		UO_GenericGump.debug( L"    TileArtTwo = "..StringToWString( tostring( selection.IconTwo ) ) )
	end
	
	WindowSetDimensions( choiceName.."IconHolderTwoIcon", newWidth, newHeight )
	DynamicImageSetTexture( choiceName.."IconHolderTwoIcon", texture, x, y )
	DynamicImageSetTextureScale( choiceName.."IconHolderTwoIcon", scale )

	-- Have to fix the anchors for specific cases. The defualt looks perfect for Ankhs, but isn't so good for, say, Hearth of the Home Fires.
	-- Add other cases that use this gump here as needed.
	if selection.IconTwo then
		if selection.IconTwo == 9056 then -- Hearth of Home Fire South
			WindowClearAnchors( choiceName.."IconHolderTwo" )
			WindowAddAnchor( choiceName.."IconHolderTwo", "topleft", choiceName, "topleft", 10, 1 )
		elseif selection.IconTwo == 9048 then -- Hearth of Home Fire East
			WindowClearAnchors( choiceName.."IconHolderTwo" )
			WindowAddAnchor( choiceName.."IconHolderTwo", "topleft", choiceName, "topleft", 10, 1 )
		end
	end
end
--]]