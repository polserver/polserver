
----------------------------------------------------------------
-- Global Variables/Functions
----------------------------------------------------------------

BulkOrderFilter = {}

BulkOrderFilterManager = GGManager

function BulkOrderFilter:new( newWindow )
	newWindow = newWindow or {}
	setmetatable(newWindow, self)
	self.__index = self
	
	return newWindow
end


function BulkOrderFilter:Init()
	UO_GenericGump.debug( L"called BulkOrderFilter:Init()" )
	
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end

	if self.setFields then
		self:setFields()
	end

	BulkOrderFilterManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
	
	Debug.PrintToDebugConsole( L"Initialize "..self.name )
end


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- BulkOrderFilter Functions
----------------------------------------------------------------


function BulkOrderFilter:parseData(gumpData)
	
end

-- TODO: Replace this so it does a check box (that is checked or not) with a label
-- I'm not going to worry about indicating which selection is active til that is done
function BulkOrderFilter:addButton( anchorTo, uniqueID, wText, buttonID)
	local me = self.windowName.."Button"..uniqueID
	local scrollParent = self.windowName.."ScrollChild"
	CreateWindowFromTemplate( me, "MediumButton",  scrollParent )
	ButtonSetText( me, wText )
	if uniqueID == 1 then -- the first one has no 5 pixel space
		WindowAddAnchor( me, "top", anchorTo, "top", 0, 0 ) -- tl, tl
	else
		WindowAddAnchor( me, "bottom", anchorTo, "top", 0, 5 ) -- bl, tl
	end
	WindowSetId( me, buttonID )
--	ButtonSetPressedFlag( me, true ) -- THIS WORKS (sort of)
--	ButtonSetTextColor( me, 22 )
	return me
end

function BulkOrderFilter:addText( anchorTo, uniqueID, wText )
	local me = self.windowName.."Text"..uniqueID
	local scrollParent = self.windowName.."ScrollChild"
	CreateWindowFromTemplate( me, "SomeText",  scrollParent )
	LabelSetText( me, wText )
	if uniqueID == 1 then -- the first one has no 5 pixel space
		WindowAddAnchor( me, "top", anchorTo, "top", 0, 0 ) -- tl, tl
	else
		WindowAddAnchor( me, "bottom", anchorTo, "top", 0, 5 ) -- bl, tl
	end
	return me
end

function BulkOrderFilter:addSpace( anchorTo, uniqueID )
	local me = self.windowName.."Space"..uniqueID
	local scrollParent = self.windowName.."ScrollChild"
	CreateWindowFromTemplate( me, "SomeText",  scrollParent )
	LabelSetText( me, L" " )
	if uniqueID == 1 then -- the first one has no 5 pixel space
		WindowAddAnchor( me, "top", anchorTo, "top", 0, 0 )	-- tl, tl
	else
		WindowAddAnchor( me, "bottom", anchorTo, "top", 0, 5 ) -- bl, tl
	end
	return me
end


function BulkOrderFilter:setFields()

	-- Title
	WindowUtils.SetActiveDialogTitle( GGManager.translateTID( self.descData[1] ) )

	-- Anchor point for the first thing is the scroll child
	local curAnchor = self.windowName.."ScrollChild"

	-- Pick filter buttons
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 1, GGManager.translateTID( self.descData[32] ), self.buttonIDs[27] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 2, GGManager.translateTID( self.descData[33] ), self.buttonIDs[28] )
	curAnchor = BulkOrderFilter.addSpace( self, curAnchor, 3 )
	
	-- Type buttons
	curAnchor = BulkOrderFilter.addText( self, curAnchor, 4, GGManager.translateTID( self.descData[2] ) )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 5, GGManager.translateTID( self.descData[3] ), self.buttonIDs[1] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 6, GGManager.translateTID( self.descData[4] ), self.buttonIDs[2] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 7, GGManager.translateTID( self.descData[5] ), self.buttonIDs[3] )
	curAnchor = BulkOrderFilter.addSpace( self, curAnchor, 8 )
	
	-- Quality Buttons
	curAnchor = BulkOrderFilter.addText( self, curAnchor, 9, GGManager.translateTID( self.descData[6] ) )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 10, GGManager.translateTID( self.descData[7] ), self.buttonIDs[4] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 11, GGManager.translateTID( self.descData[8] ), self.buttonIDs[5] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 12, GGManager.translateTID( self.descData[9] ), self.buttonIDs[6] )
	curAnchor = BulkOrderFilter.addSpace( self, curAnchor, 13 )
	
	-- Material Buttons
	curAnchor = BulkOrderFilter.addText( self, curAnchor, 14, GGManager.translateTID( self.descData[10] ) )
	-- May want to add an all button sometime in the future
	--curAnchor = BulkOrderFilter.addButton( self, curAnchor, 38, GGManager.translateTID( self.descData[3] ), self.buttonIDs[???] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 15, GGManager.translateTID( self.descData[11] ), self.buttonIDs[7] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 16, GGManager.translateTID( self.descData[12] ), self.buttonIDs[8] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 17, GGManager.translateTID( self.descData[13] ), self.buttonIDs[9] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 18, GGManager.translateTID( self.descData[14] ), self.buttonIDs[10] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 19, GGManager.translateTID( self.descData[15] ), self.buttonIDs[11] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 20, GGManager.translateTID( self.descData[16] ), self.buttonIDs[12] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 21, GGManager.translateTID( self.descData[17] ), self.buttonIDs[13] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 22, GGManager.translateTID( self.descData[18] ), self.buttonIDs[14] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 23, GGManager.translateTID( self.descData[19] ), self.buttonIDs[15] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 24, GGManager.translateTID( self.descData[20] ), self.buttonIDs[16] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 25, GGManager.translateTID( self.descData[21] ), self.buttonIDs[17] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 26, GGManager.translateTID( self.descData[22] ), self.buttonIDs[18] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 27, GGManager.translateTID( self.descData[23] ), self.buttonIDs[19] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 28, GGManager.translateTID( self.descData[24] ), self.buttonIDs[20] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 29, GGManager.translateTID( self.descData[25] ), self.buttonIDs[21] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 30, GGManager.translateTID( self.descData[26] ), self.buttonIDs[22] )
	curAnchor = BulkOrderFilter.addSpace( self, curAnchor, 31 )
	
	-- Amount/Quantity Buttons
	curAnchor = BulkOrderFilter.addText( self, curAnchor, 32, GGManager.translateTID( self.descData[27] ) )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 33, GGManager.translateTID( self.descData[28] ), self.buttonIDs[23] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 34, GGManager.translateTID( self.descData[29] ), self.buttonIDs[24] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 35, GGManager.translateTID( self.descData[30] ), self.buttonIDs[25] )
	curAnchor = BulkOrderFilter.addButton( self, curAnchor, 36, GGManager.translateTID( self.descData[31] ), self.buttonIDs[26] )

	-- KLUDGE: We need an extra spacer here or the scroll window is too exact looking
	curAnchor = BulkOrderFilter.addSpace( self, curAnchor, 37 )

	-- Clear button
	-- Hardcode TID since it is a small button which has no room for the real text
	ButtonSetText( self.windowName.."ClearButton", GGManager.translateTID( 1062141 ) ) -- GGManager.translateTID( self.descData[34] ) )
	WindowSetId( self.windowName.."ClearButton", self.buttonIDs[29] )
	
	-- Apply Button
	ButtonSetText( self.windowName.."ApplyButton", GGManager.translateTID( self.descData[35] ) )
	WindowSetId( self.windowName.."ApplyButton", self.buttonIDs[30] )	
end

function BulkOrderFilter.getActiveWindowData()
	local windowName = WindowUtils.GetActiveDialog()
	return BulkOrderFilterManager.knownWindows[windowName]
end

----------------------------------------------------------------
-- BulkOrderFilter Functions
----------------------------------------------------------------

-- OnInitialize Handler
function BulkOrderFilter.Initialize()
	local newWindow = BulkOrderFilter:new()
	newWindow.setDataFunction = BulkOrderFilter.parseData
	newWindow:Init()
end 


function BulkOrderFilter.SomeButtonPressed()
	
	local self = BulkOrderFilter.getActiveWindowData()
	if  self.SomeButtonFunction then
		self:SomeButtonFunction()
	else
		self:DefaultButtonFunction()
	end	
 end


function BulkOrderFilter:DefaultButtonFunction()
	UO_GenericGump.debug( L"BulkOrderFilter:DefaultButtonFunction called. ")
	
	local buttonID = WindowGetId( SystemData.ActiveWindow.name )

	-- NOTE: this may need to be changed. Currently WindowGetId seems to return 0,
	--  if a value is not set (and 0 is a valid value). May change C++ to return negative value
	--  when no value is set
	if not buttonID then	
		Debug.PrintToDebugConsole( L"ERROR in BulkOrderFilter.DefaultButtonFunction: no ID set for button pressed." )
		return
	end
	UO_GenericGump.debug( L"called BulkOrderFilter.DefaultButtonFunction(). Sending button value of "..buttonID )
	UO_GenericGump.broadcastButtonPress( buttonID, self )
	self.OnCloseWindow()
end


-- OnClose Handler
function BulkOrderFilter.OnCloseWindow()
	UO_GenericGump.debug( L"BulkOrderFilter.OnCloseWindow called. ")

	GGManager.destroyActiveWindow()
	
	-- TabelCellManager.knownWindows = nil
end



