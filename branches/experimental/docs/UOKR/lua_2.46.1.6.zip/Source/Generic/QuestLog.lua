
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

QuestLog = ChoiceList:new()

function QuestLog.ToggleQuestLogWindow()

	if not QuestLog.showing then
		BroadcastEvent( SystemData.Events.REQUEST_OPEN_QUEST_LOG )
	else
		-- don't just close it. Need to return Close Button ID to server
        --WindowAssignFocus( QuestLog.windowName.."BottomButton", true )

		QuestLog.BottomButtonFunction()
	end

	return QuestLog.showing 
end


function QuestLog.getShowing()
	return QuestLog.showing 
end


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------


QuestLog.showing = false
QuestLog.TID_QUESTLOG = 1046026
 
----------------------------------------------------------------
-- QuestLog Functions
----------------------------------------------------------------

-- Does anyone know why this is a one off and not a direct inherits?
--
function QuestLog:setDataFunction()
	Interface.OnCloseCallBack[self.windowName] = QuestLog.BottomButtonFunction

	if self.descData then

		relativeWindow = self:CreateSubtitle( GGManager.translateTID( self.descData[1] ) ) 
		
		-- note: don't iterate through the table itself
		for choiceNum=2, self.descDataCount do
			relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
					self.buttonIDs[choiceNum], GGManager.translateTID( self.descData[choiceNum] ),
					"bottom", relativeWindow, "top", 0, 0 )
		end

	end  -- if descData


	self:CreateBottomButton( GGManager.translateTID( GGManager.OKAY_TID ), self.buttonIDs[1] )
end
	

-- OnInitialize Handler
--
-- *** NOTE: There is only one QuestLog ever open at a time, so unlike most
--   Generic Gumps, the base class data can be used rather than doing a 
--   QuestLog:new() call to create object data.
--
function QuestLog.Initialize()
	-- right now we're going to limit this window to only one version, so 
    --   delete any previous window before displaying new one
	if QuestLog.showing then
		QuestLog.OnCloseWindow()
	end
	QuestLog:Init()
	QuestLog.showing = true
	WindowUtils.SetWindowTitle(WindowUtils.GetActiveDialog(), GetStringFromTid(QuestLog.TID_QUESTLOG))
	ButtonSetPressedFlag("MenuBarWindowStatusBarToggleQuests",true)
end


-- NOTE: this function hardcodes the button ID and data sent because
-- SystemData.ActiveWindow is not always in scope to do it the normal way
--
function QuestLog.BottomButtonFunction()
	UO_GenericGump.debug( L"QuestLog.BottomButtonFunction called" )
	
	UO_GenericGump.broadcastButtonPress( QuestLog.buttonIDs[1], QuestLog )

	QuestLog.OnCloseWindow()
end



function QuestLog.Shutdown()
	UO_GenericGump.debug( L"QuestLog.Shutdown()." )
	
	if QuestLog.getShowing() == true then
		UO_GenericGump.broadcastButtonPress( QuestLog.buttonIDs[1], QuestLog )	
		QuestLog.showing = false
	end
	
	GGManager.unregisterActiveWindow()
	
	ButtonSetPressedFlag("MenuBarWindowStatusBarToggleQuests",false)
end

function QuestLog.OnCloseWindow()
	UO_GenericGump.debug( L"QuestLog.OnCloseWindow()." )
	if not QuestLog.showing then
		UO_GenericGump.debug( L"QuestLog.OnCloseWindow() called but window does not exist." )
		return
	end

	QuestLog.showing = false
	GGManager.destroyWindow( QuestLog.windowName, GGManager.DONT_DELETE_DATA_YET )
end


