
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

HouseSecuritySetting = { } -- ChoiceList:new()

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- HouseSecuritySettings Functions
----------------------------------------------------------------

-- custom set data function
function HouseSecuritySetting:parsesWithStringInSubtitle() -- gumpData)
		-- hardcode the button name ("CANCEL")
		ChoiceList.CreateBottomButton( self, GGManager.translateTID( GGManager.CANCEL_TID ), 0 ) --gumpData.buttonIDs[1] ) -- Cancel button == 1?
		-- set the title
		WindowUtils.SetActiveDialogTitle( GGManager.translateTID( self.descData[1] ) )
		-- set the subtitle, append the string data
		relativeWindow = ChoiceList.CreateSubtitle( self, GGManager.translateTID( self.descData[2] )..
							L" "..GGManager.stripMarkup( self.stringData[1] ) )			
		-- for the remaining descdata, make selectable text
		for choiceNum=3, self.descDataCount do
			relativeWindow = ChoiceList.CreateChoiceListSelectableText( self, self.buttonIDs[choiceNum-2],
							  GGManager.translateTID( self.descData[choiceNum] ),
							  "bottom", relativeWindow, "top", 0, 10 )
		end -- for
end -- parseWithStringInSubtitle()

-- on initialize handler
function HouseSecuritySetting.Initialize()
UO_GenericGump.debug( L"HouseSecuritySetting.Initialize() called." )
	HouseSecuritySetting.setDataFunction = HouseSecuritySetting.parsesWithStringInSubtitle
	ChoiceList.Init(HouseSecuritySetting)
end -- on initialize handler

-- Something is wrong with ChoiceList still, these 3 functions shouldn't need to get inherited, but it complains that it can't find them
function HouseSecuritySetting.OnCloseWindow()
	UO_GenericGump.debug( L"HouseSecuritySetting.OnCloseWindow()." )
	GGManager.destroyWindow(HouseSecuritySetting.windowName)
end

function HouseSecuritySetting.BottomButtonFunction()
	GGManager.destroyWindow(HouseSecuritySetting.windowName)
end

function HouseSecuritySetting.TextSelectedFunction()
	choiceNum = WindowGetId( SystemData.ActiveWindow.name)
	UO_GenericGump.debug( L"called HouseSecuritySetting.TextSelectedFunction() choiceNum = "..choiceNum )
	UO_GenericGump.broadcastButtonPress( choiceNum, HouseSecuritySetting )
	HouseSecuritySetting.OnCloseWindow()
end
