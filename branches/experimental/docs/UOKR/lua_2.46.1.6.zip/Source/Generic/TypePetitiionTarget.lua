
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

TypePetitiionTarget = TextEntry:new()


----------------------------------------------------------------
-- TypePetitiionTarget Functions
----------------------------------------------------------------


-- custom data set function 
function TypePetitiionTarget:setDataFunction()
	
	TextEntry.setDataFunction(self)
	
	Interface.OnCloseCallBack[self.windowName] = TypePetitiionTarget.OnCancel
	
	self.numOfTextBoxes = 3
	
	self.textBoxID[1] = self.buttonIDs[3]
	self.textBoxID[2] = self.buttonIDs[4]
	self.textBoxID[3] = self.buttonIDs[5]
	
	self.submitButtonID = self.buttonIDs[1]
	self.cancelButtonID = self.buttonIDs[2]


end


-- OnInitialize Handler
function TypePetitiionTarget.Initialize()
	TypePetitiionTarget:new():Init()
end
	


