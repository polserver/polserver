
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

CancelInsuranceConfirm = { 

	LEFT_BUTTON_ID = 0,
	RIGHT_BUTTON_ID = 100,
}



----------------------------------------------------------------
-- CancelInsuranceConfirm Functions
----------------------------------------------------------------

-- OnInitialize Handler
function CancelInsuranceConfirm.Initialize()
	-- setDataFunction is called in TwoButtonDialog:init()
	CancelInsuranceConfirm.setDataFunction = TwoButtonDialog.parseDescAsTextAndTwoButtons
	TwoButtonDialog.Init(CancelInsuranceConfirm)
end
	
	