----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

HeadRedeed = TwoButtonDialog:new()

----------------------------------------------------------------
-- HeadRedeed Functions
----------------------------------------------------------------

function HeadRedeed:parseData()
	self.text = GGManager.translateTID( self.descData[1] )
	self.leftButtonName = GGManager.translateTID( GGManager.OKAY_TID )
	self.rightButtonName = GGManager.translateTID( GGManager.CANCEL_TID)
	self.leftButtonID = self.buttonIDs[1]
	self.rightButtonID = self.buttonIDs[2]
end

-- OnInitialize Handler
function HeadRedeed.Initialize()
	local newWindow = HeadRedeed:new()
	newWindow.setDataFunction = HeadRedeed.parseData
	newWindow:Init()
end