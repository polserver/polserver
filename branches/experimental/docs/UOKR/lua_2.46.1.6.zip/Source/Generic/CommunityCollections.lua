
----------------------------------------------------------------
-- CommunityCollections
----------------------------------------------------------------

CommColl =
{
	Page = {}
}

CommCollManager = GGManager

function CommColl.Initialize()
	local commColl = CommColl:new()
	commColl:Init()
end

function CommColl:new( commColl )
	commColl = commColl or {}
	setmetatable( commColl, self )
	self.__index = self
	
	commColl.Page = {}

	return commColl
end

function CommColl:Init()
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end
	
	CommCollManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end

function CommColl:setDataFunction()
	-- descData[1] is the title
	WindowUtils.SetActiveDialogTitle( GGManager.translateTID( self.descData[1] ) )
	
	self.RequestedTileArt	= {}

	local whoIam			= 0
	local lButtonID			= 0		-- hardcodes the left button ID based on state of whoIam, because the button data from wombat is highly variable
	local pageOffSet		= 2		-- wombat is funky, skip to second page because first 2 pages are the same
	local descItrOffSet		= 0
	local descItrEndOffSet	= 0
	local strItrOffSet		= 0
	local strItrEndOffSet	= 0
	local btnItrOffSet		= 0
	local btnItrEndOffSet	= 0
	local imgItrOffSet		= 0
	local imgItrEndOffSet	= 0
	local hueItrOffSet		= 0
	local hueItrEndOffSet	= 0
	local ttipItrOffSet		= 2		-- tooltip data gets added for the button and the text, we only need one
	local ttipItrEndOffSet	= 0

	if self.descData[3] == 1072837 then				-- donations page
		whoIam		= 1
		lButtonID	= 1 -- button says "Rewards"
	elseif self.descData[3] == 1072844 then			-- rewards page
		whoIam		= 2
		lButtonID	= 50 -- button says "Status"
	elseif self.descData[3] == 1074255 then			-- rewards hue page
		whoIam		= 3
		lButtonID	= 1 -- button says "Rewards"
	end
	
	-- the subtitle
	if whoIam == 1 then
		LabelSetText( self.windowName.."Subtitle",	  GGManager.translateTID( self.descData[2] )..L" "..self.stringData[1]..L"\n"
													..GGManager.translateTID( self.descData[3] )..L" "..self.stringData[2]..L"\n"
													..GGManager.translateTID( self.descData[4] )..L" "..self.stringData[3]..L"\n\n"
													..GGManager.translateTID( self.descData[5] ) )
		strItrOffSet	= 3
		btnItrEndOffSet	= 3
		
	elseif whoIam == 2 or whoIam == 3 then
		LabelSetText( self.windowName.."Subtitle",	  GGManager.translateTID( self.descData[2] )..L" "..self.stringData[1]..L"\n\n"
													..GGManager.translateTID( self.descData[3] ) )
		strItrOffSet	= 1
		btnItrOffSet	= 1
		
		if whoIam == 2 then
			btnItrEndOffSet	= 2
		else
			btnItrEndOffSet	= 1
		end
	end

	-- Create each page
	local pageCount = 0
	for page = pageOffSet, table.getn( self.descPageIndex ) do

		local strItr		= self.stringPageIndex[page]	+ strItrOffSet
		local strItrEnd		= self.stringDataCount			- strItrEndOffSet	-- good for the last page
		local btnItr		= self.buttonPageIndex[page]	+ btnItrOffSet
		local btnItrEnd		= self.buttonCount				- btnItrEndOffSet	-- good for the last page
		local imgItr		= self.ImagePageIndex[page]		+ imgItrOffSet
		local hueItr		= self.textHuePageIndex[page]	+ hueItrOffSet
		local toolTipItr	= self.toolTipPageIndex[page]	--+ ttipItrOffSet	-- not initially!
		
		if page < table.getn( self.descPageIndex ) then	-- wait we're not the last page!

			strItrEnd		= self.stringPageIndex[page + 1] - 1 - strItrEndOffSet
			btnItrEnd		= self.buttonPageIndex[page + 1] - 1 - btnItrEndOffSet
		end
		
		local pageName	= self.windowName.."Scroll"..page
		local pageChild	= pageName.."Child"
		
		CreateWindowFromTemplate( pageName,	 "CommCollScroll",      self.windowName )
		WindowAddAnchor( pageName, "bottomleft",  self.windowName.."Subtitle", "topleft",      0,  10 )
		WindowAddAnchor( pageName, "bottomright", self.windowName,             "bottomright", -5, -70 )

ScrollWindowUpdateScrollRect( pageName )

		local hue = 0
		local text = self.stringData[strItr]
		if whoIam == 3 then
			text = L""
			hue = self.textHueData[hueItr]
		end
		
		relativeWindow = CommColl:CreateSelectableIconText( btnItr, self.buttonIDs[btnItr], self.ImageNum[imgItr], text, hue, "top", pageChild, "top", 0, 10, page )
		self.Tooltips = self.Tooltips or {}
		self.Tooltips[relativeWindow] = self.toolTipData[toolTipItr]
		strItr		= strItr + 1
		btnItr		= btnItr + 1
		imgItr		= imgItr + 1
		hueItr		= hueItr + 1
		toolTipItr	= toolTipItr + ttipItrOffSet

		for i = btnItr, btnItrEnd do
			local text = self.stringData[strItr]
			if whoIam == 3 then
				text = L""
				hue = self.textHueData[hueItr]
			end
			
			relativeWindow = CommColl:CreateSelectableIconText( btnItr, self.buttonIDs[btnItr], self.ImageNum[imgItr], text, hue, "bottom", relativeWindow, "top", 0, 10, page )
			self.Tooltips[relativeWindow] = self.toolTipData[toolTipItr]
			strItr		= strItr + 1
			btnItr		= btnItr + 1
			imgItr		= imgItr + 1
			hueItr		= hueItr + 1
			toolTipItr	= toolTipItr + ttipItrOffSet
		end

		if page <= pageOffSet then
			self.currentPage = page
			ButtonSetDisabledFlag( self.windowName.."PrevButton", true )
		else
			WindowSetShowing( pageName, false )	-- hide all but first page
		end
		
		self.Page[page] = pageName
		
		-- *** KLUDGE - the size of the subtitle was causing the text to not scroll
		--   to the bottom.
		local subtitle_width, subtitle_height	= WindowGetDimensions( self.windowName.."Subtitle" )
		local   scroll_width,   scroll_height	= WindowGetDimensions( pageChild )	
		WindowSetDimensions( pageChild, scroll_width, scroll_height + subtitle_height )
		
		pageCount = pageCount + 1
	end

	-- If we only have one page, disable and hide unneeded buttons
	if pageCount == 1 then
		ButtonSetDisabledFlag( self.windowName.."NextButton", true )
		WindowSetShowing( self.windowName.."NextButton", false )
		WindowSetShowing( self.windowName.."PrevButton", false )
	end
	
	-- Prev button
	WindowSetId( self.windowName.."PrevButton", -1 )

	-- left button
	if whoIam == 1 then
		ButtonSetText( self.windowName.."LeftButton", GGManager.translateTID( self.descData[6] ) )
		WindowSetId( self.windowName.."LeftButton", lButtonID )
	elseif whoIam == 2 or whoIam == 3 then
		ButtonSetText( self.windowName.."LeftButton", GGManager.translateTID( self.descData[4] ) )
		WindowSetId( self.windowName.."LeftButton", lButtonID )
	end
	
	-- no descData or buttonID for cancel button
	ButtonSetText( self.windowName.."RightButton", GGManager.translateTID( GGManager.CANCEL_TID ) )
	WindowSetId( self.windowName.."RightButton", 0 )

	-- Next button
	WindowSetId( self.windowName.."NextButton", 1 )
end	

function CommColl:CreateSelectableIconText( choiceNum, choiceID, iconNum, wText, hue, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset, myPage, isRight )
	local windowName	= WindowUtils.GetActiveDialog()
	local choiceName	= windowName.."Choice"..choiceNum
	local parentName	= windowName.."Scroll"..myPage.."Child"
	
	if isRight then
		parentName		= windowName.."RightScrollChild"
	end
	
	if	myPage and myPage ~= "" then
		--parentName		= parentName..myPage
	end
	
	local texture, x, y, scale, newWidth, newHeight = RequestTileArt( iconNum, 64, 64 )
	self.RequestedTileArt = self.RequestedTileArt or {}
	self.RequestedTileArt[#self.RequestedTileArt + 1] = texture
	
	if scale == 1 then
		scale = 1.28
		newWidth = newWidth * scale
		newHeight = newHeight * scale
	end
	
	CreateWindowFromTemplate( choiceName, "CommCollSelectableIconText", parentName )
	WindowAddAnchor( choiceName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	WindowSetId( choiceName, choiceID )
	WindowSetDimensions( choiceName.."Icon", newWidth, newHeight )
	DynamicImageSetTexture( choiceName.."Icon", texture, x, y )
	DynamicImageSetTextureScale( choiceName.."Icon", scale )
	LabelSetText( choiceName.."Text" , wText )
	
	if hue ~= 0 then
		local r, g, b, a = HueRGBAValue(hue)
		WindowSetTintColor( choiceName.."Icon", r, g, b )
	end
	
	if choiceID == -1 then
		ButtonSetDisabledFlag( choiceName.."Button", true )
		WindowSetTintColor( choiceName.."Icon", 128, 128, 128 )
	end
	
	return choiceName
end

function CommColl.ButtonPressed()
	local self = CommCollManager.knownWindows[WindowUtils.GetActiveDialog()]
	self:ButtonSelected()
end

function CommColl:ButtonSelected()
	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	
	if choiceNum ~= -1 then
		--UO_GenericGump.broadcastSelections( choiceNum, { choiceNum }, self )
		UO_GenericGump.broadcastButtonPress( choiceNum, self )
		self.OnCloseWindow()
	end
end

function CommColl.LRButtonPressed()
	local self = CommCollManager.knownWindows[WindowUtils.GetActiveDialog()]
	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	
	UO_GenericGump.debug( L"CommColl.LRButtonPressed() choiceNum = "..choiceNum )
	
	UO_GenericGump.broadcastSelections( choiceNum, { choiceNum }, self )
	self.OnCloseWindow()
end

function CommColl.PNButtonPressed()
	if ButtonGetDisabledFlag( SystemData.ActiveWindow.name ) then
--		UO_GenericGump.debug( L"CommColl.PrevNextButtonPressed: clicked on disabled button." )
		return
	end

	direction = WindowGetId( SystemData.ActiveWindow.name )
	
	if not direction then	
		Debug.PrintToDebugConsole( L"ERROR in CommColl.DefaultButtonFunction: no ID set for button pressed." )
		return
	end

	local self = CommCollManager.knownWindows[WindowUtils.GetActiveDialog()]

	WindowSetShowing( self.Page[self.currentPage], false )
	self.currentPage = self.currentPage + direction
	WindowSetShowing( self.Page[self.currentPage], true )

	if self.currentPage == 2 then
		ButtonSetDisabledFlag( self.windowName.."PrevButton", true )
	else
		ButtonSetDisabledFlag( self.windowName.."PrevButton", false )
	end
	if self.currentPage == table.getn( self.stringPageIndex ) then -- We skip the unused strings and that first page
		ButtonSetDisabledFlag( self.windowName.."NextButton", true )
	else
		ButtonSetDisabledFlag( self.windowName.."NextButton", false )
	end
end

function CommColl.Shutdown()
	UO_GenericGump.debug( L"CommColl.Shutdown() called." )
	
	local self = CommCollManager.knownWindows[WindowUtils.GetActiveDialog()]	
	if self == nil then
		UO_GenericGump.debug( StringToWString( "Shutdown hander called for "..SystemData.ActiveWindow.name.." but data already deleted" ) )
		return
	end	
	
	-- Delete any requested Tile Art
	if self.RequestedTileArt then
		for _, art in pairs( self.RequestedTileArt ) do
			ReleaseTileArt( art )
		end
	end
		
	GGManager.unregisterActiveWindow()
end

function CommColl.OnCloseWindow()
	UO_GenericGump.debug( L"CommColl.OnCloseWindow() called." )

	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )		
end

function createPortrait( portraitNum )
	local  width=64
	local  height=64
	
	texture, x, y = RequestTileArt( portraitNum, width, height )
	self.RequestedTileArt[#self.RequestedTileArt + 1] = texture
	
	if not texture then
		texture, x, y = GetIconData(0) -- icon name="No Icon Set"
	end
	
	return texture, x, y
end

-- table.getn() only returns the sequencial index from 1 to n, not the negative ones as well
function getTableSize( table )
	local count = 0
	
	for _, _ in pairs( table ) do
		count = count + 1
	end
	
	return count
end

function CommColl:toString()
	--local str = L"outputting table = "..self.name..L"\n\n"
	local str = L"outputting table = "..L"\n\n"
	for k, v in pairs( self ) do
		if type( v ) == "wstring" or type( v ) == "number" or type( v ) == "boolean" then
				str = str..StringToWString( tostring( k ) )..L" = "..v..L"\n"
		elseif type( v ) == "table" then
			for i, value in pairs( v ) do
				str = str..StringToWString( tostring( k ) )..L"["..StringToWString(tostring(i))..L"]"..L" = "..StringToWString(tostring(v[i]))..L"\n"
			end
		end
	end
	return str
end

function CommCollManager:toString()
	--local str = L"outputting table = "..self.name..L"\n\n"
	local str = L"outputting table = "..L"\n\n"
	for k, v in pairs( self ) do
		if type( v ) == "wstring" or type( v ) == "number" or type( v ) == "boolean" then
				str = str..StringToWString( tostring( k ) )..L" = "..v..L"\n"
		elseif type( v ) == "table" then
			for i, value in pairs( v ) do
				str = str..StringToWString( tostring( k ) )..L"["..StringToWString(tostring(i))..L"]"..L" = "..StringToWString(tostring(v[i]))..L"\n"
			end
		end
	end
	return str
end

function CommColl.OnMouseOver()
	local self = CommCollManager.knownWindows[WindowUtils.GetActiveDialog()]
	local name = SystemData.ActiveWindow.name
	
	if self ~= nil then
		Tooltips.CreateTextOnlyTooltip( name, GGManager.translateTID( self.Tooltips[name] ) )
		Tooltips.Finalize()
		Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_TOP )
	end 
end
