----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

HouseCommit = MasterGUMP:new()

function HouseCommit.Initialize()

	local newWindow					= HouseCommit:new()
	newWindow.setData				= HouseCommit.mySetData
	newWindow:Init()
end

function HouseCommit:mySetData()
	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Title = GGManager.translateTID( self.descData[1] )
	self.Page[1].ScrollText =
		GGManager.translateTID( self.descData[6] )..L"\n\n"..
		GGManager.translateTID( self.descData[2] )..L"        "..		GGManager.stripMarkup( self.stringData[1] )..L"\n\n"..
		GGManager.translateTID( self.descData[3] )..L"              "..	GGManager.stripMarkup( self.stringData[2] )..L"\n"..
		GGManager.translateTID( self.descData[4] )..L"   "..			GGManager.stripMarkup( self.stringData[3] )..L"\n"..
		GGManager.translateTID( self.descData[8] )..L"              "..	GGManager.stripMarkup( self.stringData[4] )			
	if self.buttonIDs[2] then
		self.Page[1].LeftButtonText = GGManager.translateTID( self.descData[7] )
		self.Page[1].RightButtonText = GGManager.translateTID( self.descData[5] )	
		self.Page[1].LeftButtonId = self.buttonIDs[2]
		self.Page[1].RightButtonId = self.buttonIDs[1]
	else
		self.Page[1].MiddleButtonText = GGManager.translateTID( GGManager.CLOSE_TID )	
		self.Page[1].MiddleButtonId = self.buttonIDs[1]
	end
end
