

----------------------------------------------------------------
-- Global Variables/Functions
----------------------------------------------------------------

GuildCreate = TwoButtonDialog:new()

GuildCreate2 = TextEntry:new({
	windowName = "GUMP_GUILD_CREATE2-1",
	name = L"GUMP_GUILD_CREATE2-1",
})




function GuildCreate.getShowing()
	return GuildCreate.showing 
end

function GuildCreate2.getShowing()
	return GuildCreate2.showing 
end


function GuildCreate.setShowing( isShowing )
	if isShowing then
		GuildWindowManager.registerWindow(GuildCreate.windowName,GuildCreate)
	else
		GuildWindowManager.unregisterWindow(GuildCreate.windowName)
	end
	GuildCreate.showing = isShowing
end

function GuildCreate2.setShowing( isShowing )
	if isShowing then
		GuildWindowManager.registerWindow(GuildCreate2.windowName,GuildCreate2)
	else
		GuildWindowManager.unregisterWindow(GuildCreate2.windowName)
	end
	GuildCreate2.showing = isShowing
end


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------


GuildCreate.showing = false
GuildCreate2.showing = false

----------------------------------------------------------------
-- GuildCreate Functions
----------------------------------------------------------------

GuildCreate.IGNORE_INVITES_OFF_ID = 150
GuildCreate.IGNORE_INVITES_ON_ID = 151

 --TID 1062998 = "Create Guild"
-- 1063142 You are not in a guild! 
-- GGManager.translateTID(GGManager.CANCEL_TID)


-- custom data set function 
--   can use the general TwoButtonDialog fields, 
--   and then adds the GuildCreate specific components  in GuildCreate:setFields
function GuildCreate:setDataFunction()
	
	self.title = GGManager.translateTID(self.descData[1])
	self.subtitle = GGManager.translateTID(1063142)
	
	-- info about how to start a guild with registration fee appended
	self.text = GGManager.translateTID(self.descData[2])..L"\n\n"..GGManager.translateTID(self.descData[3])..L"  "..self.stringData[2]
	self.leftButtonName = GGManager.translateTID(1077852) --TID 1062998 = "CREATE"
	self.rightButtonName = GGManager.translateTID(GGManager.CANCEL_TID)

	self.leftButtonID = -1 -- this button opens up GuildCreate2.  No ID should get sent to the server
	self.rightButtonID = self.buttonIDs[2] -- Cancel
	
	
	GuildCreate2:setDataFunction(self)
end


-- custom data set function 
function GuildCreate:setFields()
	--UO_GenericGump.debug( L"GuildCreate:setFields called" )

	-- handle all the standard 2 button fields
	TwoButtonDialog.setFields(self)
	--UO_GenericGump.debug( ChoiceButtons.toString(self) )
	
	-- then set values for the GuildCreate specific widgets
	LabelSetText( self.windowName.."IgnoreInvitesToggleLabel", GGManager.translateTID(self.descData[6]) )
	ButtonSetPressedFlag( self.windowName.."IgnoreInvitesToggleButton", (self.buttonIDs[5] == GuildCreate.IGNORE_INVITES_ON_ID) )
	WindowSetId( self.windowName.."IgnoreInvitesToggleButton", self.buttonIDs[5] )
end


-- OnInitialize Handler
function GuildCreate.Initialize()
	--local NewWindow = GuildCreate:new()
	--NewWindow:Init()
	GuildCreate:Init()
	GuildCreate.setShowing( true )
	Interface.OnCloseCallBack[GuildCreate.windowName] = GuildCreate.OnCloseWindow
end
	

function GuildCreate:LeftButtonFunction()
	UO_GenericGump.debug( L"GuildCreate:LeftButtonFunction called. ")
	
	local buttonID = WindowGetId( SystemData.ActiveWindow.name )

	-- NOTE: this may need to be changed. Currently WindowGetId seems to return 0,
	--  if a value is not set (and 0 is a valid value). May change C++ to return negative value
	--  when no value is set
	if not buttonID then	
		Debug.PrintToDebugConsole( L"ERROR in GuildCreate.DefaultButtonFunction: no ID set for button pressed." )
		return
	end

	UO_GenericGump.debug( L"called GuildCreate:LeftButtonFunction() with button value of "..buttonID )

	DestroyWindow(GuildCreate.windowName)
	GuildCreate.setShowing( false )
	 
	CreateWindowFromTemplate( GuildCreate2.windowName, "GUMP_GUILD_CREATE2", "Root" )
end



function GuildCreate.ToggleIgnoreInvites()
	
	local self = TwoButtonDialog.getActiveWindowData()
    local invitesToggleButton = self.windowName.."IgnoreInvitesToggleButton"
	ButtonSetCheckButtonFlag( invitesToggleButton, ( ButtonGetCheckButtonFlag(invitesToggleButton) ) )
	self:DefaultButtonFunction()
end

function GuildCreate.Shutdown()
	UO_GenericGump.debug( L"called GuildCreate.Shutdown" )
	GuildCreate.setShowing( false )
end

function GuildCreate.OnCloseWindow()	
	UO_GenericGump.debug( L"called GuildCreate.OnCloseWindow" )

	GGManager.destroyWindow(GuildCreate.windowName)
	GuildCreate.setShowing( false )
end




-------


-- this is actually called by GuildCreate:setDataFunction() as data for both come in together
--
function GuildCreate2:setDataFunction(gumpData)
	UO_GenericGump.debug( L"called GuildCreate2:setDataFunction using window = "..gumpData.name )
	UO_GenericGump.debug( L"called GuildCreate2:setDataFunction on self = "..self.name )
	
	self.gumpID = gumpData.gumpID
	self.objectID = gumpData.objectID
	
	self.title = GGManager.translateTID(gumpData.descData[1])
	self.text = GGManager.translateTID(gumpData.descData[2])..L"\n\n"..GGManager.translateTID(gumpData.descData[3])..L"  "..gumpData.stringData[2]
	
	
	self.numOfTextBoxes = 2
	
	self.textBoxLabel[1] = GGManager.translateTID(gumpData.descData[4])
	self.textBoxText[1] = gumpData.stringData[1]
	self.textBoxID[1] = gumpData.buttonIDs[1]
	
	self.textBoxLabel[2] = GGManager.translateTID(gumpData.descData[5])
	self.textBoxText[2] =  gumpData.stringData[3]
	self.textBoxID[2] =  gumpData.buttonIDs[2]
	
	
	self.submitButtonName = GGManager.translateTID(1077787)		-- "Submit"
	self.clearButtonName = GGManager.translateTID(3000154)		-- "Clear"
	self.cancelButtonName = GGManager.translateTID(GGManager.CANCEL_TID)
	
	self.submitButtonID = gumpData.buttonIDs[3]
	self.clearButtonID = -1
	self.cancelButtonID = gumpData.buttonIDs[4]
end




-- OnInitialize Handler
--
-- GuildCreate2 does not use a dynamically created window or dynamically created data so
--   have to do some things differently
--
function GuildCreate2.Initialize()

	TextEntryManager.knownWindows[GuildCreate2.windowName] = GuildCreate2
	TextEntry.setFields(GuildCreate2)
	
	GuildCreate2.setShowing( true )
	Interface.OnCloseCallBack[GuildCreate2.windowName] = GuildCreate2.OnCloseWindow
end
	

function GuildCreate2.Shutdown()
	UO_GenericGump.debug( L"called GuildCreate2.Shutdown" )
	GuildCreate2.setShowing( false )
end

function GuildCreate2.OnCloseWindow()
	UO_GenericGump.debug( L"called GuildCreate2.OnCloseWindow" )

	-- TODO: may need to clear the data in GuildCreate2 since we reuse this table each time
	
	GGManager.destroyWindow( GuildCreate2.windowName )
	GuildCreate2.setShowing( false )
end

