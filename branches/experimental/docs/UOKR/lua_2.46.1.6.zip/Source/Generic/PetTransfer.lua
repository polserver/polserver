
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

PetTransfer = { 

	LEFT_BUTTON_ID = 2,  -- continue
	RIGHT_BUTTON_ID = 1, -- cancel
}


----------------------------------------------------------------
-- PetTransfer Functions
----------------------------------------------------------------

-- OnInitialize Handler
function PetTransfer.Initialize()
	-- setDataFunction is called in TwoButtonDialog:init(), 
	--   most TwoButtonDialogs can use  either parseDescAsTextAndTwoButtons or parseDescAsTitleTextAndTwoButtons
	PetTransfer.setDataFunction = TwoButtonDialog.parseDescAsTextAndTwoButtons
	TwoButtonDialog.Init(PetTransfer)
end
	


