
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

VirtueMenu = ChoiceList:new()

-- TODO: Make this data driven
VirtueMenu.VirtueData		= {}
VirtueMenu.VirtueData[1]	= { iconId = 701, nameTid = 1051005 } -- Honor
VirtueMenu.VirtueData[2]	= { iconId = 706, nameTid = 1051001 } -- Sacrifice
VirtueMenu.VirtueData[3]	= { iconId = 700, nameTid = 1051004 } -- Valor
VirtueMenu.VirtueData[4]	= { iconId = 702, nameTid = 1051002 } -- Compassion
VirtueMenu.VirtueData[5]	= { iconId = 704, nameTid = 1051007 } -- Honesty
VirtueMenu.VirtueData[6]	= { iconId = 707, nameTid = 1051000 } -- Humility
VirtueMenu.VirtueData[7]	= { iconId = 703, nameTid = 1051006 } -- Justice
VirtueMenu.VirtueData[8]	= { iconId = 705, nameTid = 1051003 } -- Spirituality

NO_VIRTUE_TITLE	= 1079214 -- TID for "You have not yet attained a title for this Virtue."
HUMILITY		= VirtueMenu.VirtueData[6].nameTid
SACRIFICE		= VirtueMenu.VirtueData[2].nameTid
COMPASSION		= VirtueMenu.VirtueData[4].nameTid
SPIRITUALITY	= VirtueMenu.VirtueData[8].nameTid
VALOR			= VirtueMenu.VirtueData[3].nameTid
HONOR			= VirtueMenu.VirtueData[1].nameTid
JUSTICE			= VirtueMenu.VirtueData[7].nameTid
HONESTY			= VirtueMenu.VirtueData[5].nameTid

-- Stores tooltip TIDs to tell the player their rank in each virtue.
-- Each virtue has four ranks, and each of these is associated with a color.
-- TO DO: add color to the tooltips
-- rank 0 has no title
-- rank 1 has the title "Seeker of (Virtue name)"
-- rank 2 has the title "Follower of (Virtue name)"
-- rank 3 has the title "Knight of (Virtue name)"
VirtueMenu.TooltipData =
{
	[HUMILITY] =
	{
		Hue =
		{
			[2402]	= NO_VIRTUE_TITLE,
			[1153]	= 1051008,
			[2403]	= 1051016,
			[2405]	= 1051024
		}
	},

	[SACRIFICE] =
	{
		Hue =
		{
			[2402]	= NO_VIRTUE_TITLE,
			[1546]	= 1051009,
			[1551]	= 1051017,
			[42]	= 1051025
		}
	},
	
	[COMPASSION] =
	{
		Hue	=
		{
			[2402]	= NO_VIRTUE_TITLE,
			[2212]	= 1051010,
			[2215]	= 1051018,
			[52]	= 1051026
		}
	},
	
	[SPIRITUALITY] =
	{
		Hue	=
		{
			[2402]	= NO_VIRTUE_TITLE,
			[2405]	= 1051011,
			[2301]	= 1051019,
			[1152]	= 1051027
		}
	},
	
	[VALOR] =
	{
		Hue =
		{
			[2402]	= NO_VIRTUE_TITLE,
			[234]	= 1051012,
			[2117]	= 1051020,
			[32]	= 1051028
		}
	},
	
	[HONOR] =
	{
		Hue =
		{
			[2402]	= NO_VIRTUE_TITLE,
			[17]	= 1051013,
			[617]	= 1051021,
			[317]	= 1051029
		}
	},
	
	[JUSTICE] =
	{
		Hue =
		{
			[2402]	= NO_VIRTUE_TITLE,
			[2209]	= 1051014,
			[2211]	= 1051022,
			[66]	= 1051030
		}
	},
	
	[HONESTY] =
	{
		Hue =
		{
			[2402]	= NO_VIRTUE_TITLE,
			[1347]	= 1051015,
			[1351]	= 1051023,
			[97]	= 1051031
		}
	}
}

function VirtueMenu.ToggleVirtueMenuWindow()

	if VirtueMenu.showing then
		VirtueMenu.BottomButtonFunction(VirtueMenu)
	elseif VirtueInfo.showing then 
		VirtueInfo.OnCloseWindow(VirtueInfo)
	else
		BroadcastEvent( SystemData.Events.REQUEST_OPEN_VIRTUES_LIST )
	end

	return VirtueMenu.showing or VirtueInfo.showing
end


function VirtueMenu.getShowing()
	return VirtueMenu.showing 
end


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

VirtueMenu.showing = false

----------------------------------------------------------------
-- VirtueMenu Functions
----------------------------------------------------------------

function VirtueMenu:setDataFunction()
	self.Tooltips = {}

	if self.descData and self.descDataCount > 3 then
		self:CreateBottomButton( GGManager.translateTID( self.descData[1] ), self.buttonIDs[1] )

		WindowUtils.SetActiveDialogTitle( GGManager.translateTID( self.descData[2] ) )

		relativeWindow = self:CreateSubtitle( GGManager.translateTID( self.descData[4] ) )
		for choiceNum = 5, self.descDataCount do
			relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[choiceNum - 3], GGManager.translateTID( self.descData[choiceNum] ),
							"bottom", relativeWindow, "top", 0, 0 )	
			self.Tooltips[relativeWindow] = VirtueMenu.TooltipData[self.descData[choiceNum]].Hue[-self.portImgData[choiceNum + 2]]
		end
	else
		Debug.PrintToDebugConsole( L"ChoiceList.createButtonTitleSubtitleAndChoices ERROR: insufficient descData. descDataCount = "..self.descDataCount )
	end  -- if descData
end


-- OnInitialize Handler
function VirtueMenu.Initialize()
	if VirtueMenu.showing then
		VirtueMenu.OnCloseWindow()
	end
	
	VirtueMenu:Init()
	VirtueMenu.showing = true
	Interface.OnCloseCallBack[VirtueMenu.windowName] = VirtueMenu.BottomButtonPressed
    ButtonSetPressedFlag("MenuBarWindowStatusBarToggleVirtues",true)
end

function VirtueMenu.TextSelectedFunction()
	choiceNum = WindowGetId( SystemData.ActiveWindow.name)
	UO_GenericGump.debug( L"called VirtueMenu.TextSelectedFunction() choiceNum = "..choiceNum )
	
	UO_GenericGump.broadcastButtonPress( choiceNum, VirtueMenu )
	VirtueMenu.OnCloseWindow()
end

function VirtueMenu.Shutdown()
	UO_GenericGump.debug( L"VirtueMenu.Shutdown()." )
	VirtueMenu.showing = false
	ButtonSetPressedFlag("MenuBarWindowStatusBarToggleVirtues",false)
end

function VirtueMenu.OnCloseWindow()
	UO_GenericGump.debug( L"VirtueMenu.OnCloseWindow()." )
	if not VirtueMenu.showing then
		UO_GenericGump.debug( L"VirtueMenu.OnCloseWindow() called but window does not exist." )
		return
	end

	VirtueMenu.showing = false
	GGManager.destroyWindow(VirtueMenu.windowName)
end

