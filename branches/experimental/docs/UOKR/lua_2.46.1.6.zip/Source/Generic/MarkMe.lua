
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

MarkMe = { }


----------------------------------------------------------------
-- MarkMe Functions
----------------------------------------------------------------

-- OnInitialize Handler
function MarkMe.Initialize()
	-- setDataFunction is called in TwoButtonDialog:init(), 
	--   most TwoButtonDialogs can use  either parseDescAsTextAndTwoButtons or parseDescAsTitleTextAndTwoButtons
	MarkMe.setDataFunction = TwoButtonDialog.parseDescAsTextAndTwoButtons
	TwoButtonDialog.Init(MarkMe)
end
	


