----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

WarningSacrifice = TwoButtonDialog:new()

----------------------------------------------------------------
-- WarningSacrifice Functions
----------------------------------------------------------------

function WarningSacrifice:parseData()
	self.title = GGManager.translateTID( self.descData[1] )
	self.text = GGManager.translateTID( self.descData[2])
	self.leftButtonName = GGManager.translateTID( GGManager.OKAY_TID )
	self.rightButtonName = GGManager.translateTID( GGManager.CANCEL_TID)
	self.leftButtonID = self.buttonIDs[1]
	self.rightButtonID = self.buttonIDs[2]
end

-- OnInitialize Handler
function WarningSacrifice.Initialize()
	local newWindow = WarningSacrifice:new()
	newWindow.setDataFunction = WarningSacrifice.parseData
	newWindow:Init()
end