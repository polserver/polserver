----------------------------------------------------------
-- HousesignVendorList.lua
----------------------------------------------------------------

HousesignVendorList = MasterGUMP:new()

function HousesignVendorList.Initialize()
	local newWindow					= HousesignVendorList:new()
	newWindow.setData				= HousesignVendorList.mySetData
	newWindow:Init()
end

function HousesignVendorList:mySetData()
	self.IsStandardHeight = true
	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Title = GGManager.translateTID( self.descData[2] ) -- "SHOPS"
	self.Page[1].Selections = {}
	local itr
	local nonZeroButtonsCount = 0
	local buttonOffset = 1
	-- Need to know how many vendors there are
	for itr = 1, self.buttonCount do
		if self.buttonIDs[itr] and self.buttonIDs[itr] ~= 0 then
			nonZeroButtonsCount = nonZeroButtonsCount + 1
		end
	end
	
	-- But the code below is taking the CLOSE button into account too, so adjust for that
	nonZeroButtonsCount = nonZeroButtonsCount + 1
	
	for itr = 1, nonZeroButtonsCount-1 do
		self.Page[1].Selections[itr] = {}
		while self.buttonIDs[itr+buttonOffset] == 0 do
			buttonOffset = buttonOffset + 1
		end
		self.Page[1].Selections[itr].Id = self.buttonIDs[itr+buttonOffset]
		self.Page[1].Selections[itr].Text = self.stringData[self.stringDataCount-nonZeroButtonsCount+itr+1] -- Weirdest indexing ever!
	end
	self.Page[1].MiddleButtonId = self.buttonIDs[1]
	self.Page[1].MiddleButtonText = GGManager.translateTID( self.descData[1] ) -- "CLOSE"
end
