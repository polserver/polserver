----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

VendorBarbieMain = ChoiceList:new()

----------------------------------------------------------------
-- VendorBarbieMain Functions
----------------------------------------------------------------

-- TODO: stringData[11] and stringData[12] should be converted to TIDs
function VendorBarbieMain:setDataFunction()
	UO_GenericGump.debug( L"VendorBarbieMain:setDataFunction - setting data for = "..StringToWString( self.windowName ) )
	local scrollChild = self.windowName.."ScrollChild"
		
	self.title = self.stringData[9] -- the shop name
	self.text = GGManager.translateTID( self.descData[10] )..L"\n"..self.stringData[1]..L"\n\n"
				..GGManager.translateTID( self.descData[8] )..L"\n"..self.stringData[6]..L"\n\n"
				..GGManager.translateTID( self.descData[7] )..L"\n"..self.stringData[4]..L"\n\n"
				..self.stringData[8]..L"\n"
			
	local choiceName = {
		GGManager.translateTID( self.descData[1] ),
		GGManager.translateTID( self.descData[2] ),
		GGManager.translateTID( self.descData[3] ),
		GGManager.translateTID( self.descData[4] ),
		GGManager.translateTID( self.descData[5] ),
		self.stringData[11],
		self.stringData[12],
		GGManager.translateTID( self.descData[6] )
	}

	WindowUtils.SetActiveDialogTitle( self.title )
	local relativeWindow = 	self:CreateText( 1, self.text, "topleft", scrollChild, "topleft", 0, 0 )
	for i = 1, 8 do
		relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[i], choiceName[i], 
						"bottomleft", relativeWindow, "topleft", 0, 0 )
	end
end

-- OnInitialize Handler
function VendorBarbieMain.Initialize()
	local newWindow = VendorBarbieMain:new()
	newWindow.setDataFunction = VendorBarbieMain.setDataFunction
	newWindow:Init()
end