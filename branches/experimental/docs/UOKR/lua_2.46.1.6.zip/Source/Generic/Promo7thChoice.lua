----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

Promo7thChoice = ChoiceList:new()

----------------------------------------------------------------
-- Promo7thChoice Functions
----------------------------------------------------------------

--[[
function Promo7thChoice:setDataFunction()
	ChoiceList:createButtonTitleSubtitleAndChoices()
end -- Promo7thChoice:setDataFunction()
--]]

-- Standard OnInitialize Handler
function Promo7thChoice.Initialize()
	local newWindow = Promo7thChoice:new()
	newWindow.setDataFunction = ChoiceList.createButtonTitleSubtitleAndChoices -- Promo7thChoice:setDataFunction()
	newWindow:Init()
end
