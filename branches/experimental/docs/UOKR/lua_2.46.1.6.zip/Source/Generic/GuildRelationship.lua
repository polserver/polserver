----------------------------------------------------------
-- GuildRelationship.lua
----------------------------------------------------------------

GuildRelationship = MasterGUMP:new()

function GuildRelationship.Initialize()
	local newWindow					= GuildRelationship:new()
	newWindow.setData				= GuildRelationship.mySetData
	newWindow:Init()
end

function GuildRelationship:mySetData()

	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Title = GGManager.translateTID( self.descData[1] )
	self.Page[1].ScrollText =
		GGManager.translateTID( self.descData[2] )..L": "..GGManager.stripMarkup( self.stringData[7],  true )..L"\n\n"..
		GGManager.translateTID( self.descData[3] )..L": "..GGManager.stripMarkup( self.stringData[8],  true )..L"\n\n"..
		GGManager.translateTID( self.descData[4] )..L": "..GGManager.stripMarkup( self.stringData[9],  true )..L"\n\n"..
		GGManager.translateTID( self.descData[5] )..L": "..GGManager.stripMarkup( self.stringData[10], true )..L"\n\n"..
		GGManager.translateTID( self.descData[7] )..L": "..GGManager.stripMarkup( self.stringData[12], true )..L"\n\n"..
		GGManager.translateTID( self.descData[6] )..L": "..GGManager.stripMarkup( self.stringData[11], true )..L"\n\n"..
		GGManager.translateTID( self.descData[self.descDataCount] )..L"\n"
	local i
	self.Page[1].Selections = {}
	for i = 9, self.descDataCount - 1 do
		self.Page[1].Selections[i-8] = {}
		self.Page[1].Selections[i-8].Id = self.buttonIDs[i-7]
		self.Page[1].Selections[i-8].Text = GGManager.translateTID( self.descData[i] )
	end	
	self.Page[1].MiddleButtonId = self.buttonIDs[1]
	self.Page[1].MiddleButtonText = GGManager.translateTID( GGManager.CANCEL_TID )
	
end
