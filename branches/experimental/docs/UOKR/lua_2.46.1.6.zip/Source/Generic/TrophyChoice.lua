----------------------------------------------------------
-- TrophyChoice.lua
----------------------------------------------------------------

TrophyChoice = MasterGUMP:new()

function TrophyChoice.Initialize()

	local newWindow					= TrophyChoice:new()
	newWindow.setData				= TrophyChoice.mySetData
	newWindow:Init()
end

function TrophyChoice:mySetData()

	--self.IsStandardHeight = true
	--self.SELECTION_PADDING = 25

	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Title = GGManager.translateTID( self.descData[2] )
	--self.Page[1].Subtitle = GGManager.translateTID( self.descData[3] )
	self.Page[1].ScrollText = GGManager.translateTID( self.descData[4] )
	self.Page[1].Selections = {}
	self.Page[1].Selections[1] = {}
	self.Page[1].Selections[1].Id = self.buttonIDs[2]
	self.Page[1].Selections[1].Icon = self.ImageNum[1]
	self.Page[1].Selections[1].Text = GGManager.translateTID( self.descData[5] )
	self.Page[1].Selections[2] = {}
	self.Page[1].Selections[2].Id = self.buttonIDs[3]
	self.Page[1].Selections[2].Icon = self.ImageNum[2]
	self.Page[1].Selections[2].Text = GGManager.translateTID( self.descData[6] )
	--self.Page[1].MiddleButtonId = self.buttonIDs[1]
	--self.Page[1].MiddleButtonText = GGManager.translateTID( GGManager.CANCEL_TID )

end
