----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

ChoiceButtonsStringData = ChoiceButtons:new()

----------------------------------------------------------------
-- ChoiceButtonsStringData Functions
----------------------------------------------------------------

function ChoiceButtonsStringData:setDataFunction()
	UO_GenericGump.debug( L"ChoiceButtonsStringData:setDataFunction - setting data for = "..self.name )

	-- last button ID is not used in KR other than to send back to say a choice was selected
	self.actionID = self.buttonIDs[self.buttonCount]
	self.buttonCount = self.buttonCount-1

	self.buttonName = {}
	for i=1, self.buttonCount do
		-- the first buttonCount of descData are the choice labels
		self.buttonName[i] = GGManager.translateTID( self.descData[i] )
		UO_GenericGump.debug( L"self.buttonName["..i..L"] = "..GGManager.translateTID( self.descData[i] ) )
	end		

	self.title = nil
	self.subtitle = nil
	
	if ( self.descDataCount - self.buttonCount ) == 1 then
		self.text = GGManager.translateTID( self.descData[3] )..L"\n\n"..self.stringData[1]
	elseif ( self.descDataCount - self.buttonCount ) == 2 then
		self.text = GGManager.translateTID( self.descData[3] )..L"\n\n"..self.stringData[1]..L"\n\n"
					..GGManager.translateTID( self.descData[4] )
	else
		self.text = GGManager.translateTID( self.descData[3] )..L"\n\n"..self.stringData[1]..L" "
					..GGManager.translateTID( self.descData[5] )..L"\n\n"..GGManager.translateTID( self.descData[4] )
	end
end

-- OnInitialize Handler
function ChoiceButtonsStringData.Initialize()
	local newWindow = ChoiceButtonsStringData:new()
	newWindow.setDataFunction = ChoiceButtonsStringData.setDataFunction
	newWindow:Init()
end