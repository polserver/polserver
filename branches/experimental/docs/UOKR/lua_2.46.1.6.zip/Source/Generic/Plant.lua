
----------------------------------------------------------------
-- Plant.lua
----------------------------------------------------------------

Plant = {}

PlantManager = GGManager

function Plant.Initialize()

	local newWindow = Plant:new()
	newWindow:Init()
end

function Plant:new( newWindow )

	newWindow = newWindow or {}
	setmetatable( newWindow, self )
	self.__index = self

	return newWindow
end

function Plant:Init()

	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFuncmytion then
		self:setDataFuncmytion()
	end
	
	PlantManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end

function Plant:setDataFuncmytion()

	self.requestedTextures	= {}
	self.requestedTileArt	= {}
	self.Tooltips			= {}
	
	-- the Title                                              plant status                                      "plant"
	WindowUtils.SetActiveDialogTitle( GGManager.translateTID( self.descData[1] )..L" "..GGManager.translateTID( 1060812 ) )
	
	local textureB, xB, yB, scaleB, newWB, newHB = RequestTexture( 1417, 128, 128 )
	self.requestedTextures[#self.requestedTextures + 1] = textureB
	if textureB
	then
		DynamicImageSetTexture( self.windowName.."Bowl", textureB, xB, yB )
		
		if scaleB == 1
		then
			scaleB = 128 / newWB
		end
		DynamicImageSetTextureScale( self.windowName.."Bowl", scaleB )
	end
	
	local textureD, xD, yD, scaleD, newWD, newHD  = RequestTexture( 2324, 128, 128 )
	self.requestedTextures[#self.requestedTextures + 1] = textureD
	if textureD
	then
		DynamicImageSetTexture( self.windowName.."Dirt", textureD, xD, yD )
		
		if scaleD == 1
		then
			scaleD = 128 / newWD
		end
		DynamicImageSetTextureScale( self.windowName.."Dirt", scaleD )
	end
	
	local textureP, xP, yP, scaleP, newWP, newHP
	if  self.portImgData[5] ~= nil
	and self.portImgData[5] == 210
	then
		textureP, xP, yP, scaleP, newWP, newHP = RequestTileArt( self.ImageNum[16], 128, 128 )
		self.requestedTileArt[#self.requestedTileArt + 1] = textureP
	else
		if  tonumber( self.stringData[10] ) > 1
		and tonumber( self.stringData[10] ) < 9
		then
			textureP, xP, yP, scaleP, newWP, newHP = RequestTileArt( self.ImageNum[20], 128, 128 )
			self.requestedTileArt[#self.requestedTileArt + 1] = textureP
		end
	end
	
	if textureP
	then
		scaleP = 2
		
		DynamicImageSetTexture( self.windowName.."Plant", textureP, xP, yP )
		DynamicImageSetTextureScale( self.windowName.."Plant", scaleP )
	end
	
	-- Plant Growth
	if  self.stringData[11] ~= nil
	and self.stringData[11] ~= L""
	and self.stringData[11] ~= L" "
	then
		LabelSetText( self.windowName.."PlantGrowth", GGManager.translateTID( 3010156 )..L": "..self.stringData[10]..L" ("..self.stringData[11]..L")" )
	else
		LabelSetText( self.windowName.."PlantGrowth", GGManager.translateTID( 3010156 )..L": "..self.stringData[10] )
	end
	
	local texture, x, y, scale, newW, newH

	-- Reproduction Button
	texture, x, y, scale, newW, newH = RequestTileArt( self.ImageNum[5], 32, 32 )
	self.requestedTileArt[#self.requestedTileArt + 1] = texture
	WindowSetDimensions( self.windowName.."ScrollChildReproduceIconHolderIcon", newW, newH )
	DynamicImageSetTexture( self.windowName.."ScrollChildReproduceIconHolderIcon", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."ScrollChildReproduceIconHolderIcon", scale )
	LabelSetText( self.windowName.."ScrollChildReproduceText", GGManager.translateTID( 1053044 ) )
	
	-- Water Button
	texture, x, y, scale, newW, newH = RequestTileArt( self.ImageNum[10], 32, 32 )
	self.requestedTileArt[#self.requestedTileArt + 1] = texture
	WindowSetDimensions( self.windowName.."ScrollChildWaterIconHolderIcon", newW, newH )
	DynamicImageSetTexture( self.windowName.."ScrollChildWaterIconHolderIcon", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."ScrollChildWaterIconHolderIcon", scale )
	LabelSetText( self.windowName.."ScrollChildWaterText", GGManager.translateTID( 1046458 ) )

	-- Empty Button
	texture, x, y, scale, newW, newH = RequestTileArt( self.ImageNum[15], 32, 32 )
	self.requestedTileArt[#self.requestedTileArt + 1] = texture
	WindowSetDimensions( self.windowName.."ScrollChildEmptyIconHolderIcon", newW, newH )
	DynamicImageSetTexture( self.windowName.."ScrollChildEmptyIconHolderIcon", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."ScrollChildEmptyIconHolderIcon", scale )
	LabelSetText( self.windowName.."ScrollChildEmptyText", GGManager.translateTID( 1078532 ) )
	
	-- Poison Potion Button
	texture, x, y, scale, newW, newH = RequestTileArt( self.ImageNum[11], 32, 32 )
	self.requestedTileArt[#self.requestedTileArt + 1] = texture
	WindowSetDimensions( self.windowName.."ScrollChildPoisonPotIconHolderIcon", newW, newH )
	DynamicImageSetTexture( self.windowName.."ScrollChildPoisonPotIconHolderIcon", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."ScrollChildPoisonPotIconHolderIcon", scale )
	if  self.stringData[1] ~= L"0" then
		LabelSetText( self.windowName.."ScrollChildPoisonPotText", GGManager.translateTID( 1049416 )..L" ("..self.stringData[1]..L")" )
	else
		LabelSetText( self.windowName.."ScrollChildPoisonPotText", GGManager.translateTID( 1049416 ) )
	end
	
	-- Cure Potion Button
	texture, x, y, scale, newW, newH = RequestTileArt( self.ImageNum[12], 32, 32 )
	self.requestedTileArt[#self.requestedTileArt + 1] = texture
	WindowSetDimensions( self.windowName.."ScrollChildCurePotIconHolderIcon", newW, newH )
	DynamicImageSetTexture( self.windowName.."ScrollChildCurePotIconHolderIcon", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."ScrollChildCurePotIconHolderIcon", scale )
	if  self.stringData[2] ~= L"0" then
		LabelSetText( self.windowName.."ScrollChildCurePotText", GGManager.translateTID( 1041316 )..L" ("..self.stringData[2]..L")" )
	else
		LabelSetText( self.windowName.."ScrollChildCurePotText", GGManager.translateTID( 1041316 ) )
	end
	
	-- Heal Potion Button
	texture, x, y, scale, newW, newH = RequestTileArt( self.ImageNum[13], 32, 32 )
	self.requestedTileArt[#self.requestedTileArt + 1] = texture
	WindowSetDimensions( self.windowName.."ScrollChildHealPotIconHolderIcon", newW, newH )
	DynamicImageSetTexture( self.windowName.."ScrollChildHealPotIconHolderIcon", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."ScrollChildHealPotIconHolderIcon", scale )
	if  self.stringData[3] ~= L"0" then
		LabelSetText( self.windowName.."ScrollChildHealPotText", GGManager.translateTID( 1041329 )..L" ("..self.stringData[3]..L")" )
	else
		LabelSetText( self.windowName.."ScrollChildHealPotText", GGManager.translateTID( 1041329 ) )
	end

	-- Strength Potion Button
	texture, x, y, scale, newW, newH = RequestTileArt( self.ImageNum[14], 32, 32 )
	self.requestedTileArt[#self.requestedTileArt + 1] = texture
	WindowSetDimensions( self.windowName.."ScrollChildStrengthPotIconHolderIcon", newW, newH )
	DynamicImageSetTexture( self.windowName.."ScrollChildStrengthPotIconHolderIcon", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."ScrollChildStrengthPotIconHolderIcon", scale )
	if  self.stringData[4] ~= L"0" then
		LabelSetText( self.windowName.."ScrollChildStrengthPotText", GGManager.translateTID( 1041320 )..L" ("..self.stringData[4]..L")" )
	else
		LabelSetText( self.windowName.."ScrollChildStrengthPotText", GGManager.translateTID( 1041320 ) )
	end

	texture, x, y, scale, newW, newH = RequestTileArt( self.ImageNum[6], 32, 32 )
	self.requestedTileArt[#self.requestedTileArt + 1] = texture
	WindowSetDimensions( self.windowName.."L2I2", newW, newH )
	DynamicImageSetTexture( self.windowName.."L2I2", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."L2I2", scale )
	self.Tooltips[self.windowName.."L2"] = 3010162
	if tonumber( self.stringData[12] ) > 3 then
	
		local r, g, b, a = HueRGBAValue(33)
		if tonumber( self.stringData[12] ) == 4 then

			r, g, b, a = HueRGBAValue(53)
		end

		LabelSetTextColor( self.windowName.."LT2", r, g, b )
		LabelSetText( self.windowName.."LT2", L"+" )
	end
	
	texture, x, y, scale, newW, newH = RequestTileArt( self.ImageNum[7], 32, 32 )
	self.requestedTileArt[#self.requestedTileArt + 1] = texture
	WindowSetDimensions( self.windowName.."L3I3", newW, newH )
	DynamicImageSetTexture( self.windowName.."L3I3", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."L3I3", scale )
	self.Tooltips[self.windowName.."L3"] = 3010166
	if tonumber( self.stringData[13] ) > 3 then
	
		local r, g, b, a = HueRGBAValue(33)
		if tonumber( self.stringData[13] ) == 4 then

			r, g, b, a = HueRGBAValue(53)
		end

		LabelSetTextColor( self.windowName.."LT3", r, g, b )
		LabelSetText( self.windowName.."LT3", L"+" )
	end
	
	texture, x, y, scale, newW, newH = RequestTileArt( self.ImageNum[8], 32, 32 )
	self.requestedTileArt[#self.requestedTileArt + 1] = texture
	WindowSetDimensions( self.windowName.."L4I4", newW, newH )
	DynamicImageSetTexture( self.windowName.."L4I4", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."L4I4", scale )
	self.Tooltips[self.windowName.."L4"] = 3010170
	if tonumber( self.stringData[12] ) < 3 then
	
		local r, g, b, a = HueRGBAValue(33)
		if tonumber( self.stringData[12] ) == 2 then

			r, g, b, a = HueRGBAValue(53)
		end

		LabelSetTextColor( self.windowName.."LT4", r, g, b )
		LabelSetText( self.windowName.."LT4", L"+" )
	end
	
	texture, x, y, scale, newW, newH = RequestTileArt( self.ImageNum[9], 32, 32 )
	self.requestedTileArt[#self.requestedTileArt + 1] = texture
	WindowSetDimensions( self.windowName.."L5I5", newW, newH )
	DynamicImageSetTexture( self.windowName.."L5I5", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."L5I5", scale )
	self.Tooltips[self.windowName.."L5"] = 3010174
	if tonumber( self.stringData[13] ) < 3 then
	
		local r, g, b, a = HueRGBAValue(33)
		if tonumber( self.stringData[13] ) == 2 then

			r, g, b, a = HueRGBAValue(53)
		end

		LabelSetTextColor( self.windowName.."LT5", r, g, b )
		LabelSetText( self.windowName.."LT5", L"+" )
	end
	
	texture, x, y, scale, newW, newH = RequestTileArt( self.ImageNum[10], 32, 32 )
	self.requestedTileArt[#self.requestedTileArt + 1] = texture
	WindowSetDimensions( self.windowName.."L6I6", newW, newH )
	DynamicImageSetTexture( self.windowName.."L6I6", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."L6I6", scale )
	self.Tooltips[self.windowName.."L6"] = 3010178
	if tonumber( self.stringData[14] ) > 3 then
	
		local r, g, b, a = HueRGBAValue(33)
		if tonumber( self.stringData[13] ) == 4 then

			r, g, b, a = HueRGBAValue(53)
		end

		LabelSetTextColor( self.windowName.."LT6", r, g, b )
		LabelSetText( self.windowName.."LT6", L"+" )
	end
	if tonumber( self.stringData[14] ) < 3 then
	
		local r, g, b, a = HueRGBAValue(33)
		if tonumber( self.stringData[13] ) == 2 then

			r, g, b, a = HueRGBAValue(53)
		end

		LabelSetTextColor( self.windowName.."LT6", r, g, b )
		LabelSetText( self.windowName.."LT6", L"-" )
	end

end	

function Plant.ButtonPressed()

	local self = PlantManager.knownWindows[WindowUtils.GetActiveDialog()]
	self:ButtonSelected()
end

function Plant:ButtonSelected()

	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	
	if choiceNum ~= -1
	then
		UO_GenericGump.broadcastButtonPress( choiceNum, self )
		self.OnCloseWindow()
	end
end

function Plant.Shutdown()
	UO_GenericGump.debug( L"Plant.Shutdown() called." )
	
	local self = PlantManager.knownWindows[WindowUtils.GetActiveDialog()]	
	if self == nil then
		UO_GenericGump.debug( StringToWString( "Shutdown hander called for "..SystemData.ActiveWindow.name.." but data already deleted" ) )
		return
	end	
	
	-- Delete any requested Tile Art
	if self.RequestedTileArt then
		for _, art in pairs( self.RequestedTileArt ) do
			ReleaseTileArt( art )
		end
	end
	
	-- Delete any requested Textures
	if self.RequestedTextures then
		for _, art in pairs( self.RequestedTextures ) do
			ReleaseTileArt( art )
		end
	end
	
	GGManager.unregisterActiveWindow()
end

function Plant.OnCloseWindow()
	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )
end

function Plant.OnMouseOver()

	local self = PlantManager.knownWindows[WindowUtils.GetActiveDialog()]
	local name = SystemData.ActiveWindow.name
	
	if  self.Tooltips		~= nil
	and self.Tooltips[name]	~= nil
	then
		Tooltips.CreateTextOnlyTooltip( name, GGManager.translateTID( self.Tooltips[name] ) )
		Tooltips.Finalize()
		Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_TOP )
	end 
end
