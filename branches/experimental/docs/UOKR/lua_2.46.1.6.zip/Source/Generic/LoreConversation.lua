----------------------------------------------------------
-- LoreConversation.lua
----------------------------------------------------------------

LoreConversation = MasterGUMP:new()

function LoreConversation.Initialize()

	local newWindow					= LoreConversation:new()
	newWindow.setData				= LoreConversation.mySetData
	newWindow:Init()
end

function LoreConversation:mySetData()

	local descItr
	local pageItr = 0
	self.Page = {}
	self.CreatePrevNextButtons = true
	for descItr = self.descDataCount, 2, -1
	do
		if self.descData[descItr] ~= 1043353
		and self.descData[descItr] ~= 1043354
		then
			pageItr = pageItr + 1
			self.Page[pageItr] = {}
			self.Page[pageItr].Title = GGManager.translateTID( self.descData[1] )
			self.Page[pageItr].ScrollText = GGManager.translateTID( self.descData[descItr] )
			self.Page[pageItr].MiddleButtonId = self.buttonIDs[1]
			self.Page[pageItr].MiddleButtonText = GGManager.translateTID( GGManager.OKAY_TID )
			self.StartPage = pageItr
		end
	end
end
