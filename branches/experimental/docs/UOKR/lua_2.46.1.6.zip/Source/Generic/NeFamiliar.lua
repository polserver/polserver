
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

NeFamiliar = ChoiceList:new()


----------------------------------------------------------------
-- NeFamiliar Functions
----------------------------------------------------------------


function NeFamiliar:setDataFunction()

	ChoiceList.CreateBottomButton( self, GGManager.translateTID( GGManager.CANCEL_TID ), 0 )

	local relativeWindow = ChoiceList.CreateSubtitle( self, GGManager.translateTID( self.descData[1] ) )
	
	for choiceNum=2, self.descDataCount do
		relativeWindow = self:CreateChoiceListSelectableText( 
				self.buttonIDs[choiceNum-1], GGManager.translateTID( self.descData[choiceNum] ),
				"bottomleft", relativeWindow, "topleft", 0, 0 )
	end
	
end


-- OnInitialize Handler
function NeFamiliar.Initialize()

	local newWindow = NeFamiliar:new()
	newWindow:Init()
end

