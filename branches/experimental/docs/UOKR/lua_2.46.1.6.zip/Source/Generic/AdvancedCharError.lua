----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

AdvancedCharError = TwoButtonDialog:new()

--AdvancedCharError.spacer = UO_GenericGump.EMPTY_LINE..L"\n"

----------------------------------------------------------------
-- AdvancedCharError Functions
----------------------------------------------------------------

function AdvancedCharError:setDataFunction()
	self.text = GGManager.translateTID( self.descData[3] )..L"\n\n"
				..GGManager.translateTID( 1078151 ) -- "Press OKAY to get your token back."
	self.leftButtonName = GGManager.translateTID( self.descData[4] )
	self.rightButtonName = GGManager.translateTID( self.descData[5] )
	
	self.leftButtonID = self.buttonIDs[1]
	self.rightButtonID = self.buttonIDs[2]	
end

-- OnInitialize Handler
function AdvancedCharError.Initialize()
	local newWindow = AdvancedCharError:new()
	newWindow.setDataFunction = AdvancedCharError.setDataFunction
	newWindow:Init()
end
