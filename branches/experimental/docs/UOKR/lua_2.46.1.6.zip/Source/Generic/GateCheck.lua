
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

GateCheck = { 

	LEFT_BUTTON_ID = 0,
	RIGHT_BUTTON_ID = 1,
}


----------------------------------------------------------------
-- GateCheck Functions
----------------------------------------------------------------

-- OnInitialize Handler
function GateCheck.Initialize()
	-- setDataFunction is called in TwoButtonDialog:init(), 
	--   most TwoButtonDialogs can use  either parseDescAsTextAndTwoButtons or parseDescAsTitleTextAndTwoButtons
	GateCheck.setDataFunction = TwoButtonDialog.parseDescAsTitleTextAndTwoButtons
	TwoButtonDialog.Init(GateCheck)
end
	


