----------------------------------------------------------
-- ReallyImprisonTarget.lua
----------------------------------------------------------------

ReallyImprisonTarget = MasterGUMP:new()

function ReallyImprisonTarget.Initialize()

	local newWindow					= ReallyImprisonTarget:new()
	newWindow.setData				= ReallyImprisonTarget.mySetData
	newWindow:Init()
end

function ReallyImprisonTarget:mySetData()

	self.Page = {}
	self.Page[1] = {}
	self.Page[1].ScrollText = GGManager.translateTID( self.descData[1] )..L" "..self.stringData[1]
	self.Page[1].LeftButtonId = self.buttonIDs[2]
	self.Page[1].LeftButtonText = GGManager.translateTID( GGManager.OKAY_TID )
	self.Page[1].RightButtonId = self.buttonIDs[1]
	self.Page[1].RightButtonText = GGManager.translateTID( GGManager.CANCEL_TID )

end
