
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

Resurrection = {}



----------------------------------------------------------------
-- Resurrection Functions
----------------------------------------------------------------


-- OnInitialize Handler
function Resurrection.Initialize()

	Resurrection.setDataFunction = TwoButtonDialog.parseDescAsTitleTextAndTwoButtons
	TwoButtonDialog.Init(Resurrection)
end
	
