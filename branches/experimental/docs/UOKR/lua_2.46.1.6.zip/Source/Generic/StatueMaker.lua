----------------------------------------------------------------
-- StatueMaker.lua
----------------------------------------------------------------

StatueMaker = MasterGUMP:new()

function StatueMaker.Initialize()

	local newWindow					= StatueMaker:new()
	newWindow.setData				= StatueMaker.mySetData
	newWindow:Init()
end

function StatueMaker:mySetData()
	self.IsStandardHeight = true
	
	self.Page						= {}
	
	self.Page[1]					= {}
	self.Page[1].Subtitle			= GGManager.translateTID( self.descData[1] )
	self.Page[1].Selections			= {}
	self.Page[1].SelectionTemplate	= "StatueSelectableTextAndArrows"

	for i = 1, 6 do
		self.Page[1].Selections[i]		= {}
		self.Page[1].Selections[i].Text	= GGManager.translateTID( self.descData[i + 1] )
	end

	self.Page[1].LeftButtonId		= self.buttonIDs[8]
	self.Page[1].LeftButtonText		= GGManager.translateTID( self.descData[9] ) -- "Sculpt"

	self.Page[1].RightButtonId		= self.buttonIDs[7]
	self.Page[1].RightButtonText	= GGManager.translateTID( self.descData[8] ) -- "Cancel"
	
	if self.descData[10] then
		self.Page[1].MiddleButtonId		= self.buttonIDs[9]
		self.Page[1].MiddleButtonText	= GGManager.translateTID( self.descData[10] ) -- "Restore"
	end
end
function StatueMaker:fixup()
	-- set close window ID to the same as cancel ID
	WindowSetId( self.windowName.."Chrome_UO_WindowCloseButton", self.buttonIDs[7] )
	Interface.OnCloseCallBack[self.windowName] = self.RightButtonPressed

	local choiceName = self.windowName.."1Choice"
	
	for i = 1, 6 do -- disable and hide dummy buttons
		ButtonSetDisabledFlag( choiceName..i.."Button", true )
		WindowSetShowing( choiceName..i.."Button", false )
	end

	for i = 1, 5, 2 do -- disable and hide buttons for category names
		ButtonSetDisabledFlag( choiceName..i.."NextButton", true )
		ButtonSetDisabledFlag( choiceName..i.."PrevButton", true )
		WindowSetShowing( choiceName..i.."NextButton", false )
		WindowSetShowing( choiceName..i.."PrevButton", false )
	end
	
	for i = 2, 6, 2 do -- enable choices
		WindowSetId( choiceName..i.."NextButton", self.buttonIDs[i - 1] )
		WindowSetId( choiceName..i.."PrevButton", self.buttonIDs[i] )
	end
end
