
----------------------------------------------------------------
-- Global Variables/functions
----------------------------------------------------------------


OneButtonDialog = {}

OneButtonDialogManager = GGManager


-- Will cause all functions of OneButtonDialog to be inherited
--
function OneButtonDialog:new( newWindow )
	newWindow = newWindow or {}
	setmetatable(newWindow, self)
	self.__index = self
	
	return newWindow
end


OneButton = OneButtonDialog:new{}


-- The one Button Dialog animation has 2 states: animating and non-animating
--
OneButton.ANIMATION_TIME_BETWEEN = 120 -- seconds
OneButton.ANIMATION_DURATION = 5 -- seconds

OneButton.START_FRAME = 0	-- frame to start animation with
OneButton.END_FRAME = 1		-- frame to display while not animating


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- OneButton Functions
--
----------------------------------------------------------------

-- OneButton OnInitialize Handler
function OneButton.Initialize()
	local newWindow = OneButton:new()

	-- timer is the duration until it starts animating
	newWindow.timer = 0
	newWindow.animStarted = false
	
	newWindow:Init()
end


function OneButton:setFields()
     	
    LabelSetText( self.windowName.."Text", self.text )
	WindowSetId( self.windowName, self.buttonID )	
end

-- OneButton.Update
-- keeps track of the main state timer (i.e. when to start and stop animating)
--
function OneButton.Update( timePassed )

	local self = OneButtonDialog.getActiveWindowData()	
	
	self.timer = self.timer - timePassed
	if( self.timer <= 0)  then -- change state
		if self.animStarted == false then
			self:startAnimation()
			self.timer = OneButton.ANIMATION_DURATION
		else
			self:stopAnimation()
			self.timer = OneButton.ANIMATION_TIME_BETWEEN
		end
	end
	
end	

function OneButton:startAnimation()

	self.animStarted = true

	--[[
        LUA_STRING,  // #0 - Window Name      
        LUA_NUMBER,  // #1 - Frame (0-based)
        LUA_BOOLEAN, // #2 - Loop
        LUA_BOOLEAN, // #3 - Hide When Done
        LUA_NUMBER,  // #4 - Delay
    --]]
	AnimatedImageStartAnimation( self.windowName.."Icon", OneButton.START_FRAME, true, false, 0.0 )   

end

function OneButton:stopAnimation()

	-- set the animation to the correct idle frame (color)
	AnimatedImageStartAnimation( self.windowName.."Icon", OneButton.END_FRAME, false, false, 0.0 ) 
	--AnimatedImageStopAnimation(self.windowName.."Icon") 
	
	self.animStarted = false
end



----------------------------------------------------------------
-- OneButtonDialog Functions
--
-- setDataFunction is the most likely function to override for cases
-- where slightly different data is provided
----------------------------------------------------------------


-- Parses the incoming data in different ways based on how many descData values are provided
-- here are the 3 cases this handles:
-- if descDataCount is 1 then descData[1] is text
-- if descDataCount is 2 then descData[1] is title and descData[2] is text
-- if descDataCount is 3 then descData[1] is title,
--    descData[2] is subtitle, and descData[3] is text
--
function OneButtonDialog:setDataFunction()
    UO_GenericGump.debug( L"called OneButtonDialog:setDataFunction" )
    
    local curDescNum = 1
    if self.descDataCount > 1 then
		self.title = GGManager.translateTID(self.descData[curDescNum])
		curDescNum = curDescNum + 1
	end
    if self.descDataCount > 2 then
		self.subtitle = GGManager.translateTID(self.descData[curDescNum])
		curDescNum = curDescNum + 1
	end
	
	
    if self.descDataCount > 0 then
		self.text = GGManager.translateTID(self.descData[curDescNum])
	elseif self.stringDataCount > 0 then 
		self.text = GGManager.stripMarkup(self.stringData[1])
	end
	
	-- ALL OneButtonDialog Windows will have OKAY as button label
	self.buttonName = GGManager.translateTID(GGManager.OKAY_TID)
	self.buttonID = self.buttonIDs[1]

	UO_GenericGump.debug( L"finished OneButtonDialog:setDataFunction()" )

end


----------------------------------------------------------------
-- OneButtonDialog (generic) Functions
--
-- These should be able to be inherited and used as is in most cases
----------------------------------------------------------------


function OneButtonDialog:setFields()
     	
	if self.title then
		UO_GenericGump.debug( L"OneButtonDialog:setFields(): setting title" )
		WindowUtils.SetActiveDialogTitle( self.title )
    end
	if self.subtitle then
		LabelSetText( self.windowName.."Subtitle", self.subtitle )
    end
    
    LabelSetText( self.windowName.."ScrollChildText", self.text )
	ButtonSetText(self.windowName.."ButtonName", self.buttonName )
	WindowSetId( self.windowName.."ButtonName", self.buttonID )	

	-- *** KLUDGE - the size of the subtitle was causing the text to not scroll
	--   to the bottom.
	local subtitle_width, subtitle_height = WindowGetDimensions( self.windowName.."Subtitle" )
	local text_width, text_height = WindowGetDimensions( self.windowName.."ScrollChildText" )	
	WindowSetDimensions( self.windowName.."ScrollChildText", text_width, text_height+subtitle_height )

	--ScrollWindowUpdateScrollRect(self.windowName.."Scroll")
	
	UO_GenericGump.debug( L"finished OneButtonDialog:setDataFunction()" )
end


function OneButtonDialog:Init()
	UO_GenericGump.debug( L"called OneButtonDialog:Init "  )

	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end

	if self.setDataFunction then
		self:setDataFunction()
	end
	
	self:setFields()
	
	OneButtonDialogManager.knownWindows[self.windowName] = self
	WindowSetId( self.windowName.."Chrome_UO_WindowCloseButton", UO_GenericGump.DEFAULT_CLOSE_BUTTON_ID )
	Interface.OnCloseCallBack[self.windowName] = self.ButtonPressed
	
	Debug.PrintToDebugConsole( L"Initialize "..self.name )
end



function OneButtonDialog.getActiveWindowData()
	local windowName = WindowUtils.GetActiveDialog()
	
	return OneButtonDialogManager.knownWindows[windowName]
end



-- OneButtonDialogOnInitialize Handler
function OneButtonDialog.Initialize()
	local newWindow = OneButtonDialog:new()

	-- uses the default OneButtonDialog.setDataFunction
	newWindow:Init()
end




function OneButtonDialog.ButtonPressed()

	local self = OneButtonDialog.getActiveWindowData()	
	if self == nil then
		Debug.PrintToDebugConsole( L"OneButtonDialog.ButtonPressed failed to find window data." )	
		return
	end
	UO_GenericGump.debug( L"called OneButtonDialog.ButtonPressed() on "..self.name )
	
	self:ButtonFunction()
end


function OneButtonDialog:ButtonFunction()
	UO_GenericGump.debug( L"called OneButtonDialog:ButtonFunction" )
	
	local buttonID = WindowGetId( SystemData.ActiveWindow.name )
	
	-- NOTE: this may need to be changed. Currently WindowGetId seems to return 0,
	--  if a value is not set (and 0 is a valid value). May change C++ to return negative value
	--  when no value is set
	if not buttonID then	
		Debug.PrintToDebugConsole( L"ERROR in OneButtonDialog:ButtonFunction(): no ID set for button pressed." )
		return
	end

	UO_GenericGump.debug( L"called OneButtonDialog:ButtonFunction(). Sending button value of "..buttonID )
	
	UO_GenericGump.broadcastButtonPress( buttonID, self )
	self.OnCloseWindow()
end


-- TODO: this will need to be made smarter
--
function OneButtonDialog.OnCloseWindow()	
	UO_GenericGump.debug( L"called OneButtonDialog.OnCloseWindow()" )
	
	GGManager.destroyActiveWindow()
end



