
-- This one expects:
-- self.ImageNum[1] = picture

----------------------------------------------------------------
-- Promo7thTapestry
----------------------------------------------------------------


Promo7thTapestry = {}


Promo7thTapestryManager = GGManager


function Promo7thTapestry.Initialize()
	local NewWindow = Promo7thTapestry:new()
	NewWindow:Init()
end


function Promo7thTapestry:new( NewWindow )
	NewWindow = NewWindow or {}
	setmetatable( NewWindow, self )
	self.__index = self
	return NewWindow
end


function Promo7thTapestry:Init()
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	if self.setDataFunction then
		self:setDataFunction()
	end
	if self.setFields then
			self:setFields()
	end
	Promo7thTapestryManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end


function Promo7thTapestry:setDataFunction()	
	-- get the picure
	if self.portImgData[1] then
		self.picture = self.portImgData[1]
	end
end -- setDataFunction()


-- set the data
function Promo7thTapestry:setFields()
	if self.picture then
		--local texture, x, y, scale, width, height = RequestTileArt( self.picture, 0, 0 )	
		--WindowSetDimensions( self.windowName.."Icon", width, height )
		--DynamicImageSetTexture     ( self.windowName.."Icon", texture, x, y )
		--DynamicImageSetTextureScale( self.windowName.."Icon", scale )
	--	local testWidth = 128
	--	local testHeight = 128
		local defaultImage, x, y, scale, newWidth, newHeight = RequestTexture(self.picture, 0, 0)
		--Debug.Print("defaultImage: "..defaultImage)
		Debug.Print("newWidth: "..newWidth)
		Debug.Print("newHeight: "..newHeight)		
		WindowSetDimensions( self.windowName.."Icon", 256, 200 ) -- newWidth, newHeight)
		DynamicImageSetTexture( self.windowName.."Icon", defaultImage, 0, 0 )
		--DynamicImageSetTextureScale( self.windowName.."Icon", 1.0 )	 --We should not scale it anyways.
	end
end -- setFields()


-- OnClose handler
function Promo7thTapestry.OnCloseWindow()

	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )
end


-- OnShutdownHandler
function Promo7thTapestry.Shutdown()
	
	local self = GGManager.knownWindows[SystemData.ActiveWindow.name]	
	if self == nil then
		UO_GenericGump.debug( StringToWString( "Shutdown hander called for "..SystemData.ActiveWindow.name.." but data already deleted" ) )
		return
	end	
	
	if self.picture then
		ReleaseTexture(self.picture)
	end
	
	GGManager.unregisterActiveWindow()
end


function Promo7thTapestry.getActiveWindowData()

	local windowName = WindowUtils.GetActiveDialog()
	return Promo7thTapestryManager.knownWindows[windowName]
end
