----------------------------------------------------------------
-- Fortune.lua
----------------------------------------------------------------

Fortune = {}
FortuneManager = GGManager

function Fortune.Initialize()

	local fortune = Fortune:new()
	fortune:Init()
end

function Fortune:new( fortune )

	fortune = fortune or {}
	setmetatable( fortune, self )
	self.__index = self

	return fortune
end

function Fortune:Init()

	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end
	
	FortuneManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end

function Fortune:setDataFunction()
	self.Tooltips = {}
	
	-- subtitle
	LabelSetText( self.windowName.."Subtitle", self.stringData[1] )

	-- left Text and Icon
	LabelSetText( self.windowName.."LeftText", GGManager.translateTID( self.descData[1] ) )
	
	local texture, x, y, scale, newWidth, newHeight = RequestTexture( tonumber( self.portImgData[2] ), 256, 256 )
	DynamicImageSetTexture( self.windowName.."LeftIcon", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."LeftIcon", scale )

	self.Tooltips[self.windowName.."LeftText"] = self.toolTipData[1]
	self.Tooltips[self.windowName.."LeftIcon"] = self.toolTipData[1]
	
	-- middle Text and Icon
	LabelSetText( self.windowName.."MiddleText", GGManager.translateTID( self.descData[2] ) )
	
	texture, x, y, scale, newWidth, newHeight = RequestTexture( tonumber( self.portImgData[3] ), 256, 256 )
	DynamicImageSetTexture( self.windowName.."MiddleIcon", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."MiddleIcon", scale )
	
	self.Tooltips[self.windowName.."MiddleText"] = self.toolTipData[2]
	self.Tooltips[self.windowName.."MiddleIcon"] = self.toolTipData[2]
	
	-- right Text and Icon
	LabelSetText( self.windowName.."RightText", GGManager.translateTID( self.descData[3] ) )

	texture, x, y, scale, newWidth, newHeight = RequestTexture( tonumber( self.portImgData[4] ), 256, 256 )
	DynamicImageSetTexture( self.windowName.."RightIcon", texture, x, y )
	DynamicImageSetTextureScale( self.windowName.."RightIcon", scale )
	
	self.Tooltips[self.windowName.."RightText"] = self.toolTipData[3]
	self.Tooltips[self.windowName.."RightIcon"] = self.toolTipData[3]

	-- middle button
	ButtonSetText( self.windowName.."MiddleButton", GGManager.translateTID( 1061046 ) ) -- "Close"
	WindowSetId( self.windowName.."MiddleButton", 0 )
end

function Fortune.MButtonPressed()

	local self = FortuneManager.knownWindows[WindowUtils.GetActiveDialog()]
	self.OnCloseWindow()
end

function Fortune.OnMouseOver()

	local self = FortuneManager.knownWindows[WindowUtils.GetActiveDialog()]
	local name = SystemData.ActiveWindow.name
	
	if self ~= nil then
		Tooltips.CreateTextOnlyTooltip( name, GGManager.translateTID( self.Tooltips[name] ) )
		Tooltips.Finalize()
		Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_TOP )
	end 
end

function Fortune.OnShutdown()
	local self = FortuneManager.knownWindows[WindowUtils.GetActiveDialog()]
	if self == nil then
		UO_GenericGump.debug( StringToWString( "Shutdown hander called for "..SystemData.ActiveWindow.name.." but data already deleted" ) )
		return
	end	
	
	ReleaseTexture( tonumber( self.portImgData[2] ) )
	ReleaseTexture( tonumber( self.portImgData[3] ) )
	ReleaseTexture( tonumber( self.portImgData[4] ) )
	
	GGManager.unregisterWindow(self.windowName)
end

function Fortune.OnCloseWindow()

	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )
end
