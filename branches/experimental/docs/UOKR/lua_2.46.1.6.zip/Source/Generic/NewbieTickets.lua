----------------------------------------------------------
-- NewbieTickets.lua
----------------------------------------------------------------

NewbieTickets = MasterGUMP:new()



function NewbieTickets.Initialize()

	local newWindow					= NewbieTickets:new()
	newWindow.setData				= NewbieTickets.mySetData
	newWindow:Init()
end

function NewbieTickets:finalize()
	MasterGUMP.finalize(self)
	
	
end



function NewbieTickets:mySetData()

	self.Page	= {}
	

	for pageNum, _ in ipairs( self.stringPageIndex )
	do
		self.Page[pageNum] = {}
		
		local strItr	= 3
		local strItrEnd	= 8


		if pageNum ~= table.getn( self.descPageIndex )
		then
			strItrEnd = self.stringPageIndex[pageNum + 1] - 1
		end

	
		self.Page[pageNum].ScrollText = GGManager.translateTID( self.descData[1] )
	
		self.Page[pageNum].Selections	= {}
		
		local index = 1
		while strItr <= strItrEnd
		do
			self.Page[pageNum].Selections[index]		= {}
			self.Page[pageNum].Selections[index].Id		= self.buttonIDs[index+1]
			self.Page[pageNum].Selections[index].Text	= GGManager.translateTID( self.descData[strItr] )
			
			index = index + 1
			strItr = strItr + 1
		end


		self.Page[pageNum].MiddleButtonId = self.buttonIDs[1]
		self.Page[pageNum].MiddleButtonText = GGManager.translateTID( 1011012 )


		
	end
end
