----------------------------------------------------------
-- EditBallotbox.lua
----------------------------------------------------------------

EditBallotbox = MasterGUMP:new()

function EditBallotbox.Initialize()
	local newWindow					= EditBallotbox:new()
	newWindow.setData				= EditBallotbox.mySetData
	newWindow:Init()
end

function EditBallotbox:mySetData()
	self.IsStandardHeight	= true

	self.Page				= {}
	self.Page[1]			= {}
	self.Page[1].Title		= GGManager.translateTID( 1015129 )				-- "Ballot Box"
	self.Page[1].Subtitle	= GGManager.translateTID( self.descData[2] )	-- "Topic"
	
	local scrolltext = L""
	if self.stringData[3] then -- custom topic
		for i = 3, self.stringDataCount do
			scrolltext = scrolltext..self.stringData[i]
		end
	end
	
	self.Page[1].ScrollText	= scrolltext
	self.Page[1].Selections	= {}

	self.Page[1].Selections[1]			= {}
	self.Page[1].Selections[1].Id		= MasterGUMP.DISABLED2_BUTTON_ID
	self.Page[1].Selections[1].Text		= GGManager.translateTID( self.descData[3] ) -- "votes"
	self.Page[1].Selections[1].Bottom	= true
	
	self.Page[1].Selections[2]		= {}
	self.Page[1].Selections[2].Text	= GGManager.translateTID( self.descData[4] )..L" "..self.stringData[1] -- aye votes
	self.Page[1].Selections[2].Bottom	= true
	
	self.Page[1].Selections[3]		= {}
	self.Page[1].Selections[3].Text	= GGManager.translateTID( self.descData[5] )..L" "..self.stringData[2] -- nay votes
	self.Page[1].Selections[3].Bottom	= true
	
	if self.descDataCount == 8 then -- ballot box owner
		self.Page[1].Selections[2].Id	= MasterGUMP.DISABLED2_BUTTON_ID
		self.Page[1].Selections[3].Id	= MasterGUMP.DISABLED2_BUTTON_ID
		
		self.Page[1].Selections[4]			= {}
		self.Page[1].Selections[4].Id		= self.buttonIDs[1]
		self.Page[1].Selections[4].Text		= GGManager.translateTID( self.descData[6] ) -- "change topic"
		self.Page[1].Selections[4].Bottom	= true
		
		self.Page[1].Selections[5]			= {}
		self.Page[1].Selections[5].Id		= self.buttonIDs[2]
		self.Page[1].Selections[5].Text		= GGManager.translateTID( self.descData[7] ) -- "reset votes"
		self.Page[1].Selections[5].Bottom	= true
		
	else -- other players
		self.Page[1].Selections[2].Id	= self.buttonIDs[1] -- vote aye
		self.Page[1].Selections[3].Id	= self.buttonIDs[2] -- vote nay
	end
	
	self.Page[1].MiddleButtonId		= self.buttonIDs[3]
	self.Page[1].MiddleButtonText	= GGManager.translateTID( GGManager.OKAY_TID )
end
