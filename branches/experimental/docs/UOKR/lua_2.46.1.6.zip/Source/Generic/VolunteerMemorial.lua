----------------------------------------------------------
-- VolunteerMemorial.lua
----------------------------------------------------------------

VolunteerMemorial = MasterGUMP:new()

function VolunteerMemorial.Initialize()

	local newWindow					= VolunteerMemorial:new()
	newWindow.setData				= VolunteerMemorial.mySetData
	newWindow:Init()
end

function VolunteerMemorial:mySetData()

	self.Page = {}
		
	if self.stringDataCount
	and self.stringDataCount ~= 0
	then
		if self.descData[1] 
		and self.descData[1] <= 0
		then
			self.Page[1] = {}
			self.Page[1].Subtitle = GGManager.stripMarkup( self.stringData[ -self.descData[1] + 1 ] )
			self.Page[1].MiddleButtonId = 0
			self.Page[1].MiddleButtonText = GGManager.translateTID( GGManager.CLOSE_TID )
		else
			self.Page[1] = {}
			self.Page[1].Subtitle = GGManager.stripMarkup( self.stringData[1] )
UO_GenericGump.debug( L"Volunteer Memorial Error: No case data was found, defualting to first string. Most likely cause is out of data server code." )
			self.Page[1].MiddleButtonId = 0
			self.Page[1].MiddleButtonText = GGManager.translateTID( GGManager.CLOSE_TID )
		end
	else
		local itr
		local nextPage = 1
		for itr = 2, self.descDataCount
		do
			if self.descData[itr] ~= 1011066
			and self.descData[itr] ~= 1011067
			then
				self.Page[nextPage] = {}
				self.Page[nextPage].Subtitle = GGManager.translateTID( self.descData[1] )
				self.Page[nextPage].ScrollText = GGManager.translateTID( self.descData[itr] )
				self.Page[nextPage].MiddleButtonId = 0
				self.Page[nextPage].MiddleButtonText = GGManager.translateTID( GGManager.CLOSE_TID )
				nextPage = nextPage + 1
			else
				self.CreatePrevNextButtons = true
			end
		end
	end
end
