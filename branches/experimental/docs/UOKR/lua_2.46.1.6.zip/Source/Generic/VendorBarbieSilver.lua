----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

VendorBarbieSilver = ChoiceList:new()

----------------------------------------------------------------
-- Promo7thChoice Functions
----------------------------------------------------------------

function VendorBarbieSilver:setDataFunction()

	-- Don't use a wide ChoiceList
	local isWide = false -- true 
	
	-- Thing to attach the next thing to
	local relativeWindow
	
	-- Looping variable
	local descIndex
	
	-- Grab which case
	local case = self.descData[1]

	-- Set the title (disabled - Wouldn't fit)
	--WindowUtils.SetActiveDialogTitle( GGManager.translateTID( self.descData[2] ) )

	-- The cancel button
	self:CreateBottomButton( GGManager.translateTID( self.descData[3] ), self.buttonIDs[1] )

	-- Set the subtitle	
	relativeWindow = self:CreateSubtitle( GGManager.translateTID( self.descData[2] ), isWide )

	if case == -1 then
		
		-- "Hair"
		relativeWindow = self:CreateText( 1, GGManager.translateTID( 1011395 ), --[[ self.descData[4] ), --]]
			"topleft", relativeWindow, "topleft", 0, 0, isWide )
		-- The first hair choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[2], GGManager.translateTID( self.descData[5] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		-- The remaining hair choices
		for descIndex=6, 15 do
			relativeWindow = self:CreateChoiceListSelectableText( 
				self.buttonIDs[descIndex-3], GGManager.translateTID( self.descData[descIndex] ), "bottom", relativeWindow, "top", 0, 0, isWide )
		end -- for
		
		-- "Facial Hair"
		relativeWindow = self:CreateText( 2, GGManager.translateTID( 1015320 ), --[[ self.descData[16] ), --]]
			"bottomleft", relativeWindow, "topleft", 0, 10, isWide )
		-- The first beard choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[13], GGManager.translateTID( self.descData[17] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		-- The remaining beard choices
		for descIndex=18, 25 do
			relativeWindow = self:CreateChoiceListSelectableText( 
				self.buttonIDs[descIndex-4], GGManager.translateTID( self.descData[descIndex] ), "bottom", relativeWindow, "top", 0, 0, isWide )
		end -- for
		
		-- "Gender"
		relativeWindow = self:CreateText( 3, GGManager.translateTID( 3000120 ),
			"bottomleft", relativeWindow, "topleft", 0, 10, isWide )
		-- The only gender choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[22], GGManager.translateTID( self.descData[27] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		
		-- "Race"
		relativeWindow = self:CreateText( 4, GGManager.translateTID( 1077827 ),
			"bottomleft", relativeWindow, "topleft", 0, 10, isWide )
		-- The only race choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[23], GGManager.translateTID( self.descData[29] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		
	elseif case == -2 then

	-- "Hair"
		relativeWindow = self:CreateText( 1, GGManager.translateTID( 1011395 ), --[[ self.descData[4] ), --]]
			"topleft", relativeWindow, "topleft", 0, 0, isWide )
		-- The first hair choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[2], GGManager.translateTID( self.descData[5] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		-- The remaining hair choices
		for descIndex=6, 15 do
			relativeWindow = self:CreateChoiceListSelectableText( 
				self.buttonIDs[descIndex-3], GGManager.translateTID( self.descData[descIndex] ), "bottom", relativeWindow, "top", 0, 0, isWide )
		end -- for

		-- "Gender"
		relativeWindow = self:CreateText( 3, GGManager.translateTID( 3000120 ),
			"bottomleft", relativeWindow, "topleft", 0, 10, isWide )
		-- The only gender choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[13], GGManager.translateTID( self.descData[16] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		
		-- "Race"
		relativeWindow = self:CreateText( 4, GGManager.translateTID( 1077827 ),
			"bottomleft", relativeWindow, "topleft", 0, 10, isWide )
		-- The only race choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[14], GGManager.translateTID( self.descData[19] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )


	elseif case == -3 then

	-- "Hair"
		relativeWindow = self:CreateText( 1, GGManager.translateTID( 1011395 ), --[[ self.descData[4] ), --]]
			"topleft", relativeWindow, "topleft", 0, 0, isWide )
		-- The first hair choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[2], GGManager.translateTID( self.descData[5] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		-- The remaining hair choices
		for descIndex=6, 14 do
			relativeWindow = self:CreateChoiceListSelectableText( 
				self.buttonIDs[descIndex-3], GGManager.translateTID( self.descData[descIndex] ), "bottom", relativeWindow, "top", 0, 0, isWide )
		end -- for
				
		-- "Gender"
		relativeWindow = self:CreateText( 3, GGManager.translateTID( 3000120 ),
			"bottomleft", relativeWindow, "topleft", 0, 10, isWide )
		-- The only gender choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[12], GGManager.translateTID( self.descData[16] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		
		-- "Race"
		relativeWindow = self:CreateText( 4, GGManager.translateTID( 1077827 ),
			"bottomleft", relativeWindow, "topleft", 0, 10, isWide )
		-- The only race choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[13], GGManager.translateTID( self.descData[17] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )

	elseif case == -4 then

	-- "Hair"
		relativeWindow = self:CreateText( 1, GGManager.translateTID( 1011395 ), --[[ self.descData[4] ), --]]
			"topleft", relativeWindow, "topleft", 0, 0, isWide )
		-- The first hair choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[2], GGManager.translateTID( self.descData[5] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		-- The remaining hair choices
		for descIndex=6, 14 do
			relativeWindow = self:CreateChoiceListSelectableText( 
				self.buttonIDs[descIndex-3], GGManager.translateTID( self.descData[descIndex] ), "bottom", relativeWindow, "top", 0, 0, isWide )
		end -- for
				
		-- "Gender"
		relativeWindow = self:CreateText( 3, GGManager.translateTID( 3000120 ),
			"bottomleft", relativeWindow, "topleft", 0, 10, isWide )
		-- The only gender choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[12], GGManager.translateTID( self.descData[15] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		
		-- "Race"
		relativeWindow = self:CreateText( 4, GGManager.translateTID( 1077827 ),
			"bottomleft", relativeWindow, "topleft", 0, 10, isWide )
		-- The only race choice
		relativeWindow = self:CreateChoiceListSelectableText(
			self.buttonIDs[13], GGManager.translateTID( self.descData[17] ), "bottomleft", relativeWindow, "topleft", 0, 0, isWide )

	else
		Debug.Print( L"Reached an unknown case in VendorBarbieSilver.lua in VendorBarbieSilver:setDataFunction()" )
	end	

	
end -- VendorBarbieSilver:setDataFunction()

-- Standard OnInitialize Handler
function VendorBarbieSilver.Initialize()
	local newWindow = VendorBarbieSilver:new()
	newWindow.setDataFunction = VendorBarbieSilver.setDataFunction
	newWindow:Init()
end
