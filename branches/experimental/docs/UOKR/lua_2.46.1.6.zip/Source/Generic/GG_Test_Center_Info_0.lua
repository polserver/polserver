
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

GG_Test_Center_Info_0 = OneButtonDialog:new()

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- GG_Test_Center_Info_0 Functions
----------------------------------------------------------------

function GG_Test_Center_Info_0:setDataFunction()

	self.text = GGManager.stripMarkup(self.stringData[1])

	self.buttonName = GGManager.translateTID(GGManager.OKAY_TID)
	--self.buttonID = gumpData.buttonIDs[1]
	self.buttonID = 0
end


-- OnInitialize Handler
function GG_Test_Center_Info_0.Initialize()
	local NewWindow = GG_Test_Center_Info_0:new()
	NewWindow:Init()
end

