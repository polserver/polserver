----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

ChooseForm = ChoiceList:new()

ChooseForm.BOTTOM_BUTTON_ID = 0
ChooseForm.GUMP_CLOSE_ID_USER_BASE = 99

----------------------------------------------------------------
-- ChooseForm Functions
----------------------------------------------------------------

-- replaces GGManager.translateTID to do some custom HTML stripping
-- 
-- <BR>  -->  single space
-- anything else between < >  -->  deleted
function ChooseForm.translateTID( tid )
	if not tid or tonumber( tid ) == nil then
		UO_GenericGump.debug( L"ERROR in ChooseForm.translateTID: TID is nil" )
		return L""
	end
	local result = GetStringFromTid( tonumber( tid ) ) 
	if not result then
		UO_GenericGump.debug( L"ERROR in ChooseForm.translateTID: No string found for TID = "..tid )
		return L""
	end
	
	result = wstring.gsub( result, L"<[Bb][Rr]>", L" " )
	result = wstring.gsub( result, L"<.->", L"" )
	
	return result
end

function ChooseForm:setDataFunction()
	local choiceName = self.windowName.."SelectableText"
	local iconMaxSize = 68
	
	self.title = ChooseForm.translateTID( self.descData[2] )
	self.bottomButtonName = ChooseForm.translateTID( self.descData[1] )
	self.textValues = {}
	self.Tooltips = {}
	self.choiceNum = {}
	
	offset = 2 -- start skipping the cancel button text and title right away
	skipcounter = 0 -- needed because there's no mod function (at least none I can find!)
	for i = 1, self.ImageCount do
		local name = choiceName..i
		self.textValues[i] = ChooseForm.translateTID( self.descData[i + offset] )
		self.choiceNum[i] = ChooseForm.GUMP_CLOSE_ID_USER_BASE + i
		self.Tooltips[name] = self.toolTipData[i]
		skipcounter = skipcounter + 1
		if 10 == skipcounter then -- update the offset every tenth time 
			offset = offset + 2
			skipcounter = 0
		end -- if
	end -- for i
	self.iconValues = self.ImageNum -- copy over the icons data
	self.bottomButtonID = ChooseForm.BOTTOM_BUTTON_ID -- set the button id

	if self.title then
		WindowUtils.SetActiveDialogTitle( self.title )
	end
   
	if self.bottomButtonName then 
		CreateWindowFromTemplate( self.windowName.."BottomButton", "ChoiceListBottomButton", self.windowName )
		ButtonSetText( self.windowName.."BottomButton", self.bottomButtonName )
		WindowSetId( self.windowName.."BottomButton", self.bottomButtonID )
	end
	
	for button_num, button_string in ipairs( self.textValues ) do
		self.RequestedTileArt = self.RequestedTileArt or {}
		local texture, x, y, scale, newWidth, newHeight = RequestTileArt( self.iconValues[button_num], iconMaxSize, iconMaxSize )
		local choice = choiceName..button_num
		
		self.RequestedTileArt[#self.RequestedTileArt + 1] = texture
		
		CreateWindowFromTemplate( choice, "ChoiceListSelectableIconAndText", self.windowName.."ScrollChild" )
		WindowSetDimensions( choice.."IconHolderSquareIcon", newWidth, newHeight )
		DynamicImageSetTexture( choice.."IconHolderSquareIcon", texture, x, y )
		DynamicImageSetTextureScale( choice.."IconHolderSquareIcon", scale )
		LabelSetText( choice.."Desc", button_string )

		if button_num == 1 then
			WindowAddAnchor( choice, "topleft", self.windowName.."ScrollChild", "topleft", 5, 0 )
		elseif button_num == 2 then
			WindowAddAnchor( choice, "topright", self.windowName.."ScrollChild", "topright", 0, 0 )
		else
			WindowAddAnchor( choice, "bottom", choiceName..( button_num - 2 ), "top", 0, 20 )
		end

		WindowSetId( choice, button_num + ChooseForm.GUMP_CLOSE_ID_USER_BASE )
	end
end

function ChooseForm:BottomButtonFunction()
	ChoiceList.BottomButtonFunction(self)
	self.broadcastHasBeenSent = true
end

function ChooseForm:DefaultButtonSelectedFunction()
	ChoiceList.DefaultButtonSelectedFunction(self)
	self.broadcastHasBeenSent = true
end

function ChooseForm.Initialize()
	local newWindow = ChooseForm:new()
	newWindow:Init()
	
	newWindow.broadcastHasBeenSent = false
end

function ChooseForm.OnCloseWindow()
	UO_GenericGump.debug( L"called ChooseForm.OnCloseWindow(), active window = "..StringToWString(SystemData.ActiveWindow.name) )

	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )
end

function ChooseForm.Shutdown()
	
	local self = GGManager.knownWindows[SystemData.ActiveWindow.name]	
	if self == nil then
		UO_GenericGump.debug( StringToWString( "Shutdown hander called for "..SystemData.ActiveWindow.name.." but data already deleted" ) )
		return
	end
	
	if self.RequestedTileArt then
		for _, art in pairs( self.RequestedTileArt ) do
			ReleaseTileArt( art )
		end
	end

	if self.broadcastHasBeenSent == false then
		UO_GenericGump.broadcastButtonPress( ChooseForm.BOTTOM_BUTTON_ID, self )
	end
	
	GGManager.unregisterActiveWindow()
end
