----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

BarkeepTitle = ChoiceList:new()

----------------------------------------------------------------
-- Promo7thChoice Functions
----------------------------------------------------------------

function BarkeepTitle:setDataFunction()

	-- This isn't a wide ChoiceList
	local isWide = false 
	
	-- Thing to attach the next thing to
	local relativeWindow
	
	-- Looping variable
	local descIndex

	-- Set the title (disabled - it doesn't fit)
	--WindowUtils.SetActiveDialogTitle( GGManager.translateTID( self.descData[1] ) )

	-- Set the subtitle	
	relativeWindow = self:CreateSubtitle( GGManager.translateTID( 1078510 ), isWide )
	
	-- The first choice
	relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[1], GGManager.translateTID( self.descData[4] ), "topleft", relativeWindow, "topleft", 0, 0, isWide )
			
	-- Choices from the first page (less the first one)
	for descIndex = 2,20 do
		relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[descIndex], GGManager.translateTID( self.descData[descIndex+3] ), "bottom", relativeWindow, "top", 0, 0, isWide )
	end

	-- Choices from the second page
	for descIndex = 23,42 do
		relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[descIndex], GGManager.translateTID( self.descData[descIndex+5] ), "bottom", relativeWindow, "top", 0, 0, isWide )
	end

	-- Choices from the third page
	for descIndex = 45,64 do
		relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[descIndex], GGManager.translateTID( self.descData[descIndex+7] ), "bottom", relativeWindow, "top", 0, 0, isWide )
	end

	-- The cancel button
	self:CreateBottomButton( GGManager.translateTID( GGManager.CANCEL_TID ), self.buttonIDs[21] )
	
end -- BarkeepTitle:setDataFunction()

-- Standard OnInitialize Handler
function BarkeepTitle.Initialize()
	local newWindow = BarkeepTitle:new()
	newWindow.setDataFunction = BarkeepTitle.setDataFunction
	newWindow:Init()
end
