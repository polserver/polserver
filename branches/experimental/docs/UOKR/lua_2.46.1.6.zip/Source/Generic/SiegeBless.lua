----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

SiegeBless = OneButtonDialog:new()

----------------------------------------------------------------
-- SiegeBless Functions
----------------------------------------------------------------


function SiegeBless:setDataFunction()
	self.text = self.localizedData[1]
	self.buttonName = GGManager.translateTID(GGManager.OKAY_TID)
	self.buttonID = self.buttonIDs[1]
end


-- OnInitialize Handler
function SiegeBless.Initialize()
	local NewWindow = SiegeBless:new()
	NewWindow:Init()
end