----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

TrackingTwo = ChoiceList:new()

----------------------------------------------------------------
-- TrackingTwo Functions
----------------------------------------------------------------

function TrackingTwo:setDataFunction()

	local isWide = false 
	
	local relativeWindow = TrackingTwo.CreateChoiceListSelectableText(
							self, self.buttonIDs[1], self.stringData[1], "topleft", self.windowName.."ScrollChild", "topleft", 0, 0, isWide )
	
	local descIndex						
	for descIndex = 2, self.stringDataCount do
		relativeWindow = TrackingTwo.CreateChoiceListSelectableText(
							self, self.buttonIDs[descIndex], self.stringData[descIndex], "bottom",	relativeWindow, "top", 0, 0, isWide )
	end
end

-- OnInitialize Handler
function TrackingTwo.Initialize()
	local newWindow = TrackingTwo:new()
	newWindow.setDataFunction = TrackingTwo.setDataFunction
	newWindow:Init()
end