
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

PetRelease = { }

----------------------------------------------------------------
-- PetRelease Functions
----------------------------------------------------------------


-- OnInitialize Handler
function PetRelease.Initialize()

	PetRelease.setDataFunction = TwoButtonDialog.parseDescAsTextAndTwoButtons
	TwoButtonDialog.Init(PetRelease)
end
	

