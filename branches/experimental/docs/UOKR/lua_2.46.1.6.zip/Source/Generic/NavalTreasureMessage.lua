----------------------------------------------------------
-- NavalTreasureMessage.lua
----------------------------------------------------------------

NavalTreasureMessage = MasterGUMP:new()

function NavalTreasureMessage.Initialize()
	local newWindow	= NavalTreasureMessage:new()
	newWindow.setData = NavalTreasureMessage.mySetData
	newWindow:Init()
end

function NavalTreasureMessage:mySetData()
	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Subtitle =  self.stringData[1]
	self.Page[1].ScrollText = GGManager.translateTID( self.descData[1] )	
	self.Page[1].MiddleButtonId = self.buttonIDs[1]
	self.Page[1].MiddleButtonText = GGManager.translateTID(  self.descData[2] )
end
