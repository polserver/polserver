
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------


--NoGumpFound = { }
NoGumpFound = OneButtonDialog:new()


----------------------------------------------------------------
-- NoGumpFound Functions
----------------------------------------------------------------

function NoGumpFound:setDataFunction()
    if IsInternalBuild() then
		self.title = L"WINDOW NOT FOUND"
		self.text = GGManager.GumpToString() -- just displays the parsed gump info from server
    else
    	self.title = L"REPORT THIS BUG" -- Localize this? Nah...
		self.text = GGManager.BetaTesterHelpMessage() -- just displays the beta tester help message
	end
	self.buttonName = GGManager.translateTID( 1060675 ) -- "CLOSE"
	self.buttonID = 0
end


-- OnInitialize Handler
function NoGumpFound.Initialize()
	-- inherit parent functions and default value (for button)
	local newWindow = NoGumpFound:new()
	-- and uses NoGumpFound.setDataFunction to parse incoming data
	newWindow:Init()
	
end

-- no message is sent back to server for this Gump
function NoGumpFound:ButtonFunction()
	self.OnCloseWindow()
end


