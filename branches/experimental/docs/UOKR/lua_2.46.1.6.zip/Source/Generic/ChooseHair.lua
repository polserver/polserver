----------------------------------------------------------------
-- ChooseHair.lua
----------------------------------------------------------------

ChooseHair = MasterGUMP:new()

function ChooseHair.Initialize()

	local newWindow					= ChooseHair:new()
	newWindow.setData				= ChooseHair.mySetData
	newWindow:Init()
end

function ChooseHair:mySetData()
	self.Page = {}
	self.Page[1] = {}
	if self.descData[3] == 1018353 then -- Could add other titles possible here.
		self.Page[1].Title = GGManager.translateTID( self.descData[3] )
	end
	self.Page[1].Selections = {} -- Needed in all cases
 	self.Page[1].UseXButtons = true

	local i
	for i = 3, self.buttonCount do
		self.Page[1].Selections[i - 2] = {}
		--[[
		if self.descData[4] == 3000351 then -- TEMPORARY: Only show icons for Beards. :-O>
			if self.portImgData[i - 2] ~= -1 then
				self.Page[1].Selections[i-2].Port = self.portImgData[ i - 2 ] -- + imageOffset]
			end
		end
		--]]
		self.Page[1].Selections[i - 2].Text = GGManager.translateTID( self.descData[i + 1] ) -- descOffset] )
		self.Page[1].Selections[i - 2].Id = self.buttonIDs[i]
	end

	self.Page[1].LeftButtonId		= self.buttonIDs[1]
	self.Page[1].LeftButtonText		= GGManager.translateTID( self.descData[1] ) -- Okay

	self.Page[1].RightButtonId		= self.buttonIDs[2]
	self.Page[1].RightButtonText	= GGManager.translateTID( self.descData[2] ) -- Cancel
end

-- overriding this function to display a smaller piece of the art
function ChooseHair:SetIcon( selection, choiceName )
	local texture, x, y, scale = "0000", 0, 0, 1
	local inSize, outSize	= 352, 64
	local xOffset, yOffset	= 212, 68

	if  selection.Port
	and selection.Port > 0
	then
		self.RequestedTextures = self.RequestedTextures or {}
		texture, x, y, scale, newWidth, newHeight = RequestTexture( selection.Port, inSize, inSize )
		self.RequestedTextures[#self.RequestedTextures + 1] = selection.Port
		UO_GenericGump.debug( L"    Portrait = "..StringToWString( tostring( selection.Port ) ) )
	end
	
	WindowSetDimensions( choiceName.."IconHolderIcon", outSize, outSize )
	DynamicImageSetTexture( choiceName.."IconHolderIcon", texture, xOffset, yOffset )
	DynamicImageSetTextureScale( choiceName.."IconHolderIcon", scale )
end
