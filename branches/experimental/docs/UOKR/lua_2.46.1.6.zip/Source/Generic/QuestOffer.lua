
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

QuestOffer = 
{
	leftButtonTID = GGManager.ACCEPT_TID,
	rightButtonTID = GGManager.REFUSE_TID,
}

QuestJournalDetails = 
{
	leftButtonTID = GGManager.QUIT_TID,
	rightButtonTID = GGManager.OKAY_TID,
}


function QuestOffer.setDataFunction(self)
	UO_GenericGump.debug( L"QuestOffer.parseData(self) - setting data for = "..self.name )
	
	local ACCEPT_STRING = GGManager.translateTID(self.leftButtonTID)
	local REFUSE_STRING = GGManager.translateTID(self.rightButtonTID)
	
	self.Page[1].pageName = self.windowName.."DescriptionPage"
	self.Page[2].pageName = self.windowName.."ObjectivePage"
	self.Page[3].pageName = self.windowName.."RewardPage"
	
	-- no String from server so hardcode Accept and Refuse on left and right button for all pages
	--   Set Previous and Next button IDs to previous and next page values
	--   Previous and Next buttons don't have a string
	for i=1, table.getn(self.Page) do
		self.Page[i].leftButtonName = ACCEPT_STRING
		self.Page[i].rightButtonName = REFUSE_STRING
		self.Page[i].prevButtonID = i-1
		self.Page[i].nextButtonID = i+1
	end

	-- TODO - this is currently not handling the stringData properly
	--        as well as icons for gathering quest items
	
	--<Window name="$parentDescriptionPage" inherits="FourButtonDialog"/>	
	self.Page[1].title = GGManager.translateTID(self.descData[1])
	self.Page[1].subtitle =  GGManager.translateTID(self.descData[2])..L"\n\n"..GGManager.translateTID(self.descData[3])
	self.Page[1].text = GGManager.translateTID(self.descData[4])
	
	self.Page[1].leftButtonID = self.buttonIDs[1]
	self.Page[1].rightButtonID = self.buttonIDs[2]
	
	--<Window name="$parentObjectivePage" inherits="FourButtonDialog"/>
	
	
	--local picItr		= self.picPageIndex[2]
	local stringItr		= self.stringPageIndex[2]
	local localItr		= self.localizedPageIndex[2]
	local buttonItr		= self.buttonPageIndex[2]
	local descItr		= self.descPageIndex[2]
	local descEnd		= self.descPageIndex[3]
	
	self.Page[2].title		= GGManager.translateTID(self.descData[descItr])
	self.Page[2].subtitle	= GGManager.translateTID(self.descData[descItr + 1])..L"\n\n"..GGManager.translateTID(self.descData[descItr + 2])
	self.Page[2].text		= GGManager.translateTID(self.descData[descItr + 3])
	descItr = descItr + 4

	while descItr < descEnd
	do												-- See qsys_guestgumps.wxx for where these values are determined
													-- This is a kludge so we what type of quest we have, each new objective tells us what type of objective it is
		if self.descData[descItr] == -1 then		-- Custom quest objective with TID

			self.Page[2].text = self.Page[2].text..L"\n"..GGManager.translateTID(self.descData[descItr + 1])
			descItr = descItr + 2
			
		elseif self.descData[descItr] == -2			-- kill
			or self.descData[descItr] == -3 then	-- obtain

			self.Page[2].text = self.Page[2].text..L"\n"..GGManager.translateTID(self.descData[descItr + 1])..L" "..self.stringData[stringItr]
			if self.stringData[stringItr + 1] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr + 1]
			end
			if GGManager.translateTID(self.descData[descItr + 2]) ~= "" then
				self.Page[2].text = self.Page[2].text..L" "..GGManager.translateTID(self.descData[descItr + 2])
			end
			if GGManager.translateTID(self.descData[descItr + 3]) ~= "" then
				self.Page[2].text = self.Page[2].text..L" "..GGManager.translateTID(self.descData[descItr + 3])
			end
			if GGManager.translateTID(self.descData[descItr + 4]) ~= "" then
				self.Page[2].text = self.Page[2].text..L" "..GGManager.translateTID(self.descData[descItr + 4])
			end
			if GGManager.translateTID(self.descData[descItr + 5]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n   "..GGManager.translateTID(self.descData[descItr + 5])
			end
			if self.stringData[stringItr + 2] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr + 2]
			end
			if GGManager.translateTID(self.descData[descItr + 6]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n   "..GGManager.translateTID(self.descData[descItr + 6])
			end
			if self.stringData[stringItr + 3] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr + 3]
			end
			if GGManager.translateTID(self.descData[descItr + 7]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n   "..GGManager.translateTID(self.descData[descItr + 7])
			end
			if self.stringData[stringItr + 4] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr + 4]
			end
			if GGManager.translateTID(self.descData[descItr + 8]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n   "..GGManager.translateTID(self.descData[descItr + 8])
			end
			if self.stringData[stringItr + 5] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr + 5]
			end
			if GGManager.translateTID(self.descData[descItr + 9]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n   "..GGManager.translateTID(self.descData[descItr + 9])
			end
			if self.stringData[stringItr + 6] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr + 6]
			end
			
			stringItr	= stringItr + 7
			descItr	= descItr + 10
			
		elseif self.descData[descItr] == -4 then	-- Escort
			
			if GGManager.translateTID(self.descData[descItr + 1]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n"..GGManager.translateTID(self.descData[descItr + 1])
			end
			if GGManager.translateTID(self.descData[descItr + 2]) ~= "" then
				self.Page[2].text = self.Page[2].text..L" "..GGManager.translateTID(self.descData[descItr + 2])
			end
			if GGManager.translateTID(self.descData[descItr + 3]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n   "..GGManager.translateTID(self.descData[descItr + 3])
			end
			if self.stringData[stringItr] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr]
			end
			if GGManager.translateTID(self.descData[descItr + 4]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n   "..GGManager.translateTID(self.descData[descItr + 4])
			end		
			if self.stringData[stringItr + 1] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr + 1]
			end
			
			stringItr	= stringItr + 3
			descItr	= descItr + 5
			
		elseif self.descData[descItr] == -5 then	-- Deliver - 1T 0S 1S N 2T 3T N 4T 2S N 5T 3S N 6T 4S 
		
			if GGManager.translateTID(self.descData[descItr + 1]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n"..GGManager.translateTID(self.descData[descItr + 1])
			end
			if self.stringData[stringItr] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr]
			end
			if self.stringData[stringItr + 1] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr + 1]
			end
			if GGManager.translateTID(self.descData[descItr + 2]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n   "..GGManager.translateTID(self.descData[descItr + 2])
			end
			if GGManager.translateTID(self.descData[descItr + 3]) ~= "" then
				self.Page[2].text = self.Page[2].text..L" "..GGManager.translateTID(self.descData[descItr + 3])
			end
			if GGManager.translateTID(self.descData[descItr + 4]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n   "..GGManager.translateTID(self.descData[descItr + 4])
			end
			if self.stringData[stringItr + 2] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr + 2]
			end
			if GGManager.translateTID(self.descData[descItr + 5]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n   "..GGManager.translateTID(self.descData[descItr + 5])
			end
			if self.stringData[stringItr + 3] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr + 3]
			end
			if GGManager.translateTID(self.descData[descItr + 6]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n   "..GGManager.translateTID(self.descData[descItr + 6])
			end
			if self.stringData[stringItr + 4] ~= "" then				
				self.Page[2].text = self.Page[2].text..L" "..self.stringData[stringItr + 4]
			end
		
			stringItr	= stringItr + 5	
			descItr		= descItr + 7
	
		elseif self.descData[descItr] == -6 then	-- Skill

			if self.localizedData[localItr] ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n"..self.localizedData[localItr]
			end
			if GGManager.translateTID(self.descData[descItr + 1]) ~= "" then
				self.Page[2].text = self.Page[2].text..L"\n   "..GGManager.translateTID(self.descData[descItr + 1])
			end

			localItr	= localItr + 1
			descItr		= descItr + 2
		
		else
			descItr	= descItr + 1 -- Keep cycling forward until you hit the next negative tag (or the end)
		end
	end 
	
	self.Page[2].leftButtonID	= self.buttonIDs[buttonItr]
	self.Page[2].rightButtonID	= self.buttonIDs[buttonItr + 1]
	
	
	--<Window name="$parentRewardPage" inherits="FourButtonDialog"/>
	local buttonItr	= self.buttonPageIndex[3]
	local stringItr	= self.stringPageIndex[3]
	local descItr	= self.descPageIndex[3]
	
	self.Page[3].title		= GGManager.translateTID(self.descData[descItr])
	self.Page[3].subtitle	= GGManager.translateTID(self.descData[descItr + 1])..L"\n\n"..GGManager.translateTID(self.descData[descItr + 2])
	descItr = descItr + 3	

	self.Page[3].text = L""
	while descItr <= self.descDataCount do
		if GGManager.translateTID( self.descData[descItr] ) ~= "" then
			self.Page[3].text = self.Page[3].text..L"\n"..GGManager.translateTID( self.descData[descItr] )
		end
		descItr = descItr+1	
	end
	
	self.Page[3].leftButtonID	= self.buttonIDs[buttonItr]
	self.Page[3].rightButtonID	= self.buttonIDs[buttonItr + 1]
	
end

function QuestOffer.Initialize()
	local NumOfPages = 3
	
	local NewWindow = Multipage:new(NumOfPages)

	NewWindow.leftButtonTID = QuestOffer.leftButtonTID
	NewWindow.rightButtonTID = QuestOffer.rightButtonTID
	NewWindow.setDataFunction = QuestOffer.setDataFunction
	
	Multipage.Init(NewWindow) -- this registers the window with GGManager
	
	UO_GenericGump.debug( L"QuestOffer.Initialize - locking QuestOffer window so there can only be one of them")
	--GGManager.onCreateCallback[NewWindow.gumpID] = loadstring("Multipage.CloseWindow(\""..NewWindow.windowName.."\")")
	--GGManager.onCreateCallback[NewWindow.gumpID] = function() return GGManager.NEW_GUMP_HAS_BEEN_HANDLED end


end 


function QuestJournalDetails.Initialize()
	local NumOfPages = 3
	
	local NewWindow = Multipage:new(NumOfPages)

	NewWindow.leftButtonTID = QuestJournalDetails.leftButtonTID
	NewWindow.rightButtonTID = QuestJournalDetails.rightButtonTID
	NewWindow.setDataFunction = QuestOffer.setDataFunction
	
	Multipage.Init(NewWindow) -- this registers the window with GGManager
end 


--
function QuestOffer.OnCloseWindow()
	UO_GenericGump.debug( L"QuestOffer.OnCloseWindow.")
	GGManager.destroyActiveWindow()
end

