----------------------------------------------------------
-- GoodEvil.lua
----------------------------------------------------------------

GoodEvil = MasterGUMP:new()

function GoodEvil.Initialize()

	local newWindow					= GoodEvil:new()
	newWindow.setData				= GoodEvil.mySetData
	newWindow:Init()
end

function GoodEvil:mySetData()



	self.Page = {}
	self.Page[1] = {}
	if self.descData[3] == 1045017 then
		self.Page[1].Title = GGManager.translateTID( 1079269 ) -- "Evil Powers"
	else
		self.Page[1].Title = GGManager.translateTID( 1079270 ) -- "Good Powers"
	end
	self.Page[1].Subtitle = GGManager.translateTID( self.descData[1] )..L" "..self.stringData[1]
	self.Page[1].Selections = {}

	self.Page[1].Selections[1] = {}
	self.Page[1].Selections[1].Id = self.buttonIDs[3]
	--self.Page[1].Selections[1].Icon = self.portImgData[1]
	--self.Page[1].Selections[1].Port = self.portImgData[1]
	self.Page[1].Selections[1].Text = GGManager.translateTID( self.descData[3] )..L"\n"..
										GGManager.translateTID( self.descData[4] )..L"\n"..
										GGManager.translateTID( self.descData[5] )..L" "..
										self.stringData[2]
										
	self.Page[1].Selections[2] = {}
	self.Page[1].Selections[2].Id = self.buttonIDs[4]
	--self.Page[1].Selections[2].Icon = self.portImgData[2]
	--self.Page[1].Selections[2].Port = self.portImgData[2]
	self.Page[1].Selections[2].Text = GGManager.translateTID( self.descData[6] )..L"\n"..
										GGManager.translateTID( self.descData[7] )..L"\n"..
										GGManager.translateTID( self.descData[8] )..L" "..
										self.stringData[3]

	self.Page[1].Selections[3] = {}
	self.Page[1].Selections[3].Id = self.buttonIDs[7]
	--self.Page[1].Selections[3].Icon = self.portImgData[3]
	--self.Page[1].Selections[3].Port = self.portImgData[3]
	self.Page[1].Selections[3].Text = GGManager.translateTID( self.descData[10] )..L"\n"..
										GGManager.translateTID( self.descData[11] )..L"\n"..
										GGManager.translateTID( self.descData[12] )..L" "..
										self.stringData[4]

	self.Page[1].Selections[4] = {}
	self.Page[1].Selections[4].Id = self.buttonIDs[8]
	--self.Page[1].Selections[4].Icon = self.portImgData[4]
	--self.Page[1].Selections[4].Port = self.portImgData[4]
	self.Page[1].Selections[4].Text = GGManager.translateTID( self.descData[13] )..L"\n"..
										GGManager.translateTID( self.descData[14] )..L"\n"..
										GGManager.translateTID( self.descData[15] )..L" "..
										self.stringData[5]

	self.Page[1].Selections[5] = {}
	self.Page[1].Selections[5].Id = self.buttonIDs[10]
	--self.Page[1].Selections[5].Icon = self.portImgData[5]
	--self.Page[1].Selections[5].Port = self.portImgData[5]
	self.Page[1].Selections[5].Text = GGManager.translateTID( self.descData[18] )..L"\n"..
										GGManager.translateTID( self.descData[19] )..L"\n"..
										GGManager.translateTID( self.descData[20] )..L" "..
										self.stringData[6]

	self.Page[1].Selections[6] = {}
	self.Page[1].Selections[6].Id = self.buttonIDs[11]
	--self.Page[1].Selections[6].Icon = self.portImgData[6]
	--self.Page[1].Selections[6].Port = self.portImgData[6]
	self.Page[1].Selections[6].Text = GGManager.translateTID( self.descData[21] )..L"\n"..
										GGManager.translateTID( self.descData[22] )..L"\n"..
										GGManager.translateTID( self.descData[23] )..L" "..
										self.stringData[7]
																
	self.Page[1].MiddleButtonText = GGManager.translateTID( self.descData[2] )
	self.Page[1].MiddleButtonId = self.buttonIDs[1]
		
end
