----------------------------------------------------------------
-- PromoNameChange.lua
----------------------------------------------------------------

PromoNameChange = TextEntry:new()

function PromoNameChange.Initialize()

	local newWindow = PromoNameChange:new()
	newWindow:Init()
end

function PromoNameChange:setDataFunction()


	-- the subtitle
	LabelSetText( self.windowName.."Subtitle", GGManager.translateTID( self.descData[1] ) )


	--text
	LabelSetText( self.windowName.."Text", GGManager.translateTID(self.descData[2]) )

	-- the textbox
--	TextEditBoxSetText( self.windowName.."TextBox", "" )
	WindowSetId( self.windowName.."TextBox", self.buttonIDs[3] )
	
	LabelSetText( self.windowName.."Text2", GGManager.translateTID(self.descData[3]) )	

	-- left button
	ButtonSetText( self.windowName.."LeftButton", GGManager.translateTID( GGManager.OKAY_TID ) )
	WindowSetId( self.windowName.."LeftButton", self.buttonIDs[3] )

	-- right button
	ButtonSetText( self.windowName.."RightButton", GGManager.translateTID( GGManager.CANCEL_TID ) )
	WindowSetId( self.windowName.."RightButton", self.buttonIDs[2] )
end

function PromoNameChange:setFields()
end

function PromoNameChange.LRButtonPressed()

	local self		= TextEntryManager.knownWindows[WindowUtils.GetActiveDialog()]
	local buttonID	= WindowGetId( SystemData.ActiveWindow.name )
	
	UO_GenericGump.debug( L"buttonID = "..buttonID )
	
	local textEntries = {}
	textEntries[self.buttonIDs[3]] = TextEditBoxGetText( self.windowName.."TextBox" )
	
	UO_GenericGump.broadcastTextEntries( buttonID, textEntries, self )
	self.OnCloseWindow()
end

function PromoNameChange.OnShutdown()
end

function PromoNameChange.OnCloseWindow()
	
	GGManager.destroyActiveWindow()
end
