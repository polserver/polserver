----------------------------------------------------------
-- LoreQuestLog.lua
----------------------------------------------------------------

LoreQuestLog = MasterGUMP:new()

function LoreQuestLog.Initialize()

	local newWindow					= LoreQuestLog:new()
	newWindow.setData				= LoreQuestLog.mySetData
	newWindow:Init()
end

function LoreQuestLog:mySetData()

		local pageNum = 1
		local theText = L"\n"
		self.Page[pageNum] = {}
		
		self.Page[pageNum].Title = GGManager.translateTID( self.descData[1] )
		
		self.Page[pageNum].Subtitle = GGManager.translateTID( self.descData[2] )
		self.Page[pageNum].SubtitleHL = true

		-- This was breaking.
		-- I would like to see it try to break now!
		if( self ) and ( self.descData ) and ( self.descData[4] ) then
			theText = theText..GGManager.translateTID( self.descData[4] )..L"\n\n"
		end
		if( self ) and ( self.descData ) and ( self.descData[3] ) then
			theText = theText..GGManager.translateTID( self.descData[3] )..L"\n\n"
		end
		if( self ) and ( self.descData ) and ( self.descData[5] ) then
			theText = theText..GGManager.translateTID( self.descData[5] )..L"  "
		end
		if( self ) and ( self.stringData ) and ( self.stringData[1] ) and ( self.stringData[2] ) and ( self.stringData[3] ) then
				theText = theText..self.stringData[2]..self.stringData[1]..self.stringData[3] 
		end
		
		self.Page[pageNum].ScrollText = theText
		self.Page[pageNum].MiddleButtonId = self.buttonIDs[1]
		self.Page[pageNum].MiddleButtonText = GGManager.translateTID( 1011036 )

end
