----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

HelpMenu = ChoiceList:new()


function HelpMenu.ToggleHelpMenu()
	if not HelpMenu.showing then
		BroadcastEvent( SystemData.Events.REQUEST_OPEN_HELP_MENU )
	else
		-- don't just close it. Need to return Close Button ID to server
        --WindowAssignFocus( HelpMenu.windowName.."BottomButton", true )
		HelpMenu:BottomButtonFunction()
	end
	return HelpMenu.showing 
end


function HelpMenu.getShowing()
	return HelpMenu.showing 
end

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

HelpMenu.showing = false

----------------------------------------------------------------
-- HelpMenu Functions
----------------------------------------------------------------

function HelpMenu:setDataFunction()
	Interface.OnCloseCallBack[self.windowName] = HelpMenu.BottomButtonPressed
	local isWide = true -- use ChoiceListSelectableText_Wide XML template
	local relativeWindow
	-- Set the title
	self.title = GGManager.translateTID( self.descData[1] )
	WindowUtils.SetActiveDialogTitle( self.title )
	-- Set the subtitle
	relativeWindow = HelpMenu.CreateSubtitle( self, GGManager.translateTID(1078233), isWide )
	-- For each button that there is...
	for descIndex = 1, self.buttonCount do
		-- if the button ID is a valid one...
		if self.buttonIDs[descIndex] > 0 then
			-- TEMPORARY: Currently disabling the ability to report bugs via the help menu
			if self.buttonIDs[descIndex] ~= 6 then
				-- Create that choice
				relativeWindow = HelpMenu:CreateChoiceListSelectableText( self.buttonIDs[descIndex], GGManager.translateTID( self.descData[descIndex] ), "bottom", relativeWindow, "top", 0, 0, isWide, descIndex )
			end -- if not bug report button
		end -- if button valid
	end -- for each button
	-- create the bottom cancel button
	HelpMenu.CreateBottomButton( self, GGManager.translateTID(1011012), 0 ) -- label, buttonID )
end -- end of setDataFunction()


function HelpMenu.Initialize()
	-- right now we're going to limit this window to only one version, so 
    --   delete any previous window before displaying new one
	if HelpMenu.showing then
		HelpMenu.OnCloseWindow()
	end
	HelpMenu:Init()
	HelpMenu.showing = true
end


-- tie the help menu into the new bug reporting system
function HelpMenu.OnOpenBugReportItem()	
	ToggleWindowByName( "BugReportWindow", "", MainMenuWindow.ToggleBugReportWindow )	
	HelpMenu:BottomButtonFunction()
end


function HelpMenu:TextSelectedFunction()
	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	-- NOTE: this may need to be changed. Currently WindowGetId seems to return 0,
	--  if a value is not set (and 0 is a valid value). May change C++ to return negative value
	--  when no value is set
	if not choiceNum then	
		Debug.PrintToDebugConsole( L"ERROR IN HELP MENU: no ID set for choice selected!" )
		return
	end
	-- Check for KR bug reporting tool being request 	
	if 6 == choiceNum then -- 6 is the bug reporting tool!
		HelpMenu.OnOpenBugReportItem()
	else

	-- *** TODO Move this functionality into the C++ code before releasing the Lua code to the public!
	if 5 == choiceNum then -- visit right now web
		OpenWebBrowser("http://uo.custhelp.com/")
	elseif 9 == choiceNum then -- Account Management
		OpenWebBrowser("http://www.uo.com/account.html")
	elseif 10 == choiceNum then -- Suggestions (goes to boards)
		OpenWebBrowser("http://boards.uo.com")
	elseif 13 == choiceNum then -- visit www.uo.com
		OpenWebBrowser("http://www.uo.com/")
	end
	
		self:DefaultTextSelectedFunction()
--		UO_GenericGump.broadcastButtonPress( choiceNum, self )
--		self.OnCloseWindow()
	end
end 


-- NOTE: this function hardcodes the button ID and data sent because
-- SystemData.ActiveWindow is not always in scope to do it the normal way
function HelpMenu:BottomButtonFunction()
	UO_GenericGump.debug( L"HelpMenu.BottomButtonFunction called" )
	UO_GenericGump.broadcastButtonPress( HelpMenu.buttonIDs[1], HelpMenu ) -- not 0????
	HelpMenu.OnCloseWindow()
end


function HelpMenu.Shutdown()
	UO_GenericGump.debug( L"HelpMenu.Shutdown()." )
	
	if HelpMenu.getShowing() == true then
		UO_GenericGump.broadcastButtonPress( HelpMenu.buttonIDs[1], HelpMenu )
		HelpMenu.showing = false
	end	
end


function HelpMenu.OnCloseWindow()
	UO_GenericGump.debug( L"HelpMenu.OnCloseWindow()." )
	if not HelpMenu.showing then
		UO_GenericGump.debug( L"HelpMenu.OnCloseWindow() called but window does not exist." )
		return
	end
	HelpMenu.showing = false
	GGManager.destroyWindow(HelpMenu.windowName)
end


