
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

MurderReport = TwoButtonDialog:new()


----------------------------------------------------------------
-- MurderReport Functions
----------------------------------------------------------------


-- custom data set function
function MurderReport:parseDescAsOneStringTextAndTwoButtons()
	
	self.subtitle = self.stringData[1]
	self.text = L"\n"..GGManager.translateTID(self.descData[1])
	self.leftButtonName = GGManager.translateTID(self.descData[2])
	self.rightButtonName = GGManager.translateTID(self.descData[3])
	
	self.leftButtonID = self.buttonIDs[1]
	self.rightButtonID = self.buttonIDs[2]
end


-- OnInitialize Handler
function MurderReport.Initialize()
	local NewWindow = MurderReport:new()

	-- setDataFunction is called in TwoButtonDialog:init()
	NewWindow.setDataFunction = MurderReport.parseDescAsOneStringTextAndTwoButtons
	NewWindow:Init()
end
	


