----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

ChoiceNumOfDice = 1
ChoiceNumOfSides = 1

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

LuckyDealer = ChoiceList:new()

----------------------------------------------------------------
-- LuckyDealer Functions
----------------------------------------------------------------

function LuckyDealer:DefaultTextSelectedFunction( )	
	-- Grab the returned value
	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	-- Perform some magic on the number
	choiceNum = choiceNum / 128	
	-- Update global variables as needed
	if choiceNum < 5 then
		ChoiceNumOfDice = choiceNum
	else
		ChoiceNumOfSides = choiceNum - 4
	end
	-- Update the onscreen text TODO: update the icon texture, label color?
	local stringIndex = ChoiceNumOfSides + 4
	LabelSetText( self.windowName.."TextWindowNumber"..12, GGManager.translateTID( self.descData[4] )..L": "..self.stringData[ChoiceNumOfDice] )
	LabelSetText( self.windowName.."TextWindowNumber"..13, L"\n"..GGManager.translateTID( self.descData[5] )..L": "..self.stringData[stringIndex] )
end

function LuckyDealer:ButtonSelectedFunction()
	-- Generate the returned values
	local selectList = { ChoiceNumOfDice, ChoiceNumOfSides-1 }
	-- Broadcast the returned values
	UO_GenericGump.broadcastSelections( 1, selectList, self )
	-- Close window
	self.OnCloseWindow()
end

function LuckyDealer:CreateSelectable( choiceNum, wText, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset,
													uniqueID, style ) -- style: -1 = disable, 0 = normal, 1 = lit, nil = normal
	-- Create unique IDs for the window, use the unique ID if specified
	local mainName = ""
	if uniqueID then
		mainName = self.windowName.."Choice"..uniqueID
	else
		mainName = self.windowName.."Choice"..choiceNum
	end

	-- Create unique IDs for the window's button, window's icon, and window's text
	local buttonName = mainName.."Button"
	local iconName = mainName.."Icon"
	local textName = mainName.."Text"

	-- Define some locals used for resizing things
	local textXsize
	local textYsize
	local buttonXsize
	local mainXsize
	local mainYsize
	
	local containerWindow = self.windowName.."ScrollChild"
	
	-- Get the name of the template to use based on the style
	local mainTemplateName = "NewSelectablePlain"
	if style == -1 then
		mainTemplateName = "NewSelectableDull"
	end
	if style == 1 then
		mainTemplateName = "NewSelectableLit"
	end

	-- Create the main window
	CreateWindowFromTemplate( mainName, mainTemplateName, containerWindow )
	-- Attach the main window to where it was told to be attached
	WindowAddAnchor( mainName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	-- Set the window to have it's ID
	WindowSetId( mainName, choiceNum )
	
	-- Set the text and then get it's dimensions
	LabelSetText( textName, wText ) -- Hardcode a long wide string here if you want to see this thing in action
	textXsize, textYsize = LabelGetTextDimensions( textName )
	
	-- Also save the size of the button and window
	buttonXsize = WindowGetDimensions( buttonName )
	mainXsize, mainYsize = WindowGetDimensions( mainName )
	
	-- use the maximum Y dimension, use the defualt value from the XML if the text doesn't line wrap.
	if mainYsize < textYsize then
		mainYsize = textYsize+19 -- fudge it 9.5 pixels above and below
	end
	
	-- Set the size of the window and the size of the background to the same thing
	-- One shows where to click, the other handles the click!
	WindowSetDimensions( mainName, mainXsize, mainYsize )
	WindowSetDimensions( buttonName, buttonXsize, mainYsize )

	return mainName

end


function LuckyDealer:setDataFunction()
	-- Don't use a wide ChoiceList
	local isWide = false -- true 
	
	-- Thing to attach the next thing to
	local relativeWindow
	
	-- Looping variable
	local descIndex

	-- Set the title
	WindowUtils.SetActiveDialogTitle( GGManager.translateTID( self.descData[1] ) )

	-- The cancel button
	self:CreateBottomButton( GGManager.translateTID( self.descData[3] ), self.buttonIDs[1] )

	-- Set subtitle
	--relativeWindow = self:CreateSubtitle( L"SUBTITLE NOT SET" )  -- GGManager.translateTID( self.descData[2] ), isWide )

	-- Set the relative window
	relativeWindow = self.windowName.."ScrollChild"

	relativeWindow = self:CreateText( 12, GGManager.translateTID( self.descData[4] )..L": "..self.stringData[ChoiceNumOfDice],
		"topleft", relativeWindow, "topleft", 0, 0, isWide )

-- TODO: uncomment the code below and work out a way to get the currently selected choice to be "selected"	
	local i
	for i=1,4 do
--		if ChoiceNumOfDice == i then
--			relativeWindow = self:CreateSelectable(
--				i*128, self.stringData[i], "bottomleft", relativeWindow, "topleft", 0, 0, i, 1 )
--		else
			relativeWindow = self:CreateSelectable(
				i*128, self.stringData[i], "bottomleft", relativeWindow, "topleft", 0, 0, i, 0 )
--		end	
	end	
	
	local stringIndex = ChoiceNumOfSides + 4
	
		relativeWindow = self:CreateText( 13, L"\n"..GGManager.translateTID( self.descData[5] )..L": "..self.stringData[stringIndex],
		"bottomleft", relativeWindow, "topleft", 0, 0, isWide )
	
	for i=5,11 do
--		if ChoiceNumOfSides == i-4 then
--			relativeWindow = self:CreateSelectable(
--				i*128, self.stringData[i], "bottomleft", relativeWindow, "topleft", 0, 0, i, 1 )
--		else
			relativeWindow = self:CreateSelectable(
				i*128, self.stringData[i], "bottomleft", relativeWindow, "topleft", 0, 0, i, 0 )
--		end	
	end	
end

-- OnInitialize Handler
function LuckyDealer.Initialize()
	local newWindow = LuckyDealer:new()
	newWindow.setDataFunction = LuckyDealer.setDataFunction
	newWindow.BottomButtonFunction = LuckyDealer.ButtonSelectedFunction
	newWindow:Init()
end