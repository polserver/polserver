----------------------------------------------------------------
-- NameEntry.lua
----------------------------------------------------------------

NameEntry = TextEntry:new()

function NameEntry.Initialize()

	local newWindow = NameEntry:new()
	newWindow:Init()
end

function NameEntry:setDataFunction()


	-- the subtitle
	LabelSetText( self.windowName.."Subtitle", GGManager.translateTID( self.descData[2] ) )

	-- the textbox
--	TextEditBoxSetText( self.windowName.."TextBox", "" )
	WindowSetId( self.windowName.."TextBox", self.buttonIDs[3] )	

	-- left button
	ButtonSetText( self.windowName.."LeftButton", GGManager.translateTID( GGManager.OKAY_TID ) )
	WindowSetId( self.windowName.."LeftButton", self.buttonIDs[1] )

	-- right button
	ButtonSetText( self.windowName.."RightButton", GGManager.translateTID( GGManager.CANCEL_TID ) )
	WindowSetId( self.windowName.."RightButton", self.buttonIDs[2] )
end

function NameEntry:setFields()
end

function NameEntry.LRButtonPressed()

	local self		= TextEntryManager.knownWindows[WindowUtils.GetActiveDialog()]
	local buttonID	= WindowGetId( SystemData.ActiveWindow.name )
	
	UO_GenericGump.debug( L"buttonID = "..buttonID )
	
	local textEntries = {}
	textEntries[self.buttonIDs[3]] = TextEditBoxGetText( self.windowName.."TextBox" )
	
	UO_GenericGump.broadcastTextEntries( buttonID, textEntries, self )
	self.OnCloseWindow()
end

function NameEntry.OnShutdown()
end

function NameEntry.OnCloseWindow()
	
	GGManager.destroyActiveWindow()
end
