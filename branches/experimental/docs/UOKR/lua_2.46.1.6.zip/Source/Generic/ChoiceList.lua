
-- 
-- This is a prototype for any window that uses a list of choosable text and/or choosable icons
-- a scrollbar appears when there are too many choicesto fit in the window. 
--
-- This XML can also be used for any anonymous choice list windows as long as you call 
-- ChoiceList:Init(). Init() registers your window to be called for button press events
-- you will have to create a <WindowName>.ButtonSelectedFunction() since 
-- ChoiceList.ButtonSelectedFunction() does not have any default functionality
--

----------------------------------------------------------------
-- Global Variables/Functions
----------------------------------------------------------------



--

ChoiceList = {}

ChoiceList.DEFAULT_BOTTOM_BUTTON_ID = 0


-- lookup table for ChoiceList windows
ChoiceListManager = GGManager



-- Will cause all functions of ChoiceList to be inherited
--
-- can take in a table if you want to predefine data
-- otherwise 
--
function ChoiceList:new( newWindow )

	newWindow = newWindow or {}
	setmetatable(newWindow, self)
	self.__index = self
	
	return newWindow
end



-- Init does the following:
--   1. retrieves data from the server
--   2. calls the object specific setDataFunction() to dynamically create the 
--		windows UI elements dynamically
--
-- NOTE that ChoiceList does not have a separation between the 
--   SetDataFunction and SetFields. There are no standard fields in the default
--   ChoiceList class - it's entire contents is defined dynamically.
--   However, the Init function does look for a setFields method in sub-classes/objects
--   and will call their "self:setFields()" if it is found.
--
function ChoiceList:Init()
	
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end

	if self.setFields then
		self:setFields()
	end
	
	ChoiceListManager.knownWindows[self.windowName] = self
	WindowSetId( self.windowName.."Chrome_UO_WindowCloseButton", UO_GenericGump.DEFAULT_CLOSE_BUTTON_ID )
	Interface.OnCloseCallBack[self.windowName] = self.BottomButtonPressed
	
	Debug.PrintToDebugConsole( L"Initialize "..self.name )
end


----------------------------------------------------------------
-- ChoiceList UI Creation Functions
--
-- Methods:
--   CreateSubtitle
--   CreateText
--   CreateBlankSpace
--   CreateChoiceListSelectableText
--   CreateChoiceListSelectableIconText
--   CreateBottomButton
--   
----------------------------------------------------------------


-- XML was changed to properly put subtitle above scroll window
-- instead of inside it. This function now calls LabelSetText and
-- resizes the scroll window as needed.
--
-- Expects the following values to be set in the calling object:
--		self.windowName (type string)
--		self.name (type WString)
-- Inputs:
-- 		wText should be of type WString
-- 
-- Returns: name of the subtitle label (window) created
--
function ChoiceList:CreateSubtitle( wText, isWide )
	UO_GenericGump.debug( L"ChoiceList:CreateSubtitle using wText = "..StringToWString( tostring( wText ) ) )
	
	local subtitleName = self.windowName.."Subtitle"
	local scrollWindow = self.windowName.."Scroll"
	local lineName = subtitleName.."HR"
	local BarTemp = ""
	
	if isWide then
		BarTemp = "ChoiceListHorizLine_Wide"
	else
		BarTemp = "ChoiceListHorizLine"
	end

	--[[ strips out all whitespace and inserts single spaces
	wText = wstring.gsub( wText, L"\n", L" " )
	wText = wstring.gsub( wText, L" +", L" " )
	--]]
	LabelSetText( subtitleName, wText )

	--UO_GenericGump.debug( L"ChoiceList:CreateSubtitle setting horizontal line" )
	CreateWindowFromTemplate( lineName, BarTemp, self.windowName )   
	WindowAddAnchor( lineName, "bottomleft", subtitleName, "topleft", 0, 0 )
	
	-- adjusts size of scroll window
	local subtitleWidth, subtitleHeight = WindowGetDimensions( subtitleName )
	local lineWidth, lineHeight = WindowGetDimensions( lineName )
	local scrollWidth, scrollHeight = WindowGetDimensions( scrollWindow )	
	WindowSetDimensions( scrollWindow, scrollWidth, scrollHeight - subtitleHeight - lineHeight )

	-- KLUDGE: Some existing one-offs expect the subtitle to be inside the scroll window.
	-- This code creates a window of size 0 inside the scroll window to provide an anchor.
	local scrollChild = scrollWindow.."Child"
	local scrollInnerAnchor = scrollChild.."InnerAnchor"
	
	if isWide then
		CreateWindowFromTemplate( scrollInnerAnchor, "ChoiceListBaseText_Wide", scrollChild )
	else
		CreateWindowFromTemplate( scrollInnerAnchor, "ChoiceListBaseText", scrollChild )
	end
	LabelSetText( scrollInnerAnchor, L""  )
	WindowAddAnchor( scrollInnerAnchor, "topleft", scrollChild, "topleft", 0, 0)

	return scrollInnerAnchor
end

-- Expects the following values to be set in the calling object:
-- 		self.windowName (both of type string)
-- Inputs:
-- 		choiceNum should be of type number
-- 		wText should be of type WString
-- 
-- Returns: name of the choice text (window) created
--
function ChoiceList:CreateText( textNum, wText, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset, isWide )

	local choiceName = self.windowName.."TextWindowNumber"..textNum
	local scrollParent = self.windowName.."ScrollChild"	
	
	local textTemplateName = "ChoiceListWhiteText" -- KLUDGE: Somehow the base text for ChoiceLists is yellow - this makes it white
	if isWide then
		textTemplateName = "ChoiceListWhiteText_Wide"
	end
	
	CreateWindowFromTemplate( choiceName, textTemplateName, scrollParent )       
	LabelSetText( choiceName, wText )
	WindowAddAnchor( choiceName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	
	return choiceName
end



-- Expects the following values to be set in the calling object:
-- 		self.windowName (type string)
-- Inputs:
--  	pixels	 (type number)
-- 		uniqueID (type number or string)
-- 
-- Returns: name of the Label (window) created
--
function ChoiceList:CreateBlankSpace( pixels, relativeToow, uniqueID )

	local choiceName = self.windowName.."BlankSpace-"..uniqueID
	local scrollParent = self.windowName.."ScrollChild"
	
	CreateWindowFromTemplate(choiceName, "ChoiceListBaseText", scrollParent)
	LabelSetText( choiceName, L" "  )
	WindowAddAnchor( choiceName, "bottomleft", relativeToow, "topleft", 0, pixels)

	return choiceName
end



-- Expects the following values to be set in the calling object:
-- 		self.windowName (both of type string)
-- Inputs:
-- 		choiceNum should be of type number
-- 		wText should be of type WString
-- 
--		isWide == true uses the ChoiceList_Wide template
--		uniqueID, if present, is concatenated to window names
--		containerWindow specifies the window that the selectable text is created in. Defaults to the scroll window if not present.
--
-- Returns: name of the choice text (window) created
--
function ChoiceList:CreateChoiceListSelectableText( choiceNum, wText, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset,
													isWide, uniqueID, containerWindow )

	-- Create unique IDs for the window, use the unique ID if specified
	local mainName = ""
	if uniqueID then
		mainName = self.windowName.."Choice"..uniqueID
	else
		mainName = self.windowName.."Choice"..choiceNum
	end

	-- Create unique IDs for the window's button, window's icon, and window's text
	local buttonName = mainName.."Button"
	local iconName = mainName.."Icon"
	local textName = mainName.."Text"

	-- Define some locals used for resizing things
	local textXsize
	local textYsize
	local buttonXsize
	local mainXsize
	local mainYsize
	
	-- if no value is set for containerWindow (controls where the selectable text appears),
	-- defaults to the scroll window
	if not containerWindow then
		containerWindow = self.windowName.."ScrollChild"
	end
	
	-- Get the name of the template to use based on isWide
	local mainTemplateName = ""
	if isWide then
		mainTemplateName = "ChoiceListSelectable_Wide"
	else
		mainTemplateName = "ChoiceListSelectable"
	end

	-- Create the main window
	CreateWindowFromTemplate( mainName, mainTemplateName, containerWindow )
	-- Attach the main window to where it was told to be attached
	WindowAddAnchor( mainName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	-- Set the window to have it's ID
	WindowSetId( mainName, choiceNum )
	
	-- Set the text and then get it's dimensions
	LabelSetText( textName, wText ) -- Hardcode a long wide string here if you want to see this thing in action
	textXsize, textYsize = LabelGetTextDimensions( textName )
	
	-- Also save the size of the button and window
	buttonXsize = WindowGetDimensions( buttonName )
	mainXsize, mainYsize = WindowGetDimensions( mainName )
	
	-- use the maximum Y dimension, use the defualt value from the XML if the text doesn't line wrap.
	if mainYsize < textYsize+19 then
		mainYsize = textYsize+19 -- fudge it 9.5 pixels above and below
	end
	
	-- Set the size of the window and the size of the background to the same thing
	-- One shows where to click, the other handles the click!
	WindowSetDimensions( mainName, mainXsize, mainYsize )
	WindowSetDimensions( buttonName, buttonXsize, mainYsize )

	return mainName
end



function ChoiceList:CreateChoiceListSelectableIconText()

--[[
	CreateWindowFromTemplate("PolymorphSelectableText3", "PolymorphSelectableIconAndText", "PolymorphScrollChild")
    DynamicImageSetTexture( "PolymorphSelectableText3".."SquareIcon", texture, x, y )     
	LabelSetText("PolymorphSelectableText3Desc", L"3. "..TEST_MESSAGE)
	WindowAddAnchor( "PolymorphSelectableText3", "topleft", "PolymorphSelectableText2", "topleft", 0, 200)
	WindowSetId( choiceName, choiceNum )	
--]]

end




-- Expects the following values to be set in the calling object:
-- 		self.windowName (type string)
-- Inputs:
-- 		buttonID (type number)
-- 		Label (type WString)
-- 
-- Returns: name of the button (window) created
--
function ChoiceList:CreateBottomButton( label, buttonID )

	local choiceName = self.windowName.."BottomButton"
	CreateWindowFromTemplate( choiceName, "ChoiceListBottomButton", self.windowName )
	ButtonSetText( choiceName, label )
	WindowSetId( choiceName, buttonID )

	return choiceName
end




----------------------------------------------------------------
-- Basic methods that can be used as your SetDataFunction
----------------------------------------------------------------


function ChoiceList:createButtonAndChoices()

	if self.descData and self.descDataCount > 1 then
	
		local relativeWindow = self.windowName.."ScrollChild"
		
		ChoiceList.CreateBottomButton( self, GGManager.translateTID( self.descData[1] ), ChoiceList.DEFAULT_BOTTOM_BUTTON_ID )
	
		-- choiceNum, wText, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset, isWide 
	
		-- first choice anchors to top of ScrollChild. others below will anchor to this one.
--		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
--					1, GGManager.translateTID( self.descData[2] ),
--					"topleft", relativeWindow, "topleft", 0, 4000 )
		relativeWindow = ChoiceList:CreateChoiceListSelectableText(	1, GGManager.translateTID( self.descData[2] ),
						"topleft", relativeWindow, "topleft", 0, 0, 0 )
					
		-- note: don't iterate through the table itself
		for choiceNum=2, self.descDataCount - 1  do
			relativeWindow = ChoiceList:CreateChoiceListSelectableText( choiceNum, GGManager.translateTID( self.descData[choiceNum+1] ),
							"bottom", relativeWindow, "top", 0, 0, 0 ) 
		end
	else
		Debug.PrintToDebugConsole( L"ChoiceList.parseButtonAndChoices ERROR: insufficient descData. descDataCount = "..self.descDataCount )
	end  -- if descData

end


function ChoiceList:createButtonSubtitleAndChoices()

	if self.descData and self.descDataCount > 2 then
		
		ChoiceList.CreateBottomButton( self, GGManager.translateTID( self.descData[1] ), self.buttonIDs[1] )

		-- ***KLUDGE*** - have to insert extra spaces to cause a word wrap in order for it to properly
		--                calculate the size of the Label for anchoring purposes
		local relativeWindow = ChoiceList.CreateSubtitle( self, GGManager.translateTID( self.descData[2] ) )--..UO_GenericGump.EMPTY_LINE  )
		
		choiceNum = 3
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
					self.buttonIDs[choiceNum-1], GGManager.translateTID( self.descData[choiceNum] ),
					"topleft", relativeWindow, "topleft", 0, 0 )
		
		-- note: don't iterate through the table itself
		for choiceNum=4, self.descDataCount do
			relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
					self.buttonIDs[choiceNum-1], GGManager.translateTID( self.descData[choiceNum] ),
					"bottom", relativeWindow, "top", 0, 0 ) -- 40
		end
	else
		Debug.PrintToDebugConsole( L"ChoiceList.parseButtonAndChoices ERROR: insufficient descData. descDataCount = "..self.descDataCount )
	end  -- if descData

end

function ChoiceList:createButtonTitleSubtitleAndChoices()

	if self.descData and self.descDataCount > 3 then
				
		ChoiceList.CreateBottomButton( self, GGManager.translateTID( self.descData[1] ), self.buttonIDs[1] )

		WindowUtils.SetActiveDialogTitle( GGManager.translateTID( self.descData[2] ) )

		-- ***KLUDGE*** - have to insert extra spaces to cause a word wrap in order for it to properly
		--                calculate the size of the Label for anchoring purposes
		local relativeWindow = ChoiceList.CreateSubtitle( self, GGManager.translateTID( self.descData[3] ) ) -- ..UO_GenericGump.EMPTY_LINE  )
					
		choiceNum = 4			
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
					self.buttonIDs[choiceNum-2], GGManager.translateTID( self.descData[choiceNum] ),
					"topleft", relativeWindow, "topleft", 0, 0 )
		-- note: don't iterate through the table itself
		for choiceNum=5, self.descDataCount do
			relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
					self.buttonIDs[choiceNum-2], GGManager.translateTID( self.descData[choiceNum] ),
					"bottom", relativeWindow, "top", 0, 0 )-- 40
		end
	else
		Debug.PrintToDebugConsole( L"ChoiceList.createButtonTitleSubtitleAndChoices ERROR: insufficient descData. descDataCount = "
									..self.descDataCount )
	end  -- if descData

end


----------------------------------------------------------------
-- ChoiceList Functions
----------------------------------------------------------------


function ChoiceList.getActiveWindowData()
	--UO_GenericGump.debug( StringToWString( "ChoiceList.getActiveWindowData. top parent should be = "..WindowUtils.GetActiveDialog() ) )

	local windowName = WindowUtils.GetActiveDialog()

	return ChoiceListManager.knownWindows[windowName]
end



-- OnInitialize Handler
function ChoiceList.Initialize()

	local newWindow = ChoiceList:new()
	newWindow.setDataFunction = ChoiceList.createButtonSubtitleAndChoices
	newWindow:Init()
end



function ChoiceList.TextSelected()	

	--local windowName = WindowGetParent( WindowGetParent(SystemData.ActiveWindow.name) )
	local self = ChoiceList.getActiveWindowData()

	--UO_GenericGump.debug( L"called ChoiceList.TextSelected() on "..self.name )
	
	if self.TextSelectedFunction then
		self:TextSelectedFunction()
	else
		self:DefaultTextSelectedFunction()
	end
end



-- this is used if the object does not declare a custom TextSelectedFunction
--
function ChoiceList:DefaultTextSelectedFunction()
	--UO_GenericGump.debug( L"ChoiceList:DefaultTextSelectedFunction called")
	
	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	
	-- NOTE: this may need to be changed. Currently WindowGetId seems to return 0,
	--  if a value is not set (and 0 is a valid value). May change C++ to return negative value
	--  when no value is set
	if not choiceNum then	
		Debug.PrintToDebugConsole( L"ERROR in ChoiceList:DefaultTextSelectedFunction: no ID set for choice selected." )
		return
	end

	--UO_GenericGump.debug( L"called ChoiceList:DefaultTextSelectedFunction() choiceNum = "..choiceNum )
	
	UO_GenericGump.broadcastButtonPress( choiceNum, self )
	self.OnCloseWindow()
end


function ChoiceList.ButtonSelected()

	--local windowName = WindowGetParent( WindowGetParent(SystemData.ActiveWindow.name) )
	local self = ChoiceList.getActiveWindowData()

	UO_GenericGump.debug( L"called ChoiceList.ButtonSelected() on "..self.name )
	
	if self.ButtonSelectedFunction then
		self:ButtonSelectedFunction()
	else
		self:DefaultButtonSelectedFunction()
	end
end


-- this is used if the object does not declare a custom TextSelectedFunction
--
function ChoiceList:DefaultButtonSelectedFunction()
	--UO_GenericGump.debug( L"ChoiceList:ButtonSelectedFunction called")
	
	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	
	-- NOTE: this may need to be changed. Currently WindowGetId seems to return 0,
	--  if a value is not set (and 0 is a valid value). May change C++ to return negative value
	--  when no value is set
	if not choiceNum then	
		Debug.PrintToDebugConsole( L"ERROR in ChoiceList:ButtonSelectedFunction: no ID set for choice selected." )
		return
	end

	UO_GenericGump.debug( L"called ChoiceList:ButtonSelectedFunction() choiceNum = "..choiceNum )
	
	UO_GenericGump.broadcastButtonPress( choiceNum, self )
	self.OnCloseWindow()
end


function ChoiceList.BottomButtonPressed()

	--local windowName = WindowGetParent( WindowGetParent(SystemData.ActiveWindow.name) )
	local self = ChoiceList.getActiveWindowData()
	
	self:BottomButtonFunction()
end


-- this is used if the object does not declare a custom TextSelectedFunction
--
function ChoiceList:BottomButtonFunction()
	
	local buttonID = WindowGetId( SystemData.ActiveWindow.name )
	
	-- NOTE: this may need to be changed. Currently WindowGetId seems to return 0,
	--  if a value is not set (and 0 is a valid value). May change C++ to return negative value
	--  when no value is set
	if not buttonID then	
		Debug.PrintToDebugConsole( L"No buttonID found for button = "..SystemData.ActiveWindow.name
									..L", so sending default ID = "..DEFAULT_BOTTOM_BUTTON_ID )
		buttonID = DEFAULT_BOTTOM_BUTTON_ID
	end

	UO_GenericGump.debug( L"called ChoiceList:BottomButtonFunction() buttonID = "..buttonID )
	
	UO_GenericGump.broadcastButtonPress( buttonID, self )
	self.OnCloseWindow()
end

function ChoiceList.OnMouseOver()
	local self = ChoiceList.getActiveWindowData()
	local name = SystemData.ActiveWindow.name
	
	if  self				~= nil
	and self.Tooltips		~= nil
	and self.Tooltips[name]	~= nil
	then
		Tooltips.CreateTextOnlyTooltip( name, GGManager.translateTID( self.Tooltips[name] ) )
		Tooltips.Finalize()
		Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_TOP )
	end 
end


--
function ChoiceList.OnCloseWindow()
	UO_GenericGump.debug( L"called ChoiceList.OnCloseWindow(), active window = "..StringToWString(SystemData.ActiveWindow.name) )

	GGManager.destroyActiveWindow()
end


