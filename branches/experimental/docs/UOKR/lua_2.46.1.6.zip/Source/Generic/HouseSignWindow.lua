----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

HouseSignWindow = { }



----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

local data = {}

local tileartInUse = {}

local HouseSignWindow_GumpData = {}
local WindowName = ""
local CustomizationNoticeWindowName = nil

local HSW_AccessSubType = 1

local HSW_MasterList = {}
local HSW_GeneralList = {}
local HSW_FriendsList = {}
local HSW_CoOwnersList = {}
local HSW_BannedList = {}

--local HSW_HouseSignList = {}
--local HSW_SignHangarList = {}
--local HSW_SignPostList = {}
--local HSW_FoundationStyleList = {}

local accessName = L"GeneralJoe"
local friendName = L"FriendBob"
local coOwnerName = L"CoOwnerJeff"
local banName = L"BannedGuy"

local HSW_CurrentListBoxItemIndex = 0 -- which item in the list box is selected



----------------------------------------------------------------
-- MainMenuWindow Functions
----------------------------------------------------------------


function HouseSignWindow.windowExists()
	return( WindowName ~= nil and WindowName ~= "" )
end


-- OnInitialize Handler
function HouseSignWindow.Initialize()
	Debug.PrintToDebugConsole(L"HouseSignWindow.Initialize")
	
	GGManager.registerOnCreateCallback( "HouseSignWindow", HouseSignWindow.windowExists )

	HSW_MasterList = {}
	HSW_GeneralList = {}
	HSW_FriendsList = {}
	HSW_CoOwnersList = {}
	HSW_BannedList = {}


	UO_GenericGump.retrieveWindowData (HouseSignWindow_GumpData)
	stringData = UO_GenericGump.retreiveWindowDataStrings( HouseSignWindow_GumpData )

	Interface.OnCloseCallBack[HouseSignWindow_GumpData.windowName] = HouseSignWindow.OnCloseWindow

	WindowName = HouseSignWindow_GumpData.windowName
	Debug.PrintToDebugConsole(L"HouseSignWindow.Initialize: WindowName =  "..StringToWString(WindowName))

	RegisterWindowData(WindowData.HouseInfoChange.Type, 0)
	
	WindowRegisterEventHandler(WindowName, WindowData.HouseInfoChange.Event, "HouseSignWindow.HandleHouseInfoChange")
	--WindowRegisterEventHandler(WindowName, WindowData.MobileName.Event, "HouseSignWindow.UpdatePlayerName")
	
	WindowUtils.SetWindowTitle(WindowName,L"House Management")
	
	ButtonSetText( WindowName.."TabButton1", GetStringFromTid(3000098)) -- Information
	ButtonSetText( WindowName.."TabButton2", GetStringFromTid(1078864)) -- Access
	ButtonSetText( WindowName.."TabButton3", GetStringFromTid(1060236)) -- Storage
	ButtonSetText( WindowName.."TabButton4", GetStringFromTid(1019069)) -- Customize
	ButtonSetText( WindowName.."TabButton5", GetStringFromTid(1078865)) -- Ownership

	LabelSetText (WindowName.."AddAccessButtonText",GetStringFromTid(1078872)) -- Add Access
	LabelSetText (WindowName.."BanButtonText",GetStringFromTid(1078873)) -- Ban Player

	-- Set the active tab to "Information"
	data.activeTab = 1
	data.numTabs = 5
	--Debug.PrintToDebugConsole(L"HouseSignWindow.Initialize: data.numTabs =  "..StringToWString(tostring(data.numTabs)))

	UOBuildTableFromCSV ("data/gamedata/housesign.csv","HouseSignListCSV")
	UOBuildTableFromCSV ("data/gamedata/housesignhangar.csv","HouseSignHangarListCSV")
	UOBuildTableFromCSV ("data/gamedata/housesignpost.csv","HouseSignPostListCSV")
	UOBuildTableFromCSV ("data/gamedata/foundationstyle.csv","FoundationStyleListCSV")

	-- load data from stringData into local variables
	-- CSV files need to be read before doing this

	Debug.PrintToDebugConsole(L"HouseSignWindow.Initialize: house id raw =  "..stringData[1])

--	WindowData.HouseInfoChange = {}
	
	-- init these 2 fields - they will be set by the houseinfo_change data
	WindowData.HouseInfoChange.HouseId	= tonumber(tostring(stringData[1]))
	WindowData.HouseInfoChange.UserId = tonumber(tostring(stringData[2]))
	data.HouseName = stringData[3]

	if (data.HouseName == "") or (data.HouseName == nil) then
		LabelSetText( WindowName.."HouseNameText", L"" )	
	else
		LabelSetText( WindowName.."HouseNameText", data.HouseName )
	end
	Debug.PrintToDebugConsole(L"HouseSignWindow.Initialize: house id =  "..StringToWString(tostring(WindowData.HouseInfoChange.HouseId)))
	Debug.PrintToDebugConsole(L"HouseSignWindow.Initialize: house id =  "..WindowData.HouseInfoChange.HouseId)

	Debug.PrintToDebugConsole(L"HouseSignWindow.Initialize: user id =  "..StringToWString(tostring(WindowData.HouseInfoChange.UserId)))
	Debug.PrintToDebugConsole(L"HouseSignWindow.Initialize: house name =  "..StringToWString(tostring(WindowData.HouseInfoChange.HouseName)))
 
	HouseSignWindow.LoadInformationTabData()
	HouseSignWindow.LoadStorageTabData()
	HouseSignWindow.LoadSecurityTabData()
	HouseSignWindow.LoadCustomizeTabData()
	HouseSignWindow.LoadOwnershipTabData()
	
	HouseSignWindow.CreateMasterList()
	HouseSignWindow.CreateGeneralList()
	HouseSignWindow.CreateFriendsList()
	HouseSignWindow.CreateCoOwnersList()
	HouseSignWindow.CreateBannedList()



	HouseSignWindow.CreateHouseSignList()
	HouseSignWindow.CreateHouseSignHangarList()
	HouseSignWindow.CreateSignPostList()
	HouseSignWindow.CreateFoundationStyleList()

	showing = WindowGetShowing(WindowName)
	if (showing) then
		--Debug.PrintToDebugConsole(L"HouseSignWindow.Initialize: calling ShowTab() ")
		HouseSignWindow.ShowTab(data.activeTab)
	end	
	
	
end

function HouseSignWindow.HandleHouseInfoChange()
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange")

	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange: user id = "..StringToWString(tostring(WindowData.HouseInfoChange.UserId)))
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange: house id = "..StringToWString(tostring(WindowData.HouseInfoChange.HouseId)))
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange: command = "..StringToWString(tostring(WindowData.HouseInfoChange.Command)))
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange: value = "..StringToWString(tostring(WindowData.HouseInfoChange.Value)))
	
	local UserId = WindowData.HouseInfoChange.UserId
	local HouseId = WindowData.HouseInfoChange.HouseId
	local command = WindowData.HouseInfoChange.Command
	local value = WindowData.HouseInfoChange.Value

	-- house sign obj id changing
	if (command == 99) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange: house sign obj id changed to = "..StringToWString(tostring(WindowData.HouseInfoChange.HouseId)))
	end -- command == 99
	
	-- public/private status change
	if (command == 101) then
		if (value == 341) or (value == 342) then
			if (value == 341) then -- private
				data.PublicStatus = 0
			else
				data.PublicStatus = 1
			end
			
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange: data.PublicStatus = "..StringToWString(tostring(data.PublicStatus)))
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange: data.IsOwner = "..StringToWString(tostring(data.IsOwner)))
			
			-- update data.ChangeHouseSign
			if (data.PublicStatus == 1) and (data.IsOwner == 1) then
				data.ChangeHouseSign = 1
			else
				data.ChangeHouseSign = 0
			end	

			-- show/hide the ban button appropriately (only shown when house is public)
			HouseSignWindow.ShowBanButton()


		end
		
		-- if the information tab is showing then update the stuff on that tab
		if (data.activeTab == 1) then
			local tabWindowName = WindowName.."TabWindow"..tostring(data.activeTab)

		
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - updating information tab")
		
			if (data.PublicStatus == 0) then -- private
				LabelSetText (tabWindowName.."ChangePrivateStatusText",GetStringFromTid(1060694)) -- change to public
			elseif (data.PublicStatus == 1) then -- public
				LabelSetText (tabWindowName.."ChangePrivateStatusText",GetStringFromTid(1060695)) -- change to private
			end
					
			WindowSetShowing(tabWindowName.."ChangePrivateStatusButton", true)


			local PublicStatusTid = 0
			if (data.PublicStatus == 0) then
				PublicStatusTid = 1060679 -- private	
			elseif (data.PublicStatus == 1) then
				PublicStatusTid = 1060678 -- public
			end
			LabelSetText (tabWindowName.."PrivateStatusText",WindowUtils.translateMarkup(GetStringFromTid(PublicStatusTid)))
		
		
		end -- data.activeTab == 1
	
	end -- if command == 101
	
	-- convert to customizable
	if (command == 102) then
		if (value == 1) then
			-- once converted can't go back
			data.ConvertToCustomizable = 0

			local tabWindowName = WindowName.."TabWindow4"
			WindowSetShowing (tabWindowName.."ConvertHouseEntryIcon", false)
			--WindowSetShowing (tabWindowName.."ConvertHouseEntryText", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."ConvertHouseEntryButton", true )
			
			-- update being able to change house sign, hangar, sign post and foundation style
			data.ChangeHouseSign =1 
			WindowSetShowing (tabWindowName.."ChangeHouseSignEntryIcon", true)
			WindowSetShowing (tabWindowName.."ChangeHouseSignEntryButton", true)
			ButtonSetDisabledFlag( tabWindowName.."ChangeHouseSignEntryButton", false )

			data.ChangeHouseSignHanger = 1
			WindowSetShowing (tabWindowName.."ChangeHouseSignHangerEntryIcon", true)
			WindowSetShowing (tabWindowName.."ChangeHouseSignHangerEntryButton", true)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."ChangeHouseSignHangerEntryButton", false )
		
			data.ChangeSignPost = 1
			WindowSetShowing (tabWindowName.."ChangeSignpostEntryIcon", true)
			WindowSetShowing (tabWindowName.."ChangeSignpostEntryButton", true)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."ChangeSignpostEntryButton", false )
		
			data.ChangeFoundationStyle = 1
			WindowSetShowing (tabWindowName.."ChangeFoundationStyleEntryIcon", true)
			WindowSetShowing (tabWindowName.."ChangeFoundationStyleEntryButton", true)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."ChangeFoundationStyleEntryButton", false )
			

			-- update the data on the information tab
			tabWindowName = WindowName.."TabWindow1"
			data.CustomStatus = 1
			CustomStatusTid = 1060681 -- custom
			LabelSetText (tabWindowName.."CustomStatusText",GetStringFromTid(CustomStatusTid))

			ModernStatusTid = 1018035 -- modern
			LabelSetText (tabWindowName.."DesignTypeText",GetStringFromTid(ModernStatusTid))

			-- close gump - the house id has changed 
			HouseSignWindow.OnCloseWindow()
				
		end
	end

	if (command == 104) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - relocating moving crate")
		HouseSignWindow.OnCloseWindow()
	end -- if command == 104
	
	-- house sign style change
	if (command == 105) then
	
		
		-- figure out the current house sign index
		for i = 1, table.getn(WindowData.HouseSignListCSV) do
			if (WindowData.HouseSignListCSV[i].IconId == value) then
				data.CurrentHouseSignIndex = i
				Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - updating house sign")
			end
		end

		
		if (data.activeTab == 4) then
			-- this will reupdate the sign chosen
			local tabWindowName = WindowName.."TabWindow4"
			WindowSetShowing (tabWindowName.."CustTabHouseSignScrollingListBox", false)

			HouseSignWindow.HideCustTabMiniWindow()
			HouseSignWindow.ShowCustTabPreviewArea()
		end
		
	end -- if command == 105

	-- house sign hangar change
	if (command == 106) then
	
		
		-- figure out the current house sign index
		for i = 1, table.getn(WindowData.HouseSignHangarListCSV) do
			if (WindowData.HouseSignHangarListCSV[i].IconId == value) then
				data.CurrentHouseSignHangarIndex = i
				Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - updating house hangar")
			end
		end

		
		if (data.activeTab == 4) then
			-- this will reupdate the sign chosen
			local tabWindowName = WindowName.."TabWindow4"
			WindowSetShowing (tabWindowName.."CustTabSignHangarScrollingListBox", false)

			HouseSignWindow.HideCustTabMiniWindow()
			HouseSignWindow.ShowCustTabPreviewArea()
		end
		
	end -- if command == 106

	-- house sign post change
	if (command == 107) then
	
		
		-- figure out the current house sign index
		for i = 1, table.getn(WindowData.HouseSignPostListCSV) do
			if (WindowData.HouseSignPostListCSV[i].IconId == value) then
				data.CurrentHouseSignPostIndex = i
				Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - updating house hangar")
			end
		end

		
		if (data.activeTab == 4) then
			-- this will reupdate the sign chosen
			local tabWindowName = WindowName.."TabWindow4"
			WindowSetShowing (tabWindowName.."CustTabSignPostScrollingListBox", false)

			HouseSignWindow.HideCustTabMiniWindow()
			HouseSignWindow.ShowCustTabPreviewArea()
		end
		
	end -- if command == 107

	-- house foundation style change
	if (command == 108) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - changing foundation style")
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - changing foundation style: value = "..StringToWString(tostring(value)))
	
		if (value ~= 0) then  -- error case of some sort if 0 (i.e. didn't have privs, etc)
			-- figure out the current house sign index
			for i = 1, table.getn(WindowData.FoundationStyleListCSV) do
				if (WindowData.FoundationStyleListCSV[i].IconId == value) then
					data.CurrentFoundationStyleIndex = i
					Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - updating house hangar")
				end
			end
		end
		
		if (data.activeTab == 4) then
			-- this will reupdate the sign chosen
			local tabWindowName = WindowName.."TabWindow4"
			WindowSetShowing (tabWindowName.."CustTabFoundationStyleScrollingListBox", false)

			HouseSignWindow.HideCustTabMiniWindow()
			HouseSignWindow.ShowCustTabPreviewArea()
		end
		
	end -- if command == 108

	if (command == 109) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - re-naming house")
	
		if (value == 1) then  -- error case of some sort if 0 (i.e. didn't have privs, etc)
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - closing gump")
			-- close gump - the house id has changed 
			HouseSignWindow.OnCloseWindow()
		end
		
		if (value == 2) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - switching to tab 4")
			data.activeTab = 4  -- customize tab
			HouseSignWindow.ShowTab(data.activeTab)
		end
		
	end -- if command == 109

	if (command == 110) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - demolishing house")
		HouseSignWindow.OnCloseWindow()

	end -- if command == 110

	if (command == 111) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - traded house")
		HouseSignWindow.OnCloseWindow()

	end -- if command == 111

	if (command == 112) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - made house primary")
		if (value == 1) then
			-- disable make house primary button.
			data.MakePrimary = 0 
			local tabWindowName = WindowName.."TabWindow5"
			--WindowSetShowing (tabWindowName.."MakeHousePrimaryEntryIcon", false)
			WindowSetShowing (tabWindowName.."MakeHousePrimaryEntryButton", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."MakeHousePrimaryEntryButton", true )

		end
	end -- if command == 112
	
	if (command == 113) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - co owner change")

		if (value == 1) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - co owner change - success")
			HouseSignWindow.HandleCoOwnerStatusChangeFromServer()
		else
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - co owner change - fail")
			HouseSignWindow.FailedCoOwnerStatusChangeFromServer()		
		end
	end -- if command == 113

	if (command == 114) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - friend change ")
	
		if (value == 1) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - friend change - success ")
			HouseSignWindow.HandleFriendsStatusChangeFromServer()
		else
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - friend change - fail ")
			HouseSignWindow.FailedFriendsStatusChangeFromServer()		
		end
	end -- if command == 114

	if (command == 115) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - general status change ")
	
		if (value == 1) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - general status change - success")
			HouseSignWindow.HandleGeneralStatusChangeFromServer()
		else
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - general status change - fail")
			HouseSignWindow.FailedGeneralStatusChangeFromServer()		
		end
	end -- if command == 115

	if (command == 116) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - ban change")
	
		-- value will contain the obj id of the player if successful
		if (value > 0) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - ban change - success")
			HouseSignWindow.BanPlayerSuccess(value)
		else
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - ban change - fail")
			HouseSignWindow.FailedBanChangeFromServer()		
		end
	end -- if command == 116


	if (command == 117) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - remove co-owner")

		if (value == 0) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - remove co-owner - fail")
			HouseSignWindow.FailedRemovePlayerFromCoOwnersList()
		end
	
		if (value == 1) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - remove co-owner - success")
			HouseSignWindow.ActualRemovePlayerFromCoOwnersList()
		end
	end -- if command == 117

	if (command == 118) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - remove friend")

		if (value == 0) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - remove friend - fail")
			HouseSignWindow.FailedRemovePlayerFromFriendsList()
		end
	
		if (value == 1) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - remove friend - success")
			HouseSignWindow.ActualRemovePlayerFromFriendsList()
		end
	end -- if command == 118

	if (command == 119) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - remove general")

		if (value == 0) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - remove general - fail")
			HouseSignWindow.FailedRemovePlayerFromGeneralList()
		end
	
		if (value == 1) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - remove general - success")
			HouseSignWindow.ActualRemovePlayerFromGeneralList()
		end
	end -- if command == 119

	if (command == 120) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - unban")

		if (value == 0) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - unban - fail")
			HouseSignWindow.FailedUnbanChangeFromServer()
		end
	
		if (value == 1) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - unban - success")
			HouseSignWindow.UnbanChangeFromServer()
		end
	end -- if command == 120

	if (command == 121) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - clear co-owners")

		if (value == 0) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - clear co-owners - fail")
			HouseSignWindow.FailedServerResponseClearCoOwnersList()
		end
	
		if (value == 1) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - clear co-owners - success")
			HouseSignWindow.ServerResponseClearCoOwnersList()
		end
	end -- if command == 121

	if (command == 122) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - clear friends")

		if (value == 0) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - clear friends - fail")
			HouseSignWindow.FailedServerResponseClearFriendsList()
		end
	
		if (value == 1) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - clear friends - success")
			HouseSignWindow.ServerResponseClearFriendsList()
		end
	end -- if command == 122

	if (command == 123) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - clear general")

		if (value == 0) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - clear general - fail")
			HouseSignWindow.FailedServerResponseClearGeneralList()
		end
	
		if (value == 1) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - clear general - success")
			HouseSignWindow.ServerResponseClearGeneralList()
		end
	end -- if command == 123

	if (command == 124) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - clear banned")

		if (value == 0) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - clear banned - failed")
			HouseSignWindow.FailedServerResponseClearBannedList()
		end
	
		if (value == 1) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - clear banned - success")
			HouseSignWindow.ServerResponseClearBannedList()
		end
	end -- if command == 124

	if (command == 125) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - improper 125 response")
	end	

	if (command == 126) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - add new player")

		HouseSignWindow.HandleAddNewPlayer(value)
	end -- if command == 126

	if (command == 127) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - failed add new player")

		HouseSignWindow.HandleAddNewPlayerFailed()
	end -- if command == 127

	if (command == 128) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - customize house response")

		-- close the loading message
		if CustomizationNoticeWindowName ~= nil and DoesWindowNameExist(CustomizationNoticeWindowName) then
			GGManager.destroyWindow(CustomizationNoticeWindowName)
			CustomizationNoticeWindowName = nil
		end

		-- a non-zero value means successful and the value is the multi id
		if (value ~= 0) then 
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - customize house response= 1")
			-- tell housing system we are entering customized housing mode -- cust. housing window does this
			
			-- make available the house id
			ReturnWindowData.CustomizedHousing.HouseId = value
			-- SetIsCustomizingHouse( true )

			-- TODO tell the customize house window to show itself
			-- CreateWindowFromTemplate ("CustomizeHouseWindow", "CustomizeHouseWindow", "Root")

			-- close the house sign window - when we are done with customizing we won't reshow the house sign window
			HouseSignWindow.OnCloseWindow()
		else
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleHouseInfoChange - customize house response= 0")
				
			WindowSetShowing(WindowName, true)
		end

		-- TODO destroy the "preparing house for customization client side window"

	end -- if command == 128



end

function HouseSignWindow.LoadInformationTabData()
	Debug.PrintToDebugConsole(L"HouseSignWindow.LoadInformationTabData")

	data.OwnerName = stringData[4]
	data.PlacementStatus = tonumber(stringData[5])
	data.ModernStatus = tonumber(stringData[6])
	data.CustomStatus = tonumber(stringData[7])
	data.PublicStatus = tonumber(stringData[8])
	data.HouseStatusTid = tonumber(stringData[9])
	data.HouseStatusTidColor = tonumber(stringData[10])
	data.CreationDate = stringData[11]
	data.LastTransferTime = stringData[12]
	data.HouseValue = tonumber(stringData[13])
	data.NumVisits = tonumber(stringData[14])

	Debug.PrintToDebugConsole(L"House_Placement.LoadData: name = "..data.OwnerName)
	Debug.PrintToDebugConsole(L"House_Placement.LoadData: proper place = "..StringToWString(tostring(tonumber(data.PlacementStatus))))
	Debug.PrintToDebugConsole(L"House_Placement.LoadData: modern = "..StringToWString(tostring(data.ModernStatus)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadData: custom = "..StringToWString(tostring(data.CustomStatus)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadData: public = "..StringToWString(tostring(data.PublicStatus)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadData: house status tid = "..StringToWString(tostring(data.HouseStatusTid)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadData: house status color = "..StringToWString(tostring(data.HouseStatusTidColor)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadData: creation date = "..data.CreationDate)
	Debug.PrintToDebugConsole(L"House_Placement.LoadData: transfer time = "..data.LastTransferTime)
	Debug.PrintToDebugConsole(L"House_Placement.LoadData: value = "..StringToWString(tostring(tonumber(data.HouseValue))))
	Debug.PrintToDebugConsole(L"House_Placement.LoadData: visits = "..StringToWString(tostring(data.NumVisits)))

end

function HouseSignWindow.LoadStorageTabData()
	Debug.PrintToDebugConsole(L"HouseSignWindow.LoadStorageTabData")

	data.StorageIncrease = tonumber(stringData[15])
	data.MaxSecures = tonumber(stringData[16])
	data.MovingCrateSecures = tonumber(stringData[17])
	data.LockdownSecures = tonumber(stringData[18])
	data.SecureContainerSecures = tonumber(stringData[19])
	data.AvailableSecures = tonumber(stringData[20])
	data.MaxLockdowns = tonumber(stringData[21])
	data.AvailableLockdowns =  tonumber(stringData[22])
	data.Vendors = tonumber(stringData[23])
	data.MaxVendors = tonumber(stringData[24])

	Debug.PrintToDebugConsole(L"House_Placement.LoadStorageTabData: storage increase = "..StringToWString(tostring(data.StorageIncrease)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadStorageTabData: max secures = "..StringToWString(tostring(data.MaxSecures)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadStorageTabData: moving crate secures = "..StringToWString(tostring(data.MovingCrateSecures)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadStorageTabData: lockdown secures = "..StringToWString(tostring(data.LockdownSecures)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadStorageTabData: secure container secures = "..StringToWString(tostring(data.SecureContainerSecures)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadStorageTabData: avail secures = "..StringToWString(tostring(data.AvailableSecures)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadStorageTabData: max lockdowns = "..StringToWString(tostring(data.MaxLockdowns)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadStorageTabData: avail lockdowns = "..StringToWString(tostring(data.AvailableLockdowns)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadStorageTabData: vendors = "..StringToWString(tostring(data.Vendors)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadStorageTabData: max vendors = "..StringToWString(tostring(data.MaxVendors)))

end

function HouseSignWindow.LoadSecurityTabData()
	Debug.PrintToDebugConsole(L"HouseSignWindow.LoadStorageTabData")

	data.IsOwner = tonumber(stringData[25])
	data.IsCoOwner = tonumber(stringData[26])
	data.IsFriend = tonumber(stringData[27])

	Debug.PrintToDebugConsole(L"House_Placement.LoadSecurityTabData: is owner = "..StringToWString(tostring(data.IsOwner)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadSecurityTabData: is co-owner = "..StringToWString(tostring(data.IsCoOwner)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadSecurityTabData: is friend = "..StringToWString(tostring(data.IsFriend)))

	data.NumCoOwners = tonumber(stringData[28])
	Debug.PrintToDebugConsole(L"House_Placement.LoadSecurityTabData: num co-owners = "..StringToWString(tostring(data.NumCoOwners)))

	local current = 29  -- pointer to where we are in the stringdata
	-- co-owners
	if (data.NumCoOwners ~= nil) then
		if (data.NumCoOwners > 0) then
			for i = 1, data.NumCoOwners do
				tempData = {}
				Debug.PrintToDebugConsole(L"HouseSignWindow.LoadSecurityTabData: co-owner "..StringToWString(tostring(i))..L" name = "..stringData[current])
				tempData.name = stringData[current]
				current = current + 1
				Debug.PrintToDebugConsole(L"HouseSignWindow.LoadSecurityTabData: co-owner "..StringToWString(tostring(i))..L" status = "..stringData[current])
				tempData.status = stringData[current]
				current = current + 1
				Debug.PrintToDebugConsole(L"HouseSignWindow.LoadSecurityTabData: co-owner "..StringToWString(tostring(i))..L" objid = "..stringData[current])
				tempData.objid = tonumber(stringData[current])
				current = current + 1
				
				table.insert(HSW_CoOwnersList, tempData) 
				table.insert(HSW_MasterList, tempData) 
			end
		end
	end
	
	data.NumFriends = tonumber(stringData[current])
	Debug.PrintToDebugConsole(L"House_Placement.LoadSecurityTabData: num friends = "..StringToWString(tostring(data.NumFriends)))
	current = current + 1

	if (data.NumFriends ~= nil) then
		if (data.NumFriends > 0) then
			for i = 1, data.NumFriends do
				tempData = {}
				Debug.PrintToDebugConsole(L"HouseSignWindow.LoadSecurityTabData: friend "..StringToWString(tostring(i))..L" name = "..stringData[current])
				tempData.name = stringData[current]
				current = current + 1
				Debug.PrintToDebugConsole(L"HouseSignWindow.LoadSecurityTabData: friend "..StringToWString(tostring(i))..L" status = "..stringData[current])
				tempData.status = stringData[current]
				current = current + 1
				Debug.PrintToDebugConsole(L"HouseSignWindow.LoadSecurityTabData: friend "..StringToWString(tostring(i))..L" objid = "..stringData[current])
				tempData.objid = tonumber(stringData[current])
				current = current + 1
				
				table.insert(HSW_FriendsList, tempData) 
				table.insert(HSW_MasterList, tempData) 
				
			end
		end
	end
		
	data.NumGeneral = tonumber(stringData[current])
	Debug.PrintToDebugConsole(L"House_Placement.LoadSecurityTabData: num general = "..StringToWString(tostring(data.NumGeneral)))
	current = current + 1


	if (data.NumGeneral ~= nil) then
		if (data.NumGeneral > 0) then
			for i = 1, data.NumGeneral do
				tempData = {}
				Debug.PrintToDebugConsole(L"HouseSignWindow.LoadSecurityTabData: general "..StringToWString(tostring(i))..L" name = "..stringData[current])
				tempData.name = stringData[current]
				current = current + 1
				Debug.PrintToDebugConsole(L"HouseSignWindow.LoadSecurityTabData: general "..StringToWString(tostring(i))..L" status = "..stringData[current])
				tempData.status = stringData[current]
				current = current + 1
				Debug.PrintToDebugConsole(L"HouseSignWindow.LoadSecurityTabData: general "..StringToWString(tostring(i))..L" objid = "..stringData[current])
				tempData.objid = tonumber(stringData[current])
				current = current + 1
				
				table.insert(HSW_GeneralList, tempData) 
				table.insert(HSW_MasterList, tempData) 
				
			end
		end
	end

	data.NumBanned = tonumber(stringData[current])
	Debug.PrintToDebugConsole(L"House_Placement.LoadSecurityTabData: num banned = "..StringToWString(tostring(data.NumBanned)))
	current = current + 1

	if (data.NumBanned ~= nil) then
		if (data.NumBanned > 0) then
			for i = 1, data.NumBanned do
				tempData = {}
				Debug.PrintToDebugConsole(L"HouseSignWindow.LoadSecurityTabData: banned "..StringToWString(tostring(i))..L" name = "..stringData[current])
				tempData.name = stringData[current]
				current = current + 1
				Debug.PrintToDebugConsole(L"HouseSignWindow.LoadSecurityTabData: banned "..StringToWString(tostring(i))..L" status = "..stringData[current])
				tempData.status = stringData[current]
				current = current + 1
				Debug.PrintToDebugConsole(L"HouseSignWindow.LoadSecurityTabData: banned "..StringToWString(tostring(i))..L" objid = "..stringData[current])
				tempData.objid = tonumber(stringData[current])
				current = current + 1
				
				table.insert(HSW_BannedList, tempData) 
				
			end
		end
	end

	NextStringData = current
end

function HouseSignWindow.LoadCustomizeTabData()
	Debug.PrintToDebugConsole(L"HouseSignWindow.LoadCustomizeTabData")

	local current = NextStringData
	data.Test = tonumber(stringData[current])
	current = current + 1

	data.ConvertToCustomizable = tonumber(stringData[current])
	current = current + 1
	data.CustomizeHouse = tonumber(stringData[current])
	current = current + 1
	data.RelocateMovingCrate = tonumber(stringData[current])
	current = current + 1
	data.ChangeHouseSign = tonumber(stringData[current])
	current = current + 1
	data.CurrentHouseSignId = tonumber(stringData[current])  -- icon id from server
	current = current + 1
	data.ChangeHouseSignHanger = tonumber(stringData[current])
	current = current + 1
	data.CurrentHouseSignHanger = tonumber(stringData[current])  -- icon id from server
	current = current + 1
	data.ChangeSignPost = tonumber(stringData[current])
	current = current + 1
	data.HasSignPost = tonumber(stringData[current])  -- has a sign post
	current = current + 1
	data.CurrentSignPost = tonumber(stringData[current])  -- icon id from server
	current = current + 1
	data.ChangeFoundationStyle = tonumber(stringData[current])
	current = current + 1
	data.CurrentFoundationStyle = tonumber(stringData[current])  -- icon id from server
	current = current + 1
	data.RenameHouse =  tonumber(stringData[current])
	current = current + 1
	NextStringData = current
	
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: test = "..StringToWString(tostring(data.Test)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: ConvertToCustomizable = "..StringToWString(tostring(data.ConvertToCustomizable)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: CustomizeHouse = "..StringToWString(tostring(data.CustomizeHouse)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: RelocateMovingCrate = "..StringToWString(tostring(data.RelocateMovingCrate)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: ChangeHouseSign = "..StringToWString(tostring(data.ChangeHouseSign)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: HouseSign = "..StringToWString(tostring(data.CurrentHouseSignId)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: ChangeHouseSignHanger = "..StringToWString(tostring(data.ChangeHouseSignHanger)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: HouseSignHangar = "..StringToWString(tostring(data.CurrentHouseSignHanger)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: ChangeSignPost = "..StringToWString(tostring(data.ChangeSignPost)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: HasSignPost = "..StringToWString(tostring(data.HasSignPost)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: SignPost = "..StringToWString(tostring(data.CurrentSignPost)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: ChangeFoundationStyle = "..StringToWString(tostring(data.ChangeFoundationStyle)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: FoundationStyle = "..StringToWString(tostring(data.CurrentFoundationStyle)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: RenameHouse = "..StringToWString(tostring(data.RenameHouse)))

	-- figure out the current house sign index
	for i = 1, table.getn(WindowData.HouseSignListCSV) do
		if (WindowData.HouseSignListCSV[i].IconId == data.CurrentHouseSignId) then
			data.CurrentHouseSignIndex = i
			Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: HouseSignIndex = "..StringToWString(tostring(i)))
		end
	end
	
	-- figure out the current house sign hangar index
	for i = 1, table.getn(WindowData.HouseSignHangarListCSV) do
		if (WindowData.HouseSignHangarListCSV[i].IconId == data.CurrentHouseSignHanger) then
			data.CurrentHouseSignHangarIndex = i
			Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: HouseSignHangarIndex = "..StringToWString(tostring(i)))
		end
	end

	-- figure out the current sign post index
	for i = 1, table.getn(WindowData.HouseSignPostListCSV) do
		if (WindowData.HouseSignPostListCSV[i].IconId == data.CurrentSignPost) then
			data.CurrentHouseSignPostIndex = i
			Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: HouseSignPostIndex = "..StringToWString(tostring(i)))
		end
	end

	-- figure out the current foundation style index
	for i = 1, table.getn(WindowData.FoundationStyleListCSV) do
		if (WindowData.FoundationStyleListCSV[i].IconId == data.CurrentFoundationStyle) then
			data.CurrentFoundationStyleIndex = i
			Debug.PrintToDebugConsole(L"House_Placement.LoadCustomizeTabData: FoundationStyleIndex = "..StringToWString(tostring(i)))
		end
	end
	-- server doesn;t know what the foundation style is
	if (data.CurrentFoundationStyle == 0) then
		data.CurrentFoundationStyleIndex = -1
	end		
end

function HouseSignWindow.LoadOwnershipTabData()
	Debug.PrintToDebugConsole(L"HouseSignWindow.LoadOwnershipTabData")

	local current = NextStringData

	data.DemolishHouse = tonumber(stringData[current])
	current = current + 1
	data.TradeHouse = tonumber(stringData[current])
	current = current + 1
	data.MakePrimary = tonumber(stringData[current])
	current = current + 1
	
	Debug.PrintToDebugConsole(L"House_Placement.LoadOwnershipTabData: DemolishHouse = "..StringToWString(tostring(data.DemolishHouse)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadOwnershipTabData: TradeHouse = "..StringToWString(tostring(data.TradeHouse)))
	Debug.PrintToDebugConsole(L"House_Placement.LoadOwnershipTabData: MakePrimary = "..StringToWString(tostring(data.MakePrimary)))

end




function HouseSignWindow.DoNothing()
	doNothing = 0
end







-- Makes all the other tabs selectable
function HouseSignWindow.EnableAllTabs(parent)
	Debug.PrintToDebugConsole(L"HouseSignWindow.EnableAllTabs "..StringToWString(tostring(data.numTabs)))

	for i = 1, data.numTabs do
		tabName = parent.."TabButton"..i
		WindowSetShowing(tabName.."TabDisabled", false)
		
		ButtonSetDisabledFlag(tabName, false)
	end
end

-- Makes the current tab the live one, and unselectable
function HouseSignWindow.DisableTab(parent, tabNum)
	Debug.PrintToDebugConsole(L"HouseSignWindow.DisableTab ")

	-- TODO -- make sure the tab number passed in is a valid tab
	
	tabName = parent.."TabButton"..tostring(tabNum)
	WindowSetShowing(tabName.."TabDisabled", true)
	ButtonSetDisabledFlag(tabName, true);
	ButtonSetTextColor( tabName, 255,255,255 )

end
	
-- Force the active tab to be something
function HouseSignWindow.ForceActiveTabSetting (tabnum)
	--Debug.PrintToDebugConsole(L"HouseSignWindow.ForceActiveTabSetting tabnum = "..StringToWString(tostring(tabnum)))

	data.activeTab = tabnum

end

function HouseSignWindow.ShowTab(tabnum)
	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowTab ")

	showing = WindowGetShowing(WindowName)
	if (showing) then
		doNothing = 0
	else
		Debug.PrintToDebugConsole(L"HouseSignWindow.ShowTab(): aborting because window ain't open ")
		do return end
	end
	



	-- Make sure we always display something    
	if tabnum == nil then
		Debug.PrintToDebugConsole(L"HouseSignWindow.ShowTab(): Forcing tabnum = 1 ")
		tabnum = 1
		HouseSignWindow.ForceActiveTabSetting (tabnum)
	end

	
	-- Update tabs to highlight the correct one
	HouseSignWindow.EnableAllTabs(WindowName)
	HouseSignWindow.DisableTab(WindowName, tabnum)



	-- Hide all tabs
	for i=1, data.numTabs do
		local tabWindowName = WindowName.."TabWindow"..tostring(i)
		WindowSetShowing(tabWindowName, false)
	end

	-- Change the active tab if needed
	if data.activeTab ~= tabnum then
		--Debug.PrintToDebugConsole(L"HouseSignWindow.ShowTab():Changing tabnum from = "..StringToWString(tostring(data.activeTab))..L"to "..StringToWString(tostring(data.tabnum)))
		
		data.activeTab = tabnum



	end

	if (data.activeTab ~= 2) then	
		HouseSignWindow.HideAccessTabButtons()
	end
	
	-- this is not protected since if one is choosing a house sign style and clicks the customize tab, this will make the current selections be re-shown
	-- this will close anything in the preview area one may have been working on
	HouseSignWindow.HideCustTabMiniWindow()
	
	-- show selected tab
	local tabWindowName = WindowName.."TabWindow"..tostring(tabnum)
	WindowSetShowing(tabWindowName, true)

	-- information tab
	if (data.activeTab == 1) then

		WindowUtils.SetWindowTitle(WindowName,GetStringFromTid(1078894)) -- House Management - Information

		HouseSignWindow.ShowAccessTabButtons()

		ButtonSetDisabledFlag( tabWindowName.."ChangePrivateStatusButton", false )
		if (data.PublicStatus == 0) then -- private
			LabelSetText (tabWindowName.."ChangePrivateStatusText",GetStringFromTid(1060694)) -- change to public
		elseif (data.PublicStatus == 1) then -- public
			LabelSetText (tabWindowName.."ChangePrivateStatusText",GetStringFromTid(1060695)) -- change to private
		end
				
		WindowSetShowing(tabWindowName.."ChangePrivateStatusButton", true)

		LabelSetText (tabWindowName.."OwnerText",GetStringFromTid(1041474)..L" "..data.OwnerName)
		
		local PlacementStatusTid = 0
		if (data.PlacementStatus == 0) then
			PlacementStatusTid = 1018033 -- improperly placed
		elseif (data.PlacementStatus == 1) then
			PlacementStatusTid = 1018032 -- properly placed	
		end

		LabelSetText (tabWindowName.."PlacementStatusText",GetStringFromTid(PlacementStatusTid))
		
		local ModernStatusTid = 0
		if (data.ModernStatus == 1) then
			ModernStatusTid = 1018035 -- modern
		elseif (data.ModernStatus == 0) then
			ModernStatusTid = 1018034 -- not modern	
		end
		LabelSetText (tabWindowName.."DesignTypeText",GetStringFromTid(ModernStatusTid))

		local CustomStatusTid = 0
		if (data.CustomStatus == 0) then
			CustomStatusTid = 1060680 -- not custom	
		elseif (data.CustomStatus == 1) then
			CustomStatusTid = 1060681 -- custom
		end
		LabelSetText (tabWindowName.."CustomStatusText",GetStringFromTid(CustomStatusTid))

		local PublicStatusTid = 0
		if (data.PublicStatus == 0) then
			PublicStatusTid = 1060679 -- private	
		elseif (data.PublicStatus == 1) then
			PublicStatusTid = 1060678 -- public
		end
		LabelSetText (tabWindowName.."PrivateStatusText",WindowUtils.translateMarkup(GetStringFromTid(PublicStatusTid)))
		
		-- strip out the href tags
		LabelSetText (tabWindowName.."RefreshText",WindowUtils.translateMarkup(GetStringFromTid(data.HouseStatusTid)))
		
		-- CJT - in the legacy client the server also hued this text, but it looks like crap in the new client so the hue from the server is being ignored
		--[[local R = 255
		local G = 255
		local B = 255
		if (data.HouseStatusTidColor == 32272) then  -- red
			R = 255
			G = 0
			B = 0
		elseif (data.HouseStatusTidColor == 16927) then -- blue
			R = 0
			G = 0
			B = 255
		
		elseif (data.HouseStatusTidColor == 32752) then -- yellow
			R = 255
			G = 255
			B = 0
		
		end
		--]]
		
		LabelSetText (tabWindowName.."BuiltOnText",GetStringFromTid(1060692)..L" "..data.CreationDate) -- built on
		LabelSetText (tabWindowName.."LastTradedText",GetStringFromTid(1060693)..L" "..data.LastTransferTime) -- last traded
		LabelSetText (tabWindowName.."HouseValueText",GetStringFromTid(1061793)..L": "..WindowUtils.AddCommasToNumber(StringToWString(tostring(data.HouseValue)))) -- house value
		LabelSetText (tabWindowName.."NumberOfVisitsText",GetStringFromTid(1078869)..L": "..StringToWString(tostring(data.NumVisits))) -- Number of Visits
	
	
	end -- tab 1

	if (data.activeTab == 2) then
		--for i = 1, 10 do
		--	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowTab: HSW_FriendsList[i].name =  "..HSW_FriendsList[i].name)
		--end
		HouseSignWindow.ShowAccessTabButtons()

		WindowUtils.SetWindowTitle(WindowName,GetStringFromTid(1078870)) -- House Management - Access
		
		HouseSignWindow.UpdateAccessSubTypeText()
		ButtonSetDisabledFlag( tabWindowName.."ChangeSubTypeLeftButton", false )
		ButtonSetDisabledFlag( tabWindowName.."ChangeSubTypeRightButton", false )
		
		HouseSignWindow.UpdateListOfPlayers();
	end -- tab 2

	if (data.activeTab == 3) then

		WindowUtils.SetWindowTitle(WindowName,GetStringFromTid(1078871)) -- House Management - Storage
	
		HouseSignWindow.ShowAccessTabButtons()
	
		LabelSetText (tabWindowName.."IncreasedStorageText",GetStringFromTid(1072519)..L": "..StringToWString(tostring(data.StorageIncrease))..L"%")  -- Increased Storage
		LabelSetText (tabWindowName.."MaxSecuresText",GetStringFromTid(1060683)..L": "..StringToWString(tostring(data.MaxSecures)))  -- Maximum Secure Storage
		LabelSetText (tabWindowName.."UsedByMovingCrateText",GetStringFromTid(1060685)..L": "..StringToWString(tostring(data.MovingCrateSecures))) -- Used by moving crate
		LabelSetText (tabWindowName.."UsedByLockdownsText",GetStringFromTid(1060686)..L": "..StringToWString(tostring(data.LockdownSecures))) -- used by lockdowns
		LabelSetText (tabWindowName.."UsedBySecuresText",GetStringFromTid(1060688)..L": "..StringToWString(tostring(data.SecureContainerSecures)))  -- used by secure containers
		LabelSetText (tabWindowName.."AvailableStorageText",GetStringFromTid(1060689)..L": "..StringToWString(tostring(data.AvailableSecures)))  -- avaialble storage
		LabelSetText (tabWindowName.."MaximumLockdownsText",GetStringFromTid(1060690)..L": "..StringToWString(tostring(data.MaxLockdowns)))  -- maximum lockdowns
		LabelSetText (tabWindowName.."AvailableLockdownsText",GetStringFromTid(1060691)..L": "..StringToWString(tostring(data.AvailableLockdowns)))  -- available lockdowns
		LabelSetText (tabWindowName.."VendorCountText",GetStringFromTid(1062391)..L": "..StringToWString(tostring(data.Vendors))..L" / "..StringToWString(tostring(data.MaxVendors))) -- vendor count
	
	
	end -- tab 3

	if (data.activeTab == 4) then

		WindowUtils.SetWindowTitle(WindowName,GetStringFromTid(1078895)) -- House Management - Customize

		HouseSignWindow.ShowAccessTabButtons()
	
		local objType = 2968
		name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(objType,45,45)

		ButtonSetText (tabWindowName.."CustomizeTabSelectButton",GetStringFromTid(1078861)) -- select
		ButtonSetText (tabWindowName.."CustomizeTabCancelButton",GetStringFromTid(1006045)) -- cancel
	
	
		LabelSetText (tabWindowName.."ConvertHouseEntryText",GetStringFromTid(1060759)) -- Convert Into Customizable House
		LabelSetText (tabWindowName.."CustomizeThisHouseEntryText",GetStringFromTid(1060765)) -- Customize This House
		LabelSetText (tabWindowName.."ChangeHouseSignEntryText",GetStringFromTid(1060761)) -- Change House Sign
		LabelSetText (tabWindowName.."ChangeHouseSignHangerEntryText",GetStringFromTid(1060762)) -- Change House Sign Hanger
		LabelSetText (tabWindowName.."ChangeSignpostEntryText",GetStringFromTid(1060763)) -- Change Sign Post
		LabelSetText (tabWindowName.."ChangeFoundationStyleEntryText",GetStringFromTid(1062004)) -- Change Foundation Style
	
		-- CJT - 2/16/07 disabling buttons
		if (data.ConvertToCustomizable == 0) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.ShowTab4: house not convertable ")
			--WindowSetShowing (tabWindowName.."ConvertHouseEntryIcon", false)
			--WindowSetShowing (tabWindowName.."ConvertHouseEntryText", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."ConvertHouseEntryButton", true )
		else
			WindowSetShowing (tabWindowName.."ConvertHouseEntryButton", true)
			ButtonSetDisabledFlag( tabWindowName.."ConvertHouseEntryButton", false )		
		end
		
		if (data.CustomizeHouse == 0) then
			--WindowSetShowing (tabWindowName.."CustomizeThisHouseEntryIcon", false)
			WindowSetShowing (tabWindowName.."CustomizeThisHouseEntryButton", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."CustomizeThisHouseEntryButton", true )
		
		else
			ButtonSetDisabledFlag( tabWindowName.."CustomizeThisHouseEntryButton", false )
		end


		if (data.ChangeHouseSign == 0) then
			--WindowSetShowing (tabWindowName.."ChangeHouseSignEntryIcon", false)
			WindowSetShowing (tabWindowName.."ChangeHouseSignEntryButton", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."ChangeHouseSignEntryButton", true )
		
		else
			--WindowSetShowing (tabWindowName.."ChangeHouseSignEntryIcon", true)
			WindowSetShowing (tabWindowName.."ChangeHouseSignEntryButton", true)
			ButtonSetDisabledFlag( tabWindowName.."ChangeHouseSignEntryButton", false )
		end

		if (data.ChangeHouseSignHanger == 0) then
			--WindowSetShowing (tabWindowName.."ChangeHouseSignHangerEntryIcon", false)
			WindowSetShowing (tabWindowName.."ChangeHouseSignHangerEntryButton", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."ChangeHouseSignHangerEntryButton", true )
		
		else
			ButtonSetDisabledFlag( tabWindowName.."ChangeHouseSignHangerEntryButton", false )
		end

		if (data.ChangeSignPost == 0) then
			--WindowSetShowing (tabWindowName.."ChangeSignpostEntryIcon", false)
			WindowSetShowing (tabWindowName.."ChangeSignpostEntryButton", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."ChangeSignpostEntryButton", true )
		
		else
			ButtonSetDisabledFlag( tabWindowName.."ChangeSignpostEntryButton", false )
		end

		if (data.ChangeFoundationStyle == 0) then
			--WindowSetShowing (tabWindowName.."ChangeFoundationStyleEntryIcon", false)
			WindowSetShowing (tabWindowName.."ChangeFoundationStyleEntryButton", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."ChangeFoundationStyleEntryButton", true )
		
		else
			ButtonSetDisabledFlag( tabWindowName.."ChangeFoundationStyleEntryButton", false )
		end

		
		
		-- show current settings
		
		WindowSetShowing (tabWindowName.."CustTabHouseSignScrollingListBox", false)
		WindowSetShowing (tabWindowName.."CustTabSignHangarScrollingListBox", false)
		WindowSetShowing (tabWindowName.."CustTabSignPostScrollingListBox", false)
		WindowSetShowing (tabWindowName.."CustTabFoundationStyleScrollingListBox", false)

		HouseSignWindow.ShowCustTabPreviewArea()

		WindowSetShowing (tabWindowName.."CustomizeTabSelectButton", false)
		WindowSetShowing (tabWindowName.."CustomizeTabCancelButton", false)

		

	end -- tab 4

	if (data.activeTab == 5) then

		WindowUtils.SetWindowTitle(WindowName,GetStringFromTid(1078862)) -- House Management - Ownership

		HouseSignWindow.ShowAccessTabButtons()

		LabelSetText (tabWindowName.."DemolishHouseEntryText",GetStringFromTid(1061794)) -- Demolish House
		LabelSetText (tabWindowName.."TradeHouseEntryText",GetStringFromTid(1061797)) -- Trade House
		LabelSetText (tabWindowName.."MakeHousePrimaryEntryText",GetStringFromTid(1078863)) -- Make House Primary
		LabelSetText (tabWindowName.."RelocateMovingCrateEntryText",GetStringFromTid(1060760)) -- Relocate Moving Crate
		LabelSetText (tabWindowName.."RenameHouseEntryText",GetStringFromTid(1060764)) -- Rename House

		if (data.DemolishHouse == 0) then
			--WindowSetShowing (tabWindowName.."DemolishHouseEntryIcon", false)
			--WindowSetShowing (tabWindowName.."DemolishHouseEntryButton", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."DemolishHouseEntryButton", true )
		
		else
			ButtonSetDisabledFlag( tabWindowName.."DemolishHouseEntryButton", false )
		end

		if (data.TradeHouse == 0) then
			--WindowSetShowing (tabWindowName.."TradeHouseEntryIcon", false)
			--WindowSetShowing (tabWindowName.."TradeHouseEntryButton", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."TradeHouseEntryButton", true )
		
		else
			ButtonSetDisabledFlag( tabWindowName.."TradeHouseEntryButton", false )
		end

		if (data.MakePrimary == 0) then
			--WindowSetShowing (tabWindowName.."MakeHousePrimaryEntryIcon", false)
			--WindowSetShowing (tabWindowName.."MakeHousePrimaryEntryButton", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."MakeHousePrimaryEntryButton", true )
		
		else
			ButtonSetDisabledFlag( tabWindowName.."MakeHousePrimaryEntryButton", false )
		end

		if (data.RelocateMovingCrate == 0) then
			--WindowSetShowing (tabWindowName.."RelocateMovingCrateEntryIcon", false)
			--WindowSetShowing (tabWindowName.."RelocateMovingCrateEntryButton", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."RelocateMovingCrateEntryButton", true )
		
		else
			ButtonSetDisabledFlag( tabWindowName.."RelocateMovingCrateEntryButton", false )
		end

		if (data.RenameHouse == 0) then
			--WindowSetShowing (tabWindowName.."RenameHouseEntryIcon", false)
			--WindowSetShowing (tabWindowName.."RenameHouseEntryButton", false)
			-- todo - gray out text
			ButtonSetDisabledFlag( tabWindowName.."RenameHouseEntryButton", true )
		
		else
			ButtonSetDisabledFlag( tabWindowName.."RenameHouseEntryButton", false )
		end

		--data.HouseName = L"the quick brown fox jumped over the lazy dog - the quick brown fox jumped over the lazy dog - the quick brown fox jumped over the lazy dog - the quick brown fox jumped over the lazy dog"
		LabelSetText (tabWindowName.."OwnTabHouseSignText",data.HouseName)
	end -- tab 5
	
	
end

function HouseSignWindow.ShowAccessTabButtons()


	if (data.activeTab == 2) then
		HouseSignWindow.UpdateClearListButton()
	else
		WindowSetShowing (WindowName.."ClearListButtonText", false)
		WindowSetShowing (WindowName.."ClearListButton", false)
	
	end
	
	WindowSetShowing (WindowName.."AddAccessButtonText", true)
	WindowSetShowing (WindowName.."AddAccessButton", true)

	HouseSignWindow.ShowBanButton()
end

function HouseSignWindow.ShowBanButton()

	-- if the house is public show the ban button
	if (data.PublicStatus == 1) then
		WindowSetShowing (WindowName.."BanButtonText", true)
		WindowSetShowing (WindowName.."BanButton", true)
	else
		WindowSetShowing (WindowName.."BanButtonText", false)
		WindowSetShowing (WindowName.."BanButton", false)	
	end
end

function HouseSignWindow.HideAccessTabButtons()

	WindowSetShowing (WindowName.."ClearListButtonText", false)
	WindowSetShowing (WindowName.."ClearListButton", false)

	HouseSignWindow.HideAccessTabModifyStatusButtons()

	-- we always show the Add Access; Ban Player button only if house is public 
end

function HouseSignWindow.ShowAccessTabModifyStatusButtons(index)
	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowAccessTabModifyStatusButtons")

	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowAccessTabModifyStatusButtons: index = "..StringToWString(tostring(index)))

	local tabWindowName = WindowName.."TabWindow2"

	local nameSelected = L""
	local status = L""
	
	if (HSW_AccessSubType == 1) then
			nameSelected = HSW_MasterList[index].name
			status = HSW_MasterList[index].status
	elseif (HSW_AccessSubType == 2) then
			nameSelected = HSW_GeneralList[index].name
			status = HSW_GeneralList[index].status

	elseif (HSW_AccessSubType == 3) then
			nameSelected = HSW_FriendsList[index].name
			status = HSW_FriendsList[index].status
	elseif (HSW_AccessSubType == 4) then
			nameSelected = HSW_CoOwnersList[index].name
			status = HSW_CoOwnersList[index].status
	elseif (HSW_AccessSubType == 5) then
			nameSelected = HSW_BannedList[index].name
			status = HSW_BannedList[index].status
	end
	
	-- todo move this to an init routine
	LabelSetText (tabWindowName.."ModifyAccessText",GetStringFromTid(1078874)..L" "..nameSelected) -- Modify Status For
	LabelSetText (tabWindowName.."CoOwnerButtonText",GetStringFromTid(1078875)) -- Change to Co-owner
	LabelSetText (tabWindowName.."FriendButtonText",GetStringFromTid(1078876)) -- Change to Friend
	LabelSetText (tabWindowName.."GeneralAccessButtonText",GetStringFromTid(1078877)) -- Change to General Access
	LabelSetText (tabWindowName.."RemoveButtonText",GetStringFromTid(1078878)) -- Remove Access
	
	if (status ~= L"Banned") then
		LabelSetText (tabWindowName.."UnbanButtonText",L"") -- was Ban Player, can no longer directly ban from the list
	else
		LabelSetText (tabWindowName.."UnbanButtonText",GetStringFromTid(1078879)) -- Remove Ban	
	end
	
	WindowSetShowing (tabWindowName.."ModifyAccessText", true)

	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowAccessTabModifyStatusButtons: status =  "..status)
	
	-- don't show co-owner, friend or general button if on the banned list
	
	-- have to be an owner to modify co-owners
	if (status ~= L"Co-Owner") and (data.IsOwner == 1) and (HSW_AccessSubType ~= 5) then
		WindowSetShowing (tabWindowName.."CoOwnerButton", true)
		WindowSetShowing (tabWindowName.."CoOwnerButtonText", true)
	else
		WindowSetShowing (tabWindowName.."CoOwnerButton", false)
		WindowSetShowing (tabWindowName.."CoOwnerButtonText", false)
	end	
	
	-- have to be an owner/co-owner to modify friends
	if (status ~= L"Friend") and ((data.IsOwner == 1) or (data.IsCoOwner == 1))  and (HSW_AccessSubType ~= 5)then
		WindowSetShowing (tabWindowName.."FriendButton", true)
		WindowSetShowing (tabWindowName.."FriendButtonText", true)
	else
		WindowSetShowing (tabWindowName.."FriendButton", false)
		WindowSetShowing (tabWindowName.."FriendButtonText", false)
	end

	-- have to be an owner/co-owner/friend to modify access
	if (status ~= L"Access") and ((data.IsOwner == 1) or (data.IsCoOwner == 1) or (data.IsFriend == 1)) and (HSW_AccessSubType ~= 5) then
		WindowSetShowing (tabWindowName.."GeneralAccessButton", true)
		WindowSetShowing (tabWindowName.."GeneralAccessButtonText", true)
	else
		WindowSetShowing (tabWindowName.."GeneralAccessButton", false)
		WindowSetShowing (tabWindowName.."GeneralAccessButtonText", false)
	end	

	-- have to be an owner/co-owner/friend to remove access
	if (status ~= L"Banned") and ((data.IsOwner == 1) or (data.IsCoOwner == 1) or (data.IsFriend == 1)) then
		WindowSetShowing (tabWindowName.."RemoveButton", true)
		WindowSetShowing (tabWindowName.."RemoveButtonText", true)
	else
		WindowSetShowing (tabWindowName.."RemoveButton", false)
		WindowSetShowing (tabWindowName.."RemoveButtonText", false)
	end

	-- if the player is already banned then show the "Ban/Unban button & text", otherwise hide them
	-- can't ban a player via selecting a player on the list
	-- the status == Banned will only be true when looking at the banned list
	if (status == L"Banned") then
		WindowSetShowing (tabWindowName.."UnbanButton", true)
		WindowSetShowing (tabWindowName.."UnbanButtonText", true)
	else
		WindowSetShowing (tabWindowName.."UnbanButton", false)
		WindowSetShowing (tabWindowName.."UnbanButtonText", false)
	
	end	
end

function HouseSignWindow.HideAccessTabModifyStatusButtons()

	local tabWindowName = WindowName.."TabWindow2"
	WindowSetShowing (tabWindowName.."ModifyAccessText", false)
	WindowSetShowing (tabWindowName.."CoOwnerButton", false)
	WindowSetShowing (tabWindowName.."CoOwnerButtonText", false)
	WindowSetShowing (tabWindowName.."FriendButton", false)
	WindowSetShowing (tabWindowName.."FriendButtonText", false)
	WindowSetShowing (tabWindowName.."GeneralAccessButton", false)
	WindowSetShowing (tabWindowName.."GeneralAccessButtonText", false)
	WindowSetShowing (tabWindowName.."RemoveButton", false)
	WindowSetShowing (tabWindowName.."RemoveButtonText", false)
	WindowSetShowing (tabWindowName.."UnbanButton", false)
	WindowSetShowing (tabWindowName.."UnbanButtonText", false)


end

function HouseSignWindow.HideCustTabPreviewArea()


	local tabWindowName = WindowName.."TabWindow4"

	WindowSetShowing (tabWindowName.."HouseSignTitle", false)
	WindowSetShowing (tabWindowName.."CurrentHouseSignText", false)
	WindowSetShowing (tabWindowName.."HouseSignHangarTitle", false)
	WindowSetShowing (tabWindowName.."CurrentHouseSignHangarText", false)
	WindowSetShowing (tabWindowName.."SignPostTitle", false)
	WindowSetShowing (tabWindowName.."CurrentSignPostText", false)
	WindowSetShowing (tabWindowName.."FoundationStyleTitle", false)
	WindowSetShowing (tabWindowName.."CurrentFoundationStyleText", false)
	
	WindowSetShowing (tabWindowName.."HouseSignImage", false)
	WindowSetShowing (tabWindowName.."HouseSignHangarImage", false)
	WindowSetShowing (tabWindowName.."SignPostImage", false)
	WindowSetShowing (tabWindowName.."FoundationStyleImage", false)

	WindowSetShowing (tabWindowName.."PreviewAreaVRule", false)
	WindowSetShowing (tabWindowName.."PreviewAreaHRule", false)

end

function HouseSignWindow.ShowCustTabPreviewArea()

	local tabWindowName = WindowName.."TabWindow4"

	WindowSetShowing (tabWindowName.."HouseSignTitle", true)
	WindowSetShowing (tabWindowName.."CurrentHouseSignText", true)
	WindowSetShowing (tabWindowName.."HouseSignHangarTitle", true)
	WindowSetShowing (tabWindowName.."CurrentHouseSignHangarText", true)
	if (data.HasSignPost == 1) then
		WindowSetShowing (tabWindowName.."SignPostTitle", true)
		WindowSetShowing (tabWindowName.."CurrentSignPostText", true)
	else
		WindowSetShowing (tabWindowName.."SignPostTitle", false)
		WindowSetShowing (tabWindowName.."CurrentSignPostText", false)
	
	end
	if (data.CurrentFoundationStyleIndex ~= -1) then
		WindowSetShowing (tabWindowName.."FoundationStyleTitle", true)
		WindowSetShowing (tabWindowName.."CurrentFoundationStyleText", true)
	else
		WindowSetShowing (tabWindowName.."FoundationStyleTitle", false)
		WindowSetShowing (tabWindowName.."CurrentFoundationStyleText", false)
	
	end
	
	WindowSetShowing (tabWindowName.."PreviewAreaVRule", true)
	WindowSetShowing (tabWindowName.."PreviewAreaHRule", true)

	LabelSetText (tabWindowName.."HouseSignTitle",GetStringFromTid(1078880)) -- Current House Sign

	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowCustTabPreviewArea: index =  "..StringToWString(tostring(data.CurrentHouseSignIndex)))
	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowCustTabPreviewArea: housesign icon id =  "..StringToWString(tostring(WindowData.HouseSignListCSV[data.CurrentHouseSignIndex].IconId)))
	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowCustTabPreviewArea: housesign tid =  "..StringToWString(tostring(WindowData.HouseSignListCSV[data.CurrentHouseSignIndex].NameTid)))
	
	LabelSetText (tabWindowName.."CurrentHouseSignText",GetStringFromTid(WindowData.HouseSignListCSV[data.CurrentHouseSignIndex].NameTid))
	LabelSetText (tabWindowName.."HouseSignHangarTitle",GetStringFromTid(1078881)) -- Current Sign Hangar
	LabelSetText (tabWindowName.."CurrentHouseSignHangarText",GetStringFromTid(WindowData.HouseSignHangarListCSV[data.CurrentHouseSignHangarIndex].NameTid))
	LabelSetText (tabWindowName.."SignPostTitle",GetStringFromTid(1078882)) -- Current Sign Post
	LabelSetText (tabWindowName.."CurrentSignPostText",GetStringFromTid(WindowData.HouseSignPostListCSV[data.CurrentHouseSignPostIndex].NameTid))
	if (data.CurrentFoundationStyleIndex ~= -1) then
		LabelSetText (tabWindowName.."FoundationStyleTitle",GetStringFromTid(1078883)) -- Current Foundation Style
		LabelSetText (tabWindowName.."CurrentFoundationStyleText",GetStringFromTid(WindowData.FoundationStyleListCSV[data.CurrentFoundationStyleIndex].NameTid))
	end
	
	--HouseSignImage
	--local currentSignHangarIndex = 1
	--name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(HSW_HouseSignList[currentSignHangarIndex].IconId,45,45)
	name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(WindowData.HouseSignListCSV[data.CurrentHouseSignIndex].IconId,45,45)
	WindowSetDimensions(tabWindowName.."HouseSignImage", newWidth, newHeight)
	DynamicImageSetTexture(tabWindowName.."HouseSignImage", name, x, y )
	DynamicImageSetTextureScale(tabWindowName.."HouseSignImage", scale)		

	WindowSetShowing (tabWindowName.."HouseSignImage", true)

	--HouseSignHangarImage
	--local currentSignHangarIndex = 1
	--name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(HSW_SignHangarList[currentSignHangarIndex].IconId,45,45)
	name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(WindowData.HouseSignHangarListCSV[data.CurrentHouseSignHangarIndex].IconId,45,45)
	WindowSetDimensions(tabWindowName.."HouseSignHangarImage", newWidth, newHeight)
	DynamicImageSetTexture(tabWindowName.."HouseSignHangarImage", name, x, y )
	DynamicImageSetTextureScale(tabWindowName.."HouseSignHangarImage", scale)		

	WindowSetShowing (tabWindowName.."HouseSignHangarImage", true)

	--SignPostImage
	if (data.HasSignPost == 1) then
		--local currentSignHangarIndex = 1
		--name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(HSW_SignPostList[currentSignHangarIndex].IconId,45,45)
		name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(WindowData.HouseSignPostListCSV[data.CurrentHouseSignPostIndex].IconId,45,45)
		WindowSetDimensions(tabWindowName.."SignPostImage", newWidth, newHeight)
		DynamicImageSetTexture(tabWindowName.."SignPostImage", name, x, y )
		DynamicImageSetTextureScale(tabWindowName.."SignPostImage", scale)		

		WindowSetShowing (tabWindowName.."SignPostImage", true)
	else
		WindowSetShowing (tabWindowName.."SignPostImage", false)
	
	end
	--FoundationStyleImage
	
	-- server doesn't know the foundation style for  pre-fab houses 
	if (data.CurrentFoundationStyleIndex ~= -1) then
		--name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(HSW_FoundationStyleList[currentSignHangarIndex].IconId,45,45)
		name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(WindowData.FoundationStyleListCSV[data.CurrentFoundationStyleIndex].IconId,45,45)
		WindowSetDimensions(tabWindowName.."FoundationStyleImage", newWidth, newHeight)
		DynamicImageSetTexture(tabWindowName.."FoundationStyleImage", name, x, y )
		DynamicImageSetTextureScale(tabWindowName.."FoundationStyleImage", scale)		
		WindowSetShowing (tabWindowName.."FoundationStyleImage", true)
	else
		WindowSetShowing (tabWindowName.."FoundationStyleImage", false)	
	end
end

function HouseSignWindow.UpdateAccessSubTypeText()

	if (HSW_AccessSubType == 1) then
			LabelSetText (WindowName.."TabWindow2ChangeSubTypeText",GetStringFromTid(1078884)) -- All
	elseif (HSW_AccessSubType == 2) then
			LabelSetText (WindowName.."TabWindow2ChangeSubTypeText",GetStringFromTid(1078885)) -- General Access
	elseif (HSW_AccessSubType == 3) then
			LabelSetText (WindowName.."TabWindow2ChangeSubTypeText",GetStringFromTid(1078886)) -- Friends List
	elseif (HSW_AccessSubType == 4) then
			LabelSetText (WindowName.."TabWindow2ChangeSubTypeText",GetStringFromTid(1078887)) -- Co-Owners List
	elseif (HSW_AccessSubType == 5) then
			LabelSetText (WindowName.."TabWindow2ChangeSubTypeText",GetStringFromTid(1078888)) -- Banned List
	end
end

function HouseSignWindow.UpdateClearListButton()

	if (HSW_AccessSubType == 1) then
			LabelSetText (WindowName.."ClearListButtonText",L"")
			WindowSetShowing (WindowName.."ClearListButtonText", false)
			WindowSetShowing (WindowName.."ClearListButton", false)
	elseif (HSW_AccessSubType == 2) then
			LabelSetText (WindowName.."ClearListButtonText",GetStringFromTid(1060700)) -- Clear General Access List
			WindowSetShowing (WindowName.."ClearListButtonText", true)
			WindowSetShowing (WindowName.."ClearListButton", true)
	elseif (HSW_AccessSubType == 3) then
			LabelSetText (WindowName.."ClearListButtonText",GetStringFromTid(1011245)) -- Clear Friends List
			WindowSetShowing (WindowName.."ClearListButtonText", true)
			WindowSetShowing (WindowName.."ClearListButton", true)
	elseif (HSW_AccessSubType == 4) then
			LabelSetText (WindowName.."ClearListButtonText",GetStringFromTid(1011268)) -- Clear Co-Owners List
			WindowSetShowing (WindowName.."ClearListButtonText", true)
			WindowSetShowing (WindowName.."ClearListButton", true)
	elseif (HSW_AccessSubType == 5) then
			LabelSetText (WindowName.."ClearListButtonText",GetStringFromTid(1060698))	-- Clear Banned List
			WindowSetShowing (WindowName.."ClearListButtonText", true)
			WindowSetShowing (WindowName.."ClearListButton", true)
	end
end

function HouseSignWindow.CreateListofPlayersSlots(windowName, listname, low, high)
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateListofPlayersSlots ")

	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateListofPlayersSlots: low "..StringToWString(tostring(low)))
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateListofPlayersSlots: high "..StringToWString(tostring(high)))

	local parent = windowName..listname.."ScrollingListBoxScrollChild"
	for i=low, high do
		slotName = parent.."Item"..i
		CreateWindowFromTemplate(slotName, "HSWAccessTabEntryTemplate", parent)
		WindowSetId(slotName.."Button",i)

		--Debug.PrintToDebugConsole(L"HouseSignWindow.CreateListofPlayersSlots: Creating entry: "..StringToWString(slotName))
		
		if i == 1 then
			WindowAddAnchor(slotName, "topleft", parent, "topleft", 0, 0)
		else
			WindowAddAnchor(slotName, "bottomleft", parent.."Item"..i-1, "topleft", 0, 0)
		end

	end

end -- HouseSignWindow.CreateListofPlayersSlots

function HouseSignWindow.UpdateListOfPlayers()
	Debug.PrintToDebugConsole(L"HouseSignWindow.UpdateListOfPlayers ")

	WindowSetShowing (WindowName.."TabWindow2", false)
	WindowSetShowing (WindowName.."TabWindow2MasterScrollingListBox", false)
	WindowSetShowing (WindowName.."TabWindow2GeneralScrollingListBox", false)
	WindowSetShowing (WindowName.."TabWindow2FriendsScrollingListBox", false)
	WindowSetShowing (WindowName.."TabWindow2CoOwnersScrollingListBox", false)
	WindowSetShowing (WindowName.."TabWindow2BannedScrollingListBox", false)
	WindowSetShowing (WindowName.."TabWindow2", true)


	if (HSW_AccessSubType == 1) then
		HouseSignWindow.ShowMasterList()
	elseif (HSW_AccessSubType == 2) then
		HouseSignWindow.ShowGeneralList()
	elseif (HSW_AccessSubType == 3) then
		HouseSignWindow.ShowFriendsList()
	elseif (HSW_AccessSubType == 4) then
		HouseSignWindow.ShowCoOwnersList()
	elseif (HSW_AccessSubType == 5) then
		HouseSignWindow.ShowBannedList()
	end



end

function HouseSignWindow.ConvertStatusStringToTid(status)

	if (status == L"Friend") then
	  return (GetStringFromTid(1078866))
	elseif (status == L"Co-Owner") then
	  return (GetStringFromTid(1078867))
	elseif (status == L"Banned") then
	  return (GetStringFromTid(1078868))	
	elseif (status == L"Access") then
	  return (GetStringFromTid(1078864))
	end
end

function HouseSignWindow.CreateMasterList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateMasterList ")

	HouseSignWindow.CreateListofPlayersSlots(WindowName.."TabWindow2","Master",1,table.getn(HSW_MasterList))
	local startIndex = 1
	local endIndex = table.getn(HSW_MasterList)

	for i = startIndex, endIndex do
		LabelSetText (WindowName.."TabWindow2MasterScrollingListBoxScrollChildItem"..tostring(i).."NameText",HSW_MasterList[i].name)	
		LabelSetText (WindowName.."TabWindow2MasterScrollingListBoxScrollChildItem"..tostring(i).."StatusText",HouseSignWindow.ConvertStatusStringToTid(HSW_MasterList[i].status))	
	end

	--WindowRefreshScrollChild(WindowName.."TabWindow2MasterScrollingListBox".."ScrollChild")

	--ScrollWindowSetOffset( WindowName.."TabWindow2MasterScrollingListBox", 0 )
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow2MasterScrollingListBoxScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2MasterScrollingListBox")	

end

function HouseSignWindow.ShowMasterList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowMasterList ")

	WindowSetShowing (WindowName.."TabWindow2MasterScrollingListBox", true)
	--WindowRefreshScrollChild(WindowName.."TabWindow2MasterScrollingListBox".."ScrollChild")

	--ScrollWindowSetOffset( WindowName.."TabWindow2MasterScrollingListBox", 0 )
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow2MasterScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2MasterScrollingListBox")	

end

function HouseSignWindow.CreateGeneralList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateGeneralList ")
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateGeneralList - baseOffset = "..StringToWString(tostring(baseOffset)))

	HouseSignWindow.CreateListofPlayersSlots(WindowName.."TabWindow2","General",1,table.getn(HSW_GeneralList))
	local startIndex = 1
	local endIndex = table.getn(HSW_GeneralList)
	
	for i = startIndex, endIndex do
		LabelSetText (WindowName.."TabWindow2GeneralScrollingListBoxScrollChildItem"..tostring(i).."NameText",HSW_GeneralList[i].name)	
		LabelSetText (WindowName.."TabWindow2GeneralScrollingListBoxScrollChildItem"..tostring(i).."StatusText",HouseSignWindow.ConvertStatusStringToTid(HSW_GeneralList[i].status))	
		--Debug.PrintToDebugConsole(L"HouseSignWindow.CreateGeneralList: name-"..StringToWString(tostring(i))..L" = "..HSW_GeneralList[i].name)
	end
	--WindowRefreshScrollChild(WindowName.."TabWindow2GeneralScrollingListBox".."ScrollChild")
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	

end

function HouseSignWindow.ShowGeneralList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowGeneralList ")

	WindowSetShowing (WindowName.."TabWindow2GeneralScrollingListBox", true)
	--WindowRefreshScrollChild(WindowName.."TabWindow2GeneralScrollingListBox".."ScrollChild")
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	

end

function HouseSignWindow.CreateFriendsList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateFriendsList ")

	HouseSignWindow.CreateListofPlayersSlots(WindowName.."TabWindow2","Friends",1,table.getn(HSW_FriendsList))
	local startIndex = 1
	local endIndex = table.getn(HSW_FriendsList)

	for i = startIndex, endIndex do
		LabelSetText (WindowName.."TabWindow2FriendsScrollingListBoxScrollChildItem"..tostring(i).."NameText",HSW_FriendsList[i].name)	
		LabelSetText (WindowName.."TabWindow2FriendsScrollingListBoxScrollChildItem"..tostring(i).."StatusText",HouseSignWindow.ConvertStatusStringToTid(HSW_FriendsList[i].status))	
	end

	--WindowRefreshScrollChild(WindowName.."TabWindow2FriendsScrollingListBox".."ScrollChild")
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	

end


function HouseSignWindow.ShowFriendsList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowFriendsList ")

	WindowSetShowing (WindowName.."TabWindow2FriendsScrollingListBox", true)
	--WindowRefreshScrollChild(WindowName.."TabWindow2FriendsScrollingListBox".."ScrollChild")
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	

end

function HouseSignWindow.CreateCoOwnersList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateCoOwnersList ")

	HouseSignWindow.CreateListofPlayersSlots(WindowName.."TabWindow2","CoOwners",1,table.getn(HSW_CoOwnersList))
	local startIndex = 1
	local endIndex = table.getn(HSW_CoOwnersList)

	for i = startIndex, endIndex do
		LabelSetText (WindowName.."TabWindow2CoOwnersScrollingListBoxScrollChildItem"..tostring(i).."NameText",HSW_CoOwnersList[i].name)	
		LabelSetText (WindowName.."TabWindow2CoOwnersScrollingListBoxScrollChildItem"..tostring(i).."StatusText",HouseSignWindow.ConvertStatusStringToTid(HSW_CoOwnersList[i].status))	
	end

	--WindowRefreshScrollChild(WindowName.."TabWindow2CoOwnersScrollingListBox".."ScrollChild")
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	

end

function HouseSignWindow.ShowCoOwnersList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowCoOwnersList ")

	WindowSetShowing (WindowName.."TabWindow2CoOwnersScrollingListBox", true)
	--WindowRefreshScrollChild(WindowName.."TabWindow2CoOwnersScrollingListBox".."ScrollChild")
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	

end

function HouseSignWindow.CreateBannedList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateBannedList ")

	HouseSignWindow.CreateListofPlayersSlots(WindowName.."TabWindow2","Banned",1,table.getn(HSW_BannedList))
	local startIndex = 1
	local endIndex = table.getn(HSW_BannedList)

	for i = startIndex, endIndex do
		LabelSetText (WindowName.."TabWindow2BannedScrollingListBoxScrollChildItem"..tostring(i).."NameText",HSW_BannedList[i].name)	
		LabelSetText (WindowName.."TabWindow2BannedScrollingListBoxScrollChildItem"..tostring(i).."StatusText",HouseSignWindow.ConvertStatusStringToTid(HSW_BannedList[i].status))	
	end

	--WindowRefreshScrollChild(WindowName.."TabWindow2BannedScrollingListBox".."ScrollChild")
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow2BannedScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2BannedScrollingListBox")	

end

function HouseSignWindow.ShowBannedList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowBannedList ")

	WindowSetShowing (WindowName.."TabWindow2BannedScrollingListBox", true)
	--WindowRefreshScrollChild(WindowName.."TabWindow2BannedScrollingListBox".."ScrollChild")
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow2BannedScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2BannedScrollingListBox")	

end


function HouseSignWindow.CreateTabSlot(index, tabName, listName, templateName)

	local parentName = tabName..listName.."ScrollingListBoxScrollChild"
	local slotName = parentName.."Item"..index
	local relativeTo = parentName.."Item"..(index-1)
	
	CreateWindowFromTemplate(slotName, templateName, parentName)
	WindowSetId(slotName.."Button",index)
	
	if (index == 1) then
		WindowAddAnchor(slotName, "topleft", parentName, "topleft", 0, 0)
	else
		WindowAddAnchor(slotName, "bottomleft", relativeTo, "topleft", 0, 0)
	end

	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateListofCustTabSlots: Creating entry: "..StringToWString(slotName))
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateListofCustTabSlots: button id: "..StringToWString(tostring(buttonID)))
	
	return slotName
end


function HouseSignWindow.CreateListofCustTabSlots(tabName, listName, low, high, templateName)
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateListofCustTabSlots ")

	--Debug.PrintToDebugConsole(L"HouseSignWindow.CreateListofCustTabSlots: low "..StringToWString(tostring(low)))
	--Debug.PrintToDebugConsole(L"HouseSignWindow.CreateListofCustTabSlots: high "..StringToWString(tostring(high)))

	for i=low, high do
		HouseSignWindow.CreateTabSlot(i, tabName, listName, templateName )
	end

end -- HouseSignWindow.CreateListofCustTabSlots


function HouseSignWindow.CreateHouseSignList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateHouseSignList ")

	--HouseSignWindow.CreateListofCustTabSlots(WindowName.."TabWindow4","CustTabHouseSign",1,table.getn(HSW_HouseSignList))
	HouseSignWindow.CreateListofCustTabSlots(WindowName.."TabWindow4","CustTabHouseSign",1,table.getn(WindowData.HouseSignListCSV),"HSWCustomizeTabHouseSignEntryTemplate")
	local startIndex = 1
	local endIndex = table.getn(WindowData.HouseSignListCSV)
	
	for i = startIndex, endIndex do
		name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(WindowData.HouseSignListCSV[i].IconId,45,45)
		WindowSetDimensions(WindowName.."TabWindow4CustTabHouseSignScrollingListBoxScrollChildItem"..tostring(i).."Icon", newWidth, newHeight)
		DynamicImageSetTexture(WindowName.."TabWindow4CustTabHouseSignScrollingListBoxScrollChildItem"..tostring(i).."Icon", name, x, y )
		DynamicImageSetTextureScale(WindowName.."TabWindow4CustTabHouseSignScrollingListBoxScrollChildItem"..tostring(i).."Icon", scale)		

		LabelSetText (WindowName.."TabWindow4CustTabHouseSignScrollingListBoxScrollChildItem"..tostring(i).."Text",GetStringFromTid(WindowData.HouseSignListCSV[i].NameTid))	
	end

	--WindowRefreshScrollChild(WindowName.."TabWindow4CustTabHouseSignScrollingListBox".."ScrollChild")
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow4CustTabHouseSignScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow4CustTabHouseSignScrollingListBox")	

end




function HouseSignWindow.CreateHouseSignHangarList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateHouseSignHangarList ")

	HouseSignWindow.CreateListofCustTabSlots(WindowName.."TabWindow4","CustTabSignHangar",1,table.getn(WindowData.HouseSignHangarListCSV),"HSWCustomizeTabHouseSignHangarEntryTemplate")
	local startIndex = 1
	local endIndex = table.getn(WindowData.HouseSignHangarListCSV)

	for i = startIndex, endIndex do
		name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(WindowData.HouseSignHangarListCSV[i].IconId,45,45)
		WindowSetDimensions(WindowName.."TabWindow4CustTabSignHangarScrollingListBoxScrollChildItem"..tostring(i).."Icon", newWidth, newHeight)
		DynamicImageSetTexture(WindowName.."TabWindow4CustTabSignHangarScrollingListBoxScrollChildItem"..tostring(i).."Icon", name, x, y )
		DynamicImageSetTextureScale(WindowName.."TabWindow4CustTabSignHangarScrollingListBoxScrollChildItem"..tostring(i).."Icon", scale)		

		LabelSetText (WindowName.."TabWindow4CustTabSignHangarScrollingListBoxScrollChildItem"..tostring(i).."Text",GetStringFromTid(WindowData.HouseSignHangarListCSV[i].NameTid))	
	end

	--WindowRefreshScrollChild(WindowName.."TabWindow4CustTabSignHangarScrollingListBox".."ScrollChild")
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow4CustTabSignHangarScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow4CustTabSignHangarScrollingListBox")	

end

function HouseSignWindow.CreateSignPostList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateSignPostList ")

	HouseSignWindow.CreateListofCustTabSlots(WindowName.."TabWindow4","CustTabSignPost",1,table.getn(WindowData.HouseSignPostListCSV),"HSWCustomizeTabSignPostEntryTemplate")
	local startIndex = 1
	local endIndex = table.getn(WindowData.HouseSignPostListCSV)

	for i = startIndex, endIndex do
		name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(WindowData.HouseSignPostListCSV[i].IconId,45,45)
		WindowSetDimensions(WindowName.."TabWindow4CustTabSignPostScrollingListBoxScrollChildItem"..tostring(i).."Icon", newWidth, newHeight)
		DynamicImageSetTexture(WindowName.."TabWindow4CustTabSignPostScrollingListBoxScrollChildItem"..tostring(i).."Icon", name, x, y )
		DynamicImageSetTextureScale(WindowName.."TabWindow4CustTabSignPostScrollingListBoxScrollChildItem"..tostring(i).."Icon", scale)		

		LabelSetText (WindowName.."TabWindow4CustTabSignPostScrollingListBoxScrollChildItem"..tostring(i).."Text",GetStringFromTid(WindowData.HouseSignPostListCSV[i].NameTid))	
	end

	--WindowRefreshScrollChild(WindowName.."TabWindow4CustTabSignPostScrollingListBox".."ScrollChild")
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow4CustTabSignPostScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow4CustTabSignPostScrollingListBox")	

end

function HouseSignWindow.CreateFoundationStyleList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.CreateFoundationStyleList ")

	--HouseSignWindow.CreateListofCustTabSlots(WindowName.."TabWindow4","CustTabFoundationStyle",1,table.getn(WindowData.FoundationStyleListCSV),"HSWCustomizeTabFoundationStyleEntryTemplate")

	local slotNum = 1
	local slotName
	for i = 1, table.getn(WindowData.FoundationStyleListCSV) do
		
		if WindowData.FoundationStyleListCSV[i].Entitlement == nil then
			Debug.PrintToDebugConsole(L"ERROR HouseSignWindow.CreateFoundationStyleList: Entitlement info not set")
		
		elseif HasEntitlement( WindowData.FoundationStyleListCSV[i].Entitlement ) then
		
			slotName = HouseSignWindow.CreateTabSlot(slotNum, WindowName.."TabWindow4", "CustTabFoundationStyle", "HSWCustomizeTabFoundationStyleEntryTemplate")
			slotNum = slotNum + 1
			
			name, x, y, scale, newWidth, newHeight = HouseSignWindow.RequestTileArt(WindowData.FoundationStyleListCSV[i].IconId,45,45)
			WindowSetDimensions(slotName.."Icon", newWidth, newHeight)
			DynamicImageSetTexture(slotName.."Icon", name, x, y )
			DynamicImageSetTextureScale(slotName.."Icon", scale)		

			LabelSetText (slotName.."Text",GetStringFromTid(WindowData.FoundationStyleListCSV[i].NameTid))	
		end
	end

	ScrollWindowUpdateScrollRect(WindowName.."TabWindow4CustTabFoundationStyleScrollingListBox")	
end

function HouseSignWindow.ShowSignHangarList()
	Debug.PrintToDebugConsole(L"HouseSignWindow.ShowSignHangarList ")

	WindowSetShowing (WindowName.."TabWindow4CustTabSignHangarScrollingListBox", true)
	--WindowRefreshScrollChild(WindowName.."TabWindow4CustTabSignHangarScrollingListBox".."ScrollChild")
	--ScrollWindowUpdateScrollRect(WindowName.."TabWindow4CustTabSignHangarScrollingListBox".."ScrollChild")	
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow4CustTabSignHangarScrollingListBox")	

end

function HouseSignWindow.ShowHouseSignStuff()

	local CustTabMiniWindow = whichWindow
	-- show the vert  bar
	--WindowSetShowing (WindowName.."TabWindow4CustomizeTabVRule", true)
	
	-- show the select & cancel buttons
	WindowSetShowing (WindowName.."TabWindow4CustomizeTabCancelButton", true)
	WindowSetShowing (WindowName.."TabWindow4CustomizeTabSelectButton", true)
	
	-- show the scrolling list
	LabelSetText (WindowName.."TabWindow4CustTabHouseSignTitleText",GetStringFromTid(1078889)) -- Choose your house sign style
	WindowSetShowing (WindowName.."TabWindow4CustTabHouseSignTitleText", true)
	WindowSetShowing (WindowName.."TabWindow4CustTabHouseSignScrollingListBox", true)
	-- change the window title
	
		

end

function HouseSignWindow.ShowSignHangarStuff()

	-- show the vert  bar
	--WindowSetShowing (WindowName.."TabWindow4CustomizeTabVRule", true)
	
	-- show the select & cancel buttons
	WindowSetShowing (WindowName.."TabWindow4CustomizeTabCancelButton", true)
	WindowSetShowing (WindowName.."TabWindow4CustomizeTabSelectButton", true)
	
	-- show the scrolling list
	LabelSetText (WindowName.."TabWindow4CustTabHouseSignHangarTitleText",GetStringFromTid(1078890)) -- Choose your house sign hangar style
	WindowSetShowing (WindowName.."TabWindow4CustTabHouseSignHangarTitleText", true)
	WindowSetShowing (WindowName.."TabWindow4CustTabSignHangarScrollingListBox", true)
	-- change the window title
	
		

end

function HouseSignWindow.ShowSignPostStuff()

	-- show the vert  bar
	--WindowSetShowing (WindowName.."TabWindow4CustomizeTabVRule", true)
	
	-- show the select & cancel buttons
	WindowSetShowing (WindowName.."TabWindow4CustomizeTabCancelButton", true)
	WindowSetShowing (WindowName.."TabWindow4CustomizeTabSelectButton", true)
	
	-- show the scrolling list
	LabelSetText (WindowName.."TabWindow4CustTabSignPostTitleText",GetStringFromTid(1078891)) -- Choose your sign post style
	WindowSetShowing (WindowName.."TabWindow4CustTabSignPostTitleText", true)
	WindowSetShowing (WindowName.."TabWindow4CustTabSignPostScrollingListBox", true)
	-- change the window title
	
		

end

function HouseSignWindow.ShowFoundationStyleStuff()

	-- show the vert  bar
	--WindowSetShowing (WindowName.."TabWindow4CustomizeTabVRule", true)
	
	-- show the select & cancel buttons
	WindowSetShowing (WindowName.."TabWindow4CustomizeTabCancelButton", true)
	WindowSetShowing (WindowName.."TabWindow4CustomizeTabSelectButton", true)
	
	-- show the scrolling list
	LabelSetText (WindowName.."TabWindow4CustTabFoundationTitleText",GetStringFromTid(1078892)) -- Choose your house foundation style
	WindowSetShowing (WindowName.."TabWindow4CustTabFoundationTitleText", true)
	WindowSetShowing (WindowName.."TabWindow4CustTabFoundationStyleScrollingListBox", true)
	-- change the window title
	
end


function HouseSignWindow.HideCustTabMiniWindow()

	CustTabMiniWindow = 0 -- nothing shown
	

	-- hide the vert  bar
	--WindowSetShowing (WindowName.."TabWindow4CustomizeTabVRule", false)
	
	-- hide the select & cancel buttons
	WindowSetShowing (WindowName.."TabWindow4CustomizeTabCancelButton", false)
	WindowSetShowing (WindowName.."TabWindow4CustomizeTabSelectButton", false)
		
	-- hide the scrolling lists
	WindowSetShowing (WindowName.."TabWindow4CustTabHouseSignScrollingListBox", false)
	WindowSetShowing (WindowName.."TabWindow4CustTabSignHangarScrollingListBox", false)
	WindowSetShowing (WindowName.."TabWindow4CustTabSignPostScrollingListBox", false)
	WindowSetShowing (WindowName.."TabWindow4CustTabFoundationStyleScrollingListBox", false)

	WindowSetShowing (WindowName.."TabWindow4CustTabHouseSignTitleText", false)
	WindowSetShowing (WindowName.."TabWindow4CustTabHouseSignHangarTitleText", false)
	WindowSetShowing (WindowName.."TabWindow4CustTabSignPostTitleText", false)
	WindowSetShowing (WindowName.."TabWindow4CustTabFoundationTitleText", false)
		
	-- change the window title

end

-- Information Tab Button handlers
function HouseSignWindow.HandleChangePrivateStatusButton()
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleChangePrivateStatusButton ")

	-- data.PublicStatus 0 = private, 1 = public
	if (data.PublicStatus == 1) then
		value = 341  -- change to private button
	else
		value = 342 -- change to public button
	end
	
	ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
	ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleChangePrivateStatusButton: house id =  "..StringToWString(tostring(WindowData.HouseInfoChange.HouseId)))
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleChangePrivateStatusButton: return house id =  "..StringToWString(tostring(ReturnWindowData.HousingSystem.HouseId)))
	ReturnWindowData.HousingSystem.Command = 101
	ReturnWindowData.HousingSystem.Value = value
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleChangePrivateStatusButton: broadcasting event")
	BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)


end


-- Access Tab Button Handlers
function HouseSignWindow.HandleChangeSubTypeLeftButton()
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleChangeSubTypeLeftButton ")

	-- unhilite current selection before we change which list we are looking at
	HouseSignWindow.UnHiliteScrollingListBoxEntrySelection()

	if ((HSW_AccessSubType - 1) < 1) then
		HSW_AccessSubType = 5
	else
		HSW_AccessSubType = HSW_AccessSubType - 1
	end

	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleChangeSubTypeLeftButton: HSW_AccessSubType = "..StringToWString(tostring(HSW_AccessSubType)))

	HouseSignWindow.HideAccessTabModifyStatusButtons()
	
	
	HouseSignWindow.UpdateAccessSubTypeText()
	HouseSignWindow.UpdateClearListButton() -- the clear list button

	HouseSignWindow.UpdateListOfPlayers()
end

function HouseSignWindow.HandleChangeSubTypeRightButton()
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleChangeSubTypeRightButton ")

	-- unhilite current selection before we change which list we are looking at
	HouseSignWindow.UnHiliteScrollingListBoxEntrySelection()

	if ((HSW_AccessSubType + 1) > 5) then
		HSW_AccessSubType =  1
	else
		HSW_AccessSubType = HSW_AccessSubType + 1
	end

	HouseSignWindow.HideAccessTabModifyStatusButtons()
	

	HouseSignWindow.UpdateAccessSubTypeText()
	HouseSignWindow.UpdateClearListButton() -- the clear list button

	HouseSignWindow.UpdateListOfPlayers()
end


function HouseSignWindow.HandlePlayerEntryButton()
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandlePlayerEntryButton ")


end

function HouseSignWindow.HandleScrollingListBoxEntrySelection()
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleScrollingListBoxEntrySelection ")

	local buttonNum = WindowGetId(SystemData.ActiveWindow.name)
	
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleScrollingListBoxEntrySelection: window =  "..StringToWString(SystemData.ActiveWindow.name))
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleScrollingListBoxEntrySelection: buttonNum =  "..StringToWString(tostring(buttonNum)))

	if (buttonNum > 0) then
		HouseSignWindow.UnHiliteScrollingListBoxEntrySelection()
		HouseSignWindow.HiliteScrollingListBoxEntrySelection(buttonNum)
		HouseSignWindow.ShowAccessTabModifyStatusButtons(buttonNum)
	end

	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleScrollingListBoxEntrySelection: finished processing")

end

-- Customize Tab Button Handlers
function HouseSignWindow.HandleConvertHouseButton()
	if (data.ConvertToCustomizable == 1) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleConvertHouseButton ")

		-- value will be set to 1 if successful
		value = 0
				
		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 102
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleConvertHouseButton: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)

	end
end

function HouseSignWindow.HandleCustomizeThisHouseButton()
	if (data.CustomizeHouse == 1) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustomizeThisHouseButton ")

		-- TODO - spawn the "preparing house to be customized" client side gump

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 128
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustomizeThisHouseButton: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
		
		WindowSetShowing(WindowName, false)

		local okayButton = { textTid=UO_StandardDialog.TID_OKAY }
		local windowData = 
		{
			title = WindowUtils.translateMarkup( GetStringFromTid(1062011) ), -- Preparing House
			body = WindowUtils.translateMarkup( GetStringFromTid(1061834) ), -- This may take a few seconds...
			buttons = { okayButton },
			windowName = "HouseSignWindowCustomizeNotice",
		}

		CustomizationNoticeWindowName = UO_StandardDialog.CreateDialog( windowData )

	end
end

function HouseSignWindow.HandleRelocateMovingCrateButton()
	if (data.RelocateMovingCrate == 1) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleRelocateMovingCrateButton ")

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 104
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleRelocateMovingCrateButton: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
	end
end

function HouseSignWindow.HandleChangeHouseSignButton()
	if (data.ChangeHouseSign == 1) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleChangeHouseSignButton ")
		HouseSignWindow.HideCustTabPreviewArea()
		HouseSignWindow.HideCustTabMiniWindow()
		HouseSignWindow.ShowHouseSignStuff()
	end
end

function HouseSignWindow.HandleChangeHouseSignHangerButton()
	if (data.ChangeHouseSignHanger == 1) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleChangeHouseSignHangerButton ")
		HouseSignWindow.HideCustTabPreviewArea()
		HouseSignWindow.HideCustTabMiniWindow()
		HouseSignWindow.ShowSignHangarStuff(true)
	end
end

function HouseSignWindow.HandleChangeSignpostButton()
	if (data.ChangeSignPost == 1) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleChangeSignpostButton ")
		HouseSignWindow.HideCustTabPreviewArea()
		HouseSignWindow.HideCustTabMiniWindow()
		HouseSignWindow.ShowSignPostStuff()
	end
end

function HouseSignWindow.HandleChangeFoundationStyleButton()
	if (data.ChangeFoundationStyle == 1) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleChangeFoundationStyleButton ")
		HouseSignWindow.HideCustTabPreviewArea()
		HouseSignWindow.HideCustTabMiniWindow()
		HouseSignWindow.ShowFoundationStyleStuff()
	end
end

function HouseSignWindow.HandleRenameHouseButton()
	if (data.RenameHouse == 1) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleRenameHouseButton ")

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 109
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleRenameHouseButton: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)

	end
end

function HouseSignWindow.HandleDemolishHouseButton()
	if (data.DemolishHouse == 1) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleDemolishHouseButton ")

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 110
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleDemolishHouseButton: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
	end

end

function HouseSignWindow.HandleTradeHouseButton()
	if (data.TradeHouse == 1) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleTradeHouseButton ")

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 111
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleTradeHouseButton: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
	end

end

function HouseSignWindow.HandleMakeHousePrimaryButton()
	if (data.MakePrimary == 1) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleMakeHousePrimaryButton ")

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 112
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleMakeHousePrimaryButton: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
	end

end

function HouseSignWindow.HandleCustTabHouseSignScrollingListBoxSelection()
	
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabHouseSignScrollingListBoxSelection ")
	buttonNum = WindowGetId(SystemData.ActiveWindow.name)
	
	if (buttonNum > 0) then
		--Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabHouseSignScrollingListBoxSelection: window =  "..StringToWString(SystemData.ActiveWindow.name))
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabHouseSignScrollingListBoxSelection: buttonNum =  "..StringToWString(tostring(buttonNum)))

		-- convert button to  house sign icon id
		value = WindowData.HouseSignListCSV[buttonNum].IconId

		-- data.CurrentHouseSignIndex is set by HandleHouseInfoChange - based on what the server sends back to us
		

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 105
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabHouseSignScrollingListBoxSelection: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)


	end
end

function HouseSignWindow.HandleCustTabSignHangarScrollingListBoxSelection()
	
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabSignHangarScrollingListBoxSelection ")
	buttonNum = WindowGetId(SystemData.ActiveWindow.name)
	
	if (buttonNum > 0) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabSignHangarScrollingListBoxSelection: window =  "..StringToWString(SystemData.ActiveWindow.name))
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabSignHangarScrollingListBoxSelection: buttonNum =  "..StringToWString(tostring(buttonNum)))

		-- convert button to  house sign icon id
		value = WindowData.HouseSignHangarListCSV[buttonNum].IconId

		-- data.CurrentHouseSignIndex is set by HandleHouseInfoChange - based on what the server sends back to us
		

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 106
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabSignHangarScrollingListBoxSelection: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)


	end
end

function HouseSignWindow.HandleCustTabSignPostScrollingListBoxSelection()
	
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabSignPostScrollingListBoxSelection ")
	buttonNum = WindowGetId(SystemData.ActiveWindow.name)
	
	if (buttonNum > 0) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabSignPostScrollingListBoxSelection: window =  "..StringToWString(SystemData.ActiveWindow.name))
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabSignPostScrollingListBoxSelection: buttonNum =  "..StringToWString(tostring(buttonNum)))

		-- convert button to  house sign post icon id
		value = WindowData.HouseSignPostListCSV[buttonNum].IconId

		-- data.CurrentHouseSignIndex is set by HandleHouseInfoChange - based on what the server sends back to us
		

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 107
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabSignPostScrollingListBoxSelection: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)

	end
end

function HouseSignWindow.HandleCustTabFoundationStyleScrollingListBoxSelection()
	
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabFoundationStyleScrollingListBoxSelection ")
	buttonNum = WindowGetId(SystemData.ActiveWindow.name)
	
	if (buttonNum > 0) then
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabFoundationStyleScrollingListBoxSelection: window =  "..StringToWString(SystemData.ActiveWindow.name))
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabFoundationStyleScrollingListBoxSelection: buttonNum =  "..StringToWString(tostring(buttonNum)))

		-- convert button to  house sign post icon id
		value = WindowData.FoundationStyleListCSV[buttonNum].IconId

		-- data.CurrentHouseSignIndex is set by HandleHouseInfoChange - based on what the server sends back to us
		

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 108
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustTabFoundationStyleScrollingListBoxSelection: broadcasting event with IconId = "..value)
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)

	end
end


function HouseSignWindow.HandleCustomizeTabSelectButton()
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustomizeTabSelectButton ")
		HouseSignWindow.HideCustTabMiniWindow()
		HouseSignWindow.ShowCustTabPreviewArea()
		
end

function HouseSignWindow.HandleCustomizeTabCancelButton()
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleCustomizeTabCancelButton ")
		HouseSignWindow.HideCustTabMiniWindow()
		HouseSignWindow.ShowCustTabPreviewArea()

end

-- OnLButtonDown Handler
function HouseSignWindow.SkillLButtonDown()
end

-- OnLButtonUP Handler
function HouseSignWindow.SkillLButtonUp()
		
end


-- OnMouseOver Handler
function HouseSignWindow.SkillMouseOver()
end

-- clear list button pressed
function HouseSignWindow.HandleClearListButton()
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleClearListButton ")

	if (data.activeTab == 2) then
		if (HSW_AccessSubType == 1) then
			HouseSignWindow.DoNothing()
		elseif (HSW_AccessSubType == 2) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleClearListButton  - clear general")
			HouseSignWindow.UnHiliteScrollingListBoxEntrySelection()
			HouseSignWindow.RequestClearGeneralList()
		elseif (HSW_AccessSubType == 3) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleClearListButton  - clear friends")
			HouseSignWindow.UnHiliteScrollingListBoxEntrySelection()
			HouseSignWindow.RequestClearFriendsList()

		elseif (HSW_AccessSubType == 4) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleClearListButton  - clear co-owners")
			HouseSignWindow.UnHiliteScrollingListBoxEntrySelection()
			HouseSignWindow.RequestClearCoOwnersList()
		elseif (HSW_AccessSubType == 5) then
			Debug.PrintToDebugConsole(L"HouseSignWindow.HandleClearListButton  - clear banned")
			HouseSignWindow.UnHiliteScrollingListBoxEntrySelection()
			HouseSignWindow.RequestClearBanList()
		end
	
	end
end

function HouseSignWindow.RequestClearGeneralList()


	if ((data.IsOwner == 1) or (data.IsCoOwner == 1) or(data.IsFriend == 1)) then
	
		HouseSignWindow.ClearGeneralListWindows()
		HouseSignWindow.ClearMasterListWindows()

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 123
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.RequestClearGeneralList: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
	end
end

function HouseSignWindow.RequestClearFriendsList()

	if ((data.IsOwner == 1) or (data.IsCoOwner == 1) ) then

		HouseSignWindow.ClearFriendsListWindows()
		HouseSignWindow.ClearMasterListWindows()

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 122
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.RequestClearFriendsList: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
	end

end

function HouseSignWindow.RequestClearCoOwnersList()

	if (data.IsOwner == 1) then

		HouseSignWindow.ClearCoOwnersListWindows()
		HouseSignWindow.ClearMasterListWindows()

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 121
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.RequestClearCoOwnersList: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
	end

end

function HouseSignWindow.RequestClearBanList()

	if ((data.IsOwner == 1) or (data.IsCoOwner == 1) or(data.IsFriend == 1)) then

		HouseSignWindow.ClearBannedListWindows()


		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 124
		ReturnWindowData.HousingSystem.Value = value
		Debug.PrintToDebugConsole(L"HouseSignWindow.RequestClearBanList: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
	end

end

function HouseSignWindow.ServerResponseClearGeneralList()

	for i=1,table.getn (HSW_GeneralList) do
		for j = 1,table.getn (HSW_MasterList) do
			if (HSW_MasterList[j].objid == HSW_GeneralList[i].objid) then
				table.remove (HSW_MasterList, j)
			end
		end
		
	end
	
	HSW_GeneralList = {}
	
	HouseSignWindow.CreateGeneralList()
	HouseSignWindow.CreateMasterList()
	
	HSW_CurrentListBoxItemIndex = 0

end

function HouseSignWindow.FailedServerResponseClearGeneralList()

	HouseSignWindow.CreateGeneralList()
	HouseSignWindow.CreateMasterList()

	HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)
end

function HouseSignWindow.ServerResponseClearFriendsList()

	for i=1,table.getn (HSW_FriendsList) do
		for j = 1,table.getn (HSW_MasterList) do
			if (HSW_MasterList[j].objid == HSW_FriendsList[i].objid) then
				table.remove (HSW_MasterList, j)
			end
		end
		
	end
	
	HSW_FriendsList = {}
	
	HouseSignWindow.CreateFriendsList()
	HouseSignWindow.CreateMasterList()
	
	HSW_CurrentListBoxItemIndex = 0

end

function HouseSignWindow.FailedServerResponseClearFriendsList()

	HouseSignWindow.CreateFriendsList()
	HouseSignWindow.CreateMasterList()

	HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)

end

function HouseSignWindow.ServerResponseClearCoOwnersList()

	for i=1,table.getn (HSW_CoOwnersList) do
		for j = 1,table.getn (HSW_MasterList) do
			if (HSW_MasterList[j].objid == HSW_CoOwnersList[i].objid) then
				table.remove (HSW_MasterList, j)
			end
		end
		
	end
	
	HSW_CoOwnersList = {}
	
	HouseSignWindow.CreateCoOwnersList()
	HouseSignWindow.CreateMasterList()
	
	HSW_CurrentListBoxItemIndex = 0

end

function HouseSignWindow.FailedServerResponseClearCoOwnersList()

	HouseSignWindow.CreateCoOwnersList()
	HouseSignWindow.CreateMasterList()
	HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)

end

function HouseSignWindow.ServerResponseClearBannedList()

	
	HSW_BannedList = {}
	
	HouseSignWindow.CreateBannedList()
	
	HSW_CurrentListBoxItemIndex = 0

end

function HouseSignWindow.FailedServerResponseClearBannedList()

	HouseSignWindow.CreateBannedList()
	HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)

end





-- Tab Handler
function HouseSignWindow.ToggleTab()
	-- Get the number of the tab clicked, which should be the last character of its name
	-- NOTE: Obviously, this won't work if you have more than ten tabs
	local tab_clicked = tonumber (string.sub( SystemData.ActiveWindow.name, -1, -1))
	HouseSignWindow.ShowTab(tab_clicked)
	currentTab = tab_clicked  
end

function HouseSignWindow.UnHiliteScrollingListBoxEntrySelection()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.UnHiliteScrollingListBoxEntrySelection")


	if (data.activeTab == 2) and (HSW_CurrentListBoxItemIndex > 0) then
		local itemNum = HSW_CurrentListBoxItemIndex
		Debug.PrintToDebugConsole(L"HouseSignWindow.UnHiliteScrollingListBoxEntrySelection: buttonNum =  "..StringToWString(tostring(buttonNum)))
	
		if (HSW_AccessSubType == 1) then  -- master
			WindowItem = WindowName.."TabWindow2MasterScrollingListBoxScrollChildItem"..tostring(itemNum)
		elseif (HSW_AccessSubType == 2) then -- general
			WindowItem = WindowName.."TabWindow2GeneralScrollingListBoxScrollChildItem"..tostring(itemNum)
		elseif (HSW_AccessSubType == 3) then -- friends
			WindowItem = WindowName.."TabWindow2FriendsScrollingListBoxScrollChildItem"..tostring(itemNum)
		elseif (HSW_AccessSubType == 4) then -- co-owners
			WindowItem = WindowName.."TabWindow2CoOwnersScrollingListBoxScrollChildItem"..tostring(itemNum)
		elseif (HSW_AccessSubType == 5) then -- banned
			WindowItem = WindowName.."TabWindow2BannedScrollingListBoxScrollChildItem"..tostring(itemNum)
		end
	
	
		-- set the selected item white
		LabelSetTextColor( WindowItem.."NameText", 255, 255, 255 )
		LabelSetTextColor( WindowItem.."StatusText", 255, 255, 255 )
		
		-- clear the index since nothing is selected now
		HSW_CurrentListBoxItemIndex = 0
	end
	
end


function HouseSignWindow.HiliteScrollingListBoxEntrySelection(buttonNum)
	Debug.PrintToDebugConsole(L"HousePlacementWindow.HiliteScrollingListBoxEntrySelection")

	Debug.PrintToDebugConsole(L"HouseSignWindow.HiliteScrollingListBoxEntrySelection: buttonNum =  "..StringToWString(tostring(buttonNum)))

	if (data.activeTab == 2) then
		if (HSW_AccessSubType == 1) then  -- master
			WindowItem = WindowName.."TabWindow2MasterScrollingListBoxScrollChildItem"..tostring(buttonNum)
		elseif (HSW_AccessSubType == 2) then -- general
			WindowItem = WindowName.."TabWindow2GeneralScrollingListBoxScrollChildItem"..tostring(buttonNum)
		elseif (HSW_AccessSubType == 3) then -- friends
			WindowItem = WindowName.."TabWindow2FriendsScrollingListBoxScrollChildItem"..tostring(buttonNum)
		elseif (HSW_AccessSubType == 4) then -- co-owners
			WindowItem = WindowName.."TabWindow2CoOwnersScrollingListBoxScrollChildItem"..tostring(buttonNum)
		elseif (HSW_AccessSubType == 5) then -- banned
			WindowItem = WindowName.."TabWindow2BannedScrollingListBoxScrollChildItem"..tostring(buttonNum)
		end
	
		-- set the selected item yellow
		LabelSetTextColor( WindowItem.."NameText", 250, 250, 0 )
		LabelSetTextColor( WindowItem.."StatusText", 250, 250, 0 )
		
		-- set what is currently highlighted
		HSW_CurrentListBoxItemIndex = buttonNum
	end
	
end

function HouseSignWindow.RemoveSelectionFromMasterList()

	-- figure out and remove the entry in the appropriate related list
	
	-- remove entry from the master list
	
	-- rebuild the master list
	
	-- rebuild the related list
	
end

function HouseSignWindow.RemoveSelectionFromGeneralList()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromGeneralList")

	if (HSW_CurrentListBoxItemIndex > 0) then

		Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromGeneralList - removing item "..StringToWString(tostring(HSW_CurrentListBoxItemIndex)))

		
		-- hide the window
		--WindowSetShowing (WindowName.."TabWindow2GeneralScrollingListBox", false)

		-- delete the windows inside the general list scrolling window
		-- first delete all of the child windows
		HouseSignWindow.ClearGeneralListWindows()
	
		-- delete the windows inside the master list scrolling window
		HouseSignWindow.ClearMasterListWindows()

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 119
		ReturnWindowData.HousingSystem.Value = ObjIdMakingRequest
		Debug.PrintToDebugConsole(L"HouseSignWindow.RemoveSelectionFromGeneralList: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)

		-- if successful, HouseSignWindow.ActualRemovePlayerFromGeneralList() will be called
		-- if not successful, HouseSignWindow.FailedRemovePlayerFromGeneralList() will be called
	end
	
end

-- this is called when we get a success response from server
function HouseSignWindow.ActualRemovePlayerFromGeneralList()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.ActualRemovePlayerFromGeneralList")

	-- remove the entry from the master list
	local index = 0
	
	for i = 1, table.getn(HSW_MasterList) do
		if (HSW_MasterList[i].objid == HSW_GeneralList[HSW_CurrentListBoxItemIndex].objid) then
			index = i
			break
		end
	end

	-- remove the entry from the general list
	table.remove (HSW_GeneralList, HSW_CurrentListBoxItemIndex)

	if (index > 0) then
		-- remove entry from the master list
		table.remove (HSW_MasterList, index)
	end
	
	Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromGeneralList - general list is now  "..StringToWString(tostring(table.getn(HSW_GeneralList)))..L" items big")
	Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromGeneralList - master list is now  "..StringToWString(tostring(table.getn(HSW_MasterList)))..L" items big")
		
	-- rebuild the general list scrolling list box
	HouseSignWindow.CreateGeneralList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	

	-- rebuild the master list scrolling window
	HouseSignWindow.CreateMasterList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2MasterScrollingListBox")	
		

	HSW_CurrentListBoxItemIndex = 0
		
	-- hide the status buttons since there is no longer an item selected
	HouseSignWindow.HideAccessTabModifyStatusButtons()

end

-- this is called when we get a failure response from server
function HouseSignWindow.FailedRemovePlayerFromGeneralList()

	-- rebuild the general list scrolling list box
	HouseSignWindow.CreateGeneralList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	

	-- rebuild the master list scrolling list box
	HouseSignWindow.CreateMasterList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2MasterScrollingListBox")	

	-- rehilite selection since we deleted the window
	HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)
		
end


function HouseSignWindow.ClearMasterListWindows()

		-- delete the windows inside the master list scrolling window
		for i = table.getn(HSW_MasterList),1,-1 do
			local tempWindowName = WindowName.."TabWindow2Master".."ScrollingListBoxScrollChild".."Item"..i
			--Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromGeneralList - destroying window "..StringToWString(tempWindowName))
			WindowClearAnchors (tempWindowName)
			WindowForceProcessAnchors (WindowName.."TabWindow2Master".."ScrollingListBox")
			DestroyWindow (tempWindowName)

		end

end

function HouseSignWindow.ClearGeneralListWindows()
		for i = table.getn(HSW_GeneralList),1,-1 do
			local tempWindowName = WindowName.."TabWindow2General".."ScrollingListBoxScrollChild".."Item"..i
			--Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromGeneralList - destroying window "..StringToWString(tempWindowName))
			WindowClearAnchors (tempWindowName)
			WindowForceProcessAnchors (WindowName.."TabWindow2General".."ScrollingListBox")
			DestroyWindow (tempWindowName)

		end
end

function HouseSignWindow.ClearFriendsListWindows()
		for i = table.getn(HSW_FriendsList),1,-1 do
			local tempWindowName = WindowName.."TabWindow2Friends".."ScrollingListBoxScrollChild".."Item"..i
			--Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromFriendsList - destroying window "..StringToWString(tempWindowName))
			WindowClearAnchors (tempWindowName)
			WindowForceProcessAnchors (WindowName.."TabWindow2Friends".."ScrollingListBox")
			DestroyWindow (tempWindowName)

		end
end

function HouseSignWindow.ClearCoOwnersListWindows()
		for i = table.getn(HSW_CoOwnersList),1,-1 do
			local tempWindowName = WindowName.."TabWindow2CoOwners".."ScrollingListBoxScrollChild".."Item"..i
			--Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromCoOwnersList - destroying window "..StringToWString(tempWindowName))
			WindowClearAnchors (tempWindowName)
			WindowForceProcessAnchors (WindowName.."TabWindow2CoOwners".."ScrollingListBox")
			DestroyWindow (tempWindowName)

		end
end

function HouseSignWindow.ClearBannedListWindows()
		for i = table.getn(HSW_BannedList),1,-1 do
			local tempWindowName = WindowName.."TabWindow2Banned".."ScrollingListBoxScrollChild".."Item"..i
			--Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromBannedList - destroying window "..StringToWString(tempWindowName))
			WindowClearAnchors (tempWindowName)
			WindowForceProcessAnchors (WindowName.."TabWindow2Banned".."ScrollingListBox")
			DestroyWindow (tempWindowName)

		end
end

function HouseSignWindow.RemoveSelectionFromFriendsList()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromFriendsList")

	if (HSW_CurrentListBoxItemIndex > 0) then

		Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromFriendsList - removing item "..StringToWString(tostring(HSW_CurrentListBoxItemIndex)))

		
		-- hide the window
		--WindowSetShowing (WindowName.."TabWindow2FriendsScrollingListBox", false)

		-- delete the windows inside the friends list scrolling window
		-- first delete all of the child windows
		HouseSignWindow.ClearFriendsListWindows()

		-- delete the windows inside the master list scrolling window		
		HouseSignWindow.ClearMasterListWindows()

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 118
		ReturnWindowData.HousingSystem.Value = ObjIdMakingRequest
		Debug.PrintToDebugConsole(L"HouseSignWindow.RemoveSelectionFromFriendsList: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)

		-- if successful, HouseSignWindow.ActualRemovePlayerFromFriendsList() will be called
		-- if not successful, HouseSignWindow.FailedRemovePlayerFromFriendsList() will be called
	end
	

end


-- this is called when we get a success response from server
function HouseSignWindow.ActualRemovePlayerFromFriendsList()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.ActualRemovePlayerFromFriendsList")

	-- remove the entry from the master list
	local index = 0
	
	for i = 1, table.getn(HSW_MasterList) do
		if (HSW_MasterList[i].objid == HSW_FriendsList[HSW_CurrentListBoxItemIndex].objid) then
			index = i
			break
		end
	end

	-- remove the entry from the friends list
	table.remove (HSW_FriendsList, HSW_CurrentListBoxItemIndex)

	if (index > 0) then
		-- remove entry from the master list
		table.remove (HSW_MasterList, index)
	end
	
	Debug.PrintToDebugConsole(L"HousePlacementWindow.ActualRemovePlayerFromFriendsList - friends list is now  "..StringToWString(tostring(table.getn(HSW_FriendsList)))..L" items big")
	Debug.PrintToDebugConsole(L"HousePlacementWindow.ActualRemovePlayerFromFriendsList - master list is now  "..StringToWString(tostring(table.getn(HSW_MasterList)))..L" items big")
		
	-- rebuild the friends list scrolling list box
	HouseSignWindow.CreateFriendsList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	

	-- rebuild the master list scrolling window
	HouseSignWindow.CreateMasterList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2MasterScrollingListBox")	
		

	HSW_CurrentListBoxItemIndex = 0
		
	-- hide the status buttons since there is no longer an item selected
	HouseSignWindow.HideAccessTabModifyStatusButtons()

end

-- this is called when we get a failure response from server
function HouseSignWindow.FailedRemovePlayerFromFriendsList()

	-- rebuild the friends list scrolling list box
	HouseSignWindow.CreateFriendsList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	

	-- rebuild the master list scrolling list box
	HouseSignWindow.CreateMasterList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2MasterScrollingListBox")	

	-- rehilite selection since we deleted the window
	HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)
		
end


function HouseSignWindow.RemoveSelectionFromCoOwnersList()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromCoOwnersList")

	if (HSW_CurrentListBoxItemIndex > 0) then

		Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveSelectionFromCoOwnersList - removing item "..StringToWString(tostring(HSW_CurrentListBoxItemIndex)))


		-- delete the windows inside the co-owners list scrolling window
		-- first delete all of the child windows
		HouseSignWindow.ClearCoOwnersListWindows()
		
		-- delete the windows inside the master list scrolling window
		
		HouseSignWindow.ClearMasterListWindows()

		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 117
		ReturnWindowData.HousingSystem.Value = ObjIdMakingRequest
		Debug.PrintToDebugConsole(L"HouseSignWindow.RemoveSelectionFromFriendsList: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)

		-- if successful, HouseSignWindow.ActualRemovePlayerFromCoOwnersList() will be called
		-- if not successful, HouseSignWindow.FailedRemovePlayerFromCoOwnersList() will be called
	end
	

end


-- this is called when we get a success response from server
function HouseSignWindow.ActualRemovePlayerFromCoOwnersList()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.ActualRemovePlayerFromCoOwnersList")

	-- remove the entry from the master list
	local index = 0
	
	for i = 1, table.getn(HSW_MasterList) do
		if (HSW_MasterList[i].objid == HSW_CoOwnersList[HSW_CurrentListBoxItemIndex].objid) then
			index = i
			break
		end
	end

	-- remove the entry from the friends list
	table.remove (HSW_CoOwnersList, HSW_CurrentListBoxItemIndex)

	if (index > 0) then
		-- remove entry from the master list
		table.remove (HSW_MasterList, index)
	end
	
	Debug.PrintToDebugConsole(L"HousePlacementWindow.ActualRemovePlayerFromCoOwnersList - co-owners list is now  "..StringToWString(tostring(table.getn(HSW_CoOwnersList)))..L" items big")
	Debug.PrintToDebugConsole(L"HousePlacementWindow.ActualRemovePlayerFromCoOwnersList - master list is now  "..StringToWString(tostring(table.getn(HSW_MasterList)))..L" items big")
		
	-- rebuild the co-owners list scrolling list box
	HouseSignWindow.CreateCoOwnersList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	

	-- rebuild the master list scrolling window
	HouseSignWindow.CreateMasterList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2MasterScrollingListBox")	
		

	HSW_CurrentListBoxItemIndex = 0
		
	-- hide the status buttons since there is no longer an item selected
	HouseSignWindow.HideAccessTabModifyStatusButtons()

end

-- this is called when we get a failure response from server
function HouseSignWindow.FailedRemovePlayerFromCoOwnersList()

	-- rebuild the friends list scrolling list box
	HouseSignWindow.CreateCoOwnersList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	

	-- rebuild the master list scrolling list box
	HouseSignWindow.CreateMasterList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2MasterScrollingListBox")	

	-- rehilite selection since we deleted the window
	HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)
		
end


function HouseSignWindow.RemoveSelectionFromMasterList()

	-- trick the HSW_CurrentListBoxItemIndex to think we are on the status list of whose status we currently have selected
	if (HSW_MasterList[HSW_CurrentListBoxItemIndex].status == L"Co-Owner") then
		for i = 1,table.getn(HSW_CoOwnersList) do
			if (HWS_CoOwnersList[i].objid == HSW_MasterList[HSW_CurrentListBoxItemIndex].objid) then
				HSW_CurrentListBoxItemIndex = i
				HouseSignWindow.RemoveSelectionFromCoOwnersList()
				-- we are looking at the master list so it should still be visible when everything updates
				break
			end
		end
	elseif (HSW_MasterList[HSW_CurrentListBoxItemIndex].status == L"Friend") then
		for i = 1,table.getn(HSW_FriendsList) do
			if (HSW_FriendsList[i].objid == HSW_MasterList[HSW_CurrentListBoxItemIndex].objid) then
				HSW_CurrentListBoxItemIndex = i
				HouseSignWindow.RemoveSelectionFromFriendsList()
				-- we are looking at the master list so it should still be visible when everything updates
				break
			end
		end

	elseif (HSW_MasterList[HSW_CurrentListBoxItemIndex].status == L"Access") then
		for i = 1,table.getn(HSW_GeneralList) do
			if (HSW_GeneralList[i].objid == HSW_MasterList[HSW_CurrentListBoxItemIndex].objid) then
				HSW_CurrentListBoxItemIndex = i
				HouseSignWindow.RemoveSelectionFromGeneralList()
				-- we are looking at the master list so it should still be visible when everything updates
				break
			end
		end

	end	
	

end

function HouseSignWindow.HandleRemoveAccessButton()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleRemoveAccessButton")

	-- figure out which list we are on 
	if (HSW_AccessSubType == 1) then
		HouseSignWindow.RemoveSelectionFromMasterList()
	elseif (HSW_AccessSubType == 2) then
		HouseSignWindow.RemoveSelectionFromGeneralList()
	elseif (HSW_AccessSubType == 3) then
		HouseSignWindow.RemoveSelectionFromFriendsList()
	elseif (HSW_AccessSubType == 4) then
		HouseSignWindow.RemoveSelectionFromCoOwnersList()
	elseif (HSW_AccessSubType == 5) then
		HouseSignWindow.DoNothing()
	end
	
	
end

-- remove the entry at tempIndex from the list that HSW_AccessSubType is set to
-- this won't be called if we are looking master list
function HouseSignWindow.RemoveIndexFromCurrentList(tempIndex)
	Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveIndexFromCurrentList")

	-- remove from the list - pointed to by HSW_CurrentListBoxItemIndex

end

function HouseSignWindow.RemoveIndexFromAnotherList(tempStatus, tempObjId)
	Debug.PrintToDebugConsole(L"HousePlacementWindow.RemoveIndexFromAnotherList")
--[[
	if (tempStatus == L"Co-Owner") then
		-- figure out index of the actual list they are in first
		local tempIndex = 0
		for i = 1, table.getn (HSW_CoOwnersList) do
			if (tempObjId == HSW_CoOwnersList[i].objid) then
				tempIndex = i
				break
			end
		end
		-- remove from the actual list they are in
		if (tempIndex ~= 0) then
			-- remove them
			HouseSignWindow.DoNothing()
			
		end		

	else if (tempStatus == L"Friend") then
		HouseSignWindow.DoNothing()
	else if (tempStatus == L"Access") then
		HouseSignWindow.DoNothing()
	end
]]--
end

function GetObjIdByIndex (theIndex)
	local theObjId = 0

	-- figure out which list we are on 
	if (HSW_AccessSubType == 1) then
		theObjId = HSW_MasterList[theIndex].objid
	elseif (HSW_AccessSubType == 2) then
		theObjId = HSW_GeneralList[theIndex].objid
	elseif (HSW_AccessSubType == 3) then
		theObjId = HSW_FriendsList[theIndex].objid
	elseif (HSW_AccessSubType == 4) then
		theObjId = HSW_CoOwnersList[theIndex].objid
	elseif (HSW_AccessSubType == 5) then
		theObjId = HSW_BannedList[theIndex].objid
	end

	Debug.PrintToDebugConsole(L"HousePlacementWindow.GetObjIdByIndex - objid = "..StringToWString(tostring(theObjId)))

	return theObjId
end

function HouseSignWindow.HandleGiveCoOwnerStatusButtonPressed()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleGiveCoOwnerStatusButton")

	local theStatus = L""
	-- make sure we are not a co-owner already
	if (HSW_AccessSubType == 1) then
		theStatus = HSW_MasterList[HSW_CurrentListBoxItemIndex].status
		if (theStatus == L"Friend") then
			HouseSignWindow.ClearFriendsListWindows()
		elseif (theStatus == L"Access") then
			HouseSignWindow.ClearGeneralListWindows()
		end
		
	elseif (HSW_AccessSubType == 2) then
		theStatus = HSW_GeneralList[HSW_CurrentListBoxItemIndex].status
		HouseSignWindow.ClearGeneralListWindows()
	elseif (HSW_AccessSubType == 3) then
		theStatus = HSW_FriendsList[HSW_CurrentListBoxItemIndex].status
		HouseSignWindow.ClearFriendsListWindows()
	elseif (HSW_AccessSubType == 4) then
		theStatus = HSW_CoOwnersList[HSW_CurrentListBoxItemIndex].status
	end
	
	if (theStatus == L"Co-Owner") then
		HouseSignWindow.DoNothing()
	else
		-- clear co-owners list of windows
		HouseSignWindow.ClearCoOwnersListWindows()

		-- request from server to give co-owner status to this player 
		-- figure out the obj id
		ObjIdMakingRequest = GetObjIdByIndex(HSW_CurrentListBoxItemIndex)

		Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleGiveCoOwnerStatusButton - objid = "..StringToWString(tostring(ObjIdMakingRequest)))


		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 113
		ReturnWindowData.HousingSystem.Value = ObjIdMakingRequest
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleGiveFriendStatusButtonPressed: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
		
		-- for now just directly call this
		--HouseSignWindow.HandleCoOwnerStatusChangeFromServer()
	end
end

function HouseSignWindow.HandleCoOwnerStatusChangeFromServer()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleCoOwnerStatusChangeFromServer")

	
	if (HSW_AccessSubType == 1) then
		local theStatus = HSW_MasterList[HSW_CurrentListBoxItemIndex].status
		
		local tempData = {}
		tempData.name = HSW_MasterList[HSW_CurrentListBoxItemIndex].name
		tempData.status = L"Co-Owner"
		tempData.objid = HSW_MasterList[HSW_CurrentListBoxItemIndex].objid

		-- remove player from old access list
		if (theStatus == L"Friend") then
			local indexToRemove = 0
			for i = 1, table.getn(HSW_FriendsList) do
				if (HSW_FriendsList[i].objid == ObjIdMakingRequest) then
					indexToRemove = i
					break
				end
			end
			if (indexToRemove > 0) then
				table.remove (HSW_FriendsList, indexToRemove)
			end
			HouseSignWindow.CreateFriendsList()
			ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	
		elseif (theStatus == L"Access") then
			local indexToRemove = 0
			for i = 1, table.getn(HSW_GeneralList) do
				if (HSW_GeneralList[i].objid == ObjIdMakingRequest) then
					indexToRemove = i
					break
				end
			end
			if (indexToRemove > 0) then
				table.remove (HSW_GeneralList, indexToRemove)
			end
			HouseSignWindow.CreateGeneralList()
			ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	
		end
		
		table.insert (HSW_CoOwnersList, tempData)

	elseif (HSW_AccessSubType == 2) then
		local tempData = {}
		tempData.name = HSW_GeneralList[HSW_CurrentListBoxItemIndex].name
		tempData.status = L"Co-Owner"
		tempData.objid = HSW_GeneralList[HSW_CurrentListBoxItemIndex].objid
	
		table.insert (HSW_CoOwnersList, tempData)

		table.remove (HSW_GeneralList,HSW_CurrentListBoxItemIndex)
		HouseSignWindow.CreateGeneralList()
		ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	
	elseif (HSW_AccessSubType == 3) then
		local tempData = {}
		tempData.name = HSW_FriendsList[HSW_CurrentListBoxItemIndex].name
		tempData.status = L"Co-Owner"
		tempData.objid = HSW_FriendsList[HSW_CurrentListBoxItemIndex].objid
	
		table.insert (HSW_CoOwnersList, tempData)
		table.remove (HSW_FriendsList,HSW_CurrentListBoxItemIndex)

		HouseSignWindow.CreateFriendsList()
		ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	
	end
	
	HouseSignWindow.CreateCoOwnersList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	

	-- update master list entry
	local masterListIndex = 0
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleCoOwnerStatusChangeFromServer - masterListIndex = "..StringToWString(tostring(masterListIndex)))
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleCoOwnerStatusChangeFromServer - theobjid = "..StringToWString(tostring(theobjid)))

	if (HSW_AccessSubType ~= 1) then
		for i = 1, table.getn (HSW_MasterList) do
			--Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleCoOwnerStatusChangeFromServer - HWS_MasterList[i].objid = "..StringToWString(tostring(theHWS_MasterList[i].objid)))
			if (HSW_MasterList[i].objid == ObjIdMakingRequest) then  -- set by requesting function
				masterListIndex = i
				break
			end
		end
	else
		-- we are looking at the master list, and already have the item selected 
		masterListIndex = HSW_CurrentListBoxItemIndex	
	end
	
	if (masterListIndex ~= 0) then
		HSW_MasterList[masterListIndex].status = L"Co-Owner"
		-- find the window in the master list and update its label

		--Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleCoOwnerStatusChangeFromServer - masterList window name = "..StringToWString(tostring(masterListIndex)))

		LabelSetText (WindowName.."TabWindow2MasterScrollingListBoxScrollChildItem"..tostring(masterListIndex).."StatusText",HSW_MasterList[masterListIndex].status)	

	end

	if (HSW_AccessSubType ~= 1) then
		HSW_CurrentListBoxItemIndex = 0
		HouseSignWindow.HideAccessTabModifyStatusButtons()
	else
		-- redisplay buttons when viewing master list, since which ones are active have now changed
		HouseSignWindow.HideAccessTabModifyStatusButtons()
		HouseSignWindow.ShowAccessTabModifyStatusButtons(HSW_CurrentListBoxItemIndex)
	end
		

end

function HouseSignWindow.FailedCoOwnerStatusChangeFromServer()

	-- make sure we are not a co-owner already
	if (HSW_AccessSubType == 1) then
		theStatus = HSW_MasterList[HSW_CurrentListBoxItemIndex].status
		if (theStatus == L"Friend") then
			HouseSignWindow.CreateFriendsList()
			ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	
		elseif (theStatus == L"Access") then
			HouseSignWindow.CreateGeneralList()
			ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	
		end
		-- item in master list should already be hilited
	elseif (HSW_AccessSubType == 2) then
		HouseSignWindow.CreateGeneralList()
		ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	
		HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)
	elseif (HSW_AccessSubType == 3) then
		HouseSignWindow.CreateFriendsList()
		ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	
		HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)
	end

	HouseSignWindow.CreateCoOwnersList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	

	HouseSignWindow.HideAccessTabModifyStatusButtons()
	HouseSignWindow.ShowAccessTabModifyStatusButtons(HSW_CurrentListBoxItemIndex)
	


end

function HouseSignWindow.HandleGiveFriendStatusButtonPressed()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleGiveFriendStatusButtonPressed")

	local theStatus = L""
	-- make sure we are not a friend already
	if (HSW_AccessSubType == 1) then
		theStatus = HSW_MasterList[HSW_CurrentListBoxItemIndex].status
		if (theStatus == L"Co-Owner") then
			HouseSignWindow.ClearCoOwnersListWindows()
		elseif (theStatus == L"Access") then
			HouseSignWindow.ClearGeneralListWindows()
		end
		
	elseif (HSW_AccessSubType == 2) then
		theStatus = HSW_GeneralList[HSW_CurrentListBoxItemIndex].status
		HouseSignWindow.ClearGeneralListWindows()
	elseif (HSW_AccessSubType == 4) then
		theStatus = HSW_CoOwnersList[HSW_CurrentListBoxItemIndex].status
		HouseSignWindow.ClearCoOwnersListWindows()
	end
	
	if (theStatus == L"Friend") then
		HouseSignWindow.DoNothing()
	else
		-- clear friends list of windows
		HouseSignWindow.ClearFriendsListWindows()

		-- request from server to give co-owner status to this player 
		-- figure out the obj id
		ObjIdMakingRequest = GetObjIdByIndex(HSW_CurrentListBoxItemIndex)

		Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleGiveFriendStatusButton - objid = "..StringToWString(tostring(ObjIdMakingRequest)))


		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 114
		ReturnWindowData.HousingSystem.Value = ObjIdMakingRequest
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleGiveCoOwnerStatusButtonPressed: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
		
	end
end

function HouseSignWindow.HandleFriendsStatusChangeFromServer()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleFriendsStatusChangeFromServer")

	
	if (HSW_AccessSubType == 1) then
		local theStatus = HSW_MasterList[HSW_CurrentListBoxItemIndex].status
		
		local tempData = {}
		tempData.name = HSW_MasterList[HSW_CurrentListBoxItemIndex].name
		tempData.status = L"Friend"
		tempData.objid = HSW_MasterList[HSW_CurrentListBoxItemIndex].objid

		-- remove player from old access list
		if (theStatus == L"Co-Owner") then
			local indexToRemove = 0
			for i = 1, table.getn(HSW_CoOwnersList) do
				if (HSW_CoOwnersList[i].objid == ObjIdMakingRequest) then
					indexToRemove = i
					break
				end
			end
			if (indexToRemove > 0) then
				table.remove (HSW_CoOwnersList, indexToRemove)
			end
			HouseSignWindow.CreateCoOwnersList()
			ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	
		elseif (theStatus == L"Access") then
			local indexToRemove = 0
			for i = 1, table.getn(HSW_GeneralList) do
				if (HSW_GeneralList[i].objid == ObjIdMakingRequest) then
					indexToRemove = i
					break
				end
			end
			if (indexToRemove > 0) then
				table.remove (HSW_GeneralList, indexToRemove)
			end
			HouseSignWindow.CreateGeneralList()
			ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	
		end
		
		table.insert (HSW_FriendsList, tempData)

	elseif (HSW_AccessSubType == 2) then
		local tempData = {}
		tempData.name = HSW_GeneralList[HSW_CurrentListBoxItemIndex].name
		tempData.status = L"Friend"
		tempData.objid = HSW_GeneralList[HSW_CurrentListBoxItemIndex].objid
	
		table.insert (HSW_FriendsList, tempData)

		table.remove (HSW_GeneralList,HSW_CurrentListBoxItemIndex)
		HouseSignWindow.CreateGeneralList()
		ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	
	elseif (HSW_AccessSubType == 4) then
		local tempData = {}
		tempData.name = HSW_CoOwnersList[HSW_CurrentListBoxItemIndex].name
		tempData.status = L"Friend"
		tempData.objid = HSW_CoOwnersList[HSW_CurrentListBoxItemIndex].objid
	
		table.insert (HSW_FriendsList, tempData)
		table.remove (HSW_CoOwnersList,HSW_CurrentListBoxItemIndex)

		HouseSignWindow.CreateCoOwnersList()
		ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	
	end
	
	HouseSignWindow.CreateFriendsList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	

	-- update master list entry
	local masterListIndex = 0

	if (HSW_AccessSubType ~= 1) then
		for i = 1, table.getn (HSW_MasterList) do
			--Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleCoOwnerStatusChangeFromServer - HWS_MasterList[i].objid = "..StringToWString(tostring(theHWS_MasterList[i].objid)))
			if (HSW_MasterList[i].objid == ObjIdMakingRequest) then  -- set by requesting function
				masterListIndex = i
				break
			end
		end
	else
		-- we are looking at the master list, and already have the item selected 
		masterListIndex = HSW_CurrentListBoxItemIndex	
	end

	Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleFriendStatusChangeFromServer - masterListIndex = "..StringToWString(tostring(masterListIndex)))
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleFriendStatusChangeFromServer - theobjid = "..StringToWString(tostring(theobjid)))
	
	if (masterListIndex ~= 0) then
		HSW_MasterList[masterListIndex].status = L"Friend"
		-- find the window in the master list and update its label

		--Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleCoOwnerStatusChangeFromServer - masterList window name = "..StringToWString(tostring(masterListIndex)))

		LabelSetText (WindowName.."TabWindow2MasterScrollingListBoxScrollChildItem"..tostring(masterListIndex).."StatusText",HSW_MasterList[masterListIndex].status)	

	end

	if (HSW_AccessSubType ~= 1) then
		HSW_CurrentListBoxItemIndex = 0
		HouseSignWindow.HideAccessTabModifyStatusButtons()
	else
		-- redisplay buttons when viewing master list, since which ones are active have now changed
		HouseSignWindow.HideAccessTabModifyStatusButtons()
		HouseSignWindow.ShowAccessTabModifyStatusButtons(HSW_CurrentListBoxItemIndex)
	end
		

end

function HouseSignWindow.FailedFriendsStatusChangeFromServer()

	-- make sure we are not a friend already
	if (HSW_AccessSubType == 1) then
		theStatus = HSW_MasterList[HSW_CurrentListBoxItemIndex].status
		if (theStatus == L"Co-Owner") then
			HouseSignWindow.CreateCoOwnersList()
			ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	
		elseif (theStatus == L"Access") then
			HouseSignWindow.CreateGeneralList()
			ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	
		end
		-- item in master list should already be hilited
	elseif (HSW_AccessSubType == 2) then
		HouseSignWindow.CreateGeneralList()
		ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	
		HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)
	elseif (HSW_AccessSubType == 4) then
		HouseSignWindow.CreateCoOwnersList()
		ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	
		HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)
	end

	HouseSignWindow.CreateFriendsList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	

	HouseSignWindow.HideAccessTabModifyStatusButtons()
	HouseSignWindow.ShowAccessTabModifyStatusButtons(HSW_CurrentListBoxItemIndex)
	


end

function HouseSignWindow.HandleGiveGeneralStatusButtonPressed()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleGiveGeneralStatusButtonPressed")

	local theStatus = L""
	-- make sure we are not a general access already
	if (HSW_AccessSubType == 1) then
		theStatus = HSW_MasterList[HSW_CurrentListBoxItemIndex].status
		if (theStatus == L"Co-Owner") then
			HouseSignWindow.ClearCoOwnersListWindows()
		elseif (theStatus == L"Friend") then
			HouseSignWindow.ClearFriendsListWindows()
		end
		
	elseif (HSW_AccessSubType == 3) then
		theStatus = HSW_FriendsList[HSW_CurrentListBoxItemIndex].status
		HouseSignWindow.ClearFriendsListWindows()
	elseif (HSW_AccessSubType == 4) then
		theStatus = HSW_CoOwnersList[HSW_CurrentListBoxItemIndex].status
		HouseSignWindow.ClearCoOwnersListWindows()
	end
	
	if (theStatus == L"Access") then
		HouseSignWindow.DoNothing()
	else
		-- clear general access list of windows
		HouseSignWindow.ClearGeneralListWindows()

		-- request from server to give co-owner status to this player 
		-- figure out the obj id
		ObjIdMakingRequest = GetObjIdByIndex(HSW_CurrentListBoxItemIndex)

		Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleGiveGeneralStatusButton - objid = "..StringToWString(tostring(ObjIdMakingRequest)))


		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		ReturnWindowData.HousingSystem.Command = 115
		ReturnWindowData.HousingSystem.Value = ObjIdMakingRequest
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleGiveGeneralStatusButtonPressed: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
		
	end
end

function HouseSignWindow.HandleGeneralStatusChangeFromServer()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleFriendsStatusChangeFromServer")

	
	if (HSW_AccessSubType == 1) then
		local theStatus = HSW_MasterList[HSW_CurrentListBoxItemIndex].status
		
		local tempData = {}
		tempData.name = HSW_MasterList[HSW_CurrentListBoxItemIndex].name
		tempData.status = L"Access"
		tempData.objid = HSW_MasterList[HSW_CurrentListBoxItemIndex].objid

		-- remove player from old access list
		if (theStatus == L"Co-Owner") then
			local indexToRemove = 0
			for i = 1, table.getn(HSW_CoOwnersList) do
				if (HSW_CoOwnersList[i].objid == ObjIdMakingRequest) then
					indexToRemove = i
					break
				end
			end
			if (indexToRemove > 0) then
				table.remove (HSW_CoOwnersList, indexToRemove)
			end
			HouseSignWindow.CreateCoOwnersList()
			ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	
		elseif (theStatus == L"Friend") then
			local indexToRemove = 0
			for i = 1, table.getn(HSW_FriendsList) do
				if (HSW_FriendsList[i].objid == ObjIdMakingRequest) then
					indexToRemove = i
					break
				end
			end
			if (indexToRemove > 0) then
				table.remove (HSW_FriendsList, indexToRemove)
			end
			HouseSignWindow.CreateFriendsList()
			ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	
		end
		
		table.insert (HSW_GeneralList, tempData)

	elseif (HSW_AccessSubType == 3) then
		local tempData = {}
		tempData.name = HSW_FriendsList[HSW_CurrentListBoxItemIndex].name
		tempData.status = L"Access"
		tempData.objid = HSW_FriendsList[HSW_CurrentListBoxItemIndex].objid
	
		table.insert (HSW_GeneralList, tempData)

		table.remove (HSW_FriendsList,HSW_CurrentListBoxItemIndex)
		HouseSignWindow.CreateFriendsList()
		ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	
	elseif (HSW_AccessSubType == 4) then
		local tempData = {}
		tempData.name = HSW_CoOwnersList[HSW_CurrentListBoxItemIndex].name
		tempData.status = L"Access"
		tempData.objid = HSW_CoOwnersList[HSW_CurrentListBoxItemIndex].objid
	
		table.insert (HSW_GeneralList, tempData)
		table.remove (HSW_CoOwnersList,HSW_CurrentListBoxItemIndex)

		HouseSignWindow.CreateCoOwnersList()
		ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	
	end
	
	HouseSignWindow.CreateGeneralList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	

	-- update master list entry
	local masterListIndex = 0

	if (HSW_AccessSubType ~= 1) then
		for i = 1, table.getn (HSW_MasterList) do
			--Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleCoOwnerStatusChangeFromServer - HWS_MasterList[i].objid = "..StringToWString(tostring(theHWS_MasterList[i].objid)))
			if (HSW_MasterList[i].objid == ObjIdMakingRequest) then  -- set by requesting function
				masterListIndex = i
				break
			end
		end
	else
		-- we are looking at the master list, and already have the item selected 
		masterListIndex = HSW_CurrentListBoxItemIndex	
	end

	Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleFriendStatusChangeFromServer - masterListIndex = "..StringToWString(tostring(masterListIndex)))
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleFriendStatusChangeFromServer - theobjid = "..StringToWString(tostring(theobjid)))
	
	if (masterListIndex ~= 0) then
		HSW_MasterList[masterListIndex].status = L"Access"
		-- find the window in the master list and update its label

		--Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleCoOwnerStatusChangeFromServer - masterList window name = "..StringToWString(tostring(masterListIndex)))

		LabelSetText (WindowName.."TabWindow2MasterScrollingListBoxScrollChildItem"..tostring(masterListIndex).."StatusText",HSW_MasterList[masterListIndex].status)	

	end

	if (HSW_AccessSubType ~= 1) then
		HSW_CurrentListBoxItemIndex = 0
		HouseSignWindow.HideAccessTabModifyStatusButtons()
	else
		-- redisplay buttons when viewing master list, since which ones are active have now changed
		HouseSignWindow.HideAccessTabModifyStatusButtons()
		HouseSignWindow.ShowAccessTabModifyStatusButtons(HSW_CurrentListBoxItemIndex)
	end
		

end

function HouseSignWindow.FailedGeneralStatusChangeFromServer()

	-- make sure we are not a friend already
	if (HSW_AccessSubType == 1) then
		theStatus = HSW_MasterList[HSW_CurrentListBoxItemIndex].status
		if (theStatus == L"Co-Owner") then
			HouseSignWindow.CreateCoOwnersList()
			ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	
		elseif (theStatus == L"Friend") then
			HouseSignWindow.CreateFriendsList()
			ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	
		end
		-- item in master list should already be hilited
	elseif (HSW_AccessSubType == 3) then
		HouseSignWindow.CreateFriendsList()
		ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	
		HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)
	elseif (HSW_AccessSubType == 4) then
		HouseSignWindow.CreateCoOwnersList()
		ScrollWindowUpdateScrollRect(WindowName.."TabWindow2CoOwnersScrollingListBox")	
		HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)
	end

	HouseSignWindow.CreateGeneralList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2FriendsScrollingListBox")	

	HouseSignWindow.HideAccessTabModifyStatusButtons()
	HouseSignWindow.ShowAccessTabModifyStatusButtons(HSW_CurrentListBoxItemIndex)
	


end

function HouseSignWindow.HandleUnbanButtonPressed()

	Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleUnbanButtonPressed")

	-- this is the ban/unban button that appears next to the list when a player is selected
	-- we are not allowing to directly ban, you can only unban, and unbanning does not give general access to the house in one easy step
	
	if (HSW_AccessSubType == 5) then
		HouseSignWindow.ClearBannedListWindows()
	

		-- request from server to unban this player 
		-- figure out the obj id
		local ObjIdMakingRequest = GetObjIdByIndex(HSW_CurrentListBoxItemIndex)

		Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleBannedButtonPressed - objid = "..StringToWString(tostring(ObjIdMakingRequest)))


		ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
		ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
		-- want to unban player
		ReturnWindowData.HousingSystem.Command = 120
		
		ReturnWindowData.HousingSystem.Value = ObjIdMakingRequest
		Debug.PrintToDebugConsole(L"HouseSignWindow.HandleUnbanButtonPressed: broadcasting event")
		BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
	end		

end



function HouseSignWindow.UnbanChangeFromServer()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.UnbanChangeFromServer")

	-- we don't want to take a banned player and give them house access directly
	
	table.remove (HSW_BannedList, HSW_CurrentListBoxItemIndex)


	HouseSignWindow.CreateBannedList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2BannedScrollingListBox")	
	
	HouseSignWindow.HideAccessTabModifyStatusButtons()

	HSW_CurrentListBoxItemIndex = 0

end

function HouseSignWindow.FailedUnbanChangeFromServer()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.FailedUnbanChangeFromServer")

	
	HouseSignWindow.CreateBannedList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2BannedScrollingListBox")	

	HouseSignWindow.HiliteScrollingListBoxEntrySelection(HSW_CurrentListBoxItemIndex)


end

function HouseSignWindow.RequestAddNewPlayer()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.RequestAddNewPlayer")

	HouseSignWindow.ClearMasterListWindows()
	HouseSignWindow.ClearGeneralListWindows()

	ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
	ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
	ReturnWindowData.HousingSystem.Command = 125
	ReturnWindowData.HousingSystem.Value = 0
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleAddNewPlayerButtonPressed: broadcasting event")
	BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)

end

function HouseSignWindow.HandleAddNewPlayer(objidToAdd)
	Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleAddNewPlayer -- objid = "..StringToWString(tostring(objidToAdd)))

	local tempData = {}
	tempData.name = L"new player"
	tempData.status = L"Access"
	tempData.objid = objidToAdd

	-- register for obj info about this object id so we can get the name of the player
	RegisterWindowData(WindowData.MobileName.Type, objidToAdd)	
	-- get the name of the player
	tempData.name = WindowData.MobileName[objidToAdd].MobName
	Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleAddNewPlayer -- name = "..tempData.name)
	
	-- need to check to make sure the name doesn't have a " (young/frozen/etc)" tag appended to the end
	tempData.name = wstring.gsub(tempData.name , L" %(.-%)", L"")

	UnregisterWindowData (WindowData.MobileName.Type, objidToAdd)
	
	table.insert (HSW_GeneralList, tempData)
	table.insert (HSW_MasterList, tempData)

	HouseSignWindow.CreateMasterList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2MasterScrollingListBox")	

	HouseSignWindow.CreateGeneralList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	


	
end

function HouseSignWindow.UpdatePlayerName(mobileId)
	Debug.PrintToDebugConsole(L"HouseSignWindow.UpdatePlayerName ")

	local newName = WindowData.MobileName[mobileId].MobName
	Debug.PrintToDebugConsole(L"HouseSignWindow.UpdatePlayerName: Player's name =  "..newName)
	
	for i = 1, table.getn(HSW_MasterList) do
		if (HSW_MasterList[i].objid == mobileId) then
			HSW_MasterList[i].name = newName
			-- find the window in the master list and update its label

			--Debug.PrintToDebugConsole(L"HousePlacementWindow.UpdatePlayerName - masterList window name = "..StringToWString(tostring(i)))

			LabelSetText (WindowName.."TabWindow2MasterScrollingListBoxScrollChildItem"..tostring(masterListIndex).."NameText",HSW_MasterList[i].name)	
			
			break
		end
	end

	for i = 1, table.getn(HSW_GeneralList) do
		if (HSW_GeneralList[i].objid == mobileId) then
			HSW_GeneralList[i].name = newName
			-- find the window in the master list and update its label

			--Debug.PrintToDebugConsole(L"HousePlacementWindow.UpdatePlayerName - masterList window name = "..StringToWString(tostring(i)))

			LabelSetText (WindowName.."TabWindow2GeneralScrollingListBoxScrollChildItem"..tostring(masterListIndex).."NameText",HSW_GeneralList[i].name)	
			
			break
		end
	end
	
	UnregisterWindowData(WindowData.MobileName.Type, mobileId)

end

function HouseSignWindow.HandleAddNewPlayerFailed()

	HouseSignWindow.CreateMasterList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2MasterScrollingListBox")	

	HouseSignWindow.CreateGeneralList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2GeneralScrollingListBox")	


end

function HouseSignWindow.RequestTileArt( id, x, y )
	tileartInUse[#tileartInUse+1] = id
	return RequestTileArt( id, x, y )
end

function HouseSignWindow.ReleaseAllTileArt()
Debug.PrintToDebugConsole( L"HouseSignWindow.ReleaseAllTileArt releasing "..#tileartInUse..L" icons." )

	for dontcare, id in pairs( tileartInUse ) do
		ReleaseTileArt(id)
	end
end

-- OnShutdown Handler
function HouseSignWindow.Shutdown()
	Debug.PrintToDebugConsole(L"HouseSignWindow.Shutdown ")
	
	WindowName = ""
	
	-- release all the tile art
	HouseSignWindow.ReleaseAllTileArt()
	tileartInUse = {}
	
	-- release the mini model
	UnregisterWindowData(WindowData.HouseInfoChange.Type, 0)

	UOUnloadCSVTable ("HouseSignListCSV")
	UOUnloadCSVTable ("HouseSignHangarListCSV")
	UOUnloadCSVTable ("HouseSignPostListCSV")
	UOUnloadCSVTable ("FoundationStyleListCSV")
		
	GGManager.unregisterOnCreateCallback( "HouseSignWindow", HouseSignWindow.windowExists )

end

function HouseSignWindow.OnCloseWindow()
	Debug.PrintToDebugConsole(L"HouseSignWindow.OnCloseWindow ")

	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )
end



function HouseSignWindow.HandleBanPlayerButtonPressed()
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleBanPlayerButtonPressed ")
	ReturnWindowData.HousingSystem.UserId = WindowData.HouseInfoChange.UserId
	ReturnWindowData.HousingSystem.HouseId = WindowData.HouseInfoChange.HouseId
	ReturnWindowData.HousingSystem.Command = 116
	ReturnWindowData.HousingSystem.Value = 0
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandleAddNewPlayerButtonPressed: broadcasting event")
	BroadcastEvent (SystemData.Events.HOUSING_ACTION_HOUSEINFO_CHANGE)
end

function HouseSignWindow.BanPlayerSuccess(objidToAdd)
	Debug.PrintToDebugConsole(L"HouseSignWindow.BanPlayerSuccess ")
	local tempData = {}
	tempData.name = L"new player"  -- this is just temporary until we fetch the real name of the player
	tempData.status = L"Banned"
	tempData.objid = objidToAdd

	-- register for obj info about this object id so we can get the name of the player
	RegisterWindowData(WindowData.MobileName.Type, objidToAdd)	
	-- get the name of the player
	tempData.name = WindowData.MobileName[objidToAdd].MobName
	Debug.PrintToDebugConsole(L"HousePlacementWindow.BanPlayerSuccess -- name = "..tempData.name)
	
	-- need to check to make sure the name doesn't have a " (young/frozen/etc)" tag appended to the end
	tempData.name = wstring.gsub(tempData.name , L" %(.-%)", L"")

	UnregisterWindowData (WindowData.MobileName.Type, objidToAdd)
	
	table.insert (HSW_BannedList, tempData)

	HouseSignWindow.CreateBannedList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2BannedScrollingListBox")	

end

function HouseSignWindow.FailedBanChangeFromServer()
	Debug.PrintToDebugConsole(L"HousePlacementWindow.FailedBanChangeFromServer")

	HouseSignWindow.CreateBannedList()
	ScrollWindowUpdateScrollRect(WindowName.."TabWindow2BannedScrollingListBox")	

end

