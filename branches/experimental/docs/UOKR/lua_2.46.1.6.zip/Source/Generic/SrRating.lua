----------------------------------------------------------
-- SrRating.lua
----------------------------------------------------------------

SrRating = MasterGUMP:new()

function SrRating.Initialize()
	local newWindow					= SrRating:new()
	newWindow.setData				= SrRating.mySetData
	newWindow:Init()
end

function SrRating:mySetData()
	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Subtitle =
		GGManager.translateTID( self.descData[1] )..L" "..
		GGManager.translateTID( self.descData[2] )..L" "..
		GGManager.stripMarkup( self.stringData[1] )
	self.Page[1].ScrollText = GGManager.translateTID( self.descData[3] )
	self.Page[1].Selections = {}
	self.Page[1].Selections[1] = {}
	self.Page[1].Selections[1].Id = self.buttonIDs[1]
	self.Page[1].Selections[1].Text = GGManager.translateTID( self.descData[4] )
	self.Page[1].Selections[2] = {}
	self.Page[1].Selections[2].Id = self.buttonIDs[2]
	self.Page[1].Selections[2].Text = GGManager.translateTID( self.descData[5] )
	self.Page[1].Selections[3] = {}
	self.Page[1].Selections[3].Id = self.buttonIDs[3]
	self.Page[1].Selections[3].Text = GGManager.translateTID( self.descData[6] )
	self.Page[1].Selections[4] = {}
	self.Page[1].Selections[4].Id = self.buttonIDs[4]
	self.Page[1].Selections[4].Text = GGManager.translateTID( self.descData[7] )
	self.Page[1].Selections[5] = {}
	self.Page[1].Selections[5].Id = self.buttonIDs[5]
	self.Page[1].Selections[5].Text = GGManager.translateTID( self.descData[8] )
	self.Page[1].Selections[6] = {}
	self.Page[1].Selections[6].Id = self.buttonIDs[6]
	if self.descData[11]
	then
		self.Page[1].Selections[6].Text = GGManager.translateTID( self.descData[9] )..L" "..GGManager.translateTID( self.descData[11] )
	else
		self.Page[1].Selections[6].Text = GGManager.translateTID( self.descData[9] )	
	end
	self.Page[1].MiddleButtonId = self.buttonIDs[7]
	self.Page[1].MiddleButtonText = GGManager.translateTID( GGManager.CANCEL_TID )
end
