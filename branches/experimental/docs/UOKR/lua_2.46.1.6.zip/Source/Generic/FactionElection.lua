
----------------------------------------------------------------
-- FactionElection.lua
----------------------------------------------------------------

FactionElection = MasterGUMP:new()

function FactionElection.Initialize()

	local newWindow					= FactionElection:new()
	newWindow.setData				= FactionElection.setDataFunc
	newWindow:Init()
end

function FactionElection:setDataFunc()

	self.Page[1]					= {}
	self.Page[1].Subtitle			= GGManager.translateTID( self.descData[1] )
	
	if self.descData[4] == 1038034			-- "A new election is pending"
	then
		self.Page[1].ScrollText		= GGManager.translateTID( self.descData[4] )..L"\n\n"
									..GGManager.translateTID( self.descData[2] )..L" "..self.stringData[1]
	elseif self.descData[4] == 1018058		-- "There is an election campaign in progress"
	then
		if self.descData[5] ~= 1011427		-- "CAMPAIGN FOR LEADERSHIP"
		then
			self.Page[1].ScrollText	= GGManager.translateTID( self.descData[4] )..L"\n\n"
									..GGManager.translateTID( self.descData[5] )..L"\n\n"
									..GGManager.translateTID( self.descData[2] )..L" "..self.stringData[1]
		else
			self.Page[1].ScrollText	= GGManager.translateTID( self.descData[4] )..L"\n\n"
									..GGManager.translateTID( self.descData[2] )..L" "..self.stringData[1]
		end
	else--if self.descData[4] == 1015313		-- KR PLACE HOLDER
		self.Page[1].ScrollText		= GGManager.translateTID( self.descData[2] )..L" "..self.stringData[1]
	end
	
	self.Page[1].MiddleButtonId		= self.buttonIDs[1]
	self.Page[1].MiddleButtonText	= GGManager.translateTID(GGManager.CANCEL_TID)
	
	if self.buttonCount > 1
	then
		self.Page[1].Selections				= {}
		self.Page[1].Selections[1]			= {}
		self.Page[1].Selections[1].Id		= self.buttonIDs[self.buttonCount]
		self.Page[1].Selections[1].Text		= GGManager.translateTID( self.descData[self.descDataCount] )
		self.Page[1].Selections[1].Bottom	= true
	end
end
