----------------------------------------------------------
-- HouseBulletinboard.lua
----------------------------------------------------------------

HouseBulletinboard = MasterGUMP:new()

function HouseBulletinboard.Initialize()

	local newWindow					= HouseBulletinboard:new()
	newWindow.setData				= HouseBulletinboard.mySetData
	newWindow:Init()
end

function HouseBulletinboard:mySetData()
	self.IsStandardHeight = true

	self.Page				= {}
	self.Page[1]			= {}
	self.Page[1].Title		= GGManager.translateTID( 3000455 )													-- "Bulletin Board"
	self.Page[1].Subtitle	= self.stringData[2]																-- custom title

	local scrolltext		= GGManager.translateTID( self.descData[3] )..L" "..self.stringData[8]				-- post number
							..self.stringData[1]..self.stringData[9]..L"\n"
	if self.descData[4] > 0 then
		scrolltext = scrolltext..GGManager.translateTID( self.descData[4] )..L" "..self.stringData[6]..L"\n"	-- posted on
					..GGManager.translateTID( self.descData[5] )..L" "..self.stringData[7]..L"\n"				-- posted by
	end
	if self.descData[6] > 0 then
		scrolltext = scrolltext..GGManager.translateTID( self.descData[6] )..L" "..self.stringData[5]..L"\n"	-- account number
					..GGManager.translateTID( self.descData[7] )..L" "..self.stringData[4]..L"\n"				-- player id
	end
	self.Page[1].ScrollText	= scrolltext..L"\n"..self.stringData[3]												-- message text

	self.Page[1].Selections	= {}

	local i = 1
	if self.buttonIDs[4] > 0 then			-- set title
		self.Page[1].Selections[i]			= {}
		self.Page[1].Selections[i].Id		= self.buttonIDs[4]
		self.Page[1].Selections[i].Text		= GGManager.translateTID( self.descData[1] )
		--self.Page[1].Selections[i].Bottom	= true
		i = i + 1
	end
	if self.buttonIDs[5] > 0 then			-- post greeting
		self.Page[1].Selections[i]			= {}
		self.Page[1].Selections[i].Id		= self.buttonIDs[5]
		self.Page[1].Selections[i].Text		= GGManager.translateTID( self.descData[2] )
		--self.Page[1].Selections[i].Bottom	= true
		i = i + 1
	end
	if self.buttonIDs[6] > 0 then			-- banish poster
		self.Page[1].Selections[i]			= {}
		self.Page[1].Selections[i].Id		= self.buttonIDs[6]
		self.Page[1].Selections[i].Text		= GGManager.translateTID( self.descData[8] )
		--self.Page[1].Selections[i].Bottom	= true
		i = i + 1
	end
	if self.buttonIDs[7] > 0 then			-- delete message
		self.Page[1].Selections[i]			= {}
		self.Page[1].Selections[i].Id		= self.buttonIDs[7]
		self.Page[1].Selections[i].Text		= GGManager.translateTID( self.descData[9] )
		--self.Page[1].Selections[i].Bottom	= true
		i = i + 1
	end
											-- post message
	self.Page[1].Selections[i]				= {}
	self.Page[1].Selections[i].Id			= self.buttonIDs[3]
	self.Page[1].Selections[i].Text			= GGManager.translateTID( 3000157 )
	--self.Page[1].Selections[i].Bottom		= true

	self.CreatePrevNextButtons				= true
end

function HouseBulletinboard:fixup()
	UO_GenericGump.debug( L"HouseBulletinboard:fixup() called" )
	local OnLButtonUp = 4
	
	-- previous button
	WindowSetId( self.windowName.."PrevButton", self.buttonIDs[1] )
	ButtonSetDisabledFlag( self.windowName.."PrevButton", false )
	WindowUnregisterEventHandler( self.windowName.."PrevButton", OnLButtonUp )
	WindowRegisterEventHandler( self.windowName.."PrevButton", OnLButtonUp, "HouseBulletinboard.PNButtonPressed" )
		
	-- next button
	WindowSetId( self.windowName.."NextButton", self.buttonIDs[2] )
	ButtonSetDisabledFlag( self.windowName.."NextButton", false )
	WindowUnregisterEventHandler( self.windowName.."NextButton", OnLButtonUp )
	WindowRegisterEventHandler( self.windowName.."NextButton", OnLButtonUp, "HouseBulletinboard.PNButtonPressed" )
end

function HouseBulletinboard.PNButtonPressed()
	UO_GenericGump.debug( L"HouseBulletinboard.PNButtonPressed() called" )
	
	local self		= MasterGUMPManager.knownWindows[WindowUtils.GetActiveDialog()]
	local choiceId	= WindowGetId( SystemData.ActiveWindow.name )
	
	UO_GenericGump.debug( L"MasterGUMP:LMRButtonPressed() choiceId = "..StringToWString( tostring( choiceId ) ) )
	UO_GenericGump.broadcastButtonPress( choiceId, self )
	self.OnCloseWindow()
end
