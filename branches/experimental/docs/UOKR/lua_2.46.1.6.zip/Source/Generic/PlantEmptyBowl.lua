----------------------------------------------------------
-- FactionElect.lua
----------------------------------------------------------------

EmptyBowl = TwoButtonDialog:new()

function EmptyBowl.Initialize()

	local newWindow = EmptyBowl:new()
	newWindow.setDataFunction = EmptyBowl.mySetDataFunc
	newWindow:Init()
end

function EmptyBowl:mySetDataFunc()

	self.subtitle			= GGManager.translateTID( self.descData[1] )
	self.text				= L""
	self.leftButtonName		= GGManager.translateTID( GGManager.OKAY_TID )
	self.leftButtonID		= self.buttonIDs[3]
	self.rightButtonName	= GGManager.translateTID( GGManager.CANCEL_TID )
	self.rightButtonID		= self.buttonIDs[2]
	self.RequestedTileArt	= {}
	
	DestroyWindow( self.windowName.."Scroll" )
	CreateWindowFromTemplate( self.windowName.."Body", "EmptyBowl", self.windowName )
	WindowAddAnchor( self.windowName.."Body", "center", self.windowName, "center", 0, 0 )
	
	local textureF, xF, yF, scaleF, widthF, heightF = RequestTileArt( tonumber( self.ImageNum[5] ), 32, 32 )
	self.RequestedTileArt[#self.RequestedTileArt + 1] = textureF

	DynamicImageSetTexture( self.windowName.."BodyFullBowl", textureF, xF, yF )
	DynamicImageSetTextureScale( self.windowName.."BodyFullBowl", scaleF )
	
--	local textureA, xA, yA, scaleA, widthA, heightA = RequestTileArt( tonumber( self.portImgData[1] ), 32, 32 )
--	self.RequestedTileArt[#self.RequestedTileArt + 1] = textureA

--	DynamicImageSetTexture( self.windowName.."BodyArrow", textureA, xA, yA )
--	DynamicImageSetTextureScale( self.windowName.."BodyArrow", scaleA )
	
	local textureE, xE, yE, scaleE, widthE, heightE = RequestTileArt( tonumber( self.ImageNum[6] ), 32, 32 )
	self.RequestedTileArt[#self.RequestedTileArt + 1] = textureE

	DynamicImageSetTexture( self.windowName.."BodyEmptyBowl", textureE, xE, yE )
	DynamicImageSetTextureScale( self.windowName.."BodyEmptyBowl", scaleE )
	
	if self.ImageNum[7] then
		local textureS, xS, yS, scaleS, widthS, heightS = RequestTileArt( tonumber( self.ImageNum[7] ), 32, 32 )
		self.RequestedTileArt[#self.RequestedTileArt + 1] = textureS

		WindowSetDimensions( self.windowName.."BodySeed", widthS, heightS )
		DynamicImageSetTexture( self.windowName.."BodySeed", textureS, xS, yS )
		DynamicImageSetTextureScale( self.windowName.."BodySeed", scaleS )
		Tooltips.AddToolTip( self, self.windowName.."BodySeed", self.descData[1] )
	end
end

function EmptyBowl.OnMouseOver()
	UO_GenericGump.debug( L"EmptyBowl.OnMouseOver() called." )
end

function EmptyBowl.Shutdown()
	UO_GenericGump.debug( L"EmptyBowl.Shutdown() called." )
	
	local self = EmptyBowlManager.knownWindows[WindowUtils.GetActiveDialog()]	
	if self == nil then
		UO_GenericGump.debug( StringToWString( "Shutdown hander called for "..SystemData.ActiveWindow.name.." but data already deleted" ) )
		return
	end	
	
	-- Delete any requested Tile Art
	if self.RequestedTileArt then
		for _, art in pairs( self.RequestedTileArt ) do
			ReleaseTileArt( art )
		end
	end
		
	GGManager.unregisterActiveWindow()
end

function EmptyBowl.OnCloseWindow()
	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )
end
