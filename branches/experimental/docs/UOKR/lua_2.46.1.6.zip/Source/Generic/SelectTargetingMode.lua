
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

SelectTargetingMode = ChoiceList:new()



----------------------------------------------------------------
-- SelectTargetingMode Functions
----------------------------------------------------------------

function SelectTargetingMode:setDataFunction()

	WindowSetId( self.windowName.."Chrome_UO_WindowCloseButton", UO_GenericGump.DEFAULT_CLOSE_BUTTON_ID )	
	Interface.OnCloseCallBack[self.windowName] = self.BottomButtonPressed

	-- set title
	--WindowUtils.SetActiveDialogTitle( GGManager.translateTID(self.descData[1])  )
	
	local parentWindow = self:CreateSubtitle( GGManager.translateTID(self.descData[1]) )

	-- create and set main text
	parentWindow = self:CreateText( 0, GGManager.translateTID( self.descData[2] ),  "top", parentWindow, "top", 0, 10 )
	
	-- create and set each text choice
	for choiceNum=1, 3 do
		parentWindow = self:CreateChoiceListSelectableText( self.buttonIDs[choiceNum], GGManager.translateTID( self.descData[choiceNum+2] ), "bottomleft", parentWindow, "topleft", 0, 20 )
	end
	
	
	--ScrollWindowUpdateScrollRect( self.windowName.."Scroll" )
	
	-- create cancel button
	self:CreateBottomButton( GGManager.translateTID( GGManager.CANCEL_TID ) , self.buttonIDs[4] )	
	
end

	

-- OnInitialize Handler
function SelectTargetingMode.Initialize()
	SelectTargetingMode:new():Init()
end
	
