
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

VirtueInfo = ThreeButtonDialog:new()

function VirtueInfo.getShowing()
	return VirtueInfo.showing 
end


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

VirtueInfo.showing = false

----------------------------------------------------------------
-- VI Functions
----------------------------------------------------------------

-- custom data set function
function VirtueInfo.parseDescAsButtonsTitleSubtitleAndText(gumpData)

	gumpData.title = GGManager.translateTID(gumpData.descData[1])
	gumpData.text = GGManager.translateTID(gumpData.descData[2])..L"\n\n"..GGManager.translateTID(1078061)
	gumpData.subtitle = GGManager.translateTID(gumpData.descData[3])..L"  ("..gumpData.descData[8]..L"/10)"
	-- ignore descData 4

	-- Since they don't have web pages linked in the callback trigger, these three virtues don't need "more" buttons!
	-- Check for the specific virtue based on the title of the virtue window
	--Humility actually has a website listed, but it is commented out, so we're leaving that one off.
	--							Humility							Spirituality				and Honesty
	if gumpData.descData[1] ~= 1051000 and gumpData.descData[1] ~= 1051003 and gumpData.descData[1] ~= 1051007 then 
		gumpData.leftButtonName = GGManager.translateTID(gumpData.descData[5]) -- "MORE" on the left
		gumpData.leftButtonID = gumpData.buttonIDs[1]
	end

	gumpData.centerButtonName = GGManager.translateTID(gumpData.descData[6]) -- "BACK" in the middle
	gumpData.centerButtonID = gumpData.buttonIDs[2]

	-- The "USE" button has been replaced by a fancy working icon thing
	--gumpData.rightButtonName = GGManager.translateTID(gumpData.descData[7]) -- "USE" on the right - TODO: Fix this so back is on the right
	--gumpData.rightButtonID = gumpData.buttonIDs[3]

	
end

-- *** TODO: this functionality needs to be moved into the C++ code before publicly releasing Lua code to the public!
 function VirtueInfo.HandleMoreButtons()
	local my_self = ThreeButtonDialog.getActiveWindowData()
 	local case = my_self.descData[1] -- Used to determine which Virtue this is!
 	if case == 1051000 or case == 1051003 or case == 1051007 then
		return -- Do nothing, as this more button shouldn't even be there!
	elseif case == 1051001 then	-- Sacrifice
		OpenWebBrowser("http://update.uo.com/design_389.html")
	elseif case == 1051002 then	-- Compassion
		OpenWebBrowser("http://update.uo.com/design_412.html")
	elseif case == 1051004 then	-- Valor
		OpenWebBrowser("http://update.uo.com/design_427.html")
	elseif case == 1051005 then	-- Honor
		OpenWebBrowser("http://guide.uo.com/virtues_2.html")
	elseif case == 1051006 then	-- Justice
		OpenWebBrowser("http://update.uo.com/design_413.html")
	end
end 


-- OnInitialize Handler
function VirtueInfo.Initialize()
	VirtueInfo.setDataFunction = VirtueInfo.parseDescAsButtonsTitleSubtitleAndText
	VirtueInfo.LeftButtonFunction = VirtueInfo.HandleMoreButtons
	if VirtueInfo.showing then
		VirtueInfo.OnCloseWindow()
	end
	VirtueInfo:Init()
	VirtueInfo.showing = true
	Interface.OnCloseCallBack[VirtueInfo.windowName] = VirtueInfo.OnCloseWindow

    ButtonSetPressedFlag("MenuBarWindowStatusBarToggleVirtues",true)
end
	
function VirtueInfo.Shutdown()
	UO_GenericGump.debug( L"VirtueInfo.Shutdown()." )
	VirtueInfo.showing = false
	ButtonSetPressedFlag("MenuBarWindowStatusBarToggleVirtues",false)
end

function VirtueInfo.OnCloseWindow()
	UO_GenericGump.debug( L"VirtueInfo.OnCloseWindow()." )
	if not VirtueInfo.showing then
		UO_GenericGump.debug( L"VirtueInfo.OnCloseWindow() called but window does not exist." )
		return
	end

	VirtueInfo.showing = false
	GGManager.destroyWindow(VirtueInfo.windowName)
end

