
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

StuckPlayer = ChoiceList:new()

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------



----------------------------------------------------------------
-- StuckPlayer Functions
----------------------------------------------------------------

function StuckPlayer:setDataFunction()
	
	Interface.OnCloseCallBack[self.windowName] = self.BottomButtonPressed

	if self.descData then
	
	
		-- ***KLUDGE*** - have to insert extra spaces to cause a word wrap in order for it to properly
		--                calculate the size of the Label for anchoring purposes
		relativeWindow = ChoiceList.CreateSubtitle( self, GGManager.translateTID( self.descData[1] )..UO_GenericGump.EMPTY_LINE..L"\n"  )
	
	
		ChoiceList.CreateBottomButton( self, GGManager.translateTID( self.descData[2] ), StuckPlayer.BOTTOM_BUTTON_ID )
	
		-- descData[3] to [8] are the values with return values 1-6
		-- note: don't iterate through the table itself
		for choiceNum=1, self.descDataCount - 2 do
			relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
					choiceNum, GGManager.translateTID( self.descData[choiceNum+2] ),
					"bottom", relativeWindow, "top", 0, 10 )
		end
		
		
	end  -- if descData

end

	
-- OnInitialize Handler
function StuckPlayer.Initialize()
	local NewWindow = StuckPlayer:new()
	NewWindow:Init()
end
	
