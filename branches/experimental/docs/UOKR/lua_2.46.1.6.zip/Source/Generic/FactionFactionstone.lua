----------------------------------------------------------
-- FactionFactionstone.lua
----------------------------------------------------------------

FactionFactionstone = MasterGUMP:new()

function FactionFactionstone.Initialize()

	local newWindow					= FactionFactionstone:new()
	newWindow.setData				= FactionFactionstone.mySetData
	newWindow:Init()
end

function FactionFactionstone:mySetData()

	self.Page	= {}
	--self.CreatePrevNextButtons = true
	
	-- Main Page
	self.Page[1]			= {}
	self.Page[1].Selections	= {}

	self.Page[1].Title		= L"Faction stone"
	self.Page[1].Subtitle	= GGManager.translateTID( self.descData[1] )
	self.Page[1].SubtitleHL = true
	self.Page[1].SelectionHL = true
	local leaderName
	if tonumber( self.descData[3] ) == -1
	then
		leaderName			= self.stringData[1]
	else
		leaderName			= GGManager.translateTID( self.descData[3] )
	end
	
	self.Page[1].ScrollText		= GGManager.translateTID( self.descData[2] )..L" "..leaderName..L"\n"
								..GGManager.translateTID( self.descData[4] )..L" "..GGManager.translateTID( self.descData[5] )
	
	-- We are joining the faction
	if tonumber( self.descData[7] ) == 1011425
	then
		self.Page[1].ScrollText	= self.Page[1].ScrollText..L"\n\n"
								..GGManager.translateTID( self.descData[6] )
		
		self.Page[1].Selections[1]		= {}
		self.Page[1].Selections[1].Id	= self.buttonIDs[1]
		self.Page[1].Selections[1].Text	= GGManager.translateTID( self.descData[7] )
		
		self.Page[1].MiddleButtonId		= self.buttonIDs[2]
		self.Page[1].MiddleButtonText	= GGManager.translateTID( self.descData[8] )
		
		return
		
	-- We are in the Faction already
	else
		self.Page[1].ScrollText	= self.Page[1].ScrollText..L"\n"
								..GGManager.translateTID( self.descData[6] )..L" "..self.stringData[6]
		
		local btnItr	= self.buttonPageIndex[2]
		local btnItrEnd	= self.buttonPageIndex[3]
		while btnItr < btnItrEnd - 1
		do
			self.Page[1].Selections[btnItr]			= {}
			self.Page[1].Selections[btnItr].Id		= self.buttonIDs[btnItr]
			self.Page[1].Selections[btnItr].Text	= GGManager.translateTID( self.descData[btnItr + 6] )
			
			btnItr = btnItr + 1
		end
		---[[
		self.Page[1].Selections[btnItr]			= {}
		self.Page[1].Selections[btnItr].Id		= self.buttonIDs[btnItr]
		self.Page[1].Selections[btnItr].Text	= GGManager.translateTID( self.descData[btnItr + 6] )
		self.Page[1].Selections[btnItr].Bottom	= true
		--]]
	end
	
	-- City Status Page
	self.Page[2]			= {}
	self.Page[2].Selections	= {}
	
	local dscItr	= self.descPageIndex[3]
	local dscItrEnd	= self.descPageIndex[4]
	local imgItr	= self.portImgPageIndex[3]
	local imgItrEnd	= self.portImgPageIndex[4]
	local btnItrEnd	= self.buttonPageIndex[4] - 1
	
--	self.Page[2].Title		= L"Page 2"
	self.Page[2].Subtitle	= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	local index = 1
	while dscItr < dscItrEnd - 4
	do
		self.Page[2].Selections[index]		= {}
		self.Page[2].Selections[index].Id	= MasterGUMP.DISABLED2_BUTTON_ID
		
		if self.portImgData[imgItr] == 2361 then -- red
			self.Page[2].Selections[index].Id = MasterGUMP.HIGHLIGHT2_BUTTON_ID
		elseif self.portImgData[imgItr] == 2360 then -- green
			self.Page[2].Selections[index].Id = MasterGUMP.HIGHLIGHT3_BUTTON_ID
		else -- NONE
			self.Page[2].Selections[index].Id = MasterGUMP.DISABLED2_BUTTON_ID
		end
		
		--self.Page[2].Selections[index].Port	= self.portImgData[imgItr]
		self.Page[2].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )..GGManager.translateTID( self.descData[dscItr + 1] )
		
		dscItr = dscItr + 2
		imgItr = imgItr + 1
		index = index + 1
	end
	
	self.Page[2].Selections[index]		= {}
	self.Page[2].Selections[index].Id	= MasterGUMP.DISABLED2_BUTTON_ID
		if self.portImgData[imgItr] == 2361 then -- red
			self.Page[2].Selections[index].Id = MasterGUMP.HIGHLIGHT2_BUTTON_ID
		elseif self.portImgData[imgItr] == 2360 then -- green
			self.Page[2].Selections[index].Id = MasterGUMP.HIGHLIGHT3_BUTTON_ID
		else -- None
			self.Page[2].Selections[index].Id = MasterGUMP.DISABLED2_BUTTON_ID
		end
	self.Page[2].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )
	self.Page[2].Selections[index].Bottom = true
	dscItr = dscItr + 1
	imgItr = imgItr + 1
	index = index + 1
	
	self.Page[2].Selections[index]		= {}
	self.Page[2].Selections[index].Id	= MasterGUMP.DISABLED2_BUTTON_ID
		if self.portImgData[imgItr] == 2361 then -- red
			self.Page[2].Selections[index].Id = MasterGUMP.HIGHLIGHT2_BUTTON_ID
		elseif self.portImgData[imgItr] == 2360 then -- green
			self.Page[2].Selections[index].Id = MasterGUMP.HIGHLIGHT3_BUTTON_ID
		else -- None
			self.Page[2].Selections[index].Id = MasterGUMP.DISABLED2_BUTTON_ID
		end
	self.Page[2].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )
	self.Page[2].Selections[index].Bottom = true
	dscItr = dscItr + 1
	imgItr = imgItr + 1
	index = index + 1
	
	self.Page[2].Selections[index]		= {}
	self.Page[2].Selections[index].Id	= self.buttonIDs[btnItrEnd]
--	self.Page[2].Selections[index].Port	= self.portImgData[imgItr]
	self.Page[2].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )
	self.Page[2].Selections[index].Bottom = true
	
--	self.Page[2].MiddleButtonId = 0
--	self.Page[2].MiddleButtonText = L"Cancel"
	
	-- Page 3 got moved to it's own gump
	-- Needs to be declared for ipairs to work
	self.Page[3]	= {}
	
	-- Statistics Page
	self.Page[4]			= {}
	
	dscItr		= self.descPageIndex[5]
	dscItrEnd	= self.descPageIndex[6]
	btnItr		= self.buttonPageIndex[5]
	
	self.Page[4].Subtitle	= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[4].ScrollText		= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[2]..L"\n"
								..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[3]..L"\n"
								..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[4]
	dscItr = dscItr + 3
	---[[
	self.Page[4].Selections			= {}
	self.Page[4].Selections[1]		= {}
	self.Page[4].Selections[1].Id	= self.buttonIDs[btnItr]
	self.Page[4].Selections[1].Text	= GGManager.translateTID( self.descData[dscItr] )
	self.Page[4].Selections[1].Bottom = true
	--]]
	
	-- Merchant Options Page
	self.Page[5]				= {}
	
	dscItr		= self.descPageIndex[6]
	dscItrEnd	= self.descPageIndex[7]
	
	self.Page[5].Subtitle		= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[5].ScrollText		= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[5].Selections	= {}
	local btnItr	= self.buttonPageIndex[6]
	local btnItrEnd	= self.buttonPageIndex[7]
	
	local index = 1
	while btnItr < btnItrEnd
	do
		self.Page[5].Selections[index]		= {}
		self.Page[5].Selections[index].Id	= self.buttonIDs[btnItr]
		self.Page[5].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )

		index = index + 1
		btnItr = btnItr + 1
		dscItr = dscItr + 1
	end
	
	-- Commander Options Page
	self.Page[6]				= {}
	
	dscItr		= self.descPageIndex[7]
	dscItrEnd	= self.descPageIndex[8]
	
	self.Page[6].Subtitle		= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[6].ScrollText		= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..GGManager.translateTID( self.descData[dscItr + 1] )..L"\n"
								..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[7]
	dscItr = dscItr + 3
	
	self.Page[6].Selections	= {}
	
	local btnItr	= self.buttonPageIndex[7]
	local btnItrEnd	= self.buttonPageIndex[8]
	
	local index = 1
	while btnItr < btnItrEnd
	do
		self.Page[6].Selections[index]		= {}
		self.Page[6].Selections[index].Id	= self.buttonIDs[btnItr]
		self.Page[6].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )

		index = index + 1
		btnItr = btnItr + 1
		dscItr = dscItr + 1
	end
	
	-- Transfer Silver Page
	self.Page[7] = {}
	
	dscItr		= self.descPageIndex[8]
	dscItrEnd	= self.descPageIndex[9]
	
	self.Page[7].Subtitle		= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[7].ScrollText		= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[7].Selections	= {}
	
	local btnItr	= self.buttonPageIndex[8]
	local btnItrEnd	= self.buttonPageIndex[9]
	
	local index = 1
	while btnItr < btnItrEnd
	do
		self.Page[7].Selections[index]		= {}
		self.Page[7].Selections[index].Id	= self.buttonIDs[btnItr]
		self.Page[7].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )

		index = index + 1
		btnItr = btnItr + 1
		dscItr = dscItr + 1
	end
	
	-- Transfer Silver Page
	self.Page[8] = {}
	
	dscItr		= self.descPageIndex[9]
	dscItrEnd	= self.descDataCount
	
	self.Page[8].ScrollText	= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[8].Selections	= {}
	
	local btnItr	= self.buttonPageIndex[9]
	local btnItrEnd	= self.buttonCount
	
	local index = 1
	while btnItr <= btnItrEnd
	do
		self.Page[8].Selections[index]		= {}
		self.Page[8].Selections[index].Id	= self.buttonIDs[btnItr]
		self.Page[8].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )

		index = index + 1
		btnItr = btnItr + 1
		dscItr = dscItr + 1
	end
end
