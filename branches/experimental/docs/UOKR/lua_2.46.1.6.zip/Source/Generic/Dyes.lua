
----------------------------------------------------------------
-- Dyes
----------------------------------------------------------------

Dyes = { }

DyesManager = GGManager

-- OnInitialize Handler
function Dyes.Initialize()
	local dyes = Dyes:new()
	dyes:Init()
end

function Dyes:new( dyes )
	dyes = dyes or {}
	setmetatable( dyes, self )
	self.__index = self
	
	dyes.rightChildren = {}

	return dyes
end

function Dyes:Init()
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	self:setDataFunction()
	
	DyesManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end


function Dyes:CreateBlankSpace( pixels, relativeToow, uniqueID, scrollParent )
	local choiceName = self.windowName.."BlankSpace-"..uniqueID
	
	CreateWindowFromTemplate( choiceName, "DyesBaseText", scrollParent )
	LabelSetText( choiceName, L" " )
	WindowAddAnchor( choiceName, "bottomleft", relativeToow, "topleft", 0, pixels )

	return choiceName
end

-- hue data comes in as button data from wombat
function Dyes:setDataFunction()
	-- cancel button
	local buttonName = self.windowName.."BottomButton"
	ButtonSetText( buttonName, GGManager.translateTID( GGManager.CANCEL_TID ) )
	WindowSetId( buttonName, 0 )

	-- subtitle 
	LabelSetText( self.windowName.."Subtitle", GGManager.translateTID( self.descData[1] ) )

	-- left page shows a color index
	local relativeWindow = self.windowName.."ScrollChild"
	
	local leftItr		 = self.buttonPageIndex[1] + 1
	local leftItrEnd	 = self.buttonPageIndex[2] - 1
	local pageItr		 = -1
	
	relativeWindow = Dyes:CreateSelectableText( pageItr, self.buttonIDs[self.buttonPageIndex[leftItr]], "top", relativeWindow, "top", 0, 10 )
	pageItr = pageItr - 1
	
	for leftItr = leftItr + 1, leftItrEnd do
		relativeWindow = Dyes:CreateSelectableText( pageItr, self.buttonIDs[self.buttonPageIndex[leftItr]], "bottom", relativeWindow, "top", 0, 10 )
		pageItr = pageItr - 1
	end
	
	-- space padding
	self:CreateBlankSpace( 10, relativeWindow, 0, self.windowName.."ScrollChild" )

	pageItr = -1

	-- the current page
	local page
	local uniqueID = 1

	-- right page shows a group of related colors for the color selected on the left
	for page = 2, table.getn( self.buttonPageIndex ) do
		local rightItr		= self.buttonPageIndex[page]
		local rightItrEnd	= self.buttonCount
		
		if page < table.getn( self.buttonPageIndex ) then
			rightItrEnd	 = self.buttonPageIndex[page + 1] - 1
		end
		
		local hueItr			= self.buttonPageIndex[page]
		local rightScroll		= self.windowName.."Scroll"..page
		local rightScrollChild	= rightScroll.."Child"

		CreateWindowFromTemplate( rightScroll, 	"DyesRightScroll", self.windowName )
		WindowAddAnchor( rightScroll, "bottom", self.windowName.."Subtitle", "top", 0, 10 )

		UO_GenericGump.debug( L"Dyes:SetDataFunction() Hues = "..self.buttonIDs[hueItr]..L" Page: "..page )
		relativeWindow = Dyes:CreateSelectableText( self.buttonIDs[hueItr], self.buttonIDs[hueItr], "top", rightScrollChild, "top", 0, 10, page, true )
		hueItr = hueItr + 1

		for rightItr = rightItr + 1, rightItrEnd do
			relativeWindow = Dyes:CreateSelectableText( self.buttonIDs[hueItr], self.buttonIDs[hueItr], "bottom", relativeWindow, "top", 0, 10, page, true, uniqueID )
			hueItr = hueItr + 1
			uniqueID = uniqueID + 1
		end
			
		-- space padding
		self:CreateBlankSpace( 10, relativeWindow, page, rightScrollChild )

		WindowSetShowing( rightScroll, false )
		self.rightChildren[pageItr] = rightScroll
		pageItr = pageItr - 1
	end
end

function Dyes:CreateSelectableText( choiceNum, hue, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset, myPage, isRight, uniqueID )
	local windowName = WindowUtils.GetActiveDialog()
	local choiceName = windowName.."Choice"..choiceNum

	if uniqueID then
		choiceName = windowName.."Choice"..choiceNum.."Unique"..uniqueID
	end

	local parentName = windowName.."ScrollChild"
	
	if isRight then
		parentName = windowName.."Scroll"..myPage.."Child"
	end
	
	if	myPage and myPage ~= ""	and not isRight then
		parentName = parentName..myPage
	end
	
	CreateWindowFromTemplate( choiceName, "DyesSelectable", parentName )
	WindowAddAnchor( choiceName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	WindowSetId( choiceName, choiceNum )
	
	hue = hue + 1 -- for some reason the value that wombat expects is one less than the hue value
	
	-- debug code
	--LabelSetText( choiceName.."Text" , L"ID = "..StringToWString( tostring( choiceNum ) )..L", hue = "..StringToWString( tostring( hue ) ) )
	
	local r, g, b, a = HueRGBAValue( hue )
	WindowSetTintColor( choiceName.."Hue", r, g, b )
	
	return choiceName
end

function Dyes.TextPressed()
	local self = DyesManager.knownWindows[WindowUtils.GetActiveDialog()]
	self:TextSelected()
end

function Dyes:TextSelected()
	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	UO_GenericGump.debug( L"Dyes:TextSelected() choiceNum = "..choiceNum )

	if choiceNum == 0 then
		UO_GenericGump.broadcastSelections( 0, { choiceNum }, self ) -- cancel
		self.OnCloseWindow()
		return
	end
	
	if choiceNum > 0 then
		UO_GenericGump.broadcastSelections( self.buttonIDs[1], { choiceNum }, self ) -- Okay id is the first button id passed in
		self.OnCloseWindow()
		return
	end

	local pageItr = -1
	local pageItrEnd = -Dyes.getTableSize( self.rightChildren )
	
	while pageItr >= pageItrEnd do
		WindowSetShowing( self.rightChildren[pageItr], ( pageItr == choiceNum ) )
		pageItr = pageItr - 1
	end
end

function Dyes.OnCloseWindow()
	UO_GenericGump.debug( L"Dyes.OnCloseWindow() called." )
	
	GGManager.destroyActiveWindow()
end

function Dyes.getTableSize( table )
	local count = 0
	
	for _, _ in pairs( table ) do
		count = count + 1
	end
	
	return count
end
