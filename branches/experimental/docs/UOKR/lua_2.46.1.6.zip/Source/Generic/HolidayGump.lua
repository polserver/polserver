----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

HolidayGump = OneButtonDialog:new()

----------------------------------------------------------------
-- HolidayGump Functions
----------------------------------------------------------------


function HolidayGump:setDataFunction()
	self.text = self.localizedData[1]..L"\n\n"..GGManager.translateTID(self.descData[1])
	self.buttonName = GGManager.translateTID(GGManager.OKAY_TID)
	self.buttonID = 1
end


-- OnInitialize Handler
function HolidayGump.Initialize()
	local NewWindow = HolidayGump:new()
	NewWindow:Init()
end