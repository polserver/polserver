----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

VendorReclaim = ChoiceList:new()

----------------------------------------------------------------
-- VendorReclaim Functions
----------------------------------------------------------------

function VendorReclaim:setDataFunction()
	UO_GenericGump.debug( L"VendorReclaim:setDataFunction - setting data for = "..self.name )

	self.title = GGManager.translateTID( self.descData[1] )
	WindowUtils.SetActiveDialogTitle( self.title )
	
	local relativeWindow = self.windowName.."ScrollChild"
	-- first choice anchors to top of ScrollChild. others below will anchor to this one.
	relativeWindow = VendorReclaim.CreateChoiceListSelectableText( self, self.buttonIDs[1], self.stringData[1],
					"topleft", relativeWindow, "topleft", 0, 0 )
	-- note: don't iterate through the table itself
	for choiceNum = 2, self.stringDataCount  do
		relativeWindow = VendorReclaim.CreateChoiceListSelectableText( self, self.buttonIDs[choiceNum], self.stringData[choiceNum],
						"bottom", relativeWindow, "top", 0, 10 )
	end
end

-- OnInitialize Handler
function VendorReclaim.Initialize()
	local newWindow = VendorReclaim:new()
	newWindow.setDataFunction = VendorReclaim.setDataFunction
	newWindow:Init()
end