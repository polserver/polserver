----------------------------------------------------------------
-- MasterOneButton.lua
----------------------------------------------------------------

MasterOneButton = MasterGUMP:new()

MasterOneButton.DEFAULT_BUTTON_ID = 0

function MasterOneButton.Initialize()

	local newWindow					= MasterOneButton:new()
	newWindow.setData				= MasterOneButton.setDataFunc
	newWindow:Init()
end

-- Parses the incoming data in different ways based on how many descData values are provided
-- here are the 3 cases this handles:
-- if descDataCount is 1 then descData[1] is text
-- if descDataCount is 2 then descData[1] is title and descData[2] is text
-- if descDataCount is 3 then descData[1] is title,
--    descData[2] is subtitle, and descData[3] is text
--
function MasterOneButton:setDataFunc()

    UO_GenericGump.debug( L"called MasterOneButton:setDataFunc()" )
    
    self.Page[1] = {}
    
    local dscItr = 1
    
    if self.descDataCount > 1
    then
		self.Page[1].Title = GGManager.translateTID( self.descData[dscItr] )
		dscItr = dscItr + 1
	end
	
    if self.descDataCount > 2
    then
		self.Page[1].Subtitle = GGManager.translateTID( self.descData[dscItr] )
		dscItr = dscItr + 1
	end
	
	self.Page[1].ScrollText = GGManager.translateTID( self.descData[dscItr] )
	
	-- ALL OneButtonDialog Windows will have OKAY as button label
	self.Page[1].MiddleButtonId		= self.buttonIDs[1]
	self.Page[1].MiddleButtonText	= GGManager.translateTID( GGManager.OKAY_TID )
end
