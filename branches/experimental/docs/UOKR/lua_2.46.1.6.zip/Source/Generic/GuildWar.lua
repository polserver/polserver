----------------------------------------------------------------
-- GuildWar.lua
----------------------------------------------------------------

GuildWar = TextEntry:new()

function GuildWar.Initialize()

	local newWindow = GuildWar:new()
	newWindow:Init()
end

function GuildWar:setDataFunction()

	self.title = GGManager.translateTID(self.descData[1])	
	self.subtitle1 = GGManager.translateTID(self.descData[2])
	self.subtitle2 = GGManager.translateTID(self.descData[3])
	self.subtitle4 = GGManager.translateTID(self.descData[4])
	self.subtitle3 = GGManager.translateTID(self.descData[5])
		
	self.numOfTextBoxes = self.stringDataCount
	
	for i=1, self.numOfTextBoxes do
		self.textBoxID[i] = self.buttonIDs[i]
		self.textBoxText[i] = self.stringData[i]
	end
	
	self.submitButtonName = GGManager.translateTID(self.descData[7])
	self.cancelButtonName = GGManager.translateTID(GGManager.CANCEL_TID)
	self.submitButtonID = self.buttonIDs[4]
	self.cancelButtonID = self.buttonIDs[3]

end

function GuildWar:setFields()

	if self.title then
		WindowUtils.SetActiveDialogTitle( self.title )
    end
    
	if self.subtitle1 then
		LabelSetText( self.windowName.."Subtitle1", self.subtitle1 )
    end
    
	if self.subtitle2 then
		LabelSetText( self.windowName.."Subtitle2", self.subtitle2 )
    end
    
    if self.subtitle3 then
		LabelSetText( self.windowName.."Subtitle3", self.subtitle3 )
    end
    
    if self.subtitle4 then
		LabelSetText( self.windowName.."Subtitle4", self.subtitle4 )
    end
    
	if self.text then
		LabelSetText( self.windowName.."ScrollChildText", self.text )
    end
    
	for i=1, self.numOfTextBoxes do
		if self.textBoxLabel[i] ~= nil and self.textBoxLabel[i] ~= "" then
			LabelSetText( self.windowName.."Label"..i, self.textBoxLabel[i] )
		end
		if self.textBoxText[i] ~= nil and self.textBoxText[i] ~= "" then
			TextEditBoxSetText( self.windowName.."BoxText"..i, self.textBoxText[i] )
		end
		WindowSetId( self.windowName.."BoxText"..i, self.textBoxID[i] )	
	end
	
	ButtonSetText(self.windowName.."SubmitButton", self.submitButtonName )
	WindowSetId( self.windowName.."SubmitButton", self.submitButtonID )	
	ButtonSetText(self.windowName.."CancelButton", self.cancelButtonName )
	WindowSetId( self.windowName.."CancelButton", self.cancelButtonID )	


    WindowAssignFocus(self.windowName.."BoxText"..1, true)
end


function GuildWar.OnCloseWindow()
	GGManager.destroyActiveWindow()
end
