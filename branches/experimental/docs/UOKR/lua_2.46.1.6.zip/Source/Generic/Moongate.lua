
----------------------------------------------------------------
-- Moongate
----------------------------------------------------------------

Moongate = { }--rightChildren = {} }

MoongateManager = GGManager


-- OnInitialize Handler
function Moongate.Initialize()

	local moonGate = Moongate:new()
	moonGate:Init()
end

function Moongate:new( moonGate )

	moonGate = moonGate or {}
	setmetatable( moonGate, self )
	self.__index = self
	
	moonGate.rightChildren = {}

	return moonGate
end

function Moongate:Init()
		
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end

	if self.setFields then
		self:setFields()
	end
	
	MoongateManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end

function Moongate:setDataFunction()
	
	-- Set the title to "MOONGATE"
	WindowUtils.SetActiveDialogTitle( GGManager.translateTID( 1023948 ) ) -- 1048047 ) ) is "A MOONGATE"
	
	-- descData[1] is the label for an ok button which is no longer needed
	
	-- descData[2] is label for cancel button
	local buttonName = self.windowName.."BottomButton"
	ButtonSetText( buttonName, GGManager.translateTID( self.descData[2] ) )
	WindowSetId( buttonName, self.buttonIDs[2] ) -- Cancel id is the second button id passed in

	-- descData[3] is text for the subtitle 
	LabelSetText( self.windowName.."Subtitle", GGManager.translateTID( self.descData[3] ) )

	-- Page 0 = "Left Page"
	relativeWindow = self.windowName.."ScrollChild"
	
	local descItr		= self.descPageIndex[1] + 3 -- Skip over buttons' labels and Subject
	local descItrEnd	= self.descPageIndex[2] - 1
	local pageItr		= -1
	
	relativeWindow = Moongate:CreateSelectableText( pageItr, GGManager.translateTID( self.descData[descItr] ), "top", relativeWindow, "top", 0, 10 )
	pageItr = pageItr - 1
	
	for descItr=descItr+1, descItrEnd do
		relativeWindow = Moongate:CreateSelectableText( pageItr, GGManager.translateTID( self.descData[descItr] ), "bottom", relativeWindow, "top", 0, 10 )
		pageItr = pageItr - 1
	end
---[[
	-- Page 1+ = right side pages
	pageItr = -1
	
	for page=2, table.getn( self.descPageIndex ) do
	
		local descItr		= self.descPageIndex[page] + 1 -- Skip over the title
		local descItrEnd	= self.descDataCount
		
		if page < table.getn( self.descPageIndex ) then
			descItrEnd	= self.descPageIndex[page+1] - 1
		end
		
		local buttonItr = self.buttonPageIndex[page]

-- This dirty hack was in place because the wombat code was throwing in a button that was already there again, in the most common case.
-- It was screwing with one of the less common cases. The wombat has been fixed, and this hack should no longer be needed!
--		if page < 4 then
--			buttonItr = buttonItr + 1	-- Dirty hack! For some reason the 2nd and 3rd pages have an extra button at the begining
--		end
		
		local rightScroll		= self.windowName.."Scroll"..page
		local rightScrollChild	= rightScroll.."Child"

		CreateWindowFromTemplate( rightScroll,	"MoongateRightScroll", self.windowName )
		WindowAddAnchor( rightScroll, "bottom", self.windowName.."Subtitle", "top", 0, 10 )
		--CreateWindowFromTemplate( rightScrollChild,	"MoongateRightScrollChild", rightScroll )
		relativeWindow = Moongate:CreateSelectableText( self.buttonIDs[buttonItr], GGManager.translateTID( self.descData[descItr] ), "top", rightScrollChild, "top", 0, 10, page, true )
		buttonItr = buttonItr + 1

		for descItr=descItr+1, descItrEnd do
			relativeWindow = Moongate:CreateSelectableText( self.buttonIDs[buttonItr], GGManager.translateTID( self.descData[descItr] ), "bottom", relativeWindow, "top", 0, 10, page, true )
			buttonItr = buttonItr + 1
		end

		WindowSetShowing( rightScroll, false )
		self.rightChildren[pageItr] = rightScroll
		pageItr = pageItr - 1
	end
--]]
end	

function Moongate:CreateSelectableText( choiceNum, wText, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset, myPage, isRight )

	local windowName	= WindowUtils.GetActiveDialog()
	local choiceName	= windowName.."Choice"..choiceNum
	local parentName	= windowName.."ScrollChild"
	
	if isRight then
		parentName	= windowName.."Scroll"..myPage.."Child"
	end
	
	if	myPage
	and myPage ~= ""
	and not isRight then
		parentName		= parentName..myPage
	end
	
	-- TODO: Adjust icons here!? - TF
	
	CreateWindowFromTemplate( choiceName, "MoongateSelectable", parentName )
	WindowAddAnchor( choiceName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	WindowSetId( choiceName, choiceNum )
	LabelSetText( choiceName.."Text" , wText )
	
	return choiceName
end

function Moongate.TextPressed()

	local self = MoongateManager.knownWindows[WindowUtils.GetActiveDialog()]
	self:TextSelected()
end

function Moongate:TextSelected()

	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	UO_GenericGump.debug( L"Moongate:TextSelected() choiceNum = "..choiceNum )

	if choiceNum == 0 then
		UO_GenericGump.broadcastSelections( self.buttonIDs[2], { choiceNum }, self )	-- Cancel id is the second button id passed in
		self.OnCloseWindow()
		return
	end
	
	if choiceNum > 0 then
		UO_GenericGump.broadcastSelections( self.buttonIDs[1], { choiceNum }, self )	-- Okay id is the first button id passed in
		self.OnCloseWindow()
		return
	end

	local pageItr = -1
	local pageItrEnd = -Moongate.getTableSize( self.rightChildren )
	
	while pageItr >= pageItrEnd do
	
--		UO_GenericGump.debug( L"Moongate:TextSelected() Setting "..StringToWString( self.rightChildren[pageItr] )..L"'s visibility to "..StringToWString( tostring( pageItr == choiceNum ) ) )
		WindowSetShowing( self.rightChildren[pageItr], (pageItr == choiceNum) )
		pageItr = pageItr - 1
	end
end

function Moongate.OnShutdown()
	UO_GenericGump.debug( L"Moongate.OnShutdown() called. It does nothing." )
end

function Moongate.OnCloseWindow()
	UO_GenericGump.debug( L"Moongate.OnCloseWindow() called." )
	GGManager.destroyActiveWindow()
end

function Moongate.getTableSize( table )

	local count = 0
	
	for _, _ in pairs( table ) do
		count = count + 1
	end
	
	return count
end

