-- I've hacked this one up a bit specifically so it works for virtue gumps.
-- It should not be use for anything else.
-- TODO: Rename this file so it doesn't look like a template / merge into virtueInfo.lua

----------------------------------------------------------------
-- Global Variables/Functions
----------------------------------------------------------------

-- static declaration for the basic ThreeButtonDialog class.
--   objects (or subclasses) created by its new function are designed to hold
--   data and provide methods for the ThreeButtonDialog.xml template
--
ThreeButtonDialog = {}

--
ThreeButtonDialogManager = GGManager


-- TODO: remove these 2 lines
--   but there are cuttently some sub-gumps using them right now
ThreeButtonDialog.LEFT_BUTTON_ID = 1
ThreeButtonDialog.CENTER_BUTTON_ID = 2
ThreeButtonDialog.RIGHT_BUTTON_ID = 3


 
-- Creates a new table or uses the passed in table, and causes all functions of 
--   ThreeButtonDialog to be inherited by it. If the table overrides these functions
--   then that new version will be used instead. 
--
-- The normal method of using this is for your new class/Lua file to call something like
--   "NewClassName = ThreeButtonDialog:new()" at the top of the file
--   then to declare an object of that class you can call "MyNewWindow = NewClassName:new()"
--   in your initialize function. 
--
-- If you then call the "MyNewWindow:Init()" function the default version will map
--   the window's name (static or dynamic) to your MyNewWindow data for retrieval 
--   by any class functions.
--
function ThreeButtonDialog:new( newWindow )
	newWindow = newWindow or {}
	setmetatable(newWindow, self)
	self.__index = self
	
	return newWindow
end


-- Init does the following:
--   1. retrieves data from the server
--   2. calls the object specific setDataFunction() to put the server data into standard fields
--   3. assigns those fields to the actual button/window names in setFields
--
-- ThreeButtonDialogs have a default setDataFunction and setFields functions, but
--   either or both can be overwritten for different behavior. In some cases you may
--   wish to ignore the setFields function, e.g. set "self:setFields = nil" and
--   directly set the incoming data to the windows in the self:setDataFunction
--
function ThreeButtonDialog:Init()
	
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end
	
	if self.setFields then
		self:setFields()
	end

	ThreeButtonDialogManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
	
	Debug.PrintToDebugConsole( L"Initialize "..self.name )
end


----------------------------------------------------------------
-- ThreeButtonDialog (Manager) Functions
----------------------------------------------------------------


function ThreeButtonDialog.parseDescAsTitleSubtitleTextAndThreeButtons(gumpData)
	--UO_GenericGump.debug( L"parseDescAsTitleTextAndTwoButtons - setting data for = "..gumpData.name )
	gumpData.title = GGManager.translateTID(gumpData.descData[1])
	gumpData.subtitle = GGManager.translateTID(gumpData.descData[2])
	gumpData.text = GGManager.translateTID(gumpData.descData[3])
	gumpData.leftButtonName = GGManager.translateTID(gumpData.descData[4])
	gumpData.rightButtonName = GGManager.translateTID(gumpData.descData[5])
	gumpData.centerButtonName = GGManager.translateTID(gumpData.descData[6])
	
	gumpData.leftButtonID = gumpData.buttonIDs[1]
	gumpData.rightButtonID = gumpData.buttonIDs[2]
	gumpData.centerButtonID = gumpData.buttonIDs[3]	
end


function ThreeButtonDialog.getVirtueIdFromTid( tid )
	for index, virtueData in pairs(VirtueMenu.VirtueData) do
		if( virtueData.nameTid == tid ) then
			return index
		end
	end
end


function ThreeButtonDialog:setFields()

	if self.title then
		WindowUtils.SetActiveDialogTitle( self.title )
    end
	if self.subtitle then
		LabelSetText( self.windowName.."Subtitle", self.subtitle )
    end
    
    LabelSetText( self.windowName.."ScrollChildText", self.text )
    
    if self.leftButtonName and self.leftButtonID then
		ButtonSetText(self.windowName.."LeftButtonName", self.leftButtonName )
		WindowSetId( self.windowName.."LeftButtonName", self.leftButtonID )	
		-- KLUDGE: The garbage collector doesn't usually destroy these fast enough.
		self.leftButtonID = nil
		self.leftButtonName = nil	
	else
		WindowSetShowing( self.windowName.."LeftButtonName", false )
	end
	
	--ButtonSetText(self.windowName.."RightButtonName", self.rightButtonName )
	--WindowSetId( self.windowName.."RightButtonName", self.rightButtonID )
	ButtonSetText(self.windowName.."CenterButtonName", self.centerButtonName )
	WindowSetId( self.windowName.."CenterButtonName", self.centerButtonID )
	
	-- get the right icon data based off the tid of the title
	local virtueId = ThreeButtonDialog.getVirtueIdFromTid( self.descData[1] )
	local texture, x, y = GetIconData( VirtueMenu.VirtueData[virtueId].iconId )
	DynamicImageSetTexture( self.windowName.."SquareIcon", texture, x, y )
	WindowSetId(self.windowName.."SquareIcon",virtueId)
	
	-- *** KLUDGE - the size of the subtitle was causing the text to not scroll
	--   to the bottom.
	local subtitle_width, subtitle_height = WindowGetDimensions( self.windowName.."Subtitle" )
	local text_width, text_height = WindowGetDimensions( self.windowName.."ScrollChildText" )	
	WindowSetDimensions( self.windowName.."ScrollChildText", text_width, text_height+subtitle_height )
end


function ThreeButtonDialog.getActiveWindowData()
	local windowName = WindowGetParent(SystemData.ActiveWindow.name)
	--local windowName = WindowUtils.GetActiveDialog()
	return ThreeButtonDialogManager.knownWindows[windowName]
end

----------------------------------------------------------------
-- ThreeButtonDialog Functions
----------------------------------------------------------------

-- OnInitialize Handler
function ThreeButtonDialog.Initialize()
	local newWindow = ThreeButtonDialog:new()

	newWindow.setDataFunction = ThreeButtonDialog.parseDescAsTitleSubtitleTextAndThreeButtons
	newWindow:Init()
	
end 


function ThreeButtonDialog.LeftButtonPressed()
	
	local self = ThreeButtonDialog.getActiveWindowData()
	
	-- specialized windows can declare their own RightButtonFunction() or else 
	--   use the DefaultButtonFunction assuming the button's ID has been set.
	if  self.LeftButtonFunction then
		self.LeftButtonFunction()
	else
		self:DefaultButtonFunction()
	end	
end


--[[ Removed due to being replaced by icon
function ThreeButtonDialog.RightButtonPressed()
	
	local self = ThreeButtonDialog.getActiveWindowData()
	
	-- specialized windows can declare their own RightButtonFunction() or else 
	--   use the DefaultButtonFunction assuming the button's ID has been set.
	if  self.RightButtonFunction then
		self.RightButtonFunction()
	else
		self:DefaultButtonFunction()
	end	
end
--]]

function ThreeButtonDialog.CenterButtonPressed()
	
	local self = ThreeButtonDialog.getActiveWindowData()
	
	-- specialized windows can declare their own RightButtonFunction() or else 
	--   use the DefaultButtonFunction assuming the button's ID has been set.
	if  self.CenterButtonFunction then
		self.CenterButtonFunction()
	else
		self:DefaultButtonFunction()
	end	
end

function ThreeButtonDialog:DefaultButtonFunction()
	UO_GenericGump.debug( L"ThreeButtonDialog:DefaultButtonFunction called. ")
	
	local buttonID = WindowGetId( SystemData.ActiveWindow.name )

	-- NOTE: this may need to be changed. Currently WindowGetId seems to return 0,
	--  if a value is not set (and 0 is a valid value). May change C++ to return negative value
	--  when no value is set
	if not buttonID then	
		Debug.PrintToDebugConsole( L"ERROR in ThreeButtonDialog.DefaultButtonFunction: no ID set for button pressed." )
		return
	end

	UO_GenericGump.debug( L"called ThreeButtonDialog.DefaultButtonFunction(). Sending button value of "..buttonID )

	UO_GenericGump.broadcastButtonPress( buttonID, self )
	self.OnCloseWindow()
end

--
function ThreeButtonDialog.OnCloseWindow()
	UO_GenericGump.debug( L"ThreeButtonDialog.OnCloseWindow called. ")

	GGManager.destroyActiveWindow()
end

function ThreeButtonDialog.ItemLButtonDown()
	local virtueId = WindowGetId(SystemData.ActiveWindow.name)
	
	local itemData = 
	{
		Type = Cursor.TYPE_ACTION,
		ActionType = SystemData.UserAction.TYPE_INVOKE_VIRTUE,
		IconId = VirtueMenu.VirtueData[virtueId].iconId,
		ItemId = virtueId
	}
	Cursor.Pickup(itemData)
end

function ThreeButtonDialog.ItemLButtonUp()
	local virtueId = WindowGetId(SystemData.ActiveWindow.name)
	
	UserActionInvokeVirtue(virtueId)
end
