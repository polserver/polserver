----------------------------------------------------------
-- PuzzleGuess.lua
----------------------------------------------------------------

PuzzleGuess = MasterGUMP:new()

function PuzzleGuess.Initialize()

	local newWindow					= PuzzleGuess:new()
	newWindow.setData				= PuzzleGuess.mySetData
	newWindow:Init()
end

function PuzzleGuess:mySetData()

	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Subtitle = GGManager.translateTID( self.descData[1] )
	self.Page[1].ScrollText = GGManager.translateTID( self.descData[2] )..L"\n"..self.stringData[1]..L"\n\n"..GGManager.translateTID( self.descData[3] )..L"\n"..self.stringData[2]
	self.Page[1].MiddleButtonId = self.buttonIDs[1]
	self.Page[1].MiddleButtonText = GGManager.translateTID( GGManager.OKAY_TID )
	
end
