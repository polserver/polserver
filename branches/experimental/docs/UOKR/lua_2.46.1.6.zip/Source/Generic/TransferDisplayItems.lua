----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

TransferDisplayItems = ChoiceList:new()
local choiceNum, choiceName = {} , {}

----------------------------------------------------------------
-- TransferDisplayItems Functions
----------------------------------------------------------------

-- The wombat script xfer_packup_player.wxx calls this gump two different times, with different data each time.
function TransferDisplayItems:setDataFunction()
	UO_GenericGump.debug( L"TransferDisplayItems:setDataFunction - setting data for = "..StringToWString( self.windowName ) )
	
	self.subtitle = GGManager.translateTID( self.descData[1] )
	
	if self.stringDataCount == 0 then
		self.text = GGManager.translateTID( self.descData[2] )
		choiceNum[1], choiceName[1] = self.buttonIDs[3], GGManager.translateTID( self.descData[4] ) -- "Transfer me!"
		choiceNum[2], choiceName[2] = self.buttonIDs[2], GGManager.translateTID( self.descData[3] ) -- "Cancel transfer"
		UO_GenericGump.debug( L"choiceNum[1] = "..choiceNum[1]..L"  choiceName[1] = "..choiceName[1]..L"\n"
							..L"choiceNum[2] = "..choiceNum[2]..L"  choiceName[2] = "..choiceName[2] )
	else
		self.text = GGManager.translateTID( self.descData[2] )..L"\n\n"
					..GGManager.translateTID( self.descData[3] )..L"\n"..self.stringData[1]..L"\n\n"
					..GGManager.translateTID( self.descData[4] )..L"\n"..self.stringData[3]..L"\n\n"
					..GGManager.translateTID( self.descData[5] )..L"\n"..self.stringData[2]
		choiceNum[1], choiceName[1] = self.buttonIDs[2], GGManager.translateTID( self.descData[6] ) -- "Next page"
		choiceNum[2], choiceName[2] = self.buttonIDs[3], GGManager.translateTID( self.descData[7] ) -- "Cancel transfer"
		UO_GenericGump.debug( L"choiceNum[1] = "..choiceNum[1]..L"  choiceName[1] = "..choiceName[1]..L"\n"
							..L"choiceNum[2] = "..choiceNum[2]..L"  choiceName[2] = "..choiceName[2] )
	end
	
	local scrollWindow = self.windowName.."Scroll"
	local tempWidth, tempHeight, scrollWindowWidth, scrollWindowHeight
	
	self:CreateSubtitle( self.subtitle )
	-- final scrollWindowHeight is dynamically reduced by the height of other windows present in each instance
	scrollWindowWidth, scrollWindowHeight = WindowGetDimensions( scrollWindow )
	local relativeWindow = self.windowName
	-- add last selectable text at bottom, underneath ScrollWindow, and work upwards
	relativeWindow = self:CreateChoiceListSelectableText( choiceNum[2], choiceName[2], 
					"bottomleft", relativeWindow, "bottomleft", 10, -10, nil, nil, self.windowName )
	UO_GenericGump.debug( L"choice 2 relativeWindow = "..StringToWString( relativeWindow ) )
	-- get height of selectable text labels and subtract from scrollWindowHeight
	tempWidth, tempHeight = WindowGetDimensions( relativeWindow )
	scrollWindowHeight = scrollWindowHeight - tempHeight
	
	relativeWindow = self:CreateChoiceListSelectableText( choiceNum[1], choiceName[1], 
					"topleft", relativeWindow, "bottomleft", 0, 0, nil, nil, self.windowName )
	UO_GenericGump.debug( L"choice 1 relativeWindow = "..StringToWString( relativeWindow ) )
	tempWidth, tempHeight = WindowGetDimensions( relativeWindow )

	-- KLUDGE: the +20 removes the extra space that was hardcoded for a regular button in ChoiceList.xml
	scrollWindowHeight = scrollWindowHeight - tempHeight + 20
	UO_GenericGump.debug( "final scrollWindowHeight of "..tostring( scrollWindowHeight ) )
	WindowSetDimensions( scrollWindow, scrollWindowWidth, scrollWindowHeight )
	-- text inside scroll window
	self:CreateText( 1, self.text, "topleft", self.windowName.."ScrollChild", "topleft", 0, 0 )	
end

-- OnInitialize Handler
function TransferDisplayItems.Initialize()
	local newWindow = TransferDisplayItems:new()
	newWindow.setDataFunction = TransferDisplayItems.setDataFunction
	newWindow:Init()
end