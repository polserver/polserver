----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

TransferWarning = OneButtonDialog:new()

----------------------------------------------------------------
-- TransferWarning Functions
----------------------------------------------------------------

function TransferWarning:setDataFunction()
--function TransferWarning.setDataFunction(self)
    UO_GenericGump.debug( L"called TransferWarning:setDataFunction()" )
    
	self.subtitle = GGManager.translateTID (self.descData[1])
	self.text = GGManager.translateTID (self.descData[2])..L"\n\n"
				..GGManager.translateTID (self.descData[3])..L" "..self.stringData[1]
	
	self.buttonName = GGManager.translateTID(GGManager.OKAY_TID)
	self.buttonID = self.buttonIDs[2]
end

-- OnInitialize Handler
function TransferWarning.Initialize()
	local newWindow = TransferWarning:new()
	newWindow.setDataFunction = TransferWarning.setDataFunction
	newWindow:Init()
end