----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------
MessageDetails = Multipage:new(1)


function MessageDetails.Initialize()
	local NumOfPages = 1
	
	local NewWindow = MessageDetails:new(NumOfPages)

	NewWindow.Page[1].pageName =  "1"

	NewWindow:Init()
	
	
end 


function MessageDetails:setFields()
	--UO_GenericGump.debug( L"Before multipage.SetFields")
	
	-- set all of the normal fields
	Multipage.setFields(self)
	
	-- make the close button act like the right (cancel) button
	WindowSetId( self.windowName.."Chrome_UO_WindowCloseButton", self.Page[1].rightButtonID )
	Interface.OnCloseCallBack[self.windowName] = Multipage.RightButtonPressed
	
	-- disable the previous/next buttons based on the number of buttons sent by the server
	-- if there's only one prev/next we have to use the ID to figure out which it is
	
	if self.buttonCount < 3 then
		ButtonSetDisabledFlag( self.Page[1].pageName.."PrevButton", true)
		ButtonSetDisabledFlag( self.Page[1].pageName.."NextButton", true)
    elseif self.buttonCount >= 4 then
		ButtonSetDisabledFlag( self.Page[1].pageName.."PrevButton", false)
		ButtonSetDisabledFlag( self.Page[1].pageName.."NextButton", false)
	else
		ButtonSetDisabledFlag( self.Page[1].pageName.."PrevButton", self.buttonIDs[3]==3)
		ButtonSetDisabledFlag( self.Page[1].pageName.."NextButton", self.buttonIDs[3]==2)
	end

end


function MessageDetails:SetCurrentPage( buttonID )
	self:DefaultButtonFunction()
end



function MessageDetails:setDataFunction()

	self.Page[1].pageName = self.windowName.."OnlyPage"

	-- the title
	self.Page[1].title = GGManager.translateTID( 1078609 )
	
	--display
	self.Page[1].text = self.stringData[1]..L"\n\n"..GGManager.translateTID( self.descData[2] )
	
	self.Page[1].leftButtonName = GGManager.translateTID(GGManager.OKAY_TID)  
	self.Page[1].rightButtonName = GGManager.translateTID(GGManager.CANCEL_TID)  
	
	
	self.Page[1].leftButtonID = self.buttonIDs[1]
	self.Page[1].rightButtonID = self.buttonIDs[2]
	self.Page[1].prevButtonID = 2
	self.Page[1].nextButtonID = 3

end

