----------------------------------------------------------------
-- PromoCode.lua
----------------------------------------------------------------

PromoCode = TextEntry:new()

function PromoCode.Initialize()

	local newWindow = PromoCode:new()
	newWindow:Init()
end

function PromoCode:setDataFunction()

	-- the title
	WindowUtils.SetActiveDialogTitle( GGManager.translateTID( 1078245 ) )

	-- the subtitle
	LabelSetText( self.windowName.."Subtitle", GGManager.translateTID( self.descData[2] ) )

	-- the textbox
--	TextEditBoxSetText( self.windowName.."TextBox", "" )
	WindowSetId( self.windowName.."TextBox", self.buttonIDs[3] )	

	-- left button
	ButtonSetText( self.windowName.."LeftButton", GGManager.translateTID( GGManager.OKAY_TID ) )
	WindowSetId( self.windowName.."LeftButton", self.buttonIDs[1] )

	-- right button
	ButtonSetText( self.windowName.."RightButton", GGManager.translateTID( GGManager.CANCEL_TID ) )
	WindowSetId( self.windowName.."RightButton", self.buttonIDs[2] )
	
	
	WindowSetId( self.windowName.."Chrome_UO_TitleBar_WindowTitle", self.buttonIDs[2] )
	Interface.OnCloseCallBack[self.windowName] = self.LRButtonPressed
end

function PromoCode:setFields()
end

function PromoCode.LRButtonPressed()

	local self		= TextEntryManager.knownWindows[WindowUtils.GetActiveDialog()]
	local buttonID	= WindowGetId( SystemData.ActiveWindow.name )
	
	UO_GenericGump.debug( L"buttonID = "..buttonID )
	
	local textEntries = {}
	textEntries[self.buttonIDs[3]] = TextEditBoxGetText( self.windowName.."TextBox" )
	
	UO_GenericGump.broadcastTextEntries( buttonID, textEntries, self )
	self.OnCloseWindow()
end


function PromoCode.OnCloseWindow()
	
	GGManager.destroyActiveWindow()
end
