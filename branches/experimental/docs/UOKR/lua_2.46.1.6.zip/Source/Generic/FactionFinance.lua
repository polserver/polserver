----------------------------------------------------------
-- FactionFactionstone.lua
----------------------------------------------------------------

FactionFinance = MasterGUMP:new()

function FactionFinance.Initialize()

	local newWindow					= FactionFinance:new()
	newWindow.setData				= FactionFinance.mySetData
	newWindow:Init()
end

function FactionFinance:mySetData()

	self.CreatePrevNextButtons = true
	
	-- Main Page
	self.Page[1] = {}
	
	-- page indexs offset because page 0 is empty but shows
	--  up as page 1 in lua
	local dscItr	= self.descPageIndex[2]
	local dscItrEnd	= self.descPageIndex[3]
	local btnItr	= self.buttonPageIndex[2]
	local btnItrEnd	= self.buttonPageIndex[3]

	self.Page[1].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[1].Selections = {}
	
	local index = 1
	while dscItr < dscItrEnd - 1
	do
		self.Page[1].Selections[index]		= {}
		self.Page[1].Selections[index].Id	= self.buttonIDs[btnItr]
		self.Page[1].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )
		
		index	= index  + 1
		dscItr	= dscItr + 1
		btnItr	= btnItr + 1
	end
	
	self.Page[1].MiddleButtonId		= self.buttonIDs[btnItr]
	self.Page[1].MiddleButtonText	= GGManager.translateTID( self.descData[dscItr] )
	
	-- Change Prices page
	self.Page[2] = {}
	
	-- page indexs offset because page 0 is empty but shows
	--  up as page 1 in lua
	local dscItr	= self.descPageIndex[3]
	local strItr	= self.stringPageIndex[3]
	local btnItr	= self.buttonPageIndex[3]
	local btnItrEnd	= self.buttonPageIndex[4]

	self.Page[2].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[2].Selections = {}
	
	local highlighted = self.buttonIDs[btnItrEnd - 3]
	
	strItr	= 12
	local index = 1
	while btnItr < btnItrEnd - 3
	do
		self.Page[2].Selections[index]		= {}
		
		if self.buttonIDs[btnItr] == highlighted
		then
			self.Page[2].Selections[index].Id	= self.HIGHLIGHT_BUTTON_ID
		else
			self.Page[2].Selections[index].Id	= self.buttonIDs[btnItr]
		end
		
		if self.buttonIDs[btnItr] == 7 -- the normal
		then
			self.Page[2].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )
			dscItr	= dscItr + 1
		else
			self.Page[2].Selections[index].Text	= self.stringData[strItr]
		end
		
		btnItr	= btnItr + 1
		strItr	= strItr + 1
		index	= index  + 1
	end
	
	self.Page[2].RadioId = self.buttonIDs[btnItr + 1]
	
	self.Page[2].MiddleButtonId		= self.buttonIDs[btnItr + 2]
	self.Page[2].MiddleButtonText	= GGManager.translateTID( 1011393 )

	-- Buy Shopkeepers page
	self.Page[3] = {}
	
	local dscItr	= self.descPageIndex[4]
	local dscItrEnd	= self.descPageIndex[5]
	local imgItr	= self.ImagePageIndex[4]
	local strItr	= self.stringPageIndex[4]
	local btnItr	= self.buttonPageIndex[4]

	self.Page[3].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[3].Selections = {}
	
	local index = 1
	while dscItr < dscItrEnd - 1
	do
		self.Page[3].Selections[index]		= {}
		self.Page[3].Selections[index].Id	= self.buttonIDs[btnItr]
		self.Page[3].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )
		self.Page[3].Selections[index].Icon	= self.ImageNum[imgItr]
		
		index	= index  + 1
		btnItr	= btnItr + 1
		dscItr	= dscItr + 1
		imgItr	= imgItr + 1
	end
	
	self.Page[3].MiddleButtonId		= self.buttonIDs[btnItr]
	self.Page[3].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- View Finances page
	self.Page[4] = {}
	
	local dscItr	= self.descPageIndex[5]
	local btnItr	= self.buttonPageIndex[5]

	self.Page[4].Subtitle	= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[4].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[58]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[56]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[55]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[54]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[53]
	
	self.Page[4].MiddleButtonId		= self.buttonIDs[btnItr]
	self.Page[4].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Bottle Vendor
	self.Page[5] = {}
	
	local dscItr	= self.descPageIndex[6]
	local btnItr	= self.buttonPageIndex[6]

	self.Page[5].Subtitle	= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[5].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[61]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[51]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[47]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[49]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[58]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[69]
	
	self.Page[5].Selections				= {}		
	self.Page[5].Selections[1]			= {}
	self.Page[5].Selections[1].Id		= self.buttonIDs[btnItr]
	self.Page[5].Selections[1].Text		= GGManager.translateTID( self.descData[dscItr + 6] )
	self.Page[5].Selections[1].Bottom	= true
	
	self.Page[5].MiddleButtonId		= self.buttonIDs[btnItr + 1]
	self.Page[5].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Wood Vendor
	self.Page[6] = {}
	
	local dscItr	= self.descPageIndex[7]
	local btnItr	= self.buttonPageIndex[7]

	self.Page[6].Subtitle	= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[6].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[62]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[51]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[48]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[50]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[58]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[69]
	
	self.Page[6].Selections				= {}		
	self.Page[6].Selections[1]			= {}
	self.Page[6].Selections[1].Id		= self.buttonIDs[btnItr]
	self.Page[6].Selections[1].Text		= GGManager.translateTID( self.descData[dscItr + 6] )
	self.Page[6].Selections[1].Bottom	= true
	
	self.Page[6].MiddleButtonId		= self.buttonIDs[btnItr + 1]
	self.Page[6].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Iron Ore Vendor
	self.Page[7] = {}
	
	local dscItr	= self.descPageIndex[8]
	local btnItr	= self.buttonPageIndex[8]

	self.Page[7].Subtitle	= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[7].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[63]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[51]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[48]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[50]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[58]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[69]
	
	self.Page[7].Selections				= {}		
	self.Page[7].Selections[1]			= {}
	self.Page[7].Selections[1].Id		= self.buttonIDs[btnItr]
	self.Page[7].Selections[1].Text		= GGManager.translateTID( self.descData[dscItr + 6] )
	self.Page[7].Selections[1].Bottom	= true
	
	self.Page[7].MiddleButtonId		= self.buttonIDs[btnItr + 1]
	self.Page[7].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Reagent Vendor
	self.Page[8] = {}
	
	local dscItr	= self.descPageIndex[9]
	local btnItr	= self.buttonPageIndex[9]

	self.Page[8].Subtitle	= GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[8].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[64]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[51]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[47]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[49]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[58]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[69]
	
	self.Page[8].Selections				= {}		
	self.Page[8].Selections[1]			= {}
	self.Page[8].Selections[1].Id		= self.buttonIDs[btnItr]
	self.Page[8].Selections[1].Text		= GGManager.translateTID( self.descData[dscItr + 6] )
	self.Page[8].Selections[1].Bottom	= true
	
	self.Page[8].MiddleButtonId		= self.buttonIDs[btnItr + 1]
	self.Page[8].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Horse Breeder Vendor
	self.Page[9] = {}
	
	local dscItr	= self.descPageIndex[10]
	local btnItr	= self.buttonPageIndex[10]

	--self.Page[9].Subtitle	= GGManager.translateTID( self.descData[dscItr] )
	self.Page[9].SubtitleHL	= true
	dscItr = dscItr + 1
	
	self.Page[9].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[65]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[51]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[47]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[49]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[58]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[69]
	
	self.Page[9].Selections				= {}		
	self.Page[9].Selections[1]			= {}
	self.Page[9].Selections[1].Id		= self.buttonIDs[btnItr]
	self.Page[9].Selections[1].Text		= GGManager.translateTID( self.descData[dscItr + 6] )
	self.Page[9].Selections[1].Bottom	= true
	
	self.Page[9].MiddleButtonId		= self.buttonIDs[btnItr + 1]
	self.Page[9].MiddleButtonText	= GGManager.translateTID( 1011393 )
end
