-- This is not the template you're looking for. No really. Try ChoiceList instead.

-- This is the code used only for the gumps that use base_choicegump_text.wxx or createChoiceGumpWithText()

----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

ChoiceText = ChoiceList:new()

----------------------------------------------------------------
-- Promo7thChoice Functions
----------------------------------------------------------------

function ChoiceText:setDataFunction()

	-- Don't use a wide ChoiceList
	local isWide = false 
	
	-- Thing to attach the next thing to
	local relativeWindow
	
	-- Looping variable
	local descIndex

	local nextButton = 1

	-- Set the title (disabled - never used)
	--WindowUtils.SetActiveDialogTitle( L"TITLE NOT SET" )

	-- The cancel button
	self:CreateBottomButton( GGManager.translateTID( self.descData[1] ), self.buttonIDs[1] )

	-- Set the subtitle	
	relativeWindow = self:CreateSubtitle( GGManager.translateTID( self.descData[2] ), isWide )

	-- If you have localized data coming in, use that instead of descData
	if self.localizedDataCount > 0 then
		--UO_GenericGump.debug( L"Using localizedData!" )
	
		-- The buttons we want to use are the nonzero ones
		while self.buttonIDs[nextButton] == 0 and self.buttonIDs[nextButton] do
			nextButton = nextButton + 1
		end -- while
			
		-- The first choice
		relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[nextButton], GGManager.stripMarkup( self.localizedData[1] ), "topleft", relativeWindow, "topleft", 0, 0, isWide )
		nextButton = nextButton + 1
		
		-- The remaining choices
		for descIndex=2, self.localizedDataCount do		
			-- The buttons we want to use are the nonzero ones
			while self.buttonIDs[nextButton] == 0 and self.buttonIDs[nextButton] do
				nextButton = nextButton + 1
			end -- while
			relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[nextButton], GGManager.stripMarkup( self.localizedData[descIndex] ), "bottom", relativeWindow, "top", 0, 0 )
			nextButton = nextButton + 1
		end -- for

	else -- Use the descData
		--UO_GenericGump.debug( L"Using descData!" )
		
		-- The first choice
		relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[2], GGManager.translateTID( self.descData[3] ), "topleft", relativeWindow, "topleft", 0, 0, isWide )

		-- The remaining choices
		for descIndex=4, self.descDataCount do
			-- Skip any back or next buttons found
			if  self.descData[descIndex] ~= 1043353 and self.descData[descIndex] ~= 1011393 then		
				relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[descIndex-1], GGManager.translateTID( self.descData[descIndex] ), "bottom", relativeWindow, "top", 0, 0 )
			end -- if
		end -- for
		
	end -- if localizedData	
	
	
end -- ChoiceText:setDataFunction()

-- Standard OnInitialize Handler
function ChoiceText.Initialize()
	local newWindow = ChoiceText:new()
	newWindow.setDataFunction = ChoiceText.setDataFunction
	newWindow:Init()
end
