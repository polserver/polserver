----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

TchestRemoveWarning = ChoiceList:new()

----------------------------------------------------------------
-- TchestRemoveWarning Functions
----------------------------------------------------------------

function TchestRemoveWarning:setDataFunction()
	UO_GenericGump.debug( L"TchestRemoveWarning:setDataFunction - setting data for = "..self.name )

	local relativeWindow = self.windowName.."ScrollChild"
	-- descData[1] and [2] are plain text, anchor to top of ScrollChild. others below will anchor to this one.
	relativeWindow = TchestRemoveWarning.CreateText( self, 1, GGManager.translateTID( self.descData[1] )
					..L"\n\n"..GGManager.translateTID( self.descData[2] )..L"\n\n", "topleft", relativeWindow, "topleft", 0, 0 )
	-- descData[3] and [4] are selectable text
	relativeWindow = TchestRemoveWarning.CreateChoiceListSelectableText( self, self.buttonIDs[1],
					GGManager.translateTID( self.descData[3] ), "bottom", relativeWindow, "top", 0, 0 )
	relativeWindow = TchestRemoveWarning.CreateChoiceListSelectableText( self, self.buttonIDs[2],
					GGManager.translateTID( self.descData[4] ), "bottom", relativeWindow, "top", 0, 10 )
end

-- OnInitialize Handler
function TchestRemoveWarning.Initialize()
	local newWindow = TchestRemoveWarning:new()
	newWindow.setDataFunction = TchestRemoveWarning.setDataFunction
	newWindow:Init()
end