----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

TransferInfo = ChoiceList:new()
local choiceNum, choiceName = {} , {}

----------------------------------------------------------------
-- TransferInfo Functions
----------------------------------------------------------------

-- The wombat script xfer_packup_player.wxx calls this gump two different times, with different data each time.
function TransferInfo:setDataFunction()
	UO_GenericGump.debug( L"TransferInfo:setDataFunction - setting data for = "..StringToWString( self.windowName ) )
	
	self.subtitle = GGManager.translateTID( self.descData[1] )
	
	self.text = GGManager.translateTID( self.descData[2] )
	choiceNum[1], choiceName[1] = self.buttonIDs[2], GGManager.translateTID( self.descData[3] )
	choiceNum[2], choiceName[2] = self.buttonIDs[1], GGManager.translateTID( self.descData[4] )
	UO_GenericGump.debug( L"choiceNum[1] = "..choiceNum[1]..L"  choiceName[1] = "..choiceName[1]..L"\n"
						..L"choiceNum[2] = "..choiceNum[2]..L"  choiceName[2] = "..choiceName[2] )
	
	local scrollWindow = self.windowName.."Scroll"
	local tempWidth, tempHeight, scrollWindowWidth, scrollWindowHeight
	
	self:CreateSubtitle( self.subtitle )
	-- final scrollWindowHeight is dynamically reduced by the height of other windows present in each instance
	scrollWindowWidth, scrollWindowHeight = WindowGetDimensions( scrollWindow )
	local relativeWindow = self.windowName
	-- add last selectable text at bottom, underneath ScrollWindow, and work upwards
	relativeWindow = self:CreateChoiceListSelectableText( choiceNum[2], choiceName[2], 
					"bottomleft", relativeWindow, "bottomleft", 10, -10, nil, nil, self.windowName )
	UO_GenericGump.debug( L"choice 2 relativeWindow = "..StringToWString( relativeWindow ) )
	-- get height of selectable text labels and subtract from scrollWindowHeight
	tempWidth, tempHeight = WindowGetDimensions( relativeWindow )
	scrollWindowHeight = scrollWindowHeight - tempHeight
	
	relativeWindow = self:CreateChoiceListSelectableText( choiceNum[1], choiceName[1], 
					"topleft", relativeWindow, "bottomleft", 0, 0, nil, nil, self.windowName )
	UO_GenericGump.debug( L"choice 1 relativeWindow = "..StringToWString( relativeWindow ) )
	tempWidth, tempHeight = WindowGetDimensions( relativeWindow )

	-- KLUDGE: the +20 removes the extra space that was hardcoded for a regular button in ChoiceList.xml
	scrollWindowHeight = scrollWindowHeight - tempHeight + 20
	UO_GenericGump.debug( "final scrollWindowHeight of "..tostring( scrollWindowHeight ) )
	WindowSetDimensions( scrollWindow, scrollWindowWidth, scrollWindowHeight )
	-- text inside scroll window
	self:CreateText( 1, self.text, "topleft", self.windowName.."ScrollChild", "topleft", 0, 0 )	
end

-- OnInitialize Handler
function TransferInfo.Initialize()
	local newWindow = TransferInfo:new()
	newWindow.setDataFunction = TransferInfo.setDataFunction
	newWindow:Init()
end