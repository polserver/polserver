----------------------------------------------------------
-- VacloakGameone.lua
----------------------------------------------------------------

VacloakGameone = MasterGUMP:new()

function VacloakGameone.Initialize()
	local newWindow					= VacloakGameone:new()
	newWindow.setData				= VacloakGameone.mySetData
	newWindow:Init()
end

function VacloakGameone:mySetData()

	-- Start NO CLOSE code block -- Put this in any gump that should not have a close button
	ButtonSetDisabledFlag( self.windowName.."Chrome_UO_WindowCloseButton", true )
	WindowSetShowing( self.windowName.."Chrome_UO_WindowCloseButton", false )
	-- End NO CLOSE code block
	
	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Subtitle = GGManager.translateTID( self.descData[1] )
	self.Page[1].Selections = {}
	self.Page[1].Selections[1] = {}
	self.Page[1].Selections[1].Id = self.buttonIDs[1]
	self.Page[1].Selections[1].Text = GGManager.translateTID( self.descData[2] )
	self.Page[1].Selections[2] = {}
	self.Page[1].Selections[2].Id = self.buttonIDs[2] 
	self.Page[1].Selections[2].Text = GGManager.translateTID( self.descData[3] )
	self.Page[1].Selections[3] = {}
	self.Page[1].Selections[3].Id = self.buttonIDs[3]
	self.Page[1].Selections[3].Text = GGManager.translateTID( self.descData[4] )
	self.Page[1].Selections[4] = {}
	self.Page[1].Selections[4].Id = self.buttonIDs[4]
	self.Page[1].Selections[4].Text = GGManager.translateTID( self.descData[5] )
end
