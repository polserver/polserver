----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

TransferShardList = ChoiceList:new()

----------------------------------------------------------------
-- TransferShardList Functions
----------------------------------------------------------------

function TransferShardList:setDataFunction()
	UO_GenericGump.debug( L"TransferShardList:setDataFunction - setting data for = "..StringToWString( self.windowName ) )
	local scrollChild = self.windowName.."ScrollChild"
		
	self.subtitle = GGManager.translateTID( self.descData[1] )
	self.text = GGManager.translateTID( self.descData[2] )

	WindowUtils.SetActiveDialogTitle( self.title )
	local relativeWindow = self:CreateSubtitle( self.subtitle )
	relativeWindow = self:CreateText( 1, self.text, "topleft", relativeWindow, "topleft", 0, 0 )
	relativeWindow = self:CreateText( 2, L" ", "bottomleft", relativeWindow, "topleft", 0, 0 )

	-- server names
	for i = 1, self.stringDataCount do
		relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[i + 2], self.stringData[i], 
						"bottomleft", relativeWindow, "topleft", 0, 0, nil, i + 2 )
		-- disables choices for unavailable servers
		if self.buttonIDs[i + 2] < 0 then
			ButtonSetDisabledFlag( relativeWindow, true )
			WindowSetTintColor( relativeWindow.."Icon", 128, 128, 128 )
		end
	end
	self:CreateBottomButton( GGManager.translateTID( GGManager.CANCEL_TID ), self.buttonIDs[1] )
end

function TransferShardList:TextSelectedFunction()
	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	
	if choiceNum >= 0 then
		UO_GenericGump.broadcastButtonPress( choiceNum, self )
		self.OnCloseWindow()
	end
end

-- OnInitialize Handler
function TransferShardList.Initialize()
	local newWindow = TransferShardList:new()
	newWindow.setDataFunction = TransferShardList.setDataFunction
	newWindow:Init()
end