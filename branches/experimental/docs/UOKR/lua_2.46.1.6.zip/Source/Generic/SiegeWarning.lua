----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

SiegeWarning = TwoButtonDialog:new()

----------------------------------------------------------------
-- SiegeWarning Functions
----------------------------------------------------------------

function SiegeWarning:parseData()
	-- self.subtitle = L"" -- GGManager.translateTID( self.descData[5] )..L"   "..GGManager.translateTID( self.descData[6] )
	self.text = GGManager.translateTID( self.descData[1] )..L" "..self.stringData[1] -- GGManager.stripMarkup( self.stringData[1] )
	self.leftButtonName = GGManager.translateTID( GGManager.OKAY_TID )
	self.rightButtonName = GGManager.translateTID( 1078056 )	 -- "MORE"
	self.leftButtonID = self.buttonIDs[1]
	self.rightButtonID = self.buttonIDs[2]
end

-- OnInitialize Handler
function SiegeWarning.Initialize()
	local newWindow = SiegeWarning:new()
	newWindow.setDataFunction = SiegeWarning.parseData
	newWindow:Init()
end
