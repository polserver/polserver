----------------------------------------------------------
-- ShrineTithe.lua
----------------------------------------------------------------

ShrineTithe = MasterGUMP:new()

function ShrineTithe.Initialize()

	local newWindow					= ShrineTithe:new()
	newWindow.setData				= ShrineTithe.mySetData
	newWindow:Init()
end

function ShrineTithe:mySetData()

	self.IsStandardHeight = true
	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Subtitle = GGManager.translateTID( self.descData[1] )
	self.Page[1].ScrollText =	GGManager.translateTID( self.descData[2] )..L" "..GGManager.stripMarkup( self.stringData[2] )..
								L"\n"..GGManager.translateTID( self.descData[3] )..L" "..GGManager.stripMarkup( self.stringData[1] )
	self.Page[1].SelectionTemplate = "ShrineTitheSelectable"
	self.Page[1].Selections = {}
	self.Page[1].Selections[1] = {}
	self.Page[1].Selections[1].Id = 0
	self.Page[1].Selections[1].Text = L" " -- GGManager.translateTID( self.descData[2] )
	self.Page[1].MiddleButtonId = self.buttonIDs[7]
	self.Page[1].MiddleButtonText = GGManager.translateTID( GGManager.OKAY_TID )

end

function ShrineTithe:fixup()

	local choiceName = self.windowName.."1Choice1" -- The 1's are page 1 and choice number 1, since we only have the 1 choice on the first page here
	
	-- Disable and hide dummy button and text
	ButtonSetDisabledFlag( choiceName.."Button", true )
	WindowSetShowing( choiceName.."Button", false )
	WindowSetShowing( choiceName.."Text", false )
	
	-- Set new Button IDs
	WindowSetId( choiceName.."NoneButton", self.buttonIDs[2] )
	WindowSetId( choiceName.."LessButton", self.buttonIDs[3] )
	WindowSetId( choiceName.."MoreButton", self.buttonIDs[4] )
	WindowSetId( choiceName.."AllButton", self.buttonIDs[5] )

	-- Set new button labels
	ButtonSetText( choiceName.."NoneButton", L"<<" )
	ButtonSetText( choiceName.."LessButton", L"<"  )
	ButtonSetText( choiceName.."MoreButton", L">"  )
	ButtonSetText( choiceName.."AllButton",  L">>" )
	
	WindowSetId( self.windowName.."Chrome_UO_WindowCloseButton", UO_GenericGump.DEFAULT_CLOSE_BUTTON_ID )
	Interface.OnCloseCallBack[self.windowName] = self.SelectionPressed
	
end
