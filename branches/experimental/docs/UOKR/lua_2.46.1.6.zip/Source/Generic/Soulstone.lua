----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

Soulstone = ChoiceList:new()

----------------------------------------------------------------
-- Soulstone Functions
----------------------------------------------------------------

function Soulstone:setDataFunction()

	-- We are currently using the wide template
	local isWide = true

	-- Use this if you want to give all the cases a title
	-- This can also be put in individual cases if needed
	--WindowUtils.SetActiveDialogTitle( L"SOULSTONE MENU" ) -- GGManager.translateTID( self.descData[3] ) )

	-- All cases have a subtitle which is really the old title
	relativeWindow = ChoiceList.CreateSubtitle( self, GGManager.translateTID( self.descData[3] ), isWide )

	-- The server is being nice and telling KR which format to use
	local case = self.descData[1]

	if -1 == case then
		-- Cancel Button
		ChoiceList.CreateBottomButton( self, GGManager.translateTID( self.descData[2] ), self.buttonIDs[1] )
		local choiceIndex -- for indexing the selectable skills
		-- Add choices for all the skills
		-- TODO: Alphabatize this list! (Maybe here, maybe server side...?)
		for choiceIndex=5,self.descDataCount-1 do  -- ignore the previous page button at the end
			-- Add skill choice
			relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
				self.buttonIDs[choiceIndex-2], GGManager.translateTID( self.descData[choiceIndex] ),
				"bottom", relativeWindow, "top", 0, 0, isWide, choiceIndex )
		end -- for

	elseif -3 == case then
		-- Body Text
		relativeWindow = ChoiceList.CreateText( self, 1, GGManager.translateTID( self.descData[4] )..L"\n\n"..
			GGManager.translateTID( self.descData[5] )..L" "..GGManager.translateTID( self.descData[6] )..L"\n"..
			GGManager.translateTID( self.descData[7] )..L" "..GGManager.stripMarkup( self.stringData[1] )..L"\n"..
			GGManager.translateTID( self.descData[8] )..L" "..GGManager.stripMarkup( self.stringData[2] )..L"\n"..
			GGManager.translateTID( self.descData[9] )..L" "..GGManager.stripMarkup( self.stringData[3] )..L"\n",
			"topleft", relativeWindow, "topleft", 0, 10, isWide )
		-- Activate Choice
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
			self.buttonIDs[3], GGManager.translateTID( self.descData[11] ),
			"bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		-- New Selection Choice
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
			self.buttonIDs[2], GGManager.translateTID( self.descData[10] ),
			"bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		-- Cancel Button
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
			self.buttonIDs[1], GGManager.translateTID( self.descData[2] ),
			"bottomleft", relativeWindow, "topleft", 0, 0, isWide )

	elseif -4 == case then
		-- Body Text
		relativeWindow = ChoiceList.CreateText( self, 1, GGManager.translateTID( self.descData[4] )..L"\n", "topleft", relativeWindow, "topleft", 0, 10, isWide )
		-- Continue Choice
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
			self.buttonIDs[2], GGManager.translateTID( self.descData[5] ),
			"bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		-- Cancel Button
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
			self.buttonIDs[1], GGManager.translateTID( self.descData[2] ),
			"bottomleft", relativeWindow, "topleft", 0, 0, isWide )

	elseif -5 == case then 
		-- Body Text
		relativeWindow = ChoiceList.CreateText( self, 1, GGManager.translateTID( self.descData[4] )..L"\n\n"..
			GGManager.translateTID( self.descData[5] )..L" "..GGManager.translateTID( self.descData[6] )..L"\n"..
			GGManager.translateTID( self.descData[7] )..L" "..GGManager.stripMarkup( self.stringData[1] )..L"\n"..
			GGManager.translateTID( self.descData[8] )..L" "..GGManager.stripMarkup( self.stringData[2] )..L"\n"..
			GGManager.translateTID( self.descData[9] )..L" "..GGManager.stripMarkup( self.stringData[3] )..L"\n",
			"topleft", relativeWindow, "topleft", 0, 10, isWide )
		-- Activate Choice
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
			self.buttonIDs[3], GGManager.translateTID( self.descData[11] ),
			"bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		-- Remove Choice
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
			self.buttonIDs[2], GGManager.translateTID( self.descData[10] ),
			"bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		-- Cancel Button
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
			self.buttonIDs[1], GGManager.translateTID( self.descData[2] ),
			"bottomleft", relativeWindow, "topleft", 0, 0, isWide )

	elseif -6 == case then
		-- Body Text
		relativeWindow = ChoiceList.CreateText( self, 1, GGManager.translateTID( self.descData[4] )..L"\n", "topleft", relativeWindow, "topleft", 0, 10, isWide )
		-- Continue Choice
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
			self.buttonIDs[2], GGManager.translateTID( self.descData[5] ),
			"bottomleft", relativeWindow, "topleft", 0, 0, isWide )
		-- Cancel Button
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
			self.buttonIDs[1], GGManager.translateTID( self.descData[2] ),
			"bottomleft", relativeWindow, "topleft", 0, 0, isWide )

	elseif -9 == case then
		-- Body Text
		relativeWindow = ChoiceList.CreateText( self, 1, GGManager.translateTID( self.descData[4] )..L"\n\n"..
			GGManager.translateTID( self.descData[5] )..L" "..GGManager.translateTID( self.descData[6] )..L"\n"..
			GGManager.translateTID( self.descData[7] )..L" "..GGManager.stripMarkup( self.stringData[1] )..L"\n",		
			"topleft", relativeWindow, "topleft", 0, 10, isWide )
		-- Delete Skill Choice
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
			self.buttonIDs[2], GGManager.translateTID( self.descData[8] ),
			"bottomleft", relativeWindow, "topleft", 0, 0, isWide )		
		-- Cancel Button
		relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
			self.buttonIDs[1], GGManager.translateTID( self.descData[2] ),
			"bottomleft", relativeWindow, "topleft", 0, 0, isWide )
						
	else -- elseif true then -- (ha ha ha)
		UO_GenericGump.debug( L"Something is broken with the soulstone gump. Reached an unknown case: "..case )		
	end -- if case
	
end -- Soulstone:setDataFunction()

-- Standard OnInitialize Handler
function Soulstone.Initialize()
	local newWindow = Soulstone:new()
	newWindow.setDataFunction = Soulstone.setDataFunction
	newWindow:Init()
end
