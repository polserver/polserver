----------------------------------------------------------------
-- StatuePlinthPlaque.lua
----------------------------------------------------------------

StatuePlinthPlaque = MasterGUMP:new()

function StatuePlinthPlaque.Initialize()

	local newWindow					= StatuePlinthPlaque:new()
	newWindow.setData				= StatuePlinthPlaque.mySetData
	newWindow:Init()
end

function StatuePlinthPlaque:mySetData()
	self.Page						= {}
	
	self.Page[1]					= {}
	self.Page[1].Subtitle			= self.stringData[1]..L"\n\n"..self.stringData[2]..L"\n\n"
									..GGManager.translateTID( self.descData[1] )

	self.Page[1].MiddleButtonId		= 1
	self.Page[1].MiddleButtonText	= GGManager.translateTID( GGManager.OKAY_TID )
end
