
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

ReleaseFamiliar = 
{
	LEFT_BUTTON_ID = 1,
	RIGHT_BUTTON_ID = 0,
}



----------------------------------------------------------------
-- ReleaseFamiliar Functions
----------------------------------------------------------------


-- OnInitialize Handler
function ReleaseFamiliar.Initialize()

	ReleaseFamiliar.setDataFunction = TwoButtonDialog.parseDescAsTitleTextAndTwoButtons
	TwoButtonDialog.Init(ReleaseFamiliar)
end
	



