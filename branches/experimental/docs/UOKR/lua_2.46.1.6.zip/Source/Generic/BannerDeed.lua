----------------------------------------------------------
-- BannerDeed.lua
----------------------------------------------------------------

BannerDeed = MasterGUMP:new()

function BannerDeed.Initialize()

	local newWindow					= BannerDeed:new()
	newWindow.setData				= BannerDeed.mySetData
	newWindow:Init()
end

function BannerDeed:mySetData()

	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Subtitle = GGManager.translateTID( 1079181 ) -- stripMarkup( self.stringData[1] ) TODO: Localize this in the Wombat!
	self.Page[1].Selections = {}
	local itr
	local butidx = 1
	for itr = 1, self.ImageCount do
		-- Skip over all the 0 IDed buttons
		while self.buttonIDs[butidx] == 0 do
			butidx = butidx + 1
		end
		self.Page[1].Selections[itr] = {}
		self.Page[1].Selections[itr].Id		= self.buttonIDs[butidx]
		self.Page[1].Selections[itr].Icon	= self.buttonIDs[butidx] -- Yeah, that's right. They're the same.
		butidx = butidx + 1	
	end -- for all images
	self.Page[1].MiddleButtonId = 0 -- Zero is even, so the callback will not do anything
	self.Page[1].MiddleButtonText = GGManager.translateTID( GGManager.CANCEL_TID )
end
