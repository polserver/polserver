
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

Monorail = OneButtonDialog:new()

Monorail.BUTTON_ID = 3


----------------------------------------------------------------
-- Monorail Functions
----------------------------------------------------------------


-- OnInitialize Handler
function Monorail.Initialize()

	local newWindow = Monorail:new()
	newWindow:Init()
	
	WindowSetId( newWindow.windowName.."Chrome_UO_WindowCloseButton", Monorail.BUTTON_ID )
end


function Monorail:setDataFunction()

	self.text = GGManager.translateTID(1075520) -- Are you sure you wish to leave this guided tour?
	self.buttonName = GGManager.translateTID(1074976) -- Yes
	self.buttonID = Monorail.BUTTON_ID	
end

