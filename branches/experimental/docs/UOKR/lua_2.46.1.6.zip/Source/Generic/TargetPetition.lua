----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

TargetPetition = ChoiceList:new()

----------------------------------------------------------------
-- TargetPetition Functions
----------------------------------------------------------------


function TargetPetition:setDataFunction()
	Interface.OnCloseCallBack[self.windowName] = TargetPetition.BottomButtonPressed

	UO_GenericGump.debug( L"TargetPetition:setDataFunction - setting data for = "..StringToWString( self.windowName ) )
	local scrollChild = self.windowName.."ScrollChild"
		
	--self.title = GGManager.translateTID( self.descData[1]) -- the shop name
	LabelSetText( self.windowName.."Subtitle", GGManager.translateTID( self.descData[1] ) )
	self.text = GGManager.translateTID( self.descData[2] )
	
			
	local choiceName = {
		GGManager.translateTID( self.descData[3] )..self.stringData[1]..L"\n",
		GGManager.translateTID( self.descData[4] )..self.stringData[2]..L"\n" ,
		GGManager.translateTID( self.descData[5] )..self.stringData[3]..L"\n"
	}

	WindowUtils.SetActiveDialogTitle( self.title )
	local relativeWindow = 	self:CreateText( 1, self.text, "topleft", scrollChild, "topleft", 0, 0 )
	for i = 1, 3 do
		relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[i], choiceName[i], 
						"bottomleft", relativeWindow, "topleft", 0, 0 )
	end
	
	self.CreateBottomButton( self, GGManager.translateTID(GGManager.OKAY_TID), self.buttonIDs[4] ) -- label, buttonID )
	
end

-- OnInitialize Handler
function TargetPetition.Initialize()
	local newWindow = TargetPetition:new()
	newWindow.setDataFunction = TargetPetition.setDataFunction
	newWindow:Init()
end