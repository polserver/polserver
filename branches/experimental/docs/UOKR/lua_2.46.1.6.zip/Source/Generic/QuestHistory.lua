----------------------------------------------------------
-- QuestHistory.lua
----------------------------------------------------------------

QuestHistory = MasterGUMP:new()

function QuestHistory.Initialize()

	local newWindow					= QuestHistory:new()
	newWindow.setData				= QuestHistory.mySetData
	newWindow:Init()
end

function QuestHistory:mySetData()

	self.Page	= {}
	
	self.CreatePrevNextButtons = true

	for pageNum, _ in ipairs( self.descPageIndex )
	do
		self.Page[pageNum] = {}
		
		local dscItr	= self.descPageIndex[pageNum]
		local dscItrEnd	= self.descDataCount
		if pageNum ~= table.getn( self.descPageIndex )
		then
			dscItrEnd = self.descPageIndex[pageNum + 1] - 1
		end
		
		self.Page[pageNum].Title = GGManager.translateTID( self.descData[1] )
		dscItr = dscItr + 1
	
		self.Page[pageNum].Selections	= {}
		
		local index = 1
		while dscItr <= dscItrEnd
		do
			self.Page[pageNum].Selections[index]		= {}
			self.Page[pageNum].Selections[index].Id		= MasterGUMP.DISABLED2_BUTTON_ID
			self.Page[pageNum].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )
			
			index = index + 1
			dscItr = dscItr + 1
		end
		
		self.Page[pageNum].MiddleButtonId = self.buttonIDs[2]
		self.Page[pageNum].MiddleButtonText = GGManager.translateTID( 1011012 )
	end
end
