
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------


--KnownBrokenGump = { }
KnownBrokenGump = OneButtonDialog:new()


----------------------------------------------------------------
-- KnownBrokenGump Functions
----------------------------------------------------------------

function KnownBrokenGump:setDataFunction()
    
	self.title = L"UNDER CONSTRUCTION" -- Localize this? Nah...
	self.text = L"Since KR is a brand new client, there are still some things that just aren't done yet. You have found one of them.\n\n"..
				L"We are aware of this problem, and are currently taking steps to fix it.\n\n"..
				L"There is no need to report this as a bug - we are already working on it!\n\nJust be patient. Thanks."
	self.buttonName = GGManager.translateTID( 1060675 ) -- "CLOSE"
	self.buttonID = 0
end


-- OnInitialize Handler
function KnownBrokenGump.Initialize()
	-- inherit parent functions and default value (for button)
	local newWindow = KnownBrokenGump:new()
	-- and uses KnownBrokenGump.setDataFunction to parse incoming data
	newWindow:Init()
	
end

-- no message is sent back to server for this Gump
function KnownBrokenGump:ButtonFunction()
	self.OnCloseWindow()
end


