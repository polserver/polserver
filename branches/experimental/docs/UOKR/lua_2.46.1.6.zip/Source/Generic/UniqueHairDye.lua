----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

UniqueHairDye = TwoButtonDialog:new()

----------------------------------------------------------------
-- UniqueHairDye Functions
----------------------------------------------------------------

function UniqueHairDye:parseData()
	self.text = GGManager.translateTID( self.descData[1] )..L"\n\n"..GGManager.translateTID( self.descData[2] )..L"?" 
	self.leftButtonName = GGManager.translateTID( GGManager.OKAY_TID )
	self.rightButtonName = GGManager.translateTID( GGManager.CANCEL_TID)
	self.leftButtonID = self.buttonIDs[1]
	self.rightButtonID = self.buttonIDs[2]
end

-- OnInitialize Handler
function UniqueHairDye.Initialize()
	local newWindow = UniqueHairDye:new()
	newWindow.setDataFunction = UniqueHairDye.parseData
	newWindow:Init()
end