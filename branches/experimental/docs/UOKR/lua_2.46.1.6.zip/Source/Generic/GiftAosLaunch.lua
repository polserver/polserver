----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

GiftAosLaunch = MasterGUMP:new()

----------------------------------------------------------------
-- GiftAosLaunch Functions
----------------------------------------------------------------

function GiftAosLaunch.Initialize()

	local newWindow					= GiftAosLaunch:new()
	newWindow.setData				= GiftAosLaunch.mySetData
	newWindow:Init()
end


function GiftAosLaunch:mySetData()

	local TITLE_TID = 1079293

	-- Check to make sure we're getting the case data
	if self.descData[1]
	and self.descData[1] <= 0
	then
		self.IsStandardHeight = true
		-- Grab the case data for easy use
		local case = self.descData[1] - 1		
		if -9 == case
		then
			self.Page = {}
			self.Page[1] = {}
			self.Page[1].Title = GGManager.translateTID( TITLE_TID )
			self.Page[1].Subtitle = GGManager.translateTID( self.descData[3] )
			local buttonItr = 2
			local descItr = 4
			local choiceItr = 1
			local itr
			self.Page[1].Selections = {}
			for itr=4, self.descDataCount 
			do
				if self.descData[descItr] ~= 1044044 
				and self.descData[descItr] ~= 1044045 
				then -- Skip NEXT PAGE and PREV PAGE
					self.Page[1].Selections[choiceItr] = {}
					self.Page[1].Selections[choiceItr].Id = self.buttonIDs[buttonItr]
					self.Page[1].Selections[choiceItr].Text = GGManager.translateTID( self.descData[descItr] )
					choiceItr = choiceItr + 1
				end
				buttonItr = buttonItr + 1
				descItr = descItr + 1
			end	
			self.Page[1].Selections[choiceItr] = {}
			self.Page[1].Selections[choiceItr].Id = self.buttonIDs[1]
			self.Page[1].Selections[choiceItr].Text = GGManager.translateTID( self.descData[2] )
			
		elseif -5 == case
		then
			self.Page = {}
			self.Page[1] = {}
			self.Page[1].Title = GGManager.translateTID( TITLE_TID )
			self.Page[1].Subtitle = GGManager.translateTID( self.descData[3] )
			self.Page[1].ScrollText = GGManager.translateTID( self.descData[4] )..L"\n\n"..GGManager.translateTID( self.descData[6] )
			--self.Page[1].SelectionTemplate = "GiftAosLaunchSelectable"
			self.Page[1].Selections = {}
			self.Page[1].Selections[1] = {}
			self.Page[1].Selections[1].Id = self.buttonIDs[2]
			self.Page[1].Selections[1].Text = GGManager.translateTID( self.descData[5] ) -- Self dye
			local itr
			for itr = 2, 25 do
				self.Page[1].Selections[itr] = {}
				self.Page[1].Selections[itr].Id = self.buttonIDs[itr+1]
				self.Page[1].Selections[itr].Text = L" " -- L"FNORD" -- This text here gets covered up by the color bar, but needs to be defined as something.
			end
			self.Page[1].Selections[26] = {}
			self.Page[1].Selections[26].Id = self.buttonIDs[1]
			self.Page[1].Selections[26].Text = GGManager.translateTID( self.descData[2] ) -- Cancel		

		elseif -6 == case
		then
			self.Page = {}
			self.Page[1] = {}
			self.Page[1].Title = GGManager.translateTID( TITLE_TID )
			self.Page[1].Subtitle = GGManager.translateTID( self.descData[3] )
			self.Page[1].ScrollText = 
				GGManager.translateTID( self.descData[4] )..L"\n\n"..
				GGManager.translateTID( self.descData[5] )..L" "..
				GGManager.translateTID( self.descData[6] )..L"\n"..
				GGManager.translateTID( self.descData[7] )..L" "..
				GGManager.translateTID( self.descData[8] )..L"\n"..
				GGManager.translateTID( self.descData[9] )..L" "..
				GGManager.translateTID( self.descData[10] )..L"\n\n"..
				GGManager.translateTID( self.descData[11] )
			self.Page[1].Selections = {}
			self.Page[1].Selections[1] = {}
			self.Page[1].Selections[1].Id = -666 -- disable this choice
			self.Page[1].Selections[1].Text = L" " -- GGManager.translateTID( self.descData[2] )
			self.Page[1].Selections[2] = {}
			self.Page[1].Selections[2].Id = self.buttonIDs[2]
			self.Page[1].Selections[2].Text = GGManager.translateTID( self.descData[12] )
			self.Page[1].Selections[3] = {}
			self.Page[1].Selections[3].Id = self.buttonIDs[3]
			self.Page[1].Selections[3].Text = GGManager.translateTID( self.descData[13] )
			self.Page[1].Selections[4] = {}
			self.Page[1].Selections[4].Id = self.buttonIDs[1]
			self.Page[1].Selections[4].Text = GGManager.translateTID( self.descData[2] )		
			
		elseif -11 == case
		then
			self.Page = {}
			self.Page[1] = {}
			self.Page[1].Title = GGManager.translateTID( TITLE_TID )
			self.Page[1].Subtitle = GGManager.translateTID( self.descData[3] )
			self.Page[1].ScrollText = 
				GGManager.translateTID( self.descData[4] )..L"\n\n"..
				GGManager.translateTID( self.descData[5] )..L" "..
				GGManager.translateTID( self.descData[6] )..L"\n"..
				GGManager.translateTID( self.descData[7] )..L" "..
				GGManager.stripMarkup( self.stringData[1] )..L"\n"..
				GGManager.translateTID( self.descData[8] )..L" "..
				GGManager.stripMarkup( self.stringData[2] )..L"\n"..
				GGManager.translateTID( self.descData[9] )..L" "..
				GGManager.stripMarkup( self.stringData[3] )
			local buttonItr = 2
			local descItr = 10
			local choiceItr = 1
			local itr
			self.Page[1].Selections = {}
			for itr=10, self.descDataCount 
			do
				if self.descData[descItr] ~= 1044044 
				and self.descData[descItr] ~= 1044045 
				then -- Skip NEXT PAGE and PREV PAGE
					self.Page[1].Selections[choiceItr] = {}
					self.Page[1].Selections[choiceItr].Id = self.buttonIDs[buttonItr]
					self.Page[1].Selections[choiceItr].Text = GGManager.translateTID( self.descData[descItr] )
					choiceItr = choiceItr + 1
				end
				buttonItr = buttonItr + 1
				descItr = descItr + 1
			end	
			self.Page[1].Selections[choiceItr] = {}
			self.Page[1].Selections[choiceItr].Id = self.buttonIDs[1]
			self.Page[1].Selections[choiceItr].Text = GGManager.translateTID( self.descData[2] )

		else
			self.Page = {}
			self.Page[1] = {}
			self.Page[1].Title = GGManager.translateTID( TITLE_TID )
			self.Page[1].Subtitle = GGManager.translateTID( self.descData[3] )
			self.Page[1].ScrollText = GGManager.translateTID( self.descData[4] )
			local buttonItr = 2
			local descItr = 5
			local choiceItr = 1
			local itr
			self.Page[1].Selections = {}
			for itr=5, self.descDataCount 
			do
				if self.descData[descItr] ~= 1044044 
				and self.descData[descItr] ~= 1044045 
				then -- Skip NEXT PAGE and PREV PAGE
					self.Page[1].Selections[choiceItr] = {}
					self.Page[1].Selections[choiceItr].Id = self.buttonIDs[buttonItr]
					self.Page[1].Selections[choiceItr].Text = GGManager.translateTID( self.descData[descItr] )
					choiceItr = choiceItr + 1
				end
				buttonItr = buttonItr + 1
				descItr = descItr + 1
			end	
			self.Page[1].Selections[choiceItr] = {}
			self.Page[1].Selections[choiceItr].Id = self.buttonIDs[1]
			self.Page[1].Selections[choiceItr].Text = GGManager.translateTID( self.descData[2] )
			
		end	-- if-else case blocks
	else	
		self.Page = {}
		self.Page[1] = {}
		self.Page[1].Title = L"Close Me" -- GGManager.translateTID( TITLE_TID )
		self.Page[1].ScrollText = L"Please close this window.\n\nYou do not need to report this as a bug."
		self.Page[1].MiddleButtonId = 0
		self.Page[1].MiddleButtonText = L"CLOSE"
		
	end -- if descdata[1]
end -- GiftAosLaunch:setDataFunction()	


function GiftAosLaunch:fixup() -- used to put the colored bars in the right places
	if self.descData[1]
	and self.descData[1] <= 0
	then
		local case = self.descData[1] - 1
		if -5 == case
		then
			local itr
			for itr = 2,25 do
				CreateWindowFromTemplate( self.windowName.."1Choice"..itr.."HueBar", "GiftAosLaunchHue", self.windowName.."Scroll1Child" )
				WindowClearAnchors( self.windowName.."1Choice"..itr.."HueBar" )
				WindowAddAnchor( self.windowName.."1Choice"..itr.."HueBar", "left", self.windowName.."1Choice"..itr, "left", 39, 0 )
				local hue = self.buttonIDs[itr+1] + 754
				local r, g, b, a = HueRGBAValue( hue )
				WindowSetTintColor( self.windowName.."1Choice"..itr.."HueBar", r, g, b )
			end
		elseif -6 == case
		then
			CreateWindowFromTemplate( self.windowName.."1Choice1HueBar", "GiftAosLaunchHue", self.windowName.."Scroll1Child" )
			WindowClearAnchors( self.windowName.."1Choice1HueBar" )
			WindowAddAnchor( self.windowName.."1Choice1HueBar", "top", self.windowName.."1Choice1", "top", 0, 0 )
			local hue = -self.descData[14]
			local r, g, b, a = HueRGBAValue( hue )
			WindowSetTintColor( self.windowName.."1Choice1HueBar", r, g, b )
		end
	end
end
