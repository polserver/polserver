----------------------------------------------------------
-- HairstylistEight.lua
----------------------------------------------------------------

HairstylistEight = MasterGUMP:new()

function HairstylistEight.Initialize()

	local newWindow					= HairstylistEight:new()
	newWindow.setData				= HairstylistEight.mySetData
	newWindow:Init()
end

function HairstylistEight:mySetData()
	
	-- Can be removed once master gump hadles the bottom buttons on short gumps correctly
	self.IsStandardHeight = true
	
	self.Page = {}
	self.Page[1] = {}
	self.Page[1].Subtitle = GGManager.translateTID( self.descData[1] )
	self.Page[1].Selections = {}
	local itr
	for itr = 1,self.descDataCount-1 do
		self.Page[1].Selections[itr] = {}
		self.Page[1].Selections[itr].Id = self.buttonIDs[itr]
		self.Page[1].Selections[itr].Text = GGManager.translateTID( self.descData[itr+1] )
	end
	self.Page[1].MiddleButtonId = 0
	self.Page[1].MiddleButtonText = GGManager.translateTID( GGManager.CANCEL_TID )
end