
----------------------------------------------------------------
-- FactionItem.lua
----------------------------------------------------------------

FactionItem = MasterGUMP:new()

function FactionItem.Initialize()

	local newWindow		= FactionItem:new()
	newWindow.setData	= FactionItem.setDataFunc
	newWindow:Init()
end

function FactionItem:setDataFunc()

	self.Page[1] = {}

	self.Page[1].Subtitle = GGManager.translateTID( self.descData[1] )
	
	self.Page[1].ScrollText	= GGManager.translateTID( self.descData[2] )..L"\n\t"
							..GGManager.translateTID( self.descData[3] )..L"\n\n"
							..GGManager.translateTID( self.descData[4] )..L"\n\t"
							..self.stringData[6]..L"\n\n"
							..GGManager.translateTID( self.descData[5] )..L"\n\t"
							..self.stringData[8]
	
	self.Page[1].Selections = {}
	self.Page[1].SelectionTemplate = "FactionItemSelectableIconText"
	
	self.Page[1].Selections[1] = {}
	self.Page[1].Selections[1].Id	= self.buttonIDs[1]
	self.Page[1].Selections[1].Text	= GGManager.translateTID( self.descData[6] )
	self.Page[1].Selections[1].Hue	= self.descData[10]
	self.Page[1].Selections[1].Bottom = true
	
	self.Page[1].Selections[2] = {}
	self.Page[1].Selections[2].Id	= self.buttonIDs[2]
	self.Page[1].Selections[2].Text	= GGManager.translateTID( self.descData[7] )
	self.Page[1].Selections[2].Hue	= self.descData[11]
	self.Page[1].Selections[2].Bottom = true

	self.Page[1].MiddleButtonId		= self.buttonIDs[4]
	self.Page[1].MiddleButtonText	= GGManager.translateTID( self.descData[9] )
end
