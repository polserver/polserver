----------------------------------------------------------
-- FactionMasterstone.lua
----------------------------------------------------------------

FactionMasterstone = MasterGUMP:new()

function FactionMasterstone.Initialize()

	local newWindow		= FactionMasterstone:new()
	newWindow.setData	= FactionMasterstone.setDataFunc
	newWindow.fixup		= FactionMasterstone.fixupFunc
	newWindow:Init()
end

function FactionMasterstone:setDataFunc()

	self.Page[1] = {}

	self.Page[1].Subtitle = GGManager.translateTID( self.descData[10] )
	
	self.Page[1].ScrollText = L""
	
	for i = 1, 9
	do
		self.Page[1].ScrollText = self.Page[1].ScrollText..GGManager.translateTID( self.descData[i] )..L" "..self.stringData[i]
		if i ~= 9
		then
			self.Page[1].ScrollText = self.Page[1].ScrollText..L"\n"
		end
	end

	self.Page[1].RadioId = self.buttonIDs[2]

	self.Page[1].LeftButtonId	= tonumber( string.sub( WStringToString( self.stringData[1] ), 3 ) )
	self.Page[1].LeftButtonText	= GGManager.translateTID( GGManager.OKAY_TID )

	self.Page[1].RightButtonId		= self.buttonIDs[3]
	self.Page[1].RightButtonText	= GGManager.translateTID( GGManager.CANCEL_TID )
end

function FactionMasterstone:fixupFunc()

	-- 4 == OnLButtonUp
	WindowUnregisterEventHandler( self.windowName.."LeftButton", 4 )
	WindowRegisterEventHandler( self.windowName.."LeftButton", 4, "MasterGUMP.SelectionPressed" )
end