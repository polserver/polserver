
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

HousePlacementWindow = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

local House_Placement_GumpData = {}

local WhichWindow = 1  -- 1 = first page, 2 = second page

local House_Placement_ValidClose = 1

local HousePlacementPage1CurrentSelection = -1
local HousePlacementPage2CurrentSelection = -1

local PreviousHousePlacementPage1Selection = -1  -- used from going back from page 2 to page 1 then back to page 2 on whether to clear the page 2 selection

local WindowName = "initialize"

local BankBalance = 0
local StorageModifier = 0
----------------------------------------------------------------
-- Functions
----------------------------------------------------------------




-- OnInitialize Handler
function HousePlacementWindow.Initialize()

	--Debug.PrintToDebugConsole(L"HousePlacementWindow.Initialize")

	UO_GenericGump.retrieveWindowData (House_Placement_GumpData)

	WindowName = House_Placement_GumpData.windowName

	stringData = UO_GenericGump.retreiveWindowDataStrings( House_Placement_GumpData )
	
	HousePlacementPage1CurrentSelection = -1
	HousePlacementPage2CurrentSelection = -1

	--Debug.PrintToDebugConsole(L"House_Placement.Initialize: gumpid = "..StringToWString(tostring(House_Placement_GumpData.gumpID)))
	--Debug.PrintToDebugConsole(L"House_Placement.Initialize: objectid = "..StringToWString(tostring(House_Placement_GumpData.objectID)))
	--Debug.PrintToDebugConsole(L"House_Placement.Initialize: windowName = "..StringToWString(House_Placement_GumpData.windowName))
	--Debug.PrintToDebugConsole(L"House_Placement.Initialize: bank balance = "..StringToWString(tostring(stringData[1])))
	
	
	UOBuildTableFromCSV ("data/gamedata/classic_housedata.csv","ClassicHouseDataCSV")
	UOBuildTableFromCSV ("data/gamedata/twostory_cust_housedata.csv","TwoStoryCustHouseDataCSV")
	UOBuildTableFromCSV ("data/gamedata/threestory_cust_housedata.csv","ThreeStoryCustHouseDataCSV")

	LabelSetText(House_Placement_GumpData.windowName.."ColumnHeader1", GetStringFromTid(1060235)) -- "House Description"
	LabelSetText(House_Placement_GumpData.windowName.."ColumnHeader2", GetStringFromTid(1060236)) -- "Storage"
	LabelSetText(House_Placement_GumpData.windowName.."ColumnHeader3", GetStringFromTid(1060237)) -- "Lockdowns"
	LabelSetText(House_Placement_GumpData.windowName.."ColumnHeader4", GetStringFromTid(1060034)) -- "Cost"



	WindowSetShowing (House_Placement_GumpData.windowName.."PrevButton", true)
	WindowSetShowing (House_Placement_GumpData.windowName.."NextButton", true)
	
	ButtonSetDisabledFlag( House_Placement_GumpData.windowName.."PrevButton", true )
	ButtonSetDisabledFlag( House_Placement_GumpData.windowName.."NextButton", true )
	

	local buttonName = ""

	for i = 1, 12 do
		buttonName = House_Placement_GumpData.windowName.."Entry"..tostring(i).."Icon"
		WindowSetId(buttonName, i)	-- Make sure the button knows which one it is
		ButtonSetDisabledFlag( buttonName, true )
		WindowSetShowing (buttonName, false)
	end
	
	BankBalance = tonumber(stringData[1])
	StorageModifier = tonumber(stringData[2])
	StorageModifier = StorageModifier / 100  -- cause we shift it 2 digits to preserve the precision
	--Debug.PrintToDebugConsole(L"House_Placement.Initialize: storage modifier = "..StringToWString(tostring(StorageModifier)))
	
	local formatted = WindowUtils.AddCommasToNumber(BankBalance)
	LabelSetText(House_Placement_GumpData.windowName.."BankBalance", GetStringFromTid(1060645)..L" "..formatted) -- "Bank Balance"

	Interface.OnCloseCallBack[House_Placement_GumpData.windowName] = HousePlacementWindow.UserClosedGump
	House_Placement_ValidClose = 0


	
	HousePlacementWindow.CreatePage1List()
	HousePlacementWindow.CreatePage2ClassicHousesList()
	HousePlacementWindow.CreatePage2TwoStoryCustHousesList()
	HousePlacementWindow.CreatePage2ThreeStoryCustHousesList()

	HousePlacementWindow.ShowPage1()
	

end

function HousePlacementWindow.UserClosedGump()
	--Debug.PrintToDebugConsole(L"House_Placement.UserClosedGump")


	if (House_Placement_ValidClose == 0) then
		-- tell server that the user closed the gump, so cleanup objvars dealing with house placement
		UO_GenericGump.broadcastButtonPress( 0, House_Placement_GumpData )
	end
end

function HousePlacementWindow.CreatePage1ScrollingListboxSlots(windowName, listname, low, high)
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage1ScrollingListboxSlots ")

	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage1ScrollingListboxSlots: low "..StringToWString(tostring(low)))
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage1ScrollingListboxSlots: high "..StringToWString(tostring(high)))

	local parent = windowName..listname.."ScrollingListBoxScrollChild"
	for i=low, high do
		slotName = parent.."Item"..i
		CreateWindowFromTemplate(slotName, "HPWPage1EntryTemplate", parent)
		WindowSetId(slotName.."Button",i)

		--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage1ScrollingListboxSlots: Creating entry: "..StringToWString(slotName))
		
		if i == 1 then
			WindowAddAnchor(slotName, "topleft", parent, "topleft", 0, 0)
		else
			WindowAddAnchor(slotName, "bottomleft", parent.."Item"..i-1, "topleft", 0, 0)
		end
	end

end -- HousePlacementWindow.CreatePage1ScrollingListboxSlots

function HousePlacementWindow.CreatePage1List()
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreateMasterList ")

	HPW_PageList = {}
	HPW_PageList[1] = {}
	HPW_PageList[1].name = GetStringFromTid(1060390)  -- "Classic Houses"
	HPW_PageList[2] = {}
	HPW_PageList[2].name = GetStringFromTid(1060391) -- "Two Story Customizable Houses"
	HPW_PageList[3] = {}
	HPW_PageList[3].name = GetStringFromTid(1060392) -- "Three Story Customizable Houses"
	

	HousePlacementWindow.CreatePage1ScrollingListboxSlots(WindowName,"Page1",1,table.getn(HPW_PageList))
	local startIndex = 1
	local endIndex = table.getn(HPW_PageList)

	for i = startIndex, endIndex do
		LabelSetText (WindowName.."Page1ScrollingListBoxScrollChildItem"..tostring(i).."NameText",HPW_PageList[i].name)	
	end

	--WindowRefreshScrollChild(WindowName.."Page1ScrollingListBox".."ScrollChild")
	ScrollWindowUpdateScrollRect(WindowName.."Page1ScrollingListBox")	

end

function HousePlacementWindow.ShowHouseDescription()
	local HouseDescription = L"test"
	if (HousePlacementPage1CurrentSelection == 1) then
		HouseDescription = GetStringFromTid(1079275) --L"Classic Houses are pre-fabricated houses that the player can choose from."
	elseif (HousePlacementPage1CurrentSelection == 2) then
		HouseDescription = GetStringFromTid(1079276) --L"Two-Story Customizable Houses provide the player with a house foundation that the player can then customize a two-story house on top of."
	elseif (HousePlacementPage1CurrentSelection == 3) then
		HouseDescription = GetStringFromTid(1079277) --L"Three-Story Customizable Houses provide the player with a house foundation that the player can then customize a three-story house on top of."
	
	end
	
	--LabelSetText(House_Placement_GumpData.windowName.."Page1Description", GetStringFromTid(tid_num)) 
	LabelSetText(House_Placement_GumpData.windowName.."Page1Description", HouseDescription) 
	WindowSetShowing (House_Placement_GumpData.windowName.."Page1Description", true)
end


function HousePlacementWindow.ShowPage1()

	WhichWindow = 1

	-- show the selection stuff on page 1: classic houses, 2story cust., 3 story cust.

	WindowUtils.SetWindowTitle( House_Placement_GumpData.windowName, L"Select House Category" )

	-- disable previous button
	ButtonSetDisabledFlag( House_Placement_GumpData.windowName.."PrevButton", true )

	--[[
	-- enable next button if choice already selected
	if (HousePlacementPage1CurrentSelection > 0) then
		ButtonSetDisabledFlag( House_Placement_GumpData.windowName.."NextButton", false )
	end
	--]]
	
	HousePlacementWindow.ShowNextButton()
	
	-- show house description
	if (HousePlacementPage1CurrentSelection > 0) then
		HousePlacementWindow.ShowHouseDescription()
	end
	
	-- display the horizontal line
	WindowSetShowing (House_Placement_GumpData.windowName.."Page1HorRule", true)

	-- hide the page 2 stuff
	-- column headers
	WindowSetShowing (House_Placement_GumpData.windowName.."ColumnHeader1", false)
	WindowSetShowing (House_Placement_GumpData.windowName.."ColumnHeader2", false)
	WindowSetShowing (House_Placement_GumpData.windowName.."ColumnHeader3", false)
	WindowSetShowing (House_Placement_GumpData.windowName.."ColumnHeader4", false)
	
	
	-- hide the scroll windows
	WindowSetShowing (House_Placement_GumpData.windowName.."Page2ClassicHousesScrollingListBox", false)
	WindowSetShowing (House_Placement_GumpData.windowName.."Page2TwoStoryCustHousesScrollingListBox", false)
	WindowSetShowing (House_Placement_GumpData.windowName.."Page2ThreeStoryCustHousesScrollingListBox", false)

	-- show page 1 stuff

	WindowSetShowing (House_Placement_GumpData.windowName.."Page1ScrollingListBox", true)

	
end

function HousePlacementWindow.CreatePage2ScrollingListboxSlots(windowName, listname, low, high)
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ScrollingListboxSlots ")

	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ScrollingListboxSlots: low "..StringToWString(tostring(low)))
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ScrollingListboxSlots: high "..StringToWString(tostring(high)))

	local parent = windowName..listname.."ScrollingListBoxScrollChild"
	for i=low, high do
		slotName = parent.."Item"..i
		CreateWindowFromTemplate(slotName, "HPWEntryColumnsTemplate", parent)
		WindowSetId(slotName.."Button",i)

		--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ScrollingListboxSlots: Creating entry: "..StringToWString(slotName))
		
		if i == 1 then
			WindowAddAnchor(slotName, "topleft", parent, "topleft", 0, 0)
		else
			WindowAddAnchor(slotName, "bottomleft", parent.."Item"..i-1, "topleft", 0, 0)
		end
	end

end -- HousePlacementWindow.CreatePage2ScrollingListboxSlots



function HousePlacementWindow.CreatePage2ClassicHousesList()
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ClassicHousesList ")


	local NumItems = table.getn(WindowData.ClassicHouseDataCSV)
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ClassicHousesList: num items = "..StringToWString(tostring(NumItems)))
	
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ClassicHousesList: 1 = "..(WindowData.ClassicHouseDataCSV[1].Name))
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ClassicHousesList: 2 = "..(WindowData.ClassicHouseDataCSV[2].Name))
	

	HousePlacementWindow.CreatePage2ScrollingListboxSlots(WindowName,"Page2ClassicHouses",1,NumItems)

	for i = 1, NumItems do
		local R = 255
		local G = 255
		local B = 255 -- white
		
		if (WindowData.ClassicHouseDataCSV[i].Cost > BankBalance) then
			R = 255
			G  = 0
			B = 0	-- red
		end


		--LabelSetText (WindowName.."Page2ClassicHousesScrollingListBoxScrollChildItem"..tostring(i).."Column1",WindowData.ClassicHouseDataCSV[i].Name)	
		LabelSetText (WindowName.."Page2ClassicHousesScrollingListBoxScrollChildItem"..tostring(i).."Column1",GetStringFromTid(WindowData.ClassicHouseDataCSV[i].NameTid))	
		--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ClassicHousesList: i = "..StringToWString(tostring(i))..L"=="..WindowData.ClassicHouseDataCSV[i].Name)
		LabelSetTextColor( WindowName.."Page2ClassicHousesScrollingListBoxScrollChildItem"..tostring(i).."Column1", R,G,B )
		
		temp = WindowData.ClassicHouseDataCSV[i].Storage * StorageModifier
		temp = math.floor(temp) -- round down
		tempStr1 = tostring(temp)
		tempStr2 = string.format("%.0f", tempStr1) -- truncate off any decimal places
		LabelSetText (WindowName.."Page2ClassicHousesScrollingListBoxScrollChildItem"..tostring(i).."Column2",StringToWString(tempStr2))	
		LabelSetTextColor( WindowName.."Page2ClassicHousesScrollingListBoxScrollChildItem"..tostring(i).."Column2", R,G,B )

		-- lockdowns are storage divided by 2
		temp = (WindowData.ClassicHouseDataCSV[i].Storage / 2) * StorageModifier
		temp = math.floor(temp) -- round down
		tempStr1 = tostring(temp) 
		tempStr2 = string.format("%.0f", tempStr1) -- truncate off any decimal places
		LabelSetText (WindowName.."Page2ClassicHousesScrollingListBoxScrollChildItem"..tostring(i).."Column3",StringToWString(tempStr2))	
		LabelSetTextColor( WindowName.."Page2ClassicHousesScrollingListBoxScrollChildItem"..tostring(i).."Column3", R,G,B )

		local formatted = WindowUtils.AddCommasToNumber(WindowData.ClassicHouseDataCSV[i].Cost)
		LabelSetText (WindowName.."Page2ClassicHousesScrollingListBoxScrollChildItem"..tostring(i).."Column4",formatted)	
		LabelSetTextColor( WindowName.."Page2ClassicHousesScrollingListBoxScrollChildItem"..tostring(i).."Column4", R,G,B )

	end

	--WindowRefreshScrollChild(WindowName.."Page2ClassicHousesScrollingListBox".."ScrollChild")
	ScrollWindowUpdateScrollRect(WindowName.."Page2ClassicHousesScrollingListBox")	

end

function HousePlacementWindow.CreatePage2TwoStoryCustHousesList()
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2TwoStoryCustHousesList ")


	local NumItems = table.getn(WindowData.TwoStoryCustHouseDataCSV)
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2TwoStoryCustHousesList: num items = "..StringToWString(tostring(NumItems)))
	
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2TwoStoryCustHousesList: 1 = "..(WindowData.TwoStoryCustHouseDataCSV[1].Name))
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2TwoStoryCustHousesList: 2 = "..(WindowData.TwoStoryCustHouseDataCSV[2].Name))
	

	HousePlacementWindow.CreatePage2ScrollingListboxSlots(WindowName,"Page2TwoStoryCustHouses",1,NumItems)

	for i = 1, NumItems do
		local R = 255
		local G = 255
		local B = 255 -- white
		
		if (WindowData.TwoStoryCustHouseDataCSV[i].Cost > BankBalance) then
			R = 255
			G  = 0
			B = 0	-- red
		end
		--LabelSetText (WindowName.."Page2TwoStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column1",WindowData.TwoStoryCustHouseDataCSV[i].Name)	
		LabelSetText (WindowName.."Page2TwoStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column1",GetStringFromTid(WindowData.TwoStoryCustHouseDataCSV[i].NameTid))	
		--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2TwoStoryCustHousesList: i = "..StringToWString(tostring(i))..L"=="..WindowData.TwoStoryCustHouseDataCSV[i].Name)
		LabelSetTextColor( WindowName.."Page2TwoStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column1", R,G,B )

		temp = WindowData.TwoStoryCustHouseDataCSV[i].Storage * StorageModifier
		temp = math.floor(temp) -- round down
		tempStr1 = tostring(temp)
		tempStr2 = string.format("%.0f", tempStr1) -- truncate off any decimal places
		LabelSetText (WindowName.."Page2TwoStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column2",StringToWString(tempStr2))	
		LabelSetTextColor( WindowName.."Page2TwoStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column2", R,G,B )

		-- lockdowns are storage divided by 2
		temp = (WindowData.TwoStoryCustHouseDataCSV[i].Storage / 2) * StorageModifier
		temp = math.floor(temp) -- round down
		tempStr1 = tostring(temp) 
		tempStr2 = string.format("%.0f", tempStr1) -- truncate off any decimal places
		LabelSetText (WindowName.."Page2TwoStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column3",StringToWString(tempStr2))	
		LabelSetTextColor( WindowName.."Page2TwoStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column3", R,G,B )

		local formatted = WindowUtils.AddCommasToNumber(WindowData.TwoStoryCustHouseDataCSV[i].Cost)
		LabelSetText (WindowName.."Page2TwoStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column4",formatted)	
		LabelSetTextColor( WindowName.."Page2TwoStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column4", R,G,B )

	end

	--WindowRefreshScrollChild(WindowName.."Page2TwoStoryCustHousesScrollingListBox".."ScrollChild")
	ScrollWindowUpdateScrollRect(WindowName.."Page2TwoStoryCustHousesScrollingListBox")	
end

function HousePlacementWindow.CreatePage2ThreeStoryCustHousesList()
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ThreeStoryCustHousesList ")


	local NumItems = table.getn(WindowData.ThreeStoryCustHouseDataCSV)
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ThreeStoryCustHousesList: num items = "..StringToWString(tostring(NumItems)))
	
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ThreeStoryCustHousesList: 1 = "..(WindowData.ThreeStoryCustHouseDataCSV[1].Name))
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ThreeStoryCustHousesList: 2 = "..(WindowData.ThreeStoryCustHouseDataCSV[2].Name))
	

	HousePlacementWindow.CreatePage2ScrollingListboxSlots(WindowName,"Page2ThreeStoryCustHouses",1,NumItems)

	for i = 1, NumItems do
		local R = 255
		local G = 255
		local B = 255 -- white
		
		if (WindowData.ThreeStoryCustHouseDataCSV[i].Cost > BankBalance) then

			R = 255
			G  = 0
			B = 0	-- red
		end
		--LabelSetText (WindowName.."Page2ThreeStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column1",WindowData.ThreeStoryCustHouseDataCSV[i].Name)	
		LabelSetText (WindowName.."Page2ThreeStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column1",GetStringFromTid(WindowData.ThreeStoryCustHouseDataCSV[i].NameTid))	
		--Debug.PrintToDebugConsole(L"HousePlacementWindow.CreatePage2ThreeStoryCustHousesList: i = "..StringToWString(tostring(i))..L"=="..WindowData.ThreeStoryCustHouseDataCSV[i].Name)
		LabelSetTextColor( WindowName.."Page2ThreeStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column1", R,G,B )
		
		temp = WindowData.ThreeStoryCustHouseDataCSV[i].Storage * StorageModifier
		temp = math.floor(temp) -- round down
		tempStr1 = tostring(temp)
		tempStr2 = string.format("%.0f", tempStr1) -- truncate off any decimal places
		LabelSetText (WindowName.."Page2ThreeStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column2",StringToWString(tempStr2))	
		LabelSetTextColor( WindowName.."Page2ThreeStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column2", R,G,B )

		-- lockdowns are storage divided by 2
		temp = (WindowData.ThreeStoryCustHouseDataCSV[i].Storage / 2) * StorageModifier
		temp = math.floor(temp) -- round down
		tempStr1 = tostring(temp) 
		tempStr2 = string.format("%.0f", tempStr1) -- truncate off any decimal places
		LabelSetText (WindowName.."Page2ThreeStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column3",StringToWString(tempStr2))	
		LabelSetTextColor( WindowName.."Page2ThreeStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column3", R,G,B )

		local formatted = WindowUtils.AddCommasToNumber(WindowData.ThreeStoryCustHouseDataCSV[i].Cost)
		LabelSetText (WindowName.."Page2ThreeStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column4",formatted)	
		LabelSetTextColor( WindowName.."Page2ThreeStoryCustHousesScrollingListBoxScrollChildItem"..tostring(i).."Column4", R,G,B )

	end

	--WindowRefreshScrollChild(WindowName.."Page2ThreeStoryCustHousesScrollingListBox".."ScrollChild")
	ScrollWindowUpdateScrollRect(WindowName.."Page2ThreeStoryCustHousesScrollingListBox")	
	
end

function HousePlacementWindow.ShowNextButton()
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.ShowNextButton ")
	local DontAllowButtonPress = true 
	
	if (WhichWindow == 1) then
		if (HousePlacementPage1CurrentSelection > 0) then
			DontAllowButtonPress = false
		end
	elseif (WhichWindow == 2) then
		if (HousePlacementPage2CurrentSelection > 0) then
			DontAllowButtonPress = false
			--Debug.PrintToDebugConsole(L"HousePlacementWindow.ShowNextButton -- allow")
		else
			--Debug.PrintToDebugConsole(L"HousePlacementWindow.ShowNextButton -- don't allow")
			donothing = 0
		end
	end
	
	ButtonSetDisabledFlag (House_Placement_GumpData.windowName.."NextButton", DontAllowButtonPress)
end

function HousePlacementWindow.ShowPage2()

	WhichWindow = 2

	ButtonSetDisabledFlag( House_Placement_GumpData.windowName.."PrevButton", false )
	
	
	HousePlacementWindow.ShowNextButton()
	-- hide page 1 stuff
	
	WindowSetShowing (House_Placement_GumpData.windowName.."Page1ScrollingListBox", false)

	WindowSetShowing (House_Placement_GumpData.windowName.."Page1Description", false)
	WindowSetShowing (House_Placement_GumpData.windowName.."Page1HorRule", false)
	
	-- Hide the scrolling list boxes that we aren't using on page 2

	if (HousePlacementPage1CurrentSelection == 1) then
		WindowUtils.SetWindowTitle( House_Placement_GumpData.windowName, L"Select Classic House" )
		--Debug.PrintToDebugConsole(L"HousePlacementWindow.ShowPage2: classic houses")
		WindowSetShowing (House_Placement_GumpData.windowName.."Page2ClassicHousesScrollingListBox", true)
		WindowSetShowing (House_Placement_GumpData.windowName.."Page2TwoStoryCustHousesScrollingListBox", false)
		WindowSetShowing (House_Placement_GumpData.windowName.."Page2ThreeStoryCustHousesScrollingListBox", false)
	elseif (HousePlacementPage1CurrentSelection == 2) then
		WindowUtils.SetWindowTitle( House_Placement_GumpData.windowName, L"Select Two-story Customizable House" )
		--Debug.PrintToDebugConsole(L"HousePlacementWindow.ShowPage2: 2-story houses")
		WindowSetShowing (House_Placement_GumpData.windowName.."Page2ClassicHousesScrollingListBox", false)
		WindowSetShowing (House_Placement_GumpData.windowName.."Page2TwoStoryCustHousesScrollingListBox", true)
		WindowSetShowing (House_Placement_GumpData.windowName.."Page2ThreeStoryCustHousesScrollingListBox", false)
	
	elseif (HousePlacementPage1CurrentSelection == 3) then
		WindowUtils.SetWindowTitle( House_Placement_GumpData.windowName, L"Select Three-story Customizable House" )
		--Debug.PrintToDebugConsole(L"HousePlacementWindow.ShowPage2: 3-story houses")
		WindowSetShowing (House_Placement_GumpData.windowName.."Page2ClassicHousesScrollingListBox", false)
		WindowSetShowing (House_Placement_GumpData.windowName.."Page2TwoStoryCustHousesScrollingListBox", false)
		WindowSetShowing (House_Placement_GumpData.windowName.."Page2ThreeStoryCustHousesScrollingListBox", true)
	
	end
	-- show page 2 stuff

	-- the column headers
	WindowSetShowing (House_Placement_GumpData.windowName.."ColumnHeader1", true)
	WindowSetShowing (House_Placement_GumpData.windowName.."ColumnHeader2", true)
	WindowSetShowing (House_Placement_GumpData.windowName.."ColumnHeader3", true)
	WindowSetShowing (House_Placement_GumpData.windowName.."ColumnHeader4", true)

	


end

function HousePlacementWindow.ClearPage2Selection()
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.ClearPage2Selection")

	if (HousePlacementPage2CurrentSelection > 0) then

		--Debug.PrintToDebugConsole(L"HousePlacementWindow.ClearPage2Selection - selection is "..StringToWString(tostring(HousePlacementPage2CurrentSelection)))

		if (PreviousHousePlacementPage1Selection == 1)  then
			WindowItem = WindowName.."Page2ClassicHousesScrollingListBoxScrollChildItem"
		elseif (PreviousHousePlacementPage1Selection == 2) then
			WindowItem = WindowName.."Page2TwoStoryCustHousesScrollingListBoxScrollChildItem"	
		elseif (PreviousHousePlacementPage1Selection == 3) then
			WindowItem = WindowName.."Page2ThreeStoryCustHousesScrollingListBoxScrollChildItem"
		end
	
		-- white
		R = 255
		G = 255
		B = 255 
		
		local CantAfford = false
		
		if (PreviousHousePlacementPage1Selection == 1)  then
			if (WindowData.ClassicHouseDataCSV[HousePlacementPage2CurrentSelection].Cost > BankBalance) then
				CantAfford = true
			end
		elseif (PreviousHousePlacementPage1Selection == 2) then
			if (WindowData.TwoStoryCustHouseDataCSV[HousePlacementPage2CurrentSelection].Cost > BankBalance) then
				CantAfford = true
			end
		elseif (PreviousHousePlacementPage1Selection == 3) then
			if (WindowData.ThreeStoryCustHouseDataCSV[HousePlacementPage2CurrentSelection].Cost > BankBalance) then
				CantAfford = true
			end
		end
		
		if (CantAfford == true) then
			R = 255
			G  = 0
			B = 0	-- red
		end

		LabelSetTextColor( WindowItem..tostring(HousePlacementPage2CurrentSelection).."Column1", R, G, B )
		LabelSetTextColor( WindowItem..tostring(HousePlacementPage2CurrentSelection).."Column2", R, G, B )
		LabelSetTextColor( WindowItem..tostring(HousePlacementPage2CurrentSelection).."Column3", R, G, B )
		LabelSetTextColor( WindowItem..tostring(HousePlacementPage2CurrentSelection).."Column4", R, G, B )
	
	end

	HousePlacementPage2CurrentSelection = -1

end

function HousePlacementWindow.PrevLButtonUp()
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.PrevLButtonUp")

	if (WhichWindow == 2) then
		
		PreviousHousePlacementPage1Selection = HousePlacementPage1CurrentSelection
		
		-- reset the current selection as lists may not be the same size
		--HousePlacementWindow.ClearPage2Selection()
		
		HousePlacementWindow.ShowPage1()
	end
	
end

function HousePlacementWindow.NextLButtonUp()
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.NextLButtonUp")

	--Debug.PrintToDebugConsole(L"HousePlacementWindow.NextLButtonUp: HousePlacementPage2CurrentSelection = "..StringToWString(tostring(HousePlacementPage2CurrentSelection)))

	--Debug.PrintToDebugConsole(L"HousePlacementWindow.NextLButtonUp: HousePlacementPage1CurrentSelection = "..StringToWString(tostring(HousePlacementPage1CurrentSelection)))
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.NextLButtonUp: PreviousHousePlacementPage1Selection = "..StringToWString(tostring(PreviousHousePlacementPage1Selection)))

	if (WhichWindow == 1) then
		if (HousePlacementPage1CurrentSelection > 0) then
			if (PreviousHousePlacementPage1Selection ~= HousePlacementPage1CurrentSelection) then
				HousePlacementWindow.ClearPage2Selection()
			end
			HousePlacementWindow.ShowPage2()
		end
	elseif (WhichWindow == 2) then
		if (HousePlacementPage2CurrentSelection > 0) then
			HousePlacementWindow.HouseSelected()
		end
		-- send message to server
	end
	
end

function HousePlacementWindow.HouseSelected()

	--Debug.PrintToDebugConsole(L"HousePlacementWindow.HouseSelected: id="..StringToWString(tostring(HousePlacementPage2CurrentSelection)))

	local HouseId = 0
	
	if (HousePlacementPage1CurrentSelection == 1) then
		HouseId = WindowData.ClassicHouseDataCSV[HousePlacementPage2CurrentSelection].HouseId
	elseif (HousePlacementPage1CurrentSelection == 2) then
		HouseId = WindowData.TwoStoryCustHouseDataCSV[HousePlacementPage2CurrentSelection].HouseId
	elseif (HousePlacementPage1CurrentSelection == 3) then 
		HouseId = WindowData.ThreeStoryCustHouseDataCSV[HousePlacementPage2CurrentSelection].HouseId
	end
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.HouseSelected: HouseId="..StringToWString(tostring(HouseId)))

	if (HousePlacementPage1CurrentSelection >= 1) and (HousePlacementPage1CurrentSelection <= 3) then
		-- first clear the current target of the UI
		HousingClearCurrentTarget()
		
		UO_GenericGump.broadcastButtonPress( HouseId, House_Placement_GumpData )

		House_Placement_ValidClose = 1
	else
		-- pretend we closed the window
		House_Placement_ValidClose = 0
	
	end
	
	HousePlacementWindow.OnCloseWindow()

end



function HousePlacementWindow.HandlePage1ScrollingListBoxEntrySelection()
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.HandleScrollingListBoxEntrySelection")

	buttonNum = WindowGetId(SystemData.ActiveWindow.name)
	--Debug.PrintToDebugConsole(L"HouseSignWindow.HandleScrollingListBoxEntrySelection: buttonNum =  "..StringToWString(tostring(buttonNum)))

	-- clicking inside the scrolling window, but not on an actual true selection returns 0
	if (buttonNum > 0) then
		-- set the previous selected item back to normal
		if (HousePlacementPage1CurrentSelection ~= -1) then
			LabelSetTextColor( WindowName.."Page1ScrollingListBoxScrollChildItem"..tostring(HousePlacementPage1CurrentSelection).."NameText", 255, 255, 255 )
		end
		
		
		HousePlacementPage1CurrentSelection = buttonNum
		-- set the selected item yellow
		LabelSetTextColor( WindowName.."Page1ScrollingListBoxScrollChildItem"..tostring(buttonNum).."NameText", 250, 250, 0 )

		-- activate the next arrow button
		--ButtonSetDisabledFlag( House_Placement_GumpData.windowName.."NextButton", false )
		HousePlacementWindow.ShowNextButton()

		-- show the description
		HousePlacementWindow.ShowHouseDescription()
		
	end

	--Debug.PrintToDebugConsole(L"HouseSignWindow.HandleScrollingListBoxEntrySelection: HousePlacementPage1CurrentSelection =  "..StringToWString(tostring(HousePlacementPage1CurrentSelection)))

end

function HousePlacementWindow.HandlePage2ScrollingListBoxEntrySelection()
	--Debug.PrintToDebugConsole(L"HousePlacementWindow.HandlePage2ScrollingListBoxEntrySelection")

	buttonNum = WindowGetId(SystemData.ActiveWindow.name)
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandlePage2ScrollingListBoxEntrySelection: window name =  "..StringToWString(SystemData.ActiveWindow.name))
	Debug.PrintToDebugConsole(L"HouseSignWindow.HandlePage2ScrollingListBoxEntrySelection: buttonNum =  "..StringToWString(tostring(buttonNum)))


	if (HousePlacementPage1CurrentSelection == 1)  then
		WindowItem = WindowName.."Page2ClassicHousesScrollingListBoxScrollChildItem"
	elseif (HousePlacementPage1CurrentSelection == 2) then
		WindowItem = WindowName.."Page2TwoStoryCustHousesScrollingListBoxScrollChildItem"	
	elseif (HousePlacementPage1CurrentSelection == 3) then
		WindowItem = WindowName.."Page2ThreeStoryCustHousesScrollingListBoxScrollChildItem"
	end

	
	-- clicking inside the scrolling window, but not on an actual true selection returns 0
	if (buttonNum > 0) then
		local cost = 0
		if (HousePlacementPage1CurrentSelection == 1) then
			cost = WindowData.ClassicHouseDataCSV[buttonNum].Cost
		elseif (HousePlacementPage1CurrentSelection == 2) then
			cost = WindowData.TwoStoryCustHouseDataCSV[buttonNum].Cost
		elseif (HousePlacementPage1CurrentSelection == 3) then
			cost = WindowData.ThreeStoryCustHouseDataCSV[buttonNum].Cost		
		end
		
		
		if (cost <= BankBalance) then
			--Debug.PrintToDebugConsole(L"HouseSignWindow.HandlePage2ScrollingListBoxEntrySelection: Able to afford house ")
	
			-- set the previous selected item back to normal
			if (HousePlacementPage2CurrentSelection ~= -1) then
				HousePlacementWindow.ClearPage2Selection()
				--[[
				LabelSetTextColor( WindowItem..tostring(HousePlacementPage2CurrentSelection).."Column1", 255, 255, 255 )
				LabelSetTextColor( WindowItem..tostring(HousePlacementPage2CurrentSelection).."Column2", 255, 255, 255 )
				LabelSetTextColor( WindowItem..tostring(HousePlacementPage2CurrentSelection).."Column3", 255, 255, 255 )
				LabelSetTextColor( WindowItem..tostring(HousePlacementPage2CurrentSelection).."Column4", 255, 255, 255 )
				--]]
			end
			HousePlacementPage2CurrentSelection = buttonNum
			-- set the selected item yellow
			LabelSetTextColor( WindowItem..tostring(buttonNum).."Column1", 250, 250, 0 )
			LabelSetTextColor( WindowItem..tostring(buttonNum).."Column2", 250, 250, 0 )
			LabelSetTextColor( WindowItem..tostring(buttonNum).."Column3", 250, 250, 0 )
			LabelSetTextColor( WindowItem..tostring(buttonNum).."Column4", 250, 250, 0 )

			-- activate the next arrow button
			--ButtonSetDisabledFlag( House_Placement_GumpData.windowName.."NextButton", false )
			HousePlacementWindow.ShowNextButton()

		end
	end

end

-- OnShutdown Handler
function HousePlacementWindow.Shutdown()
	UOUnloadCSVTable("ClassicHouseDataCSV")
	UOUnloadCSVTable("TwoStoryCustHouseDataCSV")
	UOUnloadCSVTable("ThreeStoryCustHouseDataCSV")
end

-- 
--
function HousePlacementWindow.OnCloseWindow()

	GGManager.destroyWindow(WindowName)
end



