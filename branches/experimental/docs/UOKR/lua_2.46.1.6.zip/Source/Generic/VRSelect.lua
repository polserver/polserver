----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

VRSelect = ChoiceList:new()

----------------------------------------------------------------
-- VRSelect Functions
----------------------------------------------------------------

function VRSelect:setDataFunction()
	UO_GenericGump.debug( L"VRSelect:setDataFunction - setting data for = "..StringToWString( self.windowName ) )
	local scrollChild = self.windowName.."ScrollChild"
	local blankSize = 5
	local index = 3
	local offset = 2
		
	self.text = GGManager.translateTID( self.descData[2] )..L"\n\n"
				..GGManager.translateTID( self.descData[3] )..L"\n"..self.stringData[1]..L"\n\n"
				..GGManager.translateTID( self.descData[4] )..L"\n"..self.stringData[2]
			
	local relativeWindow = self:CreateText( 1, self.text, "topleft", scrollChild, "topleft", 0, 0 )

	-- this doesn't actually use multiple pages, but the page info is still useful to group the desc data
	for i = self.descPageIndex[index], self.descDataCount do
		if i == self.descPageIndex[index] then -- adding the group name
			relativeWindow = self:CreateBlankSpace( blankSize, relativeWindow, index )
			relativeWindow = self:CreateText( index, GGManager.translateTID( self.descData[index + offset] ), "bottomleft",
							relativeWindow, "topleft", 0, 0 )
			index = index + 1
			while self.descPageIndex[index] == self.descPageIndex[index - 1] do -- skips blank "pages"
				index = index + 1
				offset = offset - 1
			end
		end
		relativeWindow = self:CreateChoiceListSelectableText( self.buttonIDs[i - 2], GGManager.translateTID( self.descData[i] ), 
						"bottomleft", relativeWindow, "topleft", 0, 0 )
	end
	self:CreateBottomButton( GGManager.translateTID( GGManager.CANCEL_TID ), 0 )
end

-- OnInitialize Handler
function VRSelect.Initialize()
	local newWindow = VRSelect:new()
	newWindow.setDataFunction = VRSelect.setDataFunction
	newWindow:Init()
end
