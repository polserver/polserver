----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

BulkOrderPurchase = TwoButtonDialog:new()

--BulkOrderPurchase.spacer = UO_GenericGump.EMPTY_LINE..L"\n"

----------------------------------------------------------------
-- BulkOrderPurchase Functions
----------------------------------------------------------------

function BulkOrderPurchase:parseData()
	
	--UO_GenericGump.debug( L"parseDescAsTitleTextAndTwoButtons - setting data for = "..self.name )
	--self.title = --GGManager.translateTID( -- put title TID here )
	--self.subtitle = GGManager.translateTID( -- put subtitle TID here )
	self.text = GGManager.translateTID( self.descData[1] )..L"\n"..GGManager.translateTID( self.descData[5] )..L"\n\n"
		..GGManager.translateTID( self.descData[2] )..L"\n"..self.stringData[1]..L"\n\n"
	self.leftButtonName = GGManager.translateTID( self.descData[4] )
	self.rightButtonName = GGManager.translateTID( self.descData[3] )
	
	self.leftButtonID = self.buttonIDs[2]
	self.rightButtonID = self.buttonIDs[3]
	
end

-- OnInitialize Handler
function BulkOrderPurchase.Initialize()
	local newWindow = BulkOrderPurchase:new()
	newWindow.setDataFunction = BulkOrderPurchase.parseData
	newWindow:Init()
end
