----------------------------------------------------------
-- TestGump.lua
----------------------------------------------------------------

TestGump = MasterGUMP:new()

function TestGump.Initialize()

	local newWindow					= TestGump:new()
	newWindow.setData				= TestGump.mySetData
	newWindow:Init()
end

function TestGump:mySetData()
	self.Page						= {}
	self.Page[1]					= {}
	self.Page[1].ScrollText			= self.stringData[1]..L" "..self.stringData[2]
	
	self.Page[1].LeftButtonId		= self.buttonIDs[2]
	self.Page[1].LeftButtonText		= GGManager.translateTID( GGManager.OKAY_TID )
	
	self.Page[1].RightButtonId		= self.buttonIDs[1]
	self.Page[1].RightButtonText	= GGManager.translateTID( GGManager.CANCEL_TID )
end
