
-- This one expects:
-- self.descData[1] = title
-- self.descData[2] = subtitle (the text)
-- self.ImageNum[1] = picture
-- self.textHueData[1] = picture hue

-- TODO: Switch this over to use gumppic data not tilepic data?

-- You can overwrite the setData() if you need to. Set these:
-- self.title, self.subtitle, self.picture, self.pictureHue

----------------------------------------------------------------
-- SingleImageAndText
----------------------------------------------------------------

SingleImageAndText = {}

SingleImageAndTextManager = GGManager


function SingleImageAndText.Initialize()
	local NewWindow = SingleImageAndText:new()
	NewWindow:Init()
end


function SingleImageAndText:new( NewWindow )
	NewWindow = NewWindow or {}
	setmetatable( NewWindow, self )
	self.__index = self
	return NewWindow
end


function SingleImageAndText:Init()
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	if self.setDataFunction then
		self:setDataFunction()
	end
	if self.setFields then
			self:setFields()
	end
	SingleImageAndTextManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end


function SingleImageAndText:setDataFunction()

    local curDescNum = 1
    if self.descDataCount > 1 then
		if GGManager.translateTID( self.descData[curDescNum] ) == L"" then
			self.title = nil
		else
			self.title = GGManager.translateTID( self.descData[curDescNum] )
		end
		curDescNum = curDescNum + 1
	end
    if self.descDataCount > 2 then
		if GGManager.translateTID( self.descData[curDescNum] ) == L"" then
			self.subtitle = nil
		else
			self.subtitle = GGManager.translateTID( self.descData[curDescNum] )
		end
		curDescNum = curDescNum + 1
	end
	
	self.text = GGManager.translateTID(self.descData[curDescNum])
	--self.buttonName = GGManager.translateTID(GGManager.OKAY_TID) --"OK"
	self.buttonID = self.buttonIDs[1]
	
	-- get the picure
	if self.ImageNum[1] then
		self.picture = self.ImageNum[1]
	end
	-- get the picture's hue
	if self.textHueData[1] then
		self.pictureHue = self.textHueData[1]
	end
end -- setDataFunction()

-- set the data
function SingleImageAndText:setFields()
	if self.title and self.title ~= "" then
		WindowUtils.SetActiveDialogTitle( self.title )
	end
	if self.subtitle and self.subtitle ~= "" then
		LabelSetText( self.windowName.."Subtitle", self.subtitle )
    end
    
    if self.text and self.text ~= "" then
	    LabelSetText( self.windowName.."ScrollChildText", self.text )
	    --Debug.Print(L"text: "..self.text)
	end
	if self.buttonName then
		ButtonSetText(self.windowName.."ButtonName", self.buttonName )
		WindowSetId( self.windowName.."ButtonName", self.buttonID )	
	end
	
	--local subtitle_width, subtitle_height = WindowGetDimensions( self.windowName.."Subtitle" )
	--local text_width, text_height = WindowGetDimensions( self.windowName.."ScrollChildText" )	
	--WindowSetDimensions( self.windowName.."ScrollChildText", text_width, text_height+subtitle_height )
	
	if self.picture then
		--local texture, x, y, scale, width, height = RequestTileArt( self.picture, 0, 0 )	
		--WindowSetDimensions( self.windowName.."Icon", width, height )
		--DynamicImageSetTexture     ( self.windowName.."Icon", texture, x, y )
		--DynamicImageSetTextureScale( self.windowName.."Icon", scale )

		local testWidth = 128
		local testHeight = 128
		
		local defaultImage, x, y, scale, newWidth, newHeight = RequestTexture(self.picture, testWidth, testHeight)
		--Debug.Print("defaultImage: "..defaultImage)
		--Debug.Print("newWidth: "..newWidth)
		--Debug.Print("newHeight: "..newHeight)		
		WindowSetDimensions( self.windowName.."Icon", newWidth, newHeight)
		DynamicImageSetTexture( self.windowName.."Icon", defaultImage, 0, 0 )
		DynamicImageSetTextureScale( self.windowName.."Icon", 1.0 )	 --We should not scale it anyways.
	end


	if self.pictureHue and self.pictureHue ~= 0 then
		local r, g, b, a = HueRGBAValue(self.pictureHue)
		WindowSetTintColor( self.windowName.."Icon", r, g, b )
	end 	
end -- setFields()


-- OnClose handler
function SingleImageAndText.OnCloseWindow()

	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )
end


-- OnShutdownHandler
function SingleImageAndText.Shutdown()
	local self = GGManager.knownWindows[SystemData.ActiveWindow.name]	
	if self == nil then
		UO_GenericGump.debug( StringToWString( "Shutdown hander called for "..SystemData.ActiveWindow.name.." but data already deleted" ) )
		return
	end	

	if self.broadcastHasBeenSent == false then
		UO_GenericGump.broadcastButtonPress( UO_GenericGump.DEFAULT_CLOSE_BUTTON_ID, self )
	end
	
	if self.picture then
		ReleaseTexture(self.picture)
	end
	
	GGManager.unregisterActiveWindow()
end

function SingleImageAndText.ButtonPressed()

	local self = SingleImageAndText.getActiveWindowData()	
	UO_GenericGump.debug( "called SingleImageAndText.ButtonPressed() on "..self.windowName )
	
	self:ButtonFunction()
end


function SingleImageAndText:ButtonFunction()
	UO_GenericGump.debug( L"called SingleImageAndText.ButtonFunction" )
	
	local buttonID = WindowGetId( SystemData.ActiveWindow.name )
	
	-- NOTE: this may need to be changed. Currently WindowGetId seems to return 0,
	--  if a value is not set (and 0 is a valid value). May change C++ to return negative value
	--  when no value is set
	if not buttonID then	
		Debug.PrintToDebugConsole( L"ERROR in SingleImageAndText.ButtonFunction: no ID set for button pressed." )
		return
	end

	UO_GenericGump.debug( L"called SingleImageAndText.ButtonFunction(). Sending button value of "..buttonID )
	
	UO_GenericGump.broadcastButtonPress( buttonID, self )
	self.OnCloseWindow()
end

function SingleImageAndText.getActiveWindowData()

	local windowName = WindowUtils.GetActiveDialog()
	return SingleImageAndTextManager.knownWindows[windowName]
end
