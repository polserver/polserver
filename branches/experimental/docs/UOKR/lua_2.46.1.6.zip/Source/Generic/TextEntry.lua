
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

TextEntry = {
	numOfTextBoxes = 0,
	textBoxID = {},
	textBoxText = {},
	textBoxLabel = {},
}

TextEntryManager = GGManager

----------------------------------------------------------------
-- TextEntry Functions
----------------------------------------------------------------

function TextEntry:new( newWindow )
	newWindow = newWindow or {}
	setmetatable(newWindow, self)
	self.__index = self
	
	return newWindow
end


-- Init does the following:
--   1. retrieves data from the server
--   2. calls the object specific setDataFunction() to put the server data into standard fields
--   3. assigns those fields to the actual button/window names in setFields
--
-- TextEntrys have a default setDataFunction and setFields functions, but
--   either or both can be overwritten for different behavior. In some cases you may
--   wish to ignore the setFields function, e.g. set "self:setFields = nil" and
--   directly set the incoming data to the windows in the self:setDataFunction
--
function TextEntry:Init()
	
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end
	
	if self.setFields then
		self:setFields()
	end

	TextEntryManager.knownWindows[self.windowName] = self
	WindowSetId( self.windowName.."Chrome_UO_WindowCloseButton", UO_GenericGump.DEFAULT_CLOSE_BUTTON_ID )
	Interface.OnCloseCallBack[self.windowName] = self.OnCancel
	
	self.broadcastHasBeenSent = false
	
	Debug.PrintToDebugConsole( L"Initialize "..self.name )
end




-- custom data set function 
function TextEntry:setDataFunction()

	local descIndex = 1
	
	if self.descDataCount == 3 or self.descDataCount == 5 then
		self.title = GGManager.translateTID(self.descData[descIndex])
		descIndex = descIndex+1
	end
	
	self.subtitle1 = GGManager.translateTID(self.descData[descIndex])
	descIndex = descIndex+1
	self.subtitle2 = GGManager.translateTID(self.descData[descIndex])
	descIndex = descIndex+1
	
	self.submitButtonName = GGManager.translateTID(1077787)		-- "Submit"
	self.clearButtonName = GGManager.translateTID(3000154)		-- "Clear"
	self.cancelButtonName = GGManager.translateTID(GGManager.CANCEL_TID)
	
	for i=1, self.stringDataCount do
		self.textBoxID[i] = self.buttonIDs[i]
		self.textBoxText[i] = self.stringData[i]
	end
	
	-- TODO put in real count
	self.numOfTextBoxes = self.stringDataCount
	local buttonNum = self.stringDataCount
	
	buttonNum = buttonNum + 1
	self.submitButtonID = self.buttonIDs[buttonNum]
	
	buttonNum = buttonNum + 1
	self.cancelButtonID = self.buttonIDs[buttonNum]
	
	self.clearButtonID = -1
	
end


function TextEntry:setFields()

	if self.title then
		WindowUtils.SetActiveDialogTitle( self.title )
    end
    
	if self.subtitle1 then
		LabelSetText( self.windowName.."Subtitle1", self.subtitle1 )
    end
    
	if self.subtitle2 then
		LabelSetText( self.windowName.."Subtitle2", self.subtitle2 )
    end
    
	if self.text then
		LabelSetText( self.windowName.."ScrollChildText", self.text )
    end
    
	for i=1, self.numOfTextBoxes do
		if self.textBoxLabel[i] ~= nil and self.textBoxLabel[i] ~= "" then
			LabelSetText( self.windowName.."Label"..i, self.textBoxLabel[i] )
		end
		if self.textBoxText[i] ~= nil and self.textBoxText[i] ~= "" then
			TextEditBoxSetText( self.windowName.."BoxText"..i, self.textBoxText[i] )
		end
		WindowSetId( self.windowName.."BoxText"..i, self.textBoxID[i] )	
	end
	
	ButtonSetText(self.windowName.."SubmitButton", self.submitButtonName )
	WindowSetId( self.windowName.."SubmitButton", self.submitButtonID )	
	ButtonSetText(self.windowName.."ClearButton", self.clearButtonName )
	WindowSetId( self.windowName.."ClearButton", self.clearButtonID )	
	ButtonSetText(self.windowName.."CancelButton", self.cancelButtonName )
	WindowSetId( self.windowName.."CancelButton", self.cancelButtonID )	


    WindowAssignFocus(self.windowName.."BoxText"..1, true)
end



function TextEntry.getActiveWindowData()
	local windowName = WindowUtils.GetActiveDialog()
	
	return TextEntryManager.knownWindows[windowName]
end


------

-- OnInitialize Handler
function TextEntry.Initialize()

	( TextEntry:new() ):Init()
end
	


function TextEntry.OnSubmit() 

	local self = TextEntry.getActiveWindowData()	
	local buttonID = WindowGetId( self.windowName.."SubmitButton" )
		
	local textEntries = {}
	for i=1, self.numOfTextBoxes do
		local textBoxName = self.windowName.."BoxText"..i
		local text = TextEditBoxGetText( textBoxName )
		local id = WindowGetId( textBoxName )

		if text ~= nil and id ~= nil  then -- and text ~= ""
			--UO_GenericGump.debug( L"textbox "..i..L"has string = "..text..L", ID = "..id)		
			textEntries[id] = text
		end
	end
	
	UO_GenericGump.broadcastTextEntries( buttonID, textEntries, self )
	self.broadcastHasBeenSent = true
	self.OnCloseWindow()
end


function TextEntry.OnClear()
	local self = TextEntry.getActiveWindowData()
    
	for i=1, self.numOfTextBoxes do
		local textBoxName = self.windowName.."BoxText"..i
		TextEditBoxSetText( textBoxName, L"" )
	end
end


function TextEntry.OnCancel()

	local self = TextEntry.getActiveWindowData()
	local buttonID = WindowGetId( self.windowName.."CancelButton" )
	
	UO_GenericGump.broadcastTextEntries( buttonID, {}, self )
	self.broadcastHasBeenSent = true
	self.OnCloseWindow()
end


--
function TextEntry.OnCloseWindow()
	UO_GenericGump.debug( L"TextEntry.OnCloseWindow called. ")

	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )
end


function TextEntry.OnCloseWindow()
	
	local self = GGManager.knownWindows[SystemData.ActiveWindow.name]	
	if self == nil then
		UO_GenericGump.debug( StringToWString( "Shutdown hander called for "..SystemData.ActiveWindow.name.." but data already deleted" ) )
		return
	end	

	if self.broadcastHasBeenSent == false then
		UO_GenericGump.broadcastTextEntries( UO_GenericGump.DEFAULT_CLOSE_BUTTON_ID, {}, self )
	end
	
	GGManager.unregisterActiveWindow()
end
