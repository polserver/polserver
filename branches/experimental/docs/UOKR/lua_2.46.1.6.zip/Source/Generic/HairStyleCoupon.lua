----------------------------------------------------------------
-- HairStyleCoupon.lua
----------------------------------------------------------------

HairStyleCoupon = MasterGUMP:new()

function HairStyleCoupon.Initialize()
	local newWindow					= HairStyleCoupon:new()
	
	UOBuildTableFromCSV( "Data/GameData/malehumanhairstyle.csv",	"MaleHumanHairstylesCSV" )
	UOBuildTableFromCSV( "Data/GameData/femalehumanhairstyle.csv",	"FemaleHumanHairstylesCSV" )
	UOBuildTableFromCSV( "Data/GameData/maleelfhairstyle.csv",		"MaleElfHairstylesCSV" )
	UOBuildTableFromCSV( "Data/GameData/femaleelfhairstyle.csv",	"FemaleElfHairstylesCSV" )
	
	newWindow.setData				= HairStyleCoupon.mySetData
	newWindow:Init()
end

function HairStyleCoupon:mySetData()
	-- stores the names of hairstyles, since the server doesn't send these
	local tidTable = HairStyleCoupon.CreateTidTable( WindowData.MaleHumanHairstylesCSV, WindowData.FemaleHumanHairstylesCSV,
													 WindowData.MaleElfHairstylesCSV, WindowData.FemaleElfHairstylesCSV )
	
	self.Page				= {}
	self.Page[1]			= {}
	self.Page[1].Title		= GGManager.translateTID( self.descData[4] ) -- "New Hairstyle"
	self.Page[1].Selections	= {}
 	self.Page[1].UseXButtons = true

	local buttonOffset	= 2
	local range			= self.buttonCount - 3

	-- hair styles
	for i = 1, range do
		self.Page[1].Selections[i]		= {}
		self.Page[1].Selections[i].Id	= self.buttonIDs[i + buttonOffset]
		self.Page[1].Selections[i].Text	= GGManager.translateTID( tidTable[self.buttonIDs[i + buttonOffset]] )
	end
	
	-- bald
	range = range + 1
	self.Page[1].Selections[range]		= {}
	self.Page[1].Selections[range].Id	= self.buttonIDs[self.buttonCount]
	self.Page[1].Selections[range].Text	= GGManager.translateTID( self.descData[3] )

	self.Page[1].LeftButtonId			= self.buttonIDs[1]
	self.Page[1].LeftButtonText			= GGManager.translateTID( self.descData[1] ) -- Okay

	self.Page[1].RightButtonId			= self.buttonIDs[2]
	self.Page[1].RightButtonText		= GGManager.translateTID( self.descData[2] ) -- Cancel
	
end

-- create a table of hairstyle names, indexed by button ID
function HairStyleCoupon.CreateTidTable( CSVTable1, CSVTable2, CSVTable3, CSVTable4 )
	local tidTable = {}

	for i = 1, table.getn( CSVTable1 ) do
		-- HACKY IF STATEMENT CHECK BECAUSE CSV TABLE SEEMS TO CONTAIN NIL VALUES
	    if not ( ( CSVTable1[i].TileArtId == 0 ) and ( CSVTable1[i].StringId == 0 ) ) then
			tidTable[CSVTable1[i].TileArtId] = CSVTable1[i].StringId
		end
	end

	for i = 1, table.getn( CSVTable2 ) do
		-- HACKY IF STATEMENT CHECK BECAUSE CSV TABLE SEEMS TO CONTAIN NIL VALUES
	    if not ( ( CSVTable2[i].TileArtId == 0 ) and ( CSVTable2[i].StringId == 0 ) ) then
			tidTable[CSVTable2[i].TileArtId] = CSVTable2[i].StringId
		end
	end
	
	for i = 1, table.getn( CSVTable3 ) do
		-- HACKY IF STATEMENT CHECK BECAUSE CSV TABLE SEEMS TO CONTAIN NIL VALUES
	    if not ( ( CSVTable3[i].TileArtId == 0 ) and ( CSVTable3[i].StringId == 0 ) ) then
			tidTable[CSVTable3[i].TileArtId] = CSVTable3[i].StringId
		end
	end

	for i = 1, table.getn( CSVTable4 ) do
		-- HACKY IF STATEMENT CHECK BECAUSE CSV TABLE SEEMS TO CONTAIN NIL VALUES
	    if not ( ( CSVTable4[i].TileArtId == 0 ) and ( CSVTable4[i].StringId == 0 ) ) then
			tidTable[CSVTable4[i].TileArtId] = CSVTable4[i].StringId
		end
	end

	return tidTable
end

-- overriding this function to display a smaller piece of the art
function HairStyleCoupon:SetIcon( selection, choiceName )
	local texture, x, y, scale = "0000", 0, 0, 1
	local inSize, outSize	= 352, 64
	local xOffset, yOffset	= 212, 68

	if  selection.Port
	and selection.Port > 0
	then
		self.RequestedTextures = self.RequestedTextures or {}
		texture, x, y, scale, newWidth, newHeight = RequestTexture( selection.Port, inSize, inSize )
		self.RequestedTextures[#self.RequestedTextures + 1] = selection.Port
		UO_GenericGump.debug( L"    Portrait = "..StringToWString( tostring( selection.Port ) ) )
	end
	
	WindowSetDimensions( choiceName.."IconHolderIcon", outSize, outSize )
	DynamicImageSetTexture( choiceName.."IconHolderIcon", texture, xOffset, yOffset )
	DynamicImageSetTextureScale( choiceName.."IconHolderIcon", scale )
end

function HairStyleCoupon.Shutdown()
	UO_GenericGump.debug( L"HairStyleCoupon.Shutdown() called." )
	
	UOUnloadCSVTable( "MaleHumanHairstylesCSV" )
	UOUnloadCSVTable( "FemaleHumanHairstylesCSV" )
	UOUnloadCSVTable( "MaleElfHairstylesCSV" )
	UOUnloadCSVTable( "FemaleElfHairstylesCSV" )
	
	MasterGUMP.Shutdown()
end
