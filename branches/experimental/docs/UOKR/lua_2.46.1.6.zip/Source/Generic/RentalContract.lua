----------------------------------------------------------
-- RentalContract.lua
----------------------------------------------------------------

RentalContract = MasterGUMP:new()

function RentalContract.Initialize()

	local newWindow					= RentalContract:new()
	newWindow.setData				= RentalContract.mySetData
	newWindow:Init()
end

function RentalContract:mySetData()
	self.Page				= {}
	self.Page[1]			= {}
	self.Page[1].Subtitle	= GGManager.translateTID( self.descData[1] )
	if self.descData[7] > 0 then
		self.Page[1].Subtitle = self.Page[1].Subtitle..L"\n"..GGManager.translateTID( self.descData[7] )..L" "..self.stringData[4]
	end
	
	if self.buttonCount == 2 then -- contract offer
		self.Page[1].Selections			= {}
		
		self.Page[1].Selections[1]		= {} -- contract length
		self.Page[1].Selections[1].Id	= self.DISABLED2_BUTTON_ID
		self.Page[1].Selections[1].Text = GGManager.translateTID( self.descData[2] )..L": "..GGManager.translateTID( self.descData[4] )
		
		self.Page[1].Selections[2]		= {} -- price
		self.Page[1].Selections[2].Id	= self.DISABLED2_BUTTON_ID
		self.Page[1].Selections[2].Text = GGManager.translateTID( self.descData[3] )..L": "..self.stringData[3]
		
		self.Page[1].Selections[3]		= {} -- accept
		self.Page[1].Selections[3].Id	= self.buttonIDs[1]
		self.Page[1].Selections[3].Text = GGManager.translateTID( self.descData[9] )

		self.Page[1].Selections[4]		= {} -- decline
		self.Page[1].Selections[4].Id	= self.buttonIDs[2]
		self.Page[1].Selections[4].Text = GGManager.translateTID( self.descData[10] )

		if self.descData[8] > 0 then
			self.Page[1].Selections[5]		= {} -- current renter
			self.Page[1].Selections[5].Id	= self.DISABLED2_BUTTON_ID
			self.Page[1].Selections[5].Text = GGManager.translateTID( self.descData[8] )..L" "..self.stringData[5]
		end
		
	else -- contract is active
		self.Page[1].Selections			= {}
		
		self.Page[1].Selections[1]		= {} -- contract length
		if self.buttonIDs[1] > 0 then
			self.Page[1].Selections[1].Id	= -2
		else
			self.Page[1].Selections[1].Id	= self.DISABLED2_BUTTON_ID
		end
		self.Page[1].Selections[1].Text = GGManager.translateTID( self.descData[2] )..L": "..GGManager.translateTID( self.descData[4] )
		
		self.Page[1].Selections[2]		= {} -- price
		self.Page[1].Selections[2].Id	= self.buttonIDs[2]
		self.Page[1].Selections[2].Text = GGManager.translateTID( self.descData[3] )..L": "..self.stringData[3]
		
		self.Page[1].Selections[3]		= {} -- renew header
		self.Page[1].Selections[3].Id	= self.DISABLED2_BUTTON_ID
		self.Page[1].Selections[3].Text = GGManager.translateTID( self.descData[9] )
		
		local n = 4
		
		if self.descData[6] > 0 then
			self.Page[1].Selections[n]		= {} -- landlord
			self.Page[1].Selections[n].Id	= self.buttonIDs[3]
			self.Page[1].Selections[n].Text = GGManager.translateTID( self.descData[10] )..L" "..GGManager.translateTID( self.descData[6] )
			n = n + 1
		end
		
		if self.descData[5] > 0 then
			self.Page[1].Selections[n]		= {} -- renter
			self.Page[1].Selections[n].Id	= self.buttonIDs[4]
			self.Page[1].Selections[n].Text = GGManager.translateTID( self.descData[11] )..L" "..GGManager.translateTID( self.descData[5] )
			n = n + 1
		end
		
		self.Page[1].Selections[n]		= {} -- renewal status
		self.Page[1].Selections[n].Id	= self.DISABLED2_BUTTON_ID
		self.Page[1].Selections[n].Text = GGManager.translateTID( self.descData[13] )
		n = n + 1
		
		if self.descData[12] > 0 and self.stringData[6] then
			self.Page[1].Selections[n]		= {} -- renewal price
			self.Page[1].Selections[n].Id	= self.buttonIDs[5]
			self.Page[1].Selections[n].Text = GGManager.translateTID( self.descData[12] )..L": "..self.stringData[6]
			n = n + 1
		end
		
		if self.descData[14] > 0 then
			self.Page[1].Selections[n]		= {} -- make offer
			self.Page[1].Selections[n].Id	= self.buttonIDs[6]
			self.Page[1].Selections[n].Text = GGManager.translateTID( self.descData[14] )
		
		elseif self.descData[8] > 0 then
			self.Page[1].Selections[n]		= {} -- current renter
			self.Page[1].Selections[n].Id	= self.DISABLED2_BUTTON_ID
			self.Page[1].Selections[n].Text = GGManager.translateTID( self.descData[8] )..L" "..self.stringData[5]
		end
		
		self.Page[2]					= {}
		self.Page[2].Subtitle			= GGManager.translateTID( self.descData[1] )
		self.Page[2].Selections			= {}
		
		-- number of weeks
		for i = 1, 4 do
			self.Page[2].Selections[i]		= {}
			self.Page[2].Selections[i].Id	= self.buttonIDs[i + 6]
			self.Page[2].Selections[i].Text = GGManager.translateTID( self.descData[i + 14] )
		end
	end
end
