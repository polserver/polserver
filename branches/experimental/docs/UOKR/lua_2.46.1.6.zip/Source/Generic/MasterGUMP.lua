----------------------------------------------------------------
--
-- MasterGUMP.lua
--	Written by Corey Johnson (cjohnson@ea.com)
--
----------------------------------------------------------------
--[[------------------------------------------------------------

Known Issues:
1.	Auto Shortening not working correctly
2.	An empty scroll window will have a scroll bar instead of being completely invisable
3.	Bottom Selections must be contigious and the last things in a selection list
4.	Tooltips might possibly be really innefficient do to the thing = thing or {} method, I don't know

--]]------------------------------------------------------------

-- Manager table to hold all MasterGump derivatives
MasterGUMPManager = GGManager

MasterGUMP = {}

-- These are the default values that get used in
-- MasterGUMP for almost all spacing. They get
-- copied to local vars in each gump and can be
-- overridden in Init(). self.XXXXX versions get
-- used throughout the rest of the script.
MasterGUMP.WINDOW_WIDTH_STANDARD	= 315
MasterGUMP.WINDOW_WIDTH_WIDE		= 630
MasterGUMP.WINDOW_HEIGHT_STANDARD	= 500
MasterGUMP.WINDOW_HEIGHT_SHORT		= 280
MasterGUMP.MAX_ICON_WIDTH			= 64		-- These should match the IconHolder size in the SelectableIconText template in the xml
MasterGUMP.MAX_ICON_HEIGHT			= 64		-- These should match the IconHolder size in the SelectableIconText template in the xml
MasterGUMP.SPACING					= 10		-- The spacing between elements like Subtitle and Subtitle Horizontal Line
MasterGUMP.SELECTION_SPACING		= 0			-- The spacing between SelectableTexts and SelectableIconTexts
MasterGUMP.SELECTION_PADDING		= 8			-- The padding between SelectableText and SelectableIconText's text and the top/bottom edges of the actual button
MasterGUMP.TITLE_OFFSET				= 60		-- The space to skip over from the top. This is to skip the window chrome (title bar) stuff.
MasterGUMP.BUTTON_OFFSET			= 60		-- The space to skip from the bottom if we have buttons
MasterGUMP.LEFT_OFFSET				= 15		-- Padding from the left side of the GUMP
MasterGUMP.RIGHT_OFFSET				= 15		-- Padding from the right side of the GUMP
MasterGUMP.BOTTOM_OFFSET			= 15		-- Padding from the bottom of the GUMP. Used if we don't have any buttons
MasterGUMP.HIGHLIGHT_BUTTON_ID		= -998		-- Id to make a selection Highlighted
MasterGUMP.DISABLED_BUTTON_ID		= -999		-- Id to make a selection Disabled
MasterGUMP.DISABLED2_BUTTON_ID		= -666		-- Id to make a selection not really a selection, but I icon/text tuple. If there is no icon, then the icon window is destroyed and there is no default icon
MasterGUMP.HIGHLIGHT2_BUTTON_ID		= -1000		-- Id to make a selection GREEN!!!
MasterGUMP.HIGHLIGHT3_BUTTON_ID		= -1001		-- Id to make a selection RED!!!


function MasterGUMP.Initialize()

	local newGUMP = MasterGUMP:new()
	
	-- A derived GUMP will have it's own Initialize()
	-- that looks a lot like this. Here is where you
	-- would overwite a default spacing value. Example:
	
	-- Overwriting the write offset to be 25 pixels instead of the default 15
	-- newGUMP.RIGHT_OFFSET = 25
	
	newGUMP:Init()
end

function MasterGUMP:new( newGUMP )

	newGUMP = newGUMP or {}
	setmetatable( newGUMP, self )
	self.__index = self

	-- Create a table for the pages to be stored
	-- MasterGUMP expects there to be at least one table
	newGUMP.Page					= {}
	
	-- Copying over the default values
	newGUMP.WINDOW_WIDTH_STANDARD	= MasterGUMP.WINDOW_WIDTH_STANDARD
	newGUMP.WINDOW_WIDTH_WIDE		= MasterGUMP.WINDOW_WIDTH_WIDE
	newGUMP.WINDOW_HEIGHT_STANDARD	= MasterGUMP.WINDOW_HEIGHT_STANDARD
	newGUMP.WINDOW_HEIGHT_SHORT		= MasterGUMP.WINDOW_HEIGHT_SHORT
	newGUMP.MAX_ICON_WIDTH			= MasterGUMP.MAX_ICON_WIDTH
	newGUMP.MAX_ICON_HEIGHT			= MasterGUMP.MAX_ICON_HEIGHT
	newGUMP.SPACING					= MasterGUMP.SPACING
	newGUMP.SELECTION_SPACING		= MasterGUMP.SELECTION_SPACING
	newGUMP.SELECTION_PADDING		= MasterGUMP.SELECTION_PADDING
	newGUMP.TITLE_OFFSET			= MasterGUMP.TITLE_OFFSET
	newGUMP.BUTTON_OFFSET			= MasterGUMP.BUTTON_OFFSET
	newGUMP.LEFT_OFFSET				= MasterGUMP.LEFT_OFFSET
	newGUMP.RIGHT_OFFSET			= MasterGUMP.RIGHT_OFFSET
	newGUMP.BOTTOM_OFFSET			= MasterGUMP.BOTTOM_OFFSET
	newGUMP.HIGHLIGHT_BUTTON_ID		= MasterGUMP.HIGHLIGHT_BUTTON_ID
	newGUMP.HIGHLIGHT2_BUTTON_ID	= MasterGUMP.HIGHLIGHT2_BUTTON_ID
	newGUMP.HIGHLIGHT3_BUTTON_ID	= MasterGUMP.HIGHLIGHT3_BUTTON_ID
	newGUMP.DISABLED_BUTTON_ID		= MasterGUMP.DISABLED_BUTTON_ID
	newGUMP.DISABLED2_BUTTON_ID		= MasterGUMP.DISABLED2_BUTTON_ID

	return newGUMP
end

function MasterGUMP:Init()

	if not UO_GenericGump.retrieveWindowData( self )
	then
		return false
	end
	
	-- the setData() should only ever set the data
	if self.setData
	then
		UO_GenericGump.debug( L"Setting data for "..StringToWString( tostring( self.windowName ) ) )
		self:setData()
	end
	
	-- finalize() takes the set data and creates/arranges the elements needed for it
	if self.finalize
	then
		UO_GenericGump.debug( L"Finalizing "..self.name )
		self:finalize()
	end
	
	-- fixup is executed afterwards so the user can overwite things in finalize with out modify finalize itself
	if self.fixup
	then
		UO_GenericGump.debug( L"Fixing up "..self.name )
		self:fixup()
	end
	
	-- Save a copy of ourselves to be retrieved in event handler callbacks
	MasterGUMPManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end

function MasterGUMP:setDataExample()

	-- Create a wide window
	self.IsWide = true
	
	-- Forces a short window
	self.IsShort = true
	
	-- Forces a standard window
	self.IsStandardHeight = true
	
	-- Forces a standard window
	-- HSould never be needed since MasterGUMP won't "auto-widen" a GUMP
	self.IsStandardWidth = true
	
	-- Enables prev/next button page nav
	self.CreatePrevNextButtons = true
	
	-- You can also do each one separatly
	-- TODO: make the buttons loop if the other doesn't exist
	self.CreatePrevButton = true
	self.CreateNextButton = true

	-- Loop through and create a page for each one provided from Wombat
	for pageItr = 1, table.getn( self.descDataCount )
	do
		-- get iteraters
		-- a lot of the time page 0 in wombat holds no KR relavent data so we need to skip it in the PageIndexes
		local dscItr		= self.descPageIndex[pageItr]--[pageItr + 1]
		local strItr		= self.stringPageIndex[pageItr]
		local icnItr		= self.ImagePageIndex[pageItr]
		local prtItr		= self.portPageIndex[pageItr]
		local btnItr		= self.buttonPageIndex[pageItr]
		local ttpItr		= self.TooltipPageIndex[pageItr]
		-- etc
		
		-- we usaully need at least one End iterater
		-- We know that the last page ends at the Count variable
		-- and page that are not the last stop 1 before the next page.
		-- Depending on if you want to do a 'while dscItr < dscItrEnd' or
		-- a 'while dscItr <= dscItrEnd', you may want to subtract 1
		local dscItrEnd		= self.descDataCount
		if pageItr < table.getn( self.descDataCount )
		then
			dscItrEnd		= self.descPageIndex[pageItr]
		--	dscItrEnd		= self.descPageIndex[pageItr] - 1
		end
		
		-- Each page needs its own tablespace
		self.Page[pageItr] = {}
		
		-- Each page has it's own title
		self.Page[pageItr].Title = GGManager.translateTID( self.descData[dscItr] )
		dscItr = dscItr + 1
		
		self.Page[pageItr].Subtitle = GGManager.translateTID( self.descData[dscItr] )
		dscItr = dscItr + 1
		
		-- Display a horizontal line left justified under the Subtitle
		self.Page[pageItr].SubtitleHL = true
		self.Page[pageItr].SubtitleHLWidthX = 45		-- Change it's width
		
		-- ScrollText is inside the scroll window, this leaves room for 
		-- a Text filed in the future that would be outside of the scroll window
		-- and used for headers, etc
		self.Page[pageItr].ScrollText = GGManager.translateTID( self.descData[dscItr] )
		dscItr = dscItr + 1
		
		-- Display a horizontal line left justified under the Scrolltext before the selections
		self.Page[pageItr].SelectionHL = true
		self.Page[pageItr].SelectionHLWidthX = 45		-- Change it's width
		
		-- Use X button icons, and tell MasterGUMP not to close the gump until the user presses Okay or equivalent
		-- If using this option, do not also use RadioId; instead, set the Okay button to the buttonID
		self.Page[pageItr].UseXButtons = true
		
		-- This will be returned by all selections as the buttonId and the the actual buttonId will be in the selections list
		-- Tells MasterGUMP to close the gump immediately and send the selection
		-- Do not use this at the same time as UseXButtons
		self.Page[pageItr].RadioId = self.buttonIDs[btnItr]
		btnItr = btnItr + 1
		
		-- Each page that needs selections will need it's own selection tablespace
		-- Don't do this if you have no selections
		self.Page[pageItr].Selections = {}
		
		-- You can set your own selection template it will still append "_wide" if IsWide is set to true
		self.Page[pageItr].SelectionTemplate = "mySelectableText"
		
		-- loop through the rest of our buttons except for the last 3, where saving those for the bottom buttons
		-- MasterGUMP uses ipairs so the indexes need to start at 1 and be contigious so we do this:
		local index = 1
		while btnItr < self.buttonCount - 3
		do
			-- each selection needs its own tablespace
			self.Page[pageItr].Selections[index] = {}
			
			-- The window Id to set, you can disable by setting this to self.DISABLED_BUTTON_ID, and other special stuff
			self.Page[pageItr].Selections[index].Id = self.buttonIDs[btnItr]
			
			-- The size of each selection resizes to fit the text
			self.Page[pageItr].Selections[index].Text = GGManager.translateTID( self.descData[dscItr] )
			dscItr = dscItr + 1
			
			-- If you set an Icon or Port then the selection will use the SelectableIconText, otherwise it uses SelectableText
			self.Page[pageItr].Selections[index].Icon = self.ImageNum[icnItr]
			icnItr = icnItr + 1
			-- A portrait would override an Icon (TileArt)
			self.Page[pageItr].Selections[index].Port = self.ImageNum[prtItr]
			prtItr = prtItr + 1
			
			-- setting this to true will append the Icon outside of the scroll window on the bottom and will shorten the scroll window accordingly
			-- Selections with bottom set to true need to be contigious and be the last ones in the list to function properly
			self.Page[pageItr].Selections[index].Bottom = true
			
			index = index + 1
		end
		
		-- Each page have there own bottom buttoms, they auto fit themselves
		-- Configurations that fit are:
		-- Left/Right w/ Prev/Next
		-- Middle w/ Prev/Next
		-- Left/Right w/o Prev/Next
		-- Left/Middle/Right w/o Prev/Next
		-- Middle w/o Prev/Next
		self.Page[pageItr].LeftButtonId		= self.buttonIDs[self.buttonCount - 2]
		self.Page[pageItr].LeftButtonText	= GGManager.translateTID( self.descData[dscItr] )
		dscItr = dscItr + 1
		
		self.Page[pageItr].MiddleButtonId	= self.buttonIDs[self.buttonCount - 1]
		self.Page[pageItr].MiddleButtonText	= GGManager.translateTID( self.descData[dscItr] )
		dscItr = dscItr + 1

		self.Page[pageItr].RightButtonId	= self.buttonIDs[self.buttonCount]
		self.Page[pageItr].RightButtonText	= GGManager.translateTID( self.descData[dscItr] )
	end
end

-- replaces the default button icon with custom art
function MasterGUMP:SetIcon( selection, choiceName )
	local texture, x, y, scale, newWidth, newHeight = "0000", 0, 0, 1, 0, 0
	
	if  selection.Icon
	and selection.Icon > 0
	then
		self.RequestedTileArt = self.RequestedTileArt or {}
		texture, x, y, scale, newWidth, newHeight = RequestTileArt( selection.Icon, 64, 64 )
		self.RequestedTileArt[#self.RequestedTileArt + 1] = texture
		UO_GenericGump.debug( L"    TileArt = "..StringToWString( tostring( selection.Icon ) ) )
	end
	
	if  selection.Port
	and selection.Port > 0
	then
		self.RequestedTextures = self.RequestedTextures or {}
		texture, x, y, scale, newWidth, newHeight = RequestTexture( selection.Port, 64, 64 )
		self.RequestedTextures[#self.RequestedTextures + 1] = texture
		UO_GenericGump.debug( L"    Portrait = "..StringToWString( tostring( selection.Port ) ) )
	end
	
	WindowSetDimensions( choiceName.."IconHolderIcon", newWidth, newHeight )
	DynamicImageSetTexture( choiceName.."IconHolderIcon", texture, x, y )
	DynamicImageSetTextureScale( choiceName.."IconHolderIcon", scale )
end

function MasterGUMP:finalize()

	if self.Page
	then
		UO_GenericGump.debug( L"Pages" )
		
		local maxBodyHeight = 0
		
		for pageNum, pageObj in ipairs( self.Page )
		do
			UO_GenericGump.debug( L" Page "..pageNum )
			
			---[[ the title
			if pageObj.Title
			then
				UO_GenericGump.debug( L"  Tile" )
				UO_GenericGump.debug( L"   "..pageObj.Title )
				if pageNum == 1
				then
					WindowUtils.SetActiveDialogTitle( pageObj.Title )
				end
			end --]]

			---[[ the body
			local bodyName = self.windowName.."Body"..pageNum
			local bodyHeight		= 0
			local bodyContentHeight	= 0
			
			if getTableSize( pageObj )
			then
				local bodyTemplate	= "masterBody"
				if self.IsWide then
					bodyTemplate	= bodyTemplate.."_Wide"
				end
				
				CreateWindowFromTemplate( bodyName, bodyTemplate, self.windowName )
				WindowClearAnchors( bodyName )
				WindowAddAnchor( bodyName, "topleft", self.windowName, "topleft", self.LEFT_OFFSET, self.TITLE_OFFSET )
				
				if self.CreatePrevNextButtons
				or self.CreatePrevButton
				or self.CreateNextButton
				or (pageObj.LeftButtonId and pageObj.LeftButtonText)
				or (pageObj.MiddleButtonId and pageObj.MiddleButtonText)
				or (pageObj.RightButtonId and pageObj.RightButtonText)
				then
					WindowAddAnchor( bodyName, "bottomright", self.windowName, "bottomright", -self.RIGHT_OFFSET, -self.BUTTON_OFFSET )
				--	bodyHeight = self.WINDOW_HEIGHT_STANDARD - self.TITLE_OFFSET - self.BUTTON_OFFSET
				else
					WindowAddAnchor( bodyName, "bottomright", self.windowName, "bottomright", -self.RIGHT_OFFSET, -self.BOTTOM_OFFSET )
				--	bodyHeight = self.WINDOW_HEIGHT_STANDARD - self.TITLE_OFFSET - self.BOTTOM_OFFSET
				end
				
				---[[ the subtitle
				local subtitleName = self.windowName.."Subtitle"..pageNum
				local subtitleHeight = 0
				
				if pageObj.Subtitle
				then
					UO_GenericGump.debug( L"  Subtitle" )
					UO_GenericGump.debug( L"   ...")--..pageObj.Subtitle )
					
					local subtitleTemplate	= "masterSubtitle"
					if self.IsWide then
						subtitleTemplate	= subtitleTemplate.."_Wide"
					end

					CreateWindowFromTemplate( subtitleName, subtitleTemplate, bodyName )
					WindowClearAnchors( subtitleName )
					WindowAddAnchor( subtitleName, "topleft", bodyName, "topleft", 0, 0 )
					LabelSetText( subtitleName, pageObj.Subtitle )

					local x, y = WindowGetDimensions( subtitleName )
					x = pageObj.SubtitleX or x
					y = pageObj.SubtitleY or y
					WindowSetDimensions( subtitleName, x, y )
					
					subtitleHeight = y
				end --]] the subtitle
				
				---[[ the subtitle horizontal line
				local subtitleHLName = self.windowName.."SubtitleHL"..pageNum
				
				if pageObj.SubtitleHL
				then
					local HLTemplate	= "masterHorizLine"
					if self.IsWide
					then
						HLTemplate		= HLTemplate.."_Wide"
					end
					
					CreateWindowFromTemplate( subtitleHLName, HLTemplate, bodyName )
					WindowClearAnchors( subtitleHLName )
					if pageObj.Subtitle
					then
						WindowAddAnchor( subtitleHLName, "bottomleft", subtitleName, "topleft", 0, self.SPACING )
						subtitleHeight = subtitleHeight + self.SPACING
					else
						WindowAddAnchor( subtitleHLName, "topleft", bodyName, "topleft", 0, 0 )
					end
					
					local x, y = WindowGetDimensions( subtitleHLName )
					x = pageObj.SubtitleHLWidthX or x
					WindowSetDimensions( subtitleHLName, x, y )
					
					subtitleHeight = subtitleHeight + y
				end --]] the subtitle horizontal line
				
				---[[ the scroll window
				local scrollName		= self.windowName.."Scroll"..pageNum
				local scrollChildName	= scrollName.."Child"
				local scrollHeight		= 0
				local scrollChildHeight	= 0
			
				local scrollTemplate	= "masterScroll"
				if self.IsWide then
					scrollTemplate		= scrollTemplate.."_Wide"
				end
				
				CreateWindowFromTemplate( scrollName, scrollTemplate, bodyName )
				
				WindowClearAnchors( scrollName )
				local body_width, body_height = WindowGetDimensions( bodyName )
				local scroll_height	= body_height
				if pageObj.Subtitle
				then
					local subtitle_width, subtitle_height	= WindowGetDimensions( subtitleName )
					scroll_height	= scroll_height - self.SPACING - subtitle_height
						
					if pageObj.SubtitleHL
					then
						local subtitleHL_width, subtitleHL_height	= WindowGetDimensions( subtitleHLName )
						scroll_height	= scroll_height - self.SPACING - subtitleHL_height
						WindowSetDimensions( scrollName, subtitle_width, scroll_height )
						WindowAddAnchor( scrollName, "bottomleft", subtitleHLName, "topleft", 0, self.SPACING )
					else
						WindowSetDimensions( scrollName, subtitle_width, scroll_height )
						WindowAddAnchor( scrollName, "bottomleft", subtitleName, "topleft", 0, self.SPACING )
					end
				else
					if pageObj.SubtitleHL
					then
						local subtitleHL_width, subtitleHL_height	= WindowGetDimensions( subtitleHLName )
						scroll_height	= scroll_height - self.SPACING - subtitleHL_height
						WindowSetDimensions( scrollName, subtitle_width, scroll_height )
						WindowAddAnchor( scrollName, "bottomleft", subtitleHLName, "topleft", 0, self.SPACING )
					else
						WindowSetDimensions( scrollName, body_width, scroll_height )
						WindowAddAnchor( scrollName, "topleft", bodyName, "topleft", 0, 0 )
					end
				end

			--	local x, y = WindowGetDimensions( scrollName )
			--	x = pageObj.ScrollX or x
			--	y = pageObj.ScrollY or y
			--	WindowSetDimensions( scrollName, x, y )
				--]] the scroll window
				
				---[[ the scrollable text
				local scrollTextName = self.windowName.."ScrollText"..pageNum
				
				if pageObj.ScrollText
				then
					UO_GenericGump.debug( L"  Scrollable Text" )
					UO_GenericGump.debug( L"   ...")--..pageObj.ScrollText )
					
					local textTemplate	= "masterText"
					if self.IsWide
					then
						textTemplate	= textTemplate.."_Wide"
					end

					CreateWindowFromTemplate( scrollTextName, textTemplate, scrollChildName )
					WindowClearAnchors( scrollTextName )
					WindowAddAnchor( scrollTextName, "topleft", scrollChildName, "topleft", 0, 0 )
					LabelSetText( scrollTextName, pageObj.ScrollText )

					local x, y = WindowGetDimensions( scrollTextName )
					x = pageObj.ScrollTextX or x
					y = pageObj.ScrollTextY or y
					WindowSetDimensions( scrollTextName, x, y )
					
					scrollChildHeight = scrollChildHeight + y
				end	--]] the scrollable text
				
				---[[ the selections horizontal line
				local selectHLName = self.windowName.."SelectHL"..pageNum
				
				if pageObj.SelectionHL
				then
					local HLTemplate	= "masterHorizLine"
					if self.IsWide
					then
						HLTemplate	= HLTemplate.."_Wide"
					end
					
					CreateWindowFromTemplate( selectHLName, HLTemplate, scrollChildName )
					WindowClearAnchors( selectHLName )
					if pageObj.ScrollText
					then
						WindowAddAnchor( selectHLName, "bottomleft", scrollTextName, "topleft", 0, self.SPACING )
						scrollChildHeight = scrollChildHeight + self.SPACING
					else
						WindowAddAnchor( selectHLName, "topleft", scrollChildName, "topleft", 0, 0 )
					end
					
					local x, y = WindowGetDimensions( selectHLName )
					x = pageObj.SelectionHLWidthX or x
					WindowSetDimensions( selectHLName, x, y )
					
					scrollChildHeight = scrollChildHeight + y
				end --]] the selections horizontal line
				
				---[[ the selections
				local scrollShorten = 0
				
				if pageObj.Selections
				then
					UO_GenericGump.debug( L"  Selections" )
					
					for i, selection in ipairs( pageObj.Selections )
					do
						local choiceTemplate	= "masterSelectableText"
						
						if selection.Icon
						or selection.Port
						then
							choiceTemplate		= "masterSelectableIconText"
						end
						
						if pageObj.UseXButtons
						then
							choiceTemplate		= "masterXButtonText"
						end
						
						if pageObj.SelectionTemplate
						then
							choiceTemplate		= pageObj.SelectionTemplate
						end

						if self.IsWide then
							choiceTemplate		= choiceTemplate.."_Wide"
						end
						
						UO_GenericGump.debug( L"   Selection "..i )
						
						local choiceName	= self.windowName..pageNum.."Choice"..i
						local relative		= self.windowName..pageNum.."Choice"..(i - 1)
						
						if selection.Bottom
						then
							CreateWindowFromTemplate( choiceName, choiceTemplate, bodyName )
						else
							CreateWindowFromTemplate( choiceName, choiceTemplate, scrollChildName )
						end
						
						if pageObj.UseXButtons
						then
							ButtonSetStayDownFlag( choiceName, true )
							ButtonSetCheckButtonFlag( choiceName, true )
						end
						
						WindowClearAnchors( choiceName )
						if i == 1
						then
							if selection.Bottom
							then
								WindowAddAnchor( choiceName, "bottomleft", scrollName, "topleft", 0, self.SELECTION_SPACING )
								scrollShorten = scrollShorten + self.SELECTION_SPACING
								pageObj.FirstBottom = true
							else
								if pageObj.ScrollText
								then
									if pageObj.SelectionHL
									then
										WindowAddAnchor( choiceName, "bottomleft", selectHLName, "topleft", 0, self.SPACING )
										scrollChildHeight = scrollChildHeight + self.SPACING
									else
										WindowAddAnchor( choiceName, "bottomleft", self.windowName.."ScrollText"..pageNum, "topleft", 0, self.SPACING )
										scrollChildHeight = scrollChildHeight + self.SPACING
									end
								else
									if pageObj.SelectionHL
									then
										WindowAddAnchor( choiceName, "bottomleft", selectHLName, "topleft", 0, self.SPACING )
										scrollChildHeight = scrollChildHeight + self.SPACING
									else
										WindowAddAnchor( choiceName, "topleft", scrollChildName, "topleft", 0, 0 )
									end
								end
							end
						else
							if  selection.Bottom
							and not pageObj.FirstBottom
							then
								WindowAddAnchor( choiceName, "bottomleft", scrollName, "topleft", 0, self.SELECTION_SPACING )
								scrollShorten = scrollShorten + self.SELECTION_SPACING
								pageObj.FirstBottom = true
							else
								WindowAddAnchor( choiceName, "bottomleft", relative, "topleft", 0, self.SELECTION_SPACING )
								if  selection.Bottom
								then
									scrollShorten = scrollShorten + self.SELECTION_SPACING
								else
									scrollChildHeight = scrollChildHeight + self.SELECTION_SPACING
								end
							end
						end
						
						if selection.Icon
						or selection.Port
						then
							-- this code was moved out to MasterGUMP:SetIcon() so that it could be overridden more easily
							self:SetIcon( selection, choiceName )
							end
							
						if selection.Id
						then
							WindowSetId( choiceName.."Button", selection.Id )
							UO_GenericGump.debug( L"    Id = "..StringToWString( tostring( selection.Id ) ) )
						end
						if selection.Text
						then
							LabelSetText( choiceName.."Text", selection.Text )
							UO_GenericGump.debug( L"    Text = "..StringToWString( tostring( selection.Text ) ) )
						end
						if selection.Tooltip
						then
							self.Tooltips = self.Tooltips or {}
							self.Tooltips[choiceName.."Button"] = selection.Tooltip
							UO_GenericGump.debug( L"    Tooltip = "..StringToWString( tostring( selection.Tooltip ) ) )
						end

						-- Fix so the height of the Icon/Port is taken into account		
						local choice_width, choice_height	= WindowGetDimensions( choiceName )
						local text_width,   text_height		= LabelGetTextDimensions( choiceName.."Text" )
						local new_height					= choice_height
						
						if choice_height < text_height + (self.SELECTION_PADDING * 2)
						then
							new_height = text_height + (self.SELECTION_PADDING * 2)
						end			
						
						WindowSetDimensions( choiceName,           choice_width, new_height )
						
						if not pageObj.UseXButtons
						then
							WindowSetDimensions( choiceName.."Button", choice_width, new_height )
						end
						
						if selection.Bottom
						then
							scrollShorten = scrollShorten + new_height
						else
							scrollChildHeight = scrollChildHeight + new_height
						end
						
						if  selection.Hue
						and selection.Hue ~= 0
						then
							local r, g, b, a = HueRGBAValue( selection.Hue )
							WindowSetTintColor( choiceName.."IconHolderIcon", r, g, b )
							UO_GenericGump.debug( L"    RGBA = "..r..L" "..g..L" "..b..L" "..a )
						end
						
						if selection.Id == self.HIGHLIGHT_BUTTON_ID
						then
						--	ButtonSetHighlightFlag( choiceName.."IconHolderIcon", true )
							LabelSetTextColor( choiceName.."Text", 255, 255, 255 )
						--	self.CurrentHLSelection = choiceName
						end
						
						if selection.Id == self.HIGHLIGHT2_BUTTON_ID
						then
							ButtonSetDisabledFlag( choiceName.."Button", true )
							WindowSetTintColor( choiceName.."IconHolderIcon", 64, 255, 64 )
						end
						
						if selection.Id == self.HIGHLIGHT3_BUTTON_ID
						then
							ButtonSetDisabledFlag( choiceName.."Button", true )
							WindowSetTintColor( choiceName.."IconHolderIcon", 255, 64, 64 )
						end
						
						if selection.Id == self.DISABLED_BUTTON_ID
						then
							ButtonSetDisabledFlag( choiceName.."Button", true )
							WindowSetTintColor( choiceName.."IconHolderIcon", 128, 128, 128 )
						end
						
						if selection.Id == self.DISABLED2_BUTTON_ID
						then
							ButtonSetDisabledFlag( choiceName.."Button", true )
							
							if not selection.Icon and not selection.Port
							then
								DestroyWindow( choiceName.."IconHolderIcon" )
							elseif selection.Icon and not selection.Port
							then
								if selection.Icon < 0
								then
									DestroyWindow( choiceName.."IconHolderIcon" )
								end
							elseif not selection.Icon and selection.Port
							then
								if selection.Port < 0
								then
									DestroyWindow( choiceName.."IconHolderIcon" )
								end
							else
								if selection.Icon < 0 and selection.Port < 0
								then
									DestroyWindow( choiceName.."IconHolderIcon" )
								end
							end
						end
					end
				end --]] the selections

				bodyContentHeight = subtitleHeight + scrollChildHeight + scrollShorten

				local scroll_width, scroll_height = WindowGetDimensions( scrollName )
				if scrollChildHeight < scroll_height
				then
					scrollChildHeight = scroll_height
				end
				WindowSetDimensions( scrollChildName, scroll_width, scrollChildHeight )

				if scrollShorten > 0
				then
					WindowSetDimensions( scrollName, scroll_width, scroll_height - scrollShorten )
				end

				---[[ Prev/Next buttons
				if self.CreatePrevNextButtons
				then
					self.CreatePrevButton	= true
					self.CreateNextButton	= true
				end --]] Prev/Next buttons
				
				---[[ the Prev button
				if self.CreatePrevButton
				then
					CreateWindowFromTemplate( self.windowName.."PrevButton", "masterPrevButton", self.windowName )
					WindowSetId( self.windowName.."PrevButton", -1 )
					
					-- Always disable Prev on first page
					ButtonSetDisabledFlag( self.windowName.."PrevButton", true )
				end --]] the Prev button

				---[[ the Next button
				if self.CreateNextButton
				then
					CreateWindowFromTemplate( self.windowName.."NextButton", "masterNextButton", self.windowName )
					WindowSetId( self.windowName.."NextButton", 1 )
					
					if table.getn( self.Page ) < 2
					then
						ButtonSetDisabledFlag( self.windowName.."NextButton", true )
					end
				end --]] the Next button
				
				---[[ Middle button
				local middleButtonName = self.windowName.."MiddleButton"--..pageNum
				
				if  pageObj.MiddleButtonId
				and pageObj.MiddleButtonText
				then
					if not self.MiddleButtonCreated
					then
						CreateWindowFromTemplate( middleButtonName, "masterMiddleButton", self.windowName )
						self.MiddleButtonCreated = true
						WindowClearAnchors( middleButtonName )
						WindowAddAnchor( middleButtonName, "bottom", self.windowName, "bottom", 0, -self.BOTTOM_OFFSET )
					end
					
--					if pageNum == 1
--					then
--						WindowSetId( middleButtonName, pageObj.MiddleButtonId )
--						ButtonSetText( middleButtonName, pageObj.MiddleButtonText )
--					end
					
--					if pageNum ~= 1
--					and	not (self.Page[1].MiddleButtonId and self.Page[1].MiddleButtonText)
--					then
						WindowSetShowing( middleButtonName, false )
--					end
				end --]] Middle button
				
				---[[ Left button
				local leftButtonName = self.windowName.."LeftButton"--..pageNum
				
				if  pageObj.LeftButtonId
				and pageObj.LeftButtonText
				then
					CreateWindowFromTemplate( leftButtonName, "masterLeftButton", self.windowName )
					WindowClearAnchors( leftButtonName )
					if self.CreatePrevNextButtons
					or self.CreatePrevButton
					then
						WindowAddAnchor( leftButtonName, "right", self.windowName.."PrevButton", "left", self.SPACING, 0 )
					elseif self.MiddleButtonCreated
					then
						WindowAddAnchor( leftButtonName, "bottomleft", self.windowName, "bottomleft", self.LEFT_OFFSET, -self.BOTTOM_OFFSET )
					else
						WindowAddAnchor( leftButtonName, "bottomleft", self.windowName, "bottomleft", self.LEFT_OFFSET * 3, -self.BOTTOM_OFFSET )
					end
					
--					if pageNum == 1
--					then
--						WindowSetId( leftButtonName, pageObj.LeftButtonId )
--						ButtonSetText( leftButtonName, pageObj.LeftButtonText )
--					end
					
--					if pageNum ~= 1
--					and	not (self.Page[1].LeftButtonId and self.Page[1].LeftButtonText)
--					then
						WindowSetShowing( leftButtonName, false )
--					end
				end --]] Left button
				
				---[[ Right button
				local rightButtonName = self.windowName.."RightButton"--..pageNum
				
				if  pageObj.RightButtonId
				and pageObj.RightButtonText
				then
					CreateWindowFromTemplate( rightButtonName, "masterRightButton", self.windowName )
					WindowClearAnchors( rightButtonName )
					if self.CreatePrevNextButtons
					or self.CreateNextButton
					then
						WindowAddAnchor( rightButtonName, "left", self.windowName.."NextButton", "right", -self.SPACING, 0 )
					elseif self.MiddleButtonCreated
					then
						WindowAddAnchor( rightButtonName, "bottomright", self.windowName, "bottomright", -self.RIGHT_OFFSET, -self.BOTTOM_OFFSET )
					else
						WindowAddAnchor( rightButtonName, "bottomright", self.windowName, "bottomright", -self.RIGHT_OFFSET * 3, -self.BOTTOM_OFFSET )
					end
					
--					if pageNum == 1
--					then
--						WindowSetId( rightButtonName, pageObj.RightButtonId )
--						ButtonSetText( rightButtonName, pageObj.RightButtonText )
--					end
					
--					if  pageNum ~= 1
--					and	not (self.Page[1].RightButtonId and self.Page[1].RightButtonText)
--					then
						WindowSetShowing( rightButtonName, false )
--					end
				end --]] Right button
				
				if  maxBodyHeight < bodyContentHeight
				then
					maxBodyHeight = bodyContentHeight
				end
				
				if pageNum ~= 1
				then
					WindowSetShowing( bodyName, false )
				end
			end --]] the body
		end -- for
		
		local window_width, window_height
		
		if self.IsWide
		then
			window_width = self.WINDOW_WIDTH_WIDE
		else
			window_width = self.WINDOW_WIDTH_STANDARD
		end
		
		if self.IsShort
		or maxBodyHeight < self.WINDOW_HEIGHT_SHORT - self.TITLE_OFFSET - self.BOTTOM_OFFSET
		then
			window_height = self.WINDOW_HEIGHT_SHORT
		else
			window_height = self.WINDOW_HEIGHT_STANDARD
		end
		
		if self.IsStandardWidth
		then
			window_width = self.WINDOW_WIDTH_STANDARD
		end
		if self.IsStandardHeight
		then
			window_height = self.WINDOW_HEIGHT_STANDARD
		end
		
		WindowSetDimensions( self.windowName, window_width, window_height )
	end -- if
	self.StartPage = self.StartPage or 1
	if self.StartPage <= 0 then -- or self.StartPage > ##sizeof(## self.Pages ) then
		self.StartPage = 1
	end
	self:ShowPage( self.StartPage )
end

function MasterGUMP:fixup()

	-- fixup() is for changing/deleting anything you want after finalize is done
	-- In this example I have overwritten the leftbutton to use the MasterGUMP.SelectionPressed()
	-- This means it will broadcast a selection when pressed and use RadioId if its provided
	
	--[[ Example:
	-- 4 == OnLButtonUp
	WindowUnregisterEventHandler( self.windowName.."LeftButton", 4 )
	WindowRegisterEventHandler( self.windowName.."LeftButton", 4, "MasterGUMP.SelectionPressed" )
	--]]
end

function MasterGUMP.SelectionPressed()

	local self			= MasterGUMPManager.knownWindows[WindowUtils.GetActiveDialog()]
	local choiceName	= SystemData.ActiveWindow.name
	local choiceId		= tonumber( WindowGetId( choiceName ) )
	local radioId		= choiceId
	
	if not choiceId
	then
		UO_GenericGump.debug( L"MasterGUMP:SelectionPressed() choiceId = "..StringToWString( tostring( choiceId ) ) )
		return
	end
	
	if choiceId == self.HIGHLIGHT_BUTTON_ID
	or choiceId == self.HIGHLIGHT2_BUTTON_ID
	or choiceId == self.HIGHLIGHT3_BUTTON_ID
	or choiceId == self.DISABLED_BUTTON_ID
	or choiceId == self.DISABLED2_BUTTON_ID
	then
		return
	end
	
	if choiceId >= 0
	then
		self.CurrentPage = self.CurrentPage or 1
		
		if self.Page[self.CurrentPage].UseXButtons -- update the current selection but do not close gump
		then
			if not self.XButtonSelected
			then
				self.XButtonSelected = choiceName
				ButtonSetPressedFlag( self.XButtonSelected, true )
			else
				if self.XButtonSelected == choiceName -- unselect this button
				then
					ButtonSetPressedFlag( self.XButtonSelected, false )
					self.XButtonSelected = nil
				else -- unselect old button and select new button
					ButtonSetPressedFlag( self.XButtonSelected, false )
					self.XButtonSelected = choiceName
					ButtonSetPressedFlag( self.XButtonSelected, true )
				end
			end	
		else
			if self.Page[self.CurrentPage].RadioId -- close gump and send current selection
			then
				radioId = self.Page[self.CurrentPage].RadioId
			end

			UO_GenericGump.debug( L"MasterGUMP:SelectionPressed() radioId = "..radioId )
			UO_GenericGump.debug( L"MasterGUMP:SelectionPressed() choiceId = "..choiceId )

			UO_GenericGump.broadcastSelections( radioId, { choiceId }, self )
			self.OnCloseWindow()
		end
		return
	end
	
	-- ShowPage takes a positive pageNum, but choiceId is a negative
	self:ShowPage( -choiceId )
end

function MasterGUMP.LeftButtonPressed()

	MasterGUMP.LMRButtonPressed()
end

function MasterGUMP.MiddleButtonPressed()

	MasterGUMP.LMRButtonPressed()
end

function MasterGUMP.RightButtonPressed()

	MasterGUMP.LMRButtonPressed()
end

function MasterGUMP.LMRButtonPressed()

	local self		= MasterGUMPManager.knownWindows[WindowUtils.GetActiveDialog()]
	local choiceId	= WindowGetId( SystemData.ActiveWindow.name )
	
	if  choiceId
	and choiceId > -1
	then
		if self.XButtonSelected -- send the selection list
		then
			-- use this button ID as the radio ID, and send the x button ID as a list
			local radioId = choiceId
			choiceId = WindowGetId( self.XButtonSelected )

			UO_GenericGump.debug( L"MasterGUMP:LMRButtonPressed() radioId = "..radioId )
			UO_GenericGump.debug( L"MasterGUMP:LMRButtonPressed() choiceId = "..choiceId )

			UO_GenericGump.broadcastSelections( radioId, { choiceId }, self )
			self.OnCloseWindow()
		else -- send just this button ID
			UO_GenericGump.debug( L"MasterGUMP:LMRButtonPressed() choiceId = "..StringToWString( tostring( choiceId ) ) )
			UO_GenericGump.broadcastButtonPress( choiceId, self )
			self.OnCloseWindow()
		end
		return
	end
	
	-- ShowPage takes a positive pageNum, but choiceId is a negative
	self:ShowPage( -choiceId )
end

function MasterGUMP.PrevButtonPressed()

	MasterGUMP.PNButtonPressed()
end

function MasterGUMP.NextButtonPressed()

	MasterGUMP.PNButtonPressed()
end

function MasterGUMP.PNButtonPressed()

	local self = MasterGUMPManager.knownWindows[WindowUtils.GetActiveDialog()]
	
	if ButtonGetDisabledFlag( SystemData.ActiveWindow.name )
	then
		return
	end

	-- Prev/Nevt buttons have Ids of -1/1 respectively
	local direction		= WindowGetId( SystemData.ActiveWindow.name ) or 1
	self.CurrentPage	= self.CurrentPage or 1
	
	self:ShowPage( self.CurrentPage + direction )
end

-- Takes a positive page number
function MasterGUMP:ShowPage( pageNum )

	if not pageNum
	or pageNum < 0
	then
		pageNum = 1
	end

	UO_GenericGump.debug( L"MasterGUMP:ShowPage called for page #"..pageNum )

	if self.Page
	then
		-- Loop through all the pages
		for pageItr = 1, table.getn( self.Page )
		do
			-- Show/Hide the Body
			if getTableSize( self.Page[pageItr] )
			then
				WindowSetShowing( self.windowName.."Body"..(pageItr), pageItr == pageNum )
			end
			
			if( pageItr == pageNum )
			then
				-- Show/Hide the Title
				if self.Page[pageItr].Title
				then
					WindowUtils.SetActiveDialogTitle( self.Page[pageItr].Title )
				else
					WindowUtils.SetActiveDialogTitle( L" " )
				end
				
				-- If I have buttons for this page, set the Ids and Texts
				-- Otherwise disable and hide them
				if  self.Page[pageItr].MiddleButtonId
				and self.Page[pageItr].MiddleButtonText
				then
							WindowSetId( self.windowName.."MiddleButton", self.Page[pageItr].MiddleButtonId )
							ButtonSetText( self.windowName.."MiddleButton", self.Page[pageItr].MiddleButtonText )
					ButtonSetDisabledFlag( self.windowName.."MiddleButton", false )
					WindowSetShowing( self.windowName.."MiddleButton", true )
				elseif self.MiddleButtonCreated
				then 
					ButtonSetDisabledFlag( self.windowName.."MiddleButton", true )
					WindowSetShowing( self.windowName.."MiddleButton", false )
				end
				
				if  self.Page[pageItr].LeftButtonId
				and self.Page[pageItr].LeftButtonText
				then
							WindowSetId( self.windowName.."LeftButton", self.Page[pageItr].LeftButtonId )
							ButtonSetText( self.windowName.."LeftButton", self.Page[pageItr].LeftButtonText )
					ButtonSetDisabledFlag( self.windowName.."LeftButton", false )
					WindowSetShowing( self.windowName.."LeftButton", true )
				elseif self.LeftButtonCreated
				then
					ButtonSetDisabledFlag( self.windowName.."LeftButton", true )
					WindowSetShowing( self.windowName.."LeftButton", false )
				end
				
				if  self.Page[pageItr].RightButtonId
				and self.Page[pageItr].RightButtonText
				then
					WindowSetId( self.windowName.."RightButton", self.Page[pageItr].RightButtonId )
					ButtonSetText( self.windowName.."RightButton", self.Page[pageItr].RightButtonText )
					ButtonSetDisabledFlag( self.windowName.."RightButton", false )
					WindowSetShowing( self.windowName.."RightButton", true )
				elseif self.RightButtonCreated
				then
					ButtonSetDisabledFlag( self.windowName.."RightButton", true )
					WindowSetShowing( self.windowName.."RightButton", false )
				end
				
				-- Save my current page
				self.CurrentPage = pageItr
			end
		end
		
		self.CurrentPage = self.CurrentPage or 1
		
		-- If I have Prev/Next buttons, enable/disable them as appropriate
		if self.CreatePrevButton
		then
			if self.CurrentPage <= 1
			then
				ButtonSetDisabledFlag( self.windowName.."PrevButton", true )
			else
				ButtonSetDisabledFlag( self.windowName.."PrevButton", false )
			end
		end

		if self.CreateNextButton
		then
			if self.CurrentPage >= table.getn( self.Page )
			then
				ButtonSetDisabledFlag( self.windowName.."NextButton", true )
			else
				ButtonSetDisabledFlag( self.windowName.."NextButton", false )
			end
		end
	end
end

function MasterGUMP.OnMouseOver()

	local self = MasterGUMPManager.knownWindows[WindowUtils.GetActiveDialog()]
	local name = SystemData.ActiveWindow.name
	
--	UO_GenericGump.debug( L"MasterGUMP.OnMouseOver()1 called for "..StringToWString( tostring( name ) ) )
	
	if  self
	and self.Tooltips
	and self.Tooltips[name]
	and self.Tooltips[name] ~= L""
	then
		Tooltips.CreateTextOnlyTooltip( name, self.Tooltips[name] )
		Tooltips.Finalize()
		Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_TOP )
	end 
end

function MasterGUMP.Shutdown()
	UO_GenericGump.debug( L"MasterGUMP.Shutdown() called." )
	
	local self = MasterGUMPManager.knownWindows[WindowUtils.GetActiveDialog()]	
	if self == nil then
		UO_GenericGump.debug( StringToWString( "Shutdown hander called for "..SystemData.ActiveWindow.name.." but data already deleted" ) )
		return
	end	
	
	-- Delete any requested Tile Art
	if self.RequestedTileArt then
		for _, art in pairs( self.RequestedTileArt ) do
			ReleaseTileArt( art )
			--UO_GenericGump.debug( "MasterGUMP.Shutdown() released tile art = "..tostring( art ) )
		end
	end
	
	-- Delete any requested Textures
	if self.RequestedTextures then
		for _, art in pairs( self.RequestedTextures ) do
			ReleaseTexture( art )
			--UO_GenericGump.debug( "MasterGUMP.Shutdown() released texture = "..tostring( art ) )
		end
	end
	
	GGManager.unregisterActiveWindow()
end

function MasterGUMP.OnCloseWindow()
	UO_GenericGump.debug( L"MasterGUMP.OnCloseWindow() called." )
	
	GGManager.destroyActiveWindow( GGManager.DONT_DELETE_DATA_YET )
end

-- table.getn() only returns the sequencial index from 1 to n, not the negative ones as well
-- this function gets everything, non contigious numerics and string keys too
function getTableSize( table )

	local count = 0
	
	for _, _ in pairs( table )
	do
		count = count + 1
	end
	
	return count
end


-- dumpGUMP is a toString() for a table but
-- it does not recurse subtables
function dumpGUMP( gump, str )

	local str = str or L"Dumping GUMP = \n"

	for k, v in pairs( gump )
	do
		if type( v ) == "table"
		then
			---[[
			for i, val in pairs( v )
			do
				str = L"\t"..str..StringToWString( tostring( k ) )..L"["..StringToWString( tostring( i ) )..L"]"..L" = "..StringToWString( tostring( v[i] ) )..L"\n"
				str = L"\t"..str..StringToWString( tostring( k ) )..L"["..StringToWString( tostring( i ) )..L"]"..L" = "..StringToWString( tostring( val  ) )..L"\n"
			end --]]
--			str = dumpGUMP( v, str )
		else
			str = L"\t"..str..StringToWString( tostring( k ) )..L" = "..StringToWString( tostring( v ) )..L"\n"
		end
	end

	return str
end
