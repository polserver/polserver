----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

Recruit = TwoButtonDialog:new()

----------------------------------------------------------------
-- Recruit Functions
----------------------------------------------------------------

function Recruit:parseData()
	-- self.subtitle = L"" -- GGManager.translateTID( self.descData[5] )..L"   "..GGManager.translateTID( self.descData[6] )
	self.text = GGManager.translateTID( self.descData[1] )..L" "..self.stringData[1] -- GGManager.stripMarkup( self.stringData[1] )
	self.leftButtonName = GGManager.translateTID( GGManager.OKAY_TID )
	self.rightButtonName = GGManager.translateTID( GGManager.CANCEL_TID )		
	self.leftButtonID = self.buttonIDs[2]
	self.rightButtonID = self.buttonIDs[1]
end

-- OnInitialize Handler
function Recruit.Initialize()
	local newWindow = Recruit:new()
	newWindow.setDataFunction = Recruit.parseData
	newWindow:Init()
end
