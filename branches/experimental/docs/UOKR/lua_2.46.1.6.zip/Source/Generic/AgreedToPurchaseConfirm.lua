----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

AgreedToPurchaseConfirm = TwoButtonDialog:new()

----------------------------------------------------------------
-- AgreedToPurchaseConfirm Functions
----------------------------------------------------------------

function AgreedToPurchaseConfirm:parseData()
	if  self.descData[5] then
		self.text = GGManager.translateTID( self.descData[1] )..L"\n"..GGManager.translateTID( self.descData[5] )..L"\n\n"..
					GGManager.translateTID( self.descData[2] )..L"\n"..self.stringData[2]
	else
		self.text = GGManager.translateTID( self.descData[1] )..L"\n"..self.stringData[1]..L"\n\n"..
					GGManager.translateTID( self.descData[2] )..L"\n"..self.stringData[2]
	end
	self.leftButtonName = GGManager.translateTID( self.descData[4] )
	self.rightButtonName = GGManager.translateTID( self.descData[3] )	
	self.leftButtonID = self.buttonIDs[2]
	self.rightButtonID = self.buttonIDs[1]
end

-- OnInitialize Handler
function AgreedToPurchaseConfirm.Initialize()
	local newWindow = AgreedToPurchaseConfirm:new()
	newWindow.setDataFunction = AgreedToPurchaseConfirm.parseData
	newWindow:Init()
end
