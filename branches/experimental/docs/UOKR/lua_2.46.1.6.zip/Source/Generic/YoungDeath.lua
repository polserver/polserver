----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

YoungDeath = OneButtonDialog:new()

----------------------------------------------------------------
-- YoungDeath Functions
----------------------------------------------------------------

function YoungDeath:setDataFunction()
--function YoungDeath.setDataFunction(self)
    UO_GenericGump.debug( L"called YoungDeath:setDataFunction()" )
    
	self.title = GGManager.translateTID (self.descData[1])
	self.text = GGManager.translateTID (self.descData[2])
	
	for i = 3, self.descDataCount do
		self.text = self.text..L"\n\n"..GGManager.translateTID (self.descData[i])
	end
		
	self.buttonName = GGManager.translateTID(GGManager.OKAY_TID)
	self.buttonID = self.buttonIDs[1]

	UO_GenericGump.debug( L"finished YoungDeath:setDataFunction()" )
end

-- OnInitialize Handler
function YoungDeath.Initialize()
	local newWindow = YoungDeath:new()
	newWindow.setDataFunction = YoungDeath.setDataFunction
	newWindow:Init()
end