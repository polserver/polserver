----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

FlipFlop = ChoiceList:new()

----------------------------------------------------------------
-- FlipFlop Functions
----------------------------------------------------------------

function FlipFlop:setDataFunction()

	-- not wide
	local isWide = false
	-- scrolls if needed
	local relativeWindow = self.windowName.."ScrollChild"
	
	-- Choice 1
	relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
		self.buttonIDs[1], GGManager.translateTID( self.descData[1] ),
		"top", relativeWindow, "top", 0, 0, isWide )
	-- Choice 2
	relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
		self.buttonIDs[2], GGManager.translateTID( self.descData[2] ),
		"bottomleft", relativeWindow, "topleft", 0, 0, isWide )
	-- Choice 3
	relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
		self.buttonIDs[3], GGManager.translateTID( self.descData[3] ),
		"bottomleft", relativeWindow, "topleft", 0, 0, isWide )
	
end -- Soulstone:setDataFunction()

-- Standard OnInitialize Handler
function FlipFlop.Initialize()
	local newWindow = FlipFlop:new()
	newWindow.setDataFunction = FlipFlop.setDataFunction
	newWindow:Init()
end
