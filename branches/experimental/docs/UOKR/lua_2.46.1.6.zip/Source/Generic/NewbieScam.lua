----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

NewbieScam = OneButtonDialog:new()

----------------------------------------------------------------
-- NewbieScam Functions
----------------------------------------------------------------


function NewbieScam:setDataFunction()
	self.text = GGManager.translateTID(self.descData[1])
	self.buttonName = GGManager.translateTID(GGManager.OKAY_TID)
	self.buttonID = 0
end


-- OnInitialize Handler
function NewbieScam.Initialize()
	local NewWindow = NewbieScam:new()
	NewWindow:Init()
end