
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

StabledPets = ChoiceList:new{}


----------------------------------------------------------------
-- StabledPets Functions
----------------------------------------------------------------


function StabledPets:setDataFunction()
	
	if self.stringData then

		relativeWindow = ChoiceList.CreateSubtitle( self, GGManager.stripMarkup( self.stringData[1] ) )
	
		-- note: don't iterate through the stringData table itself
		for choiceNum=1, self.stringDataCount - 1 do
			relativeWindow = ChoiceList.CreateChoiceListSelectableText( self,
					choiceNum, GGManager.stripMarkup( self.stringData[choiceNum+1] ),
					"bottom", relativeWindow, "top", 0, 10 )
		end
	end  -- if stringData

end

	

-- OnInitialize Handler
function StabledPets.Initialize()
	StabledPets:new():Init()
end
