----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

ExpiredVendorReclaim = ChoiceList:new()

----------------------------------------------------------------
-- ExpiredVendorReclaim Functions
----------------------------------------------------------------

--[[ TODO:	This function currently concatenates several pieces of data into one string, to be used as a label for
			CreateChoiceListSelectableText. Ideally, the time data should be separated into a separate column.
--]]
function ExpiredVendorReclaim:setDataFunction()
	UO_GenericGump.debug( L"ExpiredVendorReclaim:setDataFunction - setting data for = "..self.name )

	local isWide = true -- using ChoiceListSelectableText_Wide XML template
	self.title = GGManager.translateTID( self.descData[1] )
	WindowUtils.SetActiveDialogTitle( self.title )
	
	-- first choice anchors to top of ScrollChild. others below will anchor to this one.
	local relativeWindow = self.windowName.."ScrollChild"
	relativeWindow = ExpiredVendorReclaim.CreateChoiceListSelectableText( self, self.buttonIDs[3], self.stringData[1]
							..L" - "..GGManager.translateTID( self.descData[2] )..L": "..self.stringData[2]..L" "
							..GGManager.translateTID( self.descData[3] ), "topleft", relativeWindow, "topleft", 0, 0, isWide )
					
	--[[ the data format from the wombat script is complicated
		 for a given choice n, the corresponding data is as follows:
		 button ID is					self.buttonIDs[ n + 2(15 mod n) ] (other buttons IDs are set to 0, used in old client to switch pages)
		 vendor name is					self.stringData[ 2n - 1 ]
		 vendor expire time is			self.stringData[ 2n ]
		 time unit (e.g., "hour(s)") is	self.descData[ n + 2 ]
	--]]
	-- these are used to calculate which data to use
	local PAGELENGTH = 15
	local pagePosition = 1
	local offset = 0
	local buttonIndex, stringIndex, descIndex
	for descIndex = 4, self.descDataCount do
		buttonIndex = descIndex + offset
		stringIndex = descIndex + descIndex - 4
		pagePosition = pagePosition + 1
		if pagePosition == PAGELENGTH then
			offset = offset + 2
			pagePosition = 0
		end
		relativeWindow = ExpiredVendorReclaim.CreateChoiceListSelectableText( self, self.buttonIDs[buttonIndex], self.stringData[stringIndex - 1]
						..L" - "..GGManager.translateTID( self.descData[2] )..L": "..self.stringData[stringIndex]..L" "
						..GGManager.translateTID( self.descData[descIndex] ), "bottom",	relativeWindow, "top", 0, 10, isWide )
	end
end

-- OnInitialize Handler
function ExpiredVendorReclaim.Initialize()
	local newWindow = ExpiredVendorReclaim:new()
	newWindow.setDataFunction = ExpiredVendorReclaim.setDataFunction
	newWindow:Init()
end