----------------------------------------------------------
-- FactionSheriff.lua
----------------------------------------------------------------

FactionSheriff = MasterGUMP:new()

function FactionSheriff.Initialize()

	local newWindow					= FactionSheriff:new()
	newWindow.setData				= FactionSheriff.setDataFunc
	newWindow:Init()
end

function FactionSheriff:setDataFunc()

	-- Main Page
	self.Page[1] = {}
	
	self.Page[1].Subtitle = GGManager.translateTID( self.descData[1] )

	self.Page[1].Selections = {}
	
	self.Page[1].Selections[1]			= {}
	self.Page[1].Selections[1].Id		= self.buttonIDs[1]
	self.Page[1].Selections[1].Text		= GGManager.translateTID( self.descData[2] )
	
	self.Page[1].Selections[2]			= {}
	self.Page[1].Selections[2].Id		= self.buttonIDs[2]
	self.Page[1].Selections[2].Text		= GGManager.translateTID( self.descData[3] )
	
	self.Page[1].MiddleButtonId			= self.buttonIDs[3]
	self.Page[1].MiddleButtonText		= GGManager.translateTID( self.descData[4] )
	
	-- Finance
	self.Page[2] = {}
	
	local dscItr = self.descPageIndex[3]
	local strItr = self.stringPageIndex[3]
	local btnItr = self.buttonPageIndex[3]

	self.Page[2].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[2].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[strItr + 0]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[strItr + 1]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[strItr + 2]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[strItr + 3]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[strItr + 4]
	
	self.Page[2].MiddleButtonId		= self.buttonIDs[btnItr]
	self.Page[2].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Hire Guards page
	self.Page[3] = {}
	
	local dscItr	= self.descPageIndex[4]
	local dscItrEnd	= self.descPageIndex[5]
	local imgItr	= self.ImagePageIndex[4]
	local btnItr	= self.buttonPageIndex[4]

	self.Page[3].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[3].Selections = {}
	
	local index = 1
	while dscItr < dscItrEnd - 1
	do
		self.Page[3].Selections[index]		= {}
		self.Page[3].Selections[index].Id	= self.buttonIDs[btnItr]
		self.Page[3].Selections[index].Text	= GGManager.translateTID( self.descData[dscItr] )
		self.Page[3].Selections[index].Icon	= self.ImageNum[imgItr]
		
		index	= index  + 1
		btnItr	= btnItr + 1
		dscItr	= dscItr + 1
		imgItr	= imgItr + 1
	end
	
	self.Page[3].MiddleButtonId		= self.buttonIDs[btnItr]
	self.Page[3].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Left out of Wombat
	self.Page[4] = {}
	
	-- Henchman page
	self.Page[5] = {}
	
	local dscItr	= self.descPageIndex[5]
	local strItr	= self.stringPageIndex[5]
	local btnItr	= self.buttonPageIndex[5]
	
	self.Page[5].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[5].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[6]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[26]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[20]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[24]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[1]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[16]
	dscItr = dscItr + 6

	self.Page[5].Selections			= {}
	self.Page[5].Selections[1]		= {}
	self.Page[5].Selections[1].Id	= self.buttonIDs[btnItr]
	self.Page[5].Selections[1].Text	= GGManager.translateTID( self.descData[dscItr] )
	btnItr = btnItr + 1

	self.Page[5].MiddleButtonId		= self.buttonIDs[btnItr]
	self.Page[5].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Merc page
	self.Page[6] = {}
	
	local dscItr	= self.descPageIndex[6]
	local strItr	= self.stringPageIndex[6]
	local btnItr	= self.buttonPageIndex[6]
	
	self.Page[6].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[6].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[7]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[26]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[19]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[23]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[1]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[16]
	dscItr = dscItr + 6

	self.Page[6].Selections			= {}
	self.Page[6].Selections[1]		= {}
	self.Page[6].Selections[1].Id	= self.buttonIDs[btnItr]
	self.Page[6].Selections[1].Text	= GGManager.translateTID( self.descData[dscItr] )
	btnItr = btnItr + 1

	self.Page[6].MiddleButtonId		= self.buttonIDs[btnItr]
	self.Page[6].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Berserker page
	self.Page[7] = {}
	
	local dscItr	= self.descPageIndex[7]
	local strItr	= self.stringPageIndex[7]
	local btnItr	= self.buttonPageIndex[7]
	
	self.Page[7].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[7].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[8]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[26]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[18]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[22]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[1]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[16]
	dscItr = dscItr + 6

	self.Page[7].Selections			= {}
	self.Page[7].Selections[1]		= {}
	self.Page[7].Selections[1].Id	= self.buttonIDs[btnItr]
	self.Page[7].Selections[1].Text	= GGManager.translateTID( self.descData[dscItr] )
	btnItr = btnItr + 1

	self.Page[7].MiddleButtonId		= self.buttonIDs[btnItr]
	self.Page[7].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Dragoon page
	self.Page[8] = {}
	
	local dscItr	= self.descPageIndex[8]
	local strItr	= self.stringPageIndex[8]
	local btnItr	= self.buttonPageIndex[8]
	
	self.Page[8].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[8].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[9]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[26]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[17]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[21]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[1]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[16]
	dscItr = dscItr + 6

	self.Page[8].Selections			= {}
	self.Page[8].Selections[1]		= {}
	self.Page[8].Selections[1].Id	= self.buttonIDs[btnItr]
	self.Page[8].Selections[1].Text	= GGManager.translateTID( self.descData[dscItr] )
	btnItr = btnItr + 1

	self.Page[8].MiddleButtonId		= self.buttonIDs[btnItr]
	self.Page[8].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Sorceress page
	self.Page[9] = {}
	
	local dscItr	= self.descPageIndex[9]
	local strItr	= self.stringPageIndex[9]
	local btnItr	= self.buttonPageIndex[9]
	
	self.Page[9].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[9].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[10]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[26]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[18]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[22]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[1]..L"\n\n"
							..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[16]
	dscItr = dscItr + 6

	self.Page[9].Selections			= {}
	self.Page[9].Selections[1]		= {}
	self.Page[9].Selections[1].Id	= self.buttonIDs[btnItr]
	self.Page[9].Selections[1].Text	= GGManager.translateTID( self.descData[dscItr] )
	btnItr = btnItr + 1

	self.Page[9].MiddleButtonId		= self.buttonIDs[btnItr]
	self.Page[9].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Elder Wizard page
	self.Page[10] = {}
	
	local dscItr	= self.descPageIndex[10]
	local strItr	= self.stringPageIndex[10]
	local btnItr	= self.buttonPageIndex[10]
	
	self.Page[10].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[10].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[11]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[26]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[17]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[21]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[1]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[16]
	dscItr = dscItr + 6

	self.Page[10].Selections			= {}
	self.Page[10].Selections[1]			= {}
	self.Page[10].Selections[1].Id		= self.buttonIDs[btnItr]
	self.Page[10].Selections[1].Text	= GGManager.translateTID( self.descData[dscItr] )
	btnItr = btnItr + 1

	self.Page[10].MiddleButtonId	= self.buttonIDs[btnItr]
	self.Page[10].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Knight page
	self.Page[11] = {}
	
	local dscItr	= self.descPageIndex[11]
	local strItr	= self.stringPageIndex[11]
	local btnItr	= self.buttonPageIndex[11]
	
	self.Page[11].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[11].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[12]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[26]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[18]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[22]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[1]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[16]
	dscItr = dscItr + 6

	self.Page[11].Selections			= {}
	self.Page[11].Selections[1]			= {}
	self.Page[11].Selections[1].Id		= self.buttonIDs[btnItr]
	self.Page[11].Selections[1].Text	= GGManager.translateTID( self.descData[dscItr] )
	btnItr = btnItr + 1

	self.Page[11].MiddleButtonId	= self.buttonIDs[btnItr]
	self.Page[11].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Paladin page
	self.Page[12] = {}
	
	local dscItr	= self.descPageIndex[12]
	local strItr	= self.stringPageIndex[12]
	local btnItr	= self.buttonPageIndex[12]
	
	self.Page[12].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[12].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[13]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[26]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[17]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[21]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[1]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[16]
	dscItr = dscItr + 6

	self.Page[12].Selections			= {}
	self.Page[12].Selections[1]			= {}
	self.Page[12].Selections[1].Id		= self.buttonIDs[btnItr]
	self.Page[12].Selections[1].Text	= GGManager.translateTID( self.descData[dscItr] )
	btnItr = btnItr + 1

	self.Page[12].MiddleButtonId	= self.buttonIDs[btnItr]
	self.Page[12].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Death Knight page
	self.Page[13] = {}
	
	local dscItr	= self.descPageIndex[13]
	local strItr	= self.stringPageIndex[13]
	local btnItr	= self.buttonPageIndex[13]
	
	self.Page[13].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[13].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[14]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[26]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[18]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[22]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[1]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[16]
	dscItr = dscItr + 6

	self.Page[13].Selections			= {}
	self.Page[13].Selections[1]			= {}
	self.Page[13].Selections[1].Id		= self.buttonIDs[btnItr]
	self.Page[13].Selections[1].Text	= GGManager.translateTID( self.descData[dscItr] )
	btnItr = btnItr + 1

	self.Page[13].MiddleButtonId	= self.buttonIDs[btnItr]
	self.Page[13].MiddleButtonText	= GGManager.translateTID( 1011393 )
	
	-- Necromancer page
	self.Page[14] = {}
	
	local dscItr	= self.descPageIndex[14]
	local strItr	= self.stringPageIndex[14]
	local btnItr	= self.buttonPageIndex[14]
	
	self.Page[14].Subtitle = GGManager.translateTID( self.descData[dscItr] )
	dscItr = dscItr + 1
	
	self.Page[13].ScrollText	= GGManager.translateTID( self.descData[dscItr + 0] )..L" "..self.stringData[15]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 1] )..L" "..self.stringData[26]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 2] )..L" "..self.stringData[17]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 3] )..L" "..self.stringData[21]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 4] )..L" "..self.stringData[1]..L"\n\n"
								..GGManager.translateTID( self.descData[dscItr + 5] )..L" "..self.stringData[16]
	dscItr = dscItr + 6

	self.Page[14].Selections			= {}
	self.Page[14].Selections[1]			= {}
	self.Page[14].Selections[1].Id		= self.buttonIDs[btnItr]
	self.Page[14].Selections[1].Text	= GGManager.translateTID( self.descData[dscItr] )
	btnItr = btnItr + 1

	self.Page[14].MiddleButtonId	= self.buttonIDs[btnItr]
	self.Page[14].MiddleButtonText	= GGManager.translateTID( 1011393 )
end
