
----------------------------------------------------------------
-- FactionVote.lua
----------------------------------------------------------------

FactionVote = MasterGUMP:new()

function FactionVote.Initialize()

	local newWindow		= FactionVote:new()
	newWindow.setData	= FactionVote.setDataFunc
	newWindow:Init()
end

function FactionVote:setDataFunc()

	self.IsStandardHeight = true

	self.Page[1] = {}
	
	self.Page[1].Subtitle	= GGManager.translateTID( self.descData[1] )..L"\n\n"
							..GGManager.translateTID( self.descData[3] )
	self.Page[1].SubtitleHL	= true

	self.Page[1].MiddleButtonId		= self.buttonIDs[1]
	self.Page[1].MiddleButtonText	= GGManager.translateTID( self.descData[2] )

	self.Page[1].Selections = {}
	
	if self.buttonCount == 1
	then
		self.Page[1].Selections[1] = {}
		self.Page[1].Selections[1].Id	= self.DISABLED2_BUTTON_ID
		self.Page[1].Selections[1].Text	= GGManager.translateTID( 3000340 )
		
		return	-- EARLY OUT
	end

	local index = 1
	for i = 2, self.buttonCount do
								
		self.Page[1].Selections[index]		= {}
		self.Page[1].Selections[index].Id	= self.buttonIDs[i]
		self.Page[1].Selections[index].Text	= self.stringData[(i - 1) * 2]..L" ("..self.stringData[(i - 1) * 2 + 1]..L")"
		index = index + 1
	end
end
