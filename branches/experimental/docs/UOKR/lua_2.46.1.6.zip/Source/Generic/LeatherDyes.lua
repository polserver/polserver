
----------------------------------------------------------------
-- LeatherDyes
----------------------------------------------------------------

LeatherDyes = { }

LeatherDyesManager = GGManager


-- OnInitialize Handler
function LeatherDyes.Initialize()

	local dyes = LeatherDyes:new()
	dyes:Init()
end

function LeatherDyes:new( dyes )

	dyes = dyes or {}
	setmetatable( dyes, self )
	self.__index = self
	
	dyes.rightChildren = {}

	return dyes
end

function LeatherDyes:Init()
		
	if not UO_GenericGump.retrieveWindowData( self ) then
		return false
	end
	
	if self.setDataFunction then
		self:setDataFunction()
	end

	if self.setFields then
		self:setFields()
	end
	
	LeatherDyesManager.knownWindows[self.windowName] = self
	Interface.OnCloseCallBack[self.windowName] = self.OnCloseWindow
end


function LeatherDyes:setDataFunction()

	--Default button
	local buttonName = self.windowName.."LeftButton"
	ButtonSetText( buttonName, GGManager.translateTID( 3000094 ) )
	WindowSetId( buttonName, -66 )

	--Cancel button
	local buttonName = self.windowName.."RightButton"
	ButtonSetText( buttonName, GGManager.translateTID( GGManager.CANCEL_TID ) )
	WindowSetId( buttonName, 0 )
	
	-- Page 0 = "Left Page"
	relativeWindow = self.windowName.."ScrollChild"
	
	local descItr		= self.buttonPageIndex[1]+1  -- Skip over buttons' labels and Subject
	local descItrEnd	= self.buttonPageIndex[2]-2
		
	local pageItr		= -1
	
	relativeWindow = LeatherDyes:CreateSelectableText1( pageItr, GGManager.translateTID( self.descData[descItr] ), "top", relativeWindow, "top", 0, 10 )
	pageItr = pageItr - 1
	
	for descItr = descItr + 1, descItrEnd do
		relativeWindow = LeatherDyes:CreateSelectableText1( pageItr, GGManager.translateTID( self.descData[descItr] ), "bottom", relativeWindow, "top", 0, 10 )
		pageItr = pageItr - 1
	end

	-- Page 1+ = right side pages
	pageItr = -1
	
	local uniqueID = 1
	
	for page = 2, table.getn( self.buttonPageIndex ) do
	
		local descItr		= self.buttonPageIndex[page]
		local descItrEnd	= self.buttonCount
		
		if page < table.getn( self.buttonPageIndex ) then
			descItrEnd	= self.buttonPageIndex[page + 1] - 1
		end
		
		buttonItr = self.buttonPageIndex[page]
		
		local rightScroll		= self.windowName.."Scroll"..page
		local rightScrollChild	= rightScroll.."Child"

		CreateWindowFromTemplate( rightScroll,	"LeatherDyesRightScroll", self.windowName )
		WindowAddAnchor( rightScroll, "bottom", self.windowName.."Subtitle", "top", 0, 10 )
		
		UO_GenericGump.debug( L"LeatherDyes:SetDataFunction() Hues = "..self.buttonIDs[buttonItr]..L"  buttonItr = "..buttonItr )
		
		relativeWindow = LeatherDyes:CreateSelectableText2( self.buttonIDs[buttonItr],  L"     ",  "top", rightScrollChild, "top", 0, 10, page, true )
		buttonItr = buttonItr + 1

		for descItr = descItr + 1, descItrEnd do
			UO_GenericGump.debug( L"Hues = "..self.buttonIDs[buttonItr]..L"  buttonItr = "..buttonItr)
			relativeWindow = LeatherDyes:CreateSelectableText2( self.buttonIDs[buttonItr], L"     " , "bottom", relativeWindow, "top", 0, 10, page, true, uniqueID )
			buttonItr = buttonItr + 1
			uniqueID = uniqueID + 1
		end
	
		WindowSetShowing( rightScroll, false )
		self.rightChildren[pageItr] = rightScroll
		pageItr = pageItr - 1
	end
end	

function LeatherDyes:CreateSelectableText1( choiceNum, wText, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset, myPage, isRight )

	local windowName	= WindowUtils.GetActiveDialog()
	local choiceName	= windowName.."Choice"..choiceNum
	local parentName	= windowName.."ScrollChild"
	
	
	if isRight then
		parentName	= windowName.."Scroll"..myPage.."Child"
	end
	
	if	myPage
	and myPage ~= ""
	and not isRight then
		parentName	= parentName..myPage
	end
	
	CreateWindowFromTemplate( choiceName, "LeatherDyesSelectable", parentName )
	WindowAddAnchor( choiceName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	WindowSetId( choiceName, choiceNum )
	LabelSetText( choiceName.."Text" , wText )
		
	return choiceName
end

function LeatherDyes:CreateSelectableText2( choiceNum, wText, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset, myPage, isRight, uniqueID )

	local windowName	= WindowUtils.GetActiveDialog()
	local choiceName	= windowName.."Choice"..choiceNum

	if uniqueID then
		choiceName = windowName.."Choice"..choiceNum.."Unique"..uniqueID
	end

	local parentName	= windowName.."ScrollChild"
	
	if isRight then
		parentName	= windowName.."Scroll"..myPage.."Child"
	end
	
	if	myPage
	and myPage ~= ""
	and not isRight then
		parentName = parentName..myPage
	end
		
	CreateWindowFromTemplate( choiceName, "LeatherDyesSelectable2", parentName )
	WindowAddAnchor( choiceName, anchorPoint, relativeToow, relativeToPoint, xOffset, yOffset )
	WindowSetId( choiceName, choiceNum )
	LabelSetText( choiceName.."Text" , wText )
	
	local r, g, b, a = HueRGBAValue( choiceNum)
	WindowSetTintColor( choiceName.."Icon", r, g, b )
	
	return choiceName
end

function LeatherDyes.TextPressed()

	local self = LeatherDyesManager.knownWindows[WindowUtils.GetActiveDialog()]
	self:TextSelected()
end

function LeatherDyes:TextSelected()

	local choiceNum = WindowGetId( SystemData.ActiveWindow.name )
	UO_GenericGump.debug( L"LeatherDyes:TextSelected() choiceNum = "..choiceNum )

	if choiceNum == 0 then -- cancel button
		UO_GenericGump.broadcastSelections( 0, { }, self )
		self.OnCloseWindow()
		return
	end
	
	if choiceNum > 0 then -- dye selection
		UO_GenericGump.broadcastSelections( self.buttonIDs[1], { choiceNum }, self )
		self.OnCloseWindow()
		return
	end
	
	if choiceNum == -66 then -- default button
		UO_GenericGump.broadcastSelections( self.buttonIDs[2], { }, self )
		self.OnCloseWindow()
		return
	end

	local pageItr = -1
	local pageItrEnd = -LeatherDyes.getTableSize( self.rightChildren )
	
	while pageItr >= pageItrEnd do
		WindowSetShowing( self.rightChildren[pageItr], (pageItr == choiceNum) )
		pageItr = pageItr - 1
	end
end

function LeatherDyes.OnCloseWindow()
	UO_GenericGump.debug( L"LeatherDyes.OnCloseWindow() called." )

	GGManager.destroyActiveWindow()
end

function LeatherDyes.getTableSize( table )

	local count = 0
	
	for _, _ in pairs( table ) do
		count = count + 1
	end
	
	return count
end
