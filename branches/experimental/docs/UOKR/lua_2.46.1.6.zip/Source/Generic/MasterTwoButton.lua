----------------------------------------------------------------
-- MasterTwoButton.lua
----------------------------------------------------------------

MasterTwoButton = MasterGUMP:new()

function MasterTwoButton.Initialize()

	local newWindow					= MasterTwoButton:new()
	newWindow.setData				= MasterTwoButton.setDataFunc
	newWindow:Init()
end

-- Data expected in the self.Page[1] is buttonIDs[1] and buttonIDs[2] (for the two button return values)
--   and from 1 to 5 descData[]
--   if descDataCount = 5 - descData[1] is title, descData[2] is subtitle, descData[3] is text, descData[4] and descData[5] are button labels
--   if descDataCount = 4 - descData[1] is title, descData[2] is text, descData[3] and descData[4] are button labels
--   if descDataCount = 3 - descData[1] is text, descData[2] and descData[3] are button labels
--   if descDataCount = 2 - descData[1] and descData[2] are text, button labels are set to OK and Cancel
--   if descDataCount = 1 - descData[1] is text, button labels are set to OK and Cancel
--
-- With descDataCount 1 or 2, we must make sure that the buttonIDs sent from the server sends the
--   Cancel button last 
--
function MasterTwoButton:setDataFunc()

	UO_GenericGump.debug( L"MasterTwoButton:setDataFunc() - setting data for = "..self.name )
	
	self.Page[1] = {}
	
	if self.descDataCount > 4
	then
		MasterTwoButton.parseTitleSubtitleText( self )
	elseif self.descDataCount > 3
	then
		MasterTwoButton.parseTitleText( self )
	elseif self.descDataCount > 2
	then
		MasterTwoButton.parseText( self )
	else
		MasterTwoButton.parseTextNoButtons( self )
	end
end

function MasterTwoButton:parseTextNoButtons()

	self.Page[1].ScrollText = GGManager.translateTID( self.descData[1] )

	for dscItr = 2, self.descDataCount
	do
		self.Page[1].ScrollText = self.Page[1].ScrollText..L"\n\n"..GGManager.translateTID( self.descData[dscItr] )
	end 

	self.Page[1].LeftButtonId	= self.buttonIDs[1]
	self.Page[1].LeftButtonText	= GGManager.translateTID( GGManager.OKAY_TID )

	self.Page[1].RightButtonId		= self.buttonIDs[2]
	self.Page[1].RightButtonText	= GGManager.translateTID( GGManager.CANCEL_TID )
end

function MasterTwoButton:parseText()

	self.Page[1].ScrollText = GGManager.translateTID( self.descData[1] )

	self.Page[1].LeftButtonId		= self.buttonIDs[1]
	self.Page[1].LeftButtonText		= GGManager.translateTID( self.descData[2] )
	self.Page[1].RightButtonId		= self.buttonIDs[2]
	self.Page[1].RightButtonText	= GGManager.translateTID( self.descData[3] )
end

function MasterTwoButton:parseTitleText()

	self.Page[1].Title		= GGManager.translateTID( self.descData[1] )
	self.Page[1].ScrollText	= GGManager.translateTID( self.descData[2] )
	
	self.Page[1].LeftButtonId		= self.buttonIDs[1]
	self.Page[1].LeftButtonText		= GGManager.translateTID( self.descData[3] )
	self.Page[1].RightButtonId		= self.buttonIDs[2]
	self.Page[1].RightButtonText	= GGManager.translateTID( self.descData[4] )
end

function MasterTwoButton:parseSubtitleText()

	self.Page[1].Subtitle	= GGManager.translateTID( self.descData[1] )
	self.Page[1].ScrollText	= GGManager.translateTID( self.descData[2] )
	
	self.Page[1].LeftButtonId		= self.buttonIDs[1]
	self.Page[1].LeftButtonText		= GGManager.translateTID( self.descData[3] )
	self.Page[1].RightButtonId		= self.buttonIDs[2]
	self.Page[1].RightButtonText	= GGManager.translateTID( self.descData[4] )
end

function MasterTwoButton:parseTitleSubtitleText()

	self.Page[1].Title		= GGManager.translateTID( self.descData[1] )
	self.Page[1].Subtitle	= GGManager.translateTID( self.descData[2] )
	self.Page[1].ScrollText	= GGManager.translateTID( self.descData[3] )
	
	self.Page[1].LeftButtonId		= self.buttonIDs[1]
	self.Page[1].LeftButtonText		= GGManager.translateTID( self.descData[4] )
	self.Page[1].RightButtonId		= self.buttonIDs[2]
	self.Page[1].RightButtonText	= GGManager.translateTID( self.descData[5] )
end
