---------------------------------------------------------------------------
-- ChoiceButtons.lua
--
-- This used to be a template modified from the ChoiceList template.
-- Now it is just a wrapper for MasterGUMP, used for a few existing gumps.
---------------------------------------------------------------------------

ChoiceButtons = MasterGUMP:new()

function ChoiceButtons.Initialize()
	local newWindow					= ChoiceButtons:new()
	newWindow:Init()
end

-- this function is overridden by some gumps
function ChoiceButtons:setDataFunction()
	self.actionID = self.buttonIDs[self.buttonCount]
	local buttonCount = self.buttonCount - 1

	self.buttonName = {}
	for i=1, buttonCount do
		-- the last buttonCount of descData are the choice labels
		local textIndex =( self.descDataCount - buttonCount ) + i 
		self.buttonName[i] = GGManager.translateTID( self.descData[textIndex] )
	end
	
	if ( self.descDataCount - buttonCount ) == 1 then
		self.text = GGManager.translateTID( self.descData[1] )
		
	elseif ( self.descDataCount - buttonCount ) == 2 then
		self.title = GGManager.translateTID( self.descData[1] )
		self.text = GGManager.translateTID( self.descData[2] )
		
	elseif ( self.descDataCount - buttonCount ) > 2 then
		self.title = GGManager.translateTID( self.descData[1] )
		self.subtitle = GGManager.translateTID( self.descData[2] )
		self.text = GGManager.translateTID( self.descData[3] )	
	end
end

-- this translates the data to the MasterGUMP format	
function ChoiceButtons:setData()
	UO_GenericGump.debug( L"ChoiceButtons:setData - setting data for = "..self.name )
	self.IsStandardHeight = true
	self:setDataFunction()
	
	-- Some gumps subtract 1 from self.buttonCount, which will cause problems in MasterGUMP. This resets it.
	if self.buttonIDs[self.buttonCount + 1] ~= nil then
		self.buttonCount = self.buttonCount + 1
	end

	self.Page				= {}
	self.Page[1]			= {}
	self.Page[1].Title		= self.title
	self.Page[1].Subtitle	= self.subtitle
	self.Page[1].ScrollText	= self.text
	self.Page[1].RadioId	= self.actionID
	self.Page[1].Selections	= {}

	for i = 1, self.buttonCount - 1 do
		self.Page[1].Selections[i]			= {}
		self.Page[1].Selections[i].Id		= self.buttonIDs[i]
		self.Page[1].Selections[i].Text		= self.buttonName[i]
		self.Page[1].Selections[i].Bottom	= true
	end
end
