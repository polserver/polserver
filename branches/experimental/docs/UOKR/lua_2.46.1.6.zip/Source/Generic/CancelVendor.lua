----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

CancelVendor = TwoButtonDialog:new()

--CancelVendor.spacer = UO_GenericGump.EMPTY_LINE..L"\n"

----------------------------------------------------------------
-- CancelVendor Functions
----------------------------------------------------------------

function CancelVendor:parseData()
	
	--UO_GenericGump.debug( L"parseDescAsTitleTextAndTwoButtons - setting data for = "..self.name )
	--self.title = --GGManager.translateTID( -- put title TID here )
	--self.subtitle = GGManager.translateTID( -- put subtitle TID here )
	self.text = GGManager.translateTID( self.descData[1] )..L"\n\n"
	    ..GGManager.translateTID( self.descData[2] )..L" "..self.stringData[1]..L"\n"
		..GGManager.translateTID( self.descData[3] )..L" "..self.stringData[2]..L"\n"
		..GGManager.translateTID( self.descData[4] )..L" "..self.stringData[3]..L"\n\n"
		..GGManager.translateTID( 1078054 ) -- "Press OKAY to dismiss vendor<br>Press CANCEL to keep vendor" 
	self.leftButtonName = GGManager.translateTID( 1011036 ) -- "OKAY"
	self.rightButtonName = GGManager.translateTID( 1011012 ) -- "CANCEL" 
	
	self.leftButtonID = self.buttonIDs[1]
	self.rightButtonID = self.buttonIDs[2]
	
end

-- OnInitialize Handler
function CancelVendor.Initialize()
	local newWindow = CancelVendor:new()
	newWindow.setDataFunction = CancelVendor.parseData
	newWindow:Init()
end
