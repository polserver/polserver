----------------------------------------------------------
-- LoreQuitOffer.lua
----------------------------------------------------------------

LoreQuitOffer = MasterGUMP:new()

function LoreQuitOffer.Initialize()

	local newWindow					= LoreQuitOffer:new()
	newWindow.setData				= LoreQuitOffer.mySetData
	newWindow.fixup					= LoreQuitOffer.myFixup
	newWindow:Init()
end

function LoreQuitOffer:mySetData()

	self.Page	= {}
	

	for pageNum, _ in ipairs( self.stringPageIndex )
	do
		self.Page[pageNum] = {}
		
		local strItr	= self.stringPageIndex[pageNum]
		local strItrEnd	= self.stringDataCount
		if pageNum ~= table.getn( self.descPageIndex )
		then
			strItrEnd = self.stringPageIndex[pageNum + 1] - 1
		end
		self.Page[pageNum].Title = GGManager.translateTID( 1078848 )
		self.Page[pageNum].Subtitle = GGManager.translateTID( self.descData[2] )
		
		if GGManager.translateTID( self.descData[3] )== "" then
			self.Page[pageNum].ScrollText = L"\n\n\n"
											..GGManager.translateTID( self.descData[4] )..L"\n\n"
											..GGManager.translateTID( self.descData[5] )
		else

			self.Page[pageNum].ScrollText = GGManager.translateTID( self.descData[3] )..L"\n\n\n"
											..GGManager.translateTID( self.descData[4] )..L"\n\n"
											..GGManager.translateTID( self.descData[5] )
		end

		self.Page[pageNum].RadioId = self.buttonIDs[1]
		
		--Okay Button
		self.Page[pageNum].LeftButtonId = self.buttonIDs[3]
		self.Page[pageNum].LeftButtonText = GGManager.translateTID( 1011036 )
	
		--Cancel Button
		self.Page[pageNum].RightButtonId = self.buttonIDs[2]
		self.Page[pageNum].RightButtonText = GGManager.translateTID( 1011012 )
	end
end

function LoreQuitOffer:myFixup()

	-- 4 == OnLButtonUp
	WindowUnregisterEventHandler( self.windowName.."LeftButton", 4 )
	WindowRegisterEventHandler( self.windowName.."LeftButton", 4, "MasterGUMP.SelectionPressed" )
end
