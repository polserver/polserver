
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

HouseSignPlaqueWindow = { }

local HouseSignPlaqueWindow_GumpData = {}


----------------------------------------------------------------
-- House Sign Plaque  Functions
----------------------------------------------------------------

-- OnInitialize Handler
function HouseSignPlaqueWindow.Initialize()

	UO_GenericGump.retrieveWindowData (HouseSignPlaqueWindow_GumpData)
	local stringData = UO_GenericGump.retreiveWindowDataStrings( HouseSignPlaqueWindow_GumpData )

	local WindowName = 	HouseSignPlaqueWindow_GumpData.windowName

	if (stringData[1] ~= "") or (stringData[1] ~= nil) then
		LabelSetText( WindowName.."HouseSignText", stringData[1] )
	else
		LabelSetText( WindowName.."HouseSignText", L"empty string" )	
	end

end
	


