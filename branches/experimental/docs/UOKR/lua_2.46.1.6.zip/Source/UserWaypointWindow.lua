----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

UserWaypointWindow = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

UserWaypointWindow.TID = { Save=3000187, Delete=3000176, Cancel=1006045, CreateWaypoint=1079482, EditWaypoint=1079483,
					     Create=1077830, DeleteWaypoint=1079484, SelectAFacet=1079512, SelectAType=1079513,
					     WaypointName=1079514, Coordinates=1079515, X=1079516, Y=1079517, Z=1079518,
					     SelectAnIcon=1079519, MissingWaypointNameError=1079520, InvalidRangeCoordError=1079521,
					     Lat=1079526, Long=1079527, ViewWaypoint=1079571}
					     
UserWaypointWindow.x = nil
UserWaypointWindow.y = nil
UserWaypointWindow.z = nil
UserWaypointWindow.facetId = nil
UserWaypointWindow.waypointId = nil
UserWaypointWindow.iconId = nil
UserWaypointWindow.typeId = nil
UserWaypointWindow.waypointName = nil
UserWaypointWindow.latitude = nil
UserWaypointWindow.longitude = nil
UserWaypointWindow.XYcoords = false
UserWaypointWindow.customWaypointTypes = {}

----------------------------------------------------------------
-- Functions
----------------------------------------------------------------

function UserWaypointWindow.Initialize()
	RegisterWindowData(WindowData.WaypointDisplay.Type,0)

	--Debug.DumpToConsole("WindowData.WaypointDisplay.displayTypes.ATLAS",WindowData.WaypointDisplay.displayTypes.ATLAS,nil)
	
	ButtonSetText("UserWaypointWindowSaveButton",  GetStringFromTid(UserWaypointWindow.TID.Save))
	ButtonSetText("UserWaypointWindowCreateButton",  GetStringFromTid(UserWaypointWindow.TID.Create)) 
	ButtonSetText("UserWaypointWindowDeleteButton",  GetStringFromTid(UserWaypointWindow.TID.Delete)) 
	ButtonSetText("UserWaypointWindowCancelButton",  GetStringFromTid(UserWaypointWindow.TID.Cancel))

	LabelSetText("UserWaypointWindowFacetComboPrompt", GetStringFromTid(UserWaypointWindow.TID.SelectAFacet))
	LabelSetText("UserWaypointWindowTypeComboPrompt", GetStringFromTid(UserWaypointWindow.TID.SelectAType))
	LabelSetText("UserWaypointWindowNamePrompt", GetStringFromTid(UserWaypointWindow.TID.WaypointName))
	LabelSetText("UserWaypointWindowCoordinatePrompt", GetStringFromTid(UserWaypointWindow.TID.Coordinates))
	
	LabelSetText("UserWaypointWindowXPrompt", GetStringFromTid(UserWaypointWindow.TID.X))
	LabelSetText("UserWaypointWindowYPrompt", GetStringFromTid(UserWaypointWindow.TID.Y))
	LabelSetText("UserWaypointWindowZPrompt", GetStringFromTid(UserWaypointWindow.TID.Z))
	
	LabelSetText("UserWaypointWindowLatPrompt", GetStringFromTid(UserWaypointWindow.TID.Lat))
	LabelSetText("UserWaypointWindowLongPrompt", GetStringFromTid(UserWaypointWindow.TID.Long))
	
	LabelSetText("UserWaypointWindowIconPickerPrompt", GetStringFromTid(UserWaypointWindow.TID.SelectAnIcon))
	
	-- Start with X,Y coord
	UserWaypointWindow.ShowLatLong()
	
	-- Set up facet combo box
	ComboBoxAddMenuItem( "UserWaypointWindowFacetCombo", GetStringFromTid(MapWindow.FacetTID[0]) )
	ComboBoxAddMenuItem( "UserWaypointWindowFacetCombo", GetStringFromTid(MapWindow.FacetTID[1]) )
	ComboBoxAddMenuItem( "UserWaypointWindowFacetCombo", GetStringFromTid(MapWindow.FacetTID[2]) )
	ComboBoxAddMenuItem( "UserWaypointWindowFacetCombo", GetStringFromTid(MapWindow.FacetTID[3]) )
	ComboBoxAddMenuItem( "UserWaypointWindowFacetCombo", GetStringFromTid(MapWindow.FacetTID[4]) )

	-- Set up type combo box
	local waypointTypeComboIndex = 1
	for waypointType, isCustom in ipairs(SystemData.Waypoint.TypeIsCustomizable) do
		if (isCustom == 1) then
			UserWaypointWindow.customWaypointTypes[waypointTypeComboIndex] = waypointType
			ComboBoxAddMenuItem( "UserWaypointWindowTypeCombo", WindowData.WaypointDisplay.typeNames[waypointType])
			waypointTypeComboIndex = waypointTypeComboIndex + 1
		end
	end

	-- SETUP THE WAYPOINT ICON PICKER !!! 
	CreateWindowFromTemplate( "UserWaypointIconPickerWindow", "WaypointIconPickerWindowTemplate", "Root" )
	WindowAddAnchor( "UserWaypointIconPickerWindow", "topright", "UserWaypointWindow", "topleft", 0, 0)
	WaypointIconPickerWindow.DrawWaypointIconTable("UserWaypointIconPickerWindow")
	WaypointIconPickerWindow.SetAfterWaypointIconSelectionFunction(UserWaypointWindow.ChangeIcon, "UserWaypointIconPickerWindow")
	LabelSetText("UserWaypointIconPickerWindowTitle", GetStringFromTid(MapOptionsWindow.TID.SelectAnIcon))
	
	WindowAssignFocus("UserWaypointWindowNameEditBox", true)
	WindowSetShowing("UserWaypointIconPickerWindow", false)
end

function UserWaypointWindow.Shutdown()
	UnregisterWindowData(WindowData.WaypointDisplay.Type,0)
	UserWaypointWindow.ClearData()
end

function UserWaypointWindow.InitializeCreateWaypointData(params)
	-- DEFAULT VALUES FOR NEW CUSTOM WAYPOINTS
	local z = 0
	local typeId = UserWaypointWindow.customWaypointTypes[1]
	local iconId = WindowData.WaypointDisplay.displayTypes.ATLAS[typeId].iconId
	
	WindowUtils.SetWindowTitle("UserWaypointWindow",  GetStringFromTid(UserWaypointWindow.TID.CreateWaypoint))
	WindowSetShowing("UserWaypointWindowCreateButton", true)
	WindowSetShowing("UserWaypointWindowSaveButton", false)
	WindowSetShowing("UserWaypointWindowDeleteButton", false)
	UserWaypointWindow.UpdateDisplayInfo(nil, params.x, params.y, z, params.facetId, iconId, typeId, nil)
	--Debug.Print ("Initializing ... ")
	--UserWaypointWindow.PrintUserData()
end

function UserWaypointWindow.InitializeEditWaypointData(params)
	WindowUtils.SetWindowTitle("UserWaypointWindow",  GetStringFromTid(UserWaypointWindow.TID.EditWaypoint))
	WindowSetShowing("UserWaypointWindowSaveButton", true)
	WindowSetShowing("UserWaypointWindowDeleteButton", true)
	WindowSetShowing("UserWaypointWindowCreateButton", false)
	UserWaypointWindow.UpdateDisplayInfo(params.id, params.x, params.y, params.z, params.facetId, params.iconId, params.typeId, params.name)
	--Debug.Print ("Initializing ... ")
	--UserWaypointWindow.PrintUserData()
end

function UserWaypointWindow.InitializeViewWaypointData(params)
	WindowUtils.SetWindowTitle("UserWaypointWindow",  GetStringFromTid(UserWaypointWindow.TID.ViewWaypoint))
	WindowSetShowing("UserWaypointWindowSaveButton",false)
	WindowSetShowing("UserWaypointWindowDeleteButton", false)
	WindowSetShowing("UserWaypointWindowCreateButton", false)
	UserWaypointWindow.UpdateDisplayInfo(params.id, params.x, params.y, params.z, params.facetId, params.iconId, params.typeId, params.name)
	--Debug.Print ("Initializing ... ")
	--UserWaypointWindow.PrintUserData()
end

function UserWaypointWindow.Save()
	UserWaypointWindow.GetUserData()
	if (UserWaypointWindow.IsUserDataValid()) then
		local iconIndex = UserWaypointWindow.GetIconIndex(UserWaypointWindow.iconId)
		
		--UserWaypointWindow.PrintUserData()
		UOEditUserWaypoint( UserWaypointWindow.waypointId, UserWaypointWindow.typeId, UserWaypointWindow.x,
						UserWaypointWindow.y, UserWaypointWindow.facetId, UserWaypointWindow.waypointName )
		MapOptionsWindow.ChangeIcon(iconIndex, UserWaypointWindow.typeId)
		UserWaypointWindow.ClearData()
		WindowSetShowing("UserWaypointWindow", false)
	end
end

function UserWaypointWindow.Create()
	UserWaypointWindow.GetUserData()
	if (UserWaypointWindow.IsUserDataValid()) then
		local iconIndex = UserWaypointWindow.GetIconIndex(UserWaypointWindow.iconId)
		--UserWaypointWindow.PrintUserData()
		local waypointId = UOCreateUserWaypoint( UserWaypointWindow.typeId, UserWaypointWindow.x, UserWaypointWindow.y,
											UserWaypointWindow.facetId, UserWaypointWindow.waypointName )
		local wtype, wflags, wname, wfacet, wx, wy, wz = UOGetWaypointInfo(waypointId)
		MapOptionsWindow.ChangeIcon(iconIndex, UserWaypointWindow.typeId)
		UserWaypointWindow.ClearData()
		WindowSetShowing("UserWaypointWindow", false)
	end
end

function UserWaypointWindow.Delete()
	UserWaypointWindow.GetUserData()
	UODeleteUserWaypoint(UserWaypointWindow.waypointId)
	UserWaypointWindow.ClearData()
	WindowSetShowing("UserWaypointWindow", false)
end

function UserWaypointWindow.Cancel()
	UserWaypointWindow.ClearData()
	WindowSetShowing("UserWaypointWindow", false)
end

function UserWaypointWindow.UpdateDisplayInfo(waypointId, x, y, z, facetId, iconId, typeId, name)
	UserWaypointWindow.x = x
	UserWaypointWindow.y = y
	UserWaypointWindow.z = z
	UserWaypointWindow.facetId = facetId
	UserWaypointWindow.waypointId = waypointId
	UserWaypointWindow.iconId = iconId
	UserWaypointWindow.typeId = typeId
	UserWaypointWindow.name = name
	
	TextEditBoxSetText("UserWaypointWindowXTextEditBox", StringToWString(tostring(x)))
	TextEditBoxSetText("UserWaypointWindowYTextEditBox", StringToWString(tostring(y)))
	TextEditBoxSetText("UserWaypointWindowZTextEditBox", StringToWString(tostring(z)))
	
	if (name) then
		TextEditBoxSetText("UserWaypointWindowNameEditBox", name)
	end
	
	ComboBoxSetSelectedMenuItem( "UserWaypointWindowFacetCombo", facetId+1)
	
	local typeDisplayIndex = nil
	for comboBoxIndex, type in ipairs (UserWaypointWindow.customWaypointTypes) do
		if (type == typeId) then
			typeDisplayIndex = comboBoxIndex	
			break
		end
	end
	
	if (typeDisplayIndex) then
		ComboBoxSetSelectedMenuItem( "UserWaypointWindowTypeCombo",  typeDisplayIndex)
	end
	
	UserWaypointWindow.UpdateWaypointIcon(iconId)
	
	-- CONVERT TO LAT/LONG and DISPLAY INFO
	UserWaypointWindow.ConvertToLatLong()
	UserWaypointWindow.ShowLatLong()
	
	WindowSetShowing("UserWaypointWindow", true)
end

function UserWaypointWindow.UpdateWaypointIcon(waypointIconId)
	UserWaypointWindow.iconId = waypointIconId 
	local iconTexture, x, y = GetIconData(waypointIconId)
	local waypointIconWidth, waypointIconHeight = UOGetTextureSize("icon"..tostring(waypointIconId))

	if (waypointIconWidth and waypointIconHeight) then
		WindowSetDimensions("UserWaypointWindowIconPicker", waypointIconWidth, waypointIconHeight)
	    WindowSetDimensions("UserWaypointWindowIconPickerGraphic", waypointIconWidth, waypointIconHeight)
		DynamicImageSetTexture("UserWaypointWindowIconPickerGraphic", iconTexture, x, y)
		return true
	else
		return false
	end
end

function UserWaypointWindow.UpdateTypeIcon()
	UserWaypointWindow.typeId = UserWaypointWindow.customWaypointTypes[ComboBoxGetSelectedMenuItem("UserWaypointWindowTypeCombo")]
	UserWaypointWindow.iconId = WindowData.WaypointDisplay.displayTypes.ATLAS[UserWaypointWindow.typeId].iconId
	UserWaypointWindow.UpdateWaypointIcon(UserWaypointWindow.iconId)
end

function UserWaypointWindow.OpenIconPicker()
	WindowSetShowing("UserWaypointIconPickerWindow", true)	
end

function UserWaypointWindow.ChangeIcon()
	UserWaypointWindow.UpdateWaypointIcon(WindowData.WaypointDisplay.iconIds[WaypointIconPickerWindow.WaypointIconSelected["UserWaypointIconPickerWindow"]])
end

function UserWaypointWindow.ClearData()
	UserWaypointWindow.x = nil
	UserWaypointWindow.y = nil
	UserWaypointWindow.z = nil
	UserWaypointWindow.facetId = nil
	UserWaypointWindow.waypointId = nil
	UserWaypointWindow.iconId = nil
	UserWaypointWindow.typeId = nil
	UserWaypointWindow.waypointName = nil
	UserWaypointWindow.Latitude = nil
	UserWaypointWindow.Longitude = nil

	UserWaypointWindow.ShowLatLong()
	
	TextEditBoxSetText("UserWaypointWindowXTextEditBox", L"")
	TextEditBoxSetText("UserWaypointWindowYTextEditBox", L"")
	TextEditBoxSetText("UserWaypointWindowZTextEditBox", L"")
	TextEditBoxSetText("UserWaypointWindowNameEditBox", L"")
	
	TextEditBoxSetText("UserWaypointWindowLatTextEditBox", L"")
	TextEditBoxSetText("UserWaypointWindowLongTextEditBox", L"")
end

function UserWaypointWindow.GetUserData()
	if (UserWaypointWindow.XYcoords) then
		UserWaypointWindow.x = tonumber(TextEditBoxGetText("UserWaypointWindowXTextEditBox"))
		UserWaypointWindow.y = tonumber(TextEditBoxGetText("UserWaypointWindowYTextEditBox"))
		UserWaypointWindow.z = tonumber(TextEditBoxGetText("UserWaypointWindowZTextEditBox"))
		UserWaypointWindow.ConvertToLatLong()
	else
		UserWaypointWindow.latitude = tonumber(TextEditBoxGetText("UserWaypointWindowLatTextEditBox"))
		UserWaypointWindow.longitude = tonumber(TextEditBoxGetText("UserWaypointWindowLongTextEditBox"))
		UserWaypointWindow.ConvertToXY()
	end
	
	UserWaypointWindow.facetId = tonumber(ComboBoxGetSelectedMenuItem("UserWaypointWindowFacetCombo")) - 1
	UserWaypointWindow.typeId = UserWaypointWindow.customWaypointTypes[tonumber(ComboBoxGetSelectedMenuItem("UserWaypointWindowTypeCombo")) ]
	UserWaypointWindow.waypointName = TextEditBoxGetText("UserWaypointWindowNameEditBox")
end

function UserWaypointWindow.IsUserDataValid()
	if (UserWaypointWindow.waypointName == L"" or UserWaypointWindow.waypointName == "" or not(UserWaypointWindow.waypointName)) then
		UserWaypointWindow.ShowErrorMessage(GetStringFromTid(UserWaypointWindow.TID.MissingWaypointNameError) ,"UserWaypointWindowNameEditBox")
		return false
	elseif ((UserWaypointWindow.x == nil) or (UserWaypointWindow.y== nil) or (UserWaypointWindow.z== nil) or 
			  not(0 <= UserWaypointWindow.x) or not(UserWaypointWindow.x <= MapWindow.FacetDimensions[UserWaypointWindow.facetId].x) or	
		      not(0 <= UserWaypointWindow.y) or not(UserWaypointWindow.y <= MapWindow.FacetDimensions[UserWaypointWindow.facetId].y) or
			  not(-128 <= UserWaypointWindow.z) or not(UserWaypointWindow.z <= 127 )) then
		UserWaypointWindow.ShowErrorMessage(GetStringFromTid(UserWaypointWindow.TID.InvalidRangeCoordError),"UserWaypointWindowNameEditBox")
		return false
	else
		return true
	end
end

function UserWaypointWindow.ShowErrorMessage(bodyText,focusOnClose,callback)
    local okayButton = { textTid=UO_StandardDialog.TID_OKAY, callback=callback }
    local windowData = 
    {
        windowName = "UserWaypointWindow",
        titleTid = 503269,
        body = bodyText,
        focusOnClose = focusOnClose,
        buttons = { okayButton }
    }
    UO_StandardDialog.CreateDialog(windowData)
end

function UserWaypointWindow.GetIconIndex(iconId)
	for key, value in ipairs(WindowData.WaypointDisplay.iconIds) do
		if (tonumber(value) == iconId) then
			return key
		end
	end
	return nil
end

function UserWaypointWindow.PrintUserData()
	Debug.Print(" -----------------------------------------------------------------------")
	Debug.Print(" *** UserWaypointWindow DATA ***")
	Debug.Print ("UserWaypointWindow.x = "..tostring(UserWaypointWindow.x))
	Debug.Print ("UserWaypointWindow.y = "..tostring(UserWaypointWindow.y))
	Debug.Print ("UserWaypointWindow.z = "..tostring(UserWaypointWindow.z))
	Debug.Print ("UserWaypointWindow.latitude = "..tostring(UserWaypointWindow.latitude))
	Debug.Print ("UserWaypointWindow.longitude = "..tostring(UserWaypointWindow.longitude))
	Debug.Print ("UserWaypointWindow.facetId = "..tostring(UserWaypointWindow.facetId))
	Debug.Print ("UserWaypointWindow.waypointId = "..tostring(UserWaypointWindow.waypointId ))
	Debug.Print ("UserWaypointWindow.iconId = "..tostring(UserWaypointWindow.iconId))
	Debug.Print ("UserWaypointWindow.typeId = "..tostring(UserWaypointWindow.typeId))
	Debug.Print ("UserWaypointWindow.waypointName = "..tostring(UserWaypointWindow.waypointName))
	Debug.Print(" ----------------------------------------------------------------------- ")
end

function UserWaypointWindow.ConvertToLatLong()
	UserWaypointWindow.latitude = (UserWaypointWindow.x - (MapWindow.FacetDimensions[UserWaypointWindow.facetId].x/2 - 1)) * 360/ MapWindow.FacetDimensions[UserWaypointWindow.facetId].x
	UserWaypointWindow.longitude = (UserWaypointWindow.y - (MapWindow.FacetDimensions[UserWaypointWindow.facetId].y/2 - 1)) * 360/ MapWindow.FacetDimensions[UserWaypointWindow.facetId].y
end

function UserWaypointWindow.ConvertToXY()
	UserWaypointWindow.x = UserWaypointWindow.latitude *  (MapWindow.FacetDimensions[UserWaypointWindow.facetId].x)/360 + (MapWindow.FacetDimensions[UserWaypointWindow.facetId].x/2 - 1)
	UserWaypointWindow.y = UserWaypointWindow.longitude *  (MapWindow.FacetDimensions[UserWaypointWindow.facetId].y)/360 + (MapWindow.FacetDimensions[UserWaypointWindow.facetId].y/2 - 1)
	
	if (UserWaypointWindow.x < 0) then
		UserWaypointWindow.x = UserWaypointWindow.x + MapWindow.FacetDimensions[UserWaypointWindow.facetId].x
	end
	
	if (UserWaypointWindow.x >= MapWindow.FacetDimensions[UserWaypointWindow.facetId].x) then
		UserWaypointWindow.x = UserWaypoint.x - MapWindow.FacetDimensions[UserWaypointWindow.facetId].x
	end

	if (UserWaypointWindow.y < 0) then
		UserWaypoint.y = UserWaypoint.y + MapWindow.FacetDimensions[UserWaypointWindow.facetId].y
	end
	
	if (UserWaypointWindow.y >= MapWindow.FacetDimensions[UserWaypointWindow.facetId].y) then
		UserWaypointWindow.x = UserWaypoint.y - MapWindow.FacetDimensions[UserWaypointWindow.facetId].y
	end 
end

function UserWaypointWindow.ToggleCoord()
	UserWaypointWindow.GetUserData()
	if (UserWaypointWindow.XYcoords == true)  then
		UserWaypointWindow.ShowLatLong()
	else
		UserWaypointWindow.ShowXY()
	end
end

function UserWaypointWindow.ShowLatLong()
	UserWaypointWindow.XYcoords = false
	
	if (UserWaypointWindow.latitude) then
		TextEditBoxSetText("UserWaypointWindowLatTextEditBox", StringToWString(string.format ("%.2f", UserWaypointWindow.latitude) ))
	end
	
	if (UserWaypointWindow.longitude) then
		TextEditBoxSetText("UserWaypointWindowLongTextEditBox", StringToWString(string.format ("%.2f", UserWaypointWindow.longitude) ))
	end
	
	WindowSetShowing("UserWaypointWindowX",false)
	WindowSetShowing("UserWaypointWindowY",false)
	WindowSetShowing("UserWaypointWindowZ",false)

	WindowAssignFocus("UserWaypointWindowLatTextEditBox", true)
	
	WindowSetShowing("UserWaypointWindowLat",true)
	WindowSetShowing("UserWaypointWindowLong",true)
end

function UserWaypointWindow.ShowXY()
	UserWaypointWindow.XYcoords = true
	
	if (UserWaypointWindow.x) then
		TextEditBoxSetText("UserWaypointWindowXTextEditBox", StringToWString(string.format("%.0f",UserWaypointWindow.x) ))
	end
	if (UserWaypointWindow.y) then
		TextEditBoxSetText("UserWaypointWindowYTextEditBox", StringToWString(string.format("%.0f",UserWaypointWindow.y) ))
	end
	
	WindowSetShowing("UserWaypointWindowX",true)
	WindowSetShowing("UserWaypointWindowY",true)
	WindowSetShowing("UserWaypointWindowZ",true)

	WindowAssignFocus("UserWaypointWindowXTextEditBox", true)
	
	WindowSetShowing("UserWaypointWindowLat",false)
	WindowSetShowing("UserWaypointWindowLong",false)
end

-- TO DO: MOUSEOVER IS NOT WORKING !!!
function UserWaypointWindow.ToggleCoordMouseOver()
	local messageText = L""
	local id = WindowGetId(WindowUtils.GetActiveDialog())
	
	if (UserWaypointWindow.XYcoords)  then
		messageText = L"Enter Lat/Long coordinates"
	else
		messageText = L"Enter X,Y,Z coordinates"
	end
    
	--Debug.Print("toggleCoordMouseOver: messageText = "..tostring(messageText))
    
	local itemData = { 	windowName = WindowUtils.GetActiveDialog(),
					itemId = id,
					itemType = ItemProperties.type.TYPE_WSTRINGDATA,
					binding = L"",
					detail = nil,
					title = messageText,
					body = L""}

	ItemProperties.SetActiveItem(itemData)
end

function UserWaypointWindow.FocusOnTextBox()
	local parentWindowName = SystemData.ActiveWindow.name
	if (parentWindowName == "UserWaypointWindowName") then
		WindowAssignFocus(parentWindowName.."EditBox", true)
	else	
		WindowAssignFocus(parentWindowName.."TextEditBox", true)
	end
end