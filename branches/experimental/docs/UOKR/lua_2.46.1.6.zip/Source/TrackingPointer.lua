----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

TrackingPointer = {}
TrackingPointer.PointerOn = false

function TrackingPointer.OnUpdate(timePassed)
	if (SystemData.TrackingPointer.PointerType ~= 0) then
		TrackingPointer.PointerOn = true
		local visible, x, y, rotation
		visible,x,y,rotation = TranslatePointer(SystemData.TrackingPointer.PointerType, SystemData.TrackingPointer.PointerX, SystemData.TrackingPointer.PointerY)
--		Debug.Print("x="..x.."y="..y.."rotation="..rotation)
		DynamicImageSetTexture("TrackingPointerPointerImage", "UO_Common", 368, 0)
		WindowClearAnchors("TrackingPointerPointerImage")
		WindowAddAnchor("TrackingPointerPointerImage", "topleft", "Root", "center", x, y)
		DynamicImageSetRotation("TrackingPointerPointerImage", rotation)
		WindowSetShowing("TrackingPointerPointerImage", true)
	else
		if (TrackingPointer.PointerOn) then
--			Debug.Print("Turning off tracking pointer")
			WindowSetShowing("TrackingPointerPointerImage", false)
			TrackingPointer.PointerOn = false
		end
	end
end
