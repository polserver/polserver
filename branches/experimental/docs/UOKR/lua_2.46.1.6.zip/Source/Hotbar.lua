----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

Hotbar = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- MainMenuWindow Functions
----------------------------------------------------------------

Hotbar.NUM_BUTTONS = 12

Hotbar.CurrentUseSlot = 0
Hotbar.CurrentUseHotbar = 0

Hotbar.DarkItemLabel = { r=245,g=229,b=0 }
Hotbar.LightItemLabel = { r=0,g=0,b=0 }

Hotbar.RecordingSlot = 0
Hotbar.RecordingHotbar = 0

Hotbar.StaticPageNum = 1

Hotbar.HANDLE_OFFSET = 14

Hotbar.TID_BINDING_CONFLICT_TITLE = 1079169
Hotbar.TID_BINDING_CONFLICT_BODY = 1079170

function Hotbar.GetItemIndexForSlot(hotbarId,slot)
	local itemIndex = slot
	
	if( hotbarId == HotbarSystem.STATIC_HOTBAR_ID ) then
		itemIndex = (slot + ((Hotbar.StaticPageNum-1) * Hotbar.NUM_BUTTONS))
	end

	return itemIndex
end

function Hotbar.GetSlotForItemIndex(hotbarId,itemIndex)
	local slot = itemIndex
	if( hotbarId == HotbarSystem.STATIC_HOTBAR_ID ) then
		slot = itemIndex - ((Hotbar.StaticPageNum-1) * Hotbar.NUM_BUTTONS)
		if( slot <= 0 or slot > Hotbar.NUM_BUTTONS ) then
			slot = 0
		end
	end
	
	return slot
end

function Hotbar.SetHotbarItem(hotbarId, slot, isDropped)
	local itemIndex = Hotbar.GetItemIndexForSlot(hotbarId,slot)

	element = "Hotbar"..hotbarId.."Button"..slot
	
	local hasItem = HotbarHasItem(hotbarId, itemIndex)
	--Debug.Print("Hotbar.SetHotbarItem: "..tostring(slot).." itemIndex: "..tostring(itemIndex).." hasItem: "..tostring(hasItem))
	
	-- bail out if this item doesnt exist in c++
	if( hasItem == false ) then
		return
	end
	
	if( HotbarSystem.SetIconForAction(element, hotbarId, itemIndex, 0, isDropped) == false ) then
		-- the placement failed so remove this hotbar item
		Debug.Print("Hotbar.SetHotbarItem FAILED: IconId can not be found for actionType "..tostring(type))
		local itemIndex = Hotbar.GetItemIndexForSlot(param.HotbarId,param.Slot)
		HotbarClearItem(hotbarId,itemIndex)
	end
	
	if( isDropped == true ) then
		Cursor.Clear()
	end
end

function Hotbar.ClearHotbarItem(hotbarId, slot, bUnregister)
	--Debug.PrintToDebugConsole(L"Hotbar::ClearHotbarSlot Slot: "..slot)
	
	local itemIndex = Hotbar.GetItemIndexForSlot(hotbarId,slot)
	local element = "Hotbar"..hotbarId.."Button"..slot
	
	HotbarSystem.ClearActionIcon(element, hotbarId, itemIndex, 0, bUnregister)
end

function Hotbar.ReloadHotbar(hotbarId)
	--Debug.Print("Hotbar.ReloadHotbar")
	
	for slot = 1, Hotbar.NUM_BUTTONS do	
		Hotbar.SetHotbarItem(hotbarId,slot,false)
	end
end

function Hotbar.UseSlot(hotbarId, slot)
	local itemIndex = Hotbar.GetItemIndexForSlot(hotbarId,slot)
		
	if( HotbarHasItem(hotbarId, itemIndex) ) then
		HotbarExecuteItem(hotbarId, itemIndex)
	end
end

-- OnInitialize Handler
function Hotbar.Initialize()
	this = SystemData.ActiveWindow.name
	local hotbarId = SystemData.DynamicWindowId
	
	WindowSetId(this,hotbarId)
	
	WindowRegisterEventHandler( this, SystemData.Events.INTERFACE_KEY_RECORDED, "Hotbar.KeyRecorded" )
	WindowRegisterEventHandler( this, SystemData.Events.HOTBAR_ITEM_USE, "Hotbar.UseActiveSlot")
	WindowRegisterEventHandler( this, SystemData.Events.HOTBAR_SET_PAGE, "Hotbar.SetPage")

	-- hide dynamic elements for the static hotbar
	if( hotbarId == HotbarSystem.STATIC_HOTBAR_ID ) then
		WindowSetShowing(this.."ResizeButton",false)
		WindowSetMovable(this,false)
		WindowSetShowing(this.."VertHandle",false)
		WindowSetShowing(this.."HorizHandle",false)
		LabelSetText(this.."PageNum",L""..Hotbar.StaticPageNum)
	-- dynamic hotbars positions and sizes are tracked
	else
		WindowUtils.RestoreWindowPosition(this,true)
		WindowSetShowing(this.."Page",false)
		Hotbar.OnResizeEnd(this)
	end
	
	-- set the hotbar labels based on the hotkey
	-- and initialize the slots
	for slot = 1, Hotbar.NUM_BUTTONS do
	   local HotkeyLabel = this.."Button"..slot.."Hotkey"
	   local key = SystemData.Hotbar[hotbarId].BindingDisplayStrings[slot]
	   LabelSetText(HotkeyLabel, key)
	   
	   Hotbar.ClearHotbarItem(hotbarId,slot,false)
	end	
	
	Hotbar.ReloadHotbar(hotbarId)
end

-- OnShutdown Handler
function Hotbar.Shutdown()
	--Debug.Print("Hotbar.Shutdown")
	
	this = SystemData.ActiveWindow.name
	hotbarId = WindowGetId(this)
	
	for slot = 1, Hotbar.NUM_BUTTONS do
		Hotbar.ClearHotbarItem(hotbarId,slot,true)
	end
	
	if( ItemProperties.GetCurrentWindow() == "Hotbar"..hotbarId ) then
		ItemProperties.ClearMouseOverItem()
	end
	
	-- only save the position of dynamic bars
	if( hotbarId ~= HotbarSystem.STATIC_HOTBAR_ID ) then
		WindowUtils.SaveWindowPosition(this)
	end
end

-- OnLButtonDown Handler
function Hotbar.ItemLButtonDown()
	local slot = WindowGetId(SystemData.ActiveWindow.name)
	local hotbarId = WindowGetId(WindowUtils.GetActiveDialog())
	
	--Debug.PrintToDebugConsole(L"Hotbar::OnLButtonDown(): Slot "..slot)

	local itemIndex = Hotbar.GetItemIndexForSlot(hotbarId,slot)
		
	if( HotbarHasItem(hotbarId, itemIndex) ) then
		Hotbar.CurrentUseHotbar = hotbarId
		Hotbar.CurrentUseSlot = slot
	end
end

-- OnLButtonUP Handler
function Hotbar.ItemLButtonUp()
	local hotbarId = WindowGetId(WindowUtils.GetActiveDialog())
	local slot = WindowGetId(SystemData.ActiveWindow.name)
	
	--Debug.PrintToDebugConsole(L"Hotbar::OnLButtonUp(): Slot = "..StringToWString(tostring(slot)))
	--Debug.PrintToDebugConsole(L"Hotbar::OnLButtonUp(): Cursor.Data.Type =  "..StringToWString(tostring(Cursor.Data.Type)))
	
	if Cursor.IconOnCursor() then	
	
		local id = Cursor.Data.ItemId
		local originalId = id

		local actionType = Cursor.Data.ActionType
		local itemIndex = Hotbar.GetItemIndexForSlot(hotbarId,slot)	
	
		-- only accept items coming from backpack or paperdoll
		if( Cursor.Data.Type == Cursor.TYPE_ITEM ) then
			if( not (Cursor.Data.SourceType == SystemData.DragItem.SOURCETYPE_CONTAINER or
					 Cursor.Data.SourceType == SystemData.DragItem.SOURCETYPE_PAPERDOLL) ) then
				return
			end
			
			-- convert item type to use item user action
			if(IsGenericItem(id)) then
				actionType = SystemData.UserAction.TYPE_USE_OBJECTTYPE 
				local objectType, objectHue = UserActionGetObjectTypeHueGivenObjectId(id)
				if( objectType==0 and objectHue == 0) then
					objectType, objectHue = UserActionUseObjectTypeGetIconObjectTypeHue(hotbarId, itemIndex, 0)
				end
				id = UserActionGetSpecialId(objectType, objectHue )
			else
				actionType = SystemData.UserAction.TYPE_USE_ITEM 
			end
		end

		-- for now default all items to type current (except weaponabilities)
		local targetType = SystemData.Hotbar.TargetType.TARGETTYPE_CURRENT
		
		Hotbar.ClearHotbarItem(hotbarId,slot,true)
		
		HotbarCreateNewItem(hotbarId,itemIndex,actionType,id,targetType,originalId)

		Hotbar.SetHotbarItem(hotbarId,slot,true)
		
		local slotWindow = "Hotbar"..hotbarId.."Button"..slot
		ActionEditWindow.OpenEditWindow(actionType,slotWindow,hotbarId,itemIndex)
	
	elseif( slot == Hotbar.CurrentUseSlot and hotbarId == Hotbar.CurrentUseHotbar ) then
		--Debug.PrintToDebugConsole(L"Hotbar::OnLButtonUp:Use Slot "..slot)
		Hotbar.UseSlot(hotbarId, slot)

	end
	
end

function Hotbar.ContextMenuCallback(returnCode,param)
	if( param ~= nil ) then
		local bHandled = HotbarSystem.ContextMenuCallback(returnCode,param) 
		
		-- if it wasnt handled then check for hotbar specific options
		if( bHandled == false ) then	
			if( returnCode == HotbarSystem.ContextReturnCodes.CLEAR_ITEM ) then
				HotbarSystem.ClearActionIcon(param.SlotWindow, param.HotbarId, param.ItemIndex, param.SubIndex, true)
				HotbarClearItem(param.HotbarId,param.ItemIndex)
			elseif( returnCode == HotbarSystem.ContextReturnCodes.ASSIGN_KEY ) then
				WindowClearAnchors("AssignHotkeyInfo")
				WindowAddAnchor("AssignHotkeyInfo","topright","Hotbar"..param.HotbarId.."Button"..param.Slot,"bottomleft",0,-6)
				WindowSetShowing("AssignHotkeyInfo",true)
			
				Hotbar.RecordingSlot = param.Slot
				Hotbar.RecordingHotbar = param.HotbarId
				BroadcastEvent( SystemData.Events.INTERFACE_RECORD_KEY )
			elseif( returnCode == HotbarSystem.ContextReturnCodes.NEW_HOTBAR ) then
				HotbarSystem.SpawnNewHotbar()
			elseif( returnCode == HotbarSystem.ContextReturnCodes.DESTROY_HOTBAR ) then
                local okayButton = { textTid=UO_StandardDialog.TID_OKAY, callback=function() HotbarSystem.DestroyHotbar(param.HotbarId) end }
                local cancelButton = { textTid=UO_StandardDialog.TID_CANCEL }
				local DestroyConfirmWindow = 
				{
				    windowName = "Hotbar"..param.HotbarId,
					titleTid = HotbarSystem.TID_DESTROY_HOTBAR,
					bodyTid = HotbarSystem.TID_DESTROY_CONFIRM,
					buttons = { okayButton, cancelButton }
				}
					
				UO_StandardDialog.CreateDialog(DestroyConfirmWindow)
			end	
		end						 
	end
end

function Hotbar.ItemRButtonUp()
	local hotbarId = WindowGetId(WindowUtils.GetActiveDialog())
	local slot = WindowGetId(SystemData.ActiveWindow.name)
	local param = {Slot=slot,HotbarId=hotbarId}	
	
	--Debug.Print("Hotbar.ItemRButtonUp hotbarId: "..hotbarId.." slot: " .. slot)
	
	ContextMenu.CreateLuaContextMenuItem(HotbarSystem.TID_NEW_HOTBAR,0,HotbarSystem.ContextReturnCodes.NEW_HOTBAR,param)
	
	if( hotbarId ~= HotbarSystem.STATIC_HOTBAR_ID ) then
		ContextMenu.CreateLuaContextMenuItem(HotbarSystem.TID_DESTROY_HOTBAR,0,HotbarSystem.ContextReturnCodes.DESTROY_HOTBAR,param)
	end
	
	ContextMenu.CreateLuaContextMenuItem(HotbarSystem.TID_ASSIGN_HOTKEY,0,HotbarSystem.ContextReturnCodes.ASSIGN_KEY,param)
	
	local itemIndex = Hotbar.GetItemIndexForSlot(hotbarId,slot)
	
	if( HotbarHasItem(hotbarId,itemIndex) == true ) then
		local slotWindow = "Hotbar"..hotbarId.."Button"..slot
		HotbarSystem.CreateUserActionContextMenuOptions(hotbarId, itemIndex, 0, slotWindow)
	end
	
	ContextMenu.ActivateLuaContextMenu(Hotbar.ContextMenuCallback)
end

-- OnMouseOver Handler
function Hotbar.ItemMouseOver()
	local this = SystemData.ActiveWindow.name
	local hotbarId = WindowGetId(WindowUtils.GetActiveDialog())
	local slot = WindowGetId(this)
	local itemIndex = Hotbar.GetItemIndexForSlot(hotbarId,slot)
	
	local actionType = SystemData.UserAction.TYPE_NONE
	-- default id to the slot so it shows the item properties when there is only a binding
	local itemId = slot
	
	if( HotbarHasItem(hotbarId,itemIndex) == true ) then
	    actionType = UserActionGetType(hotbarId,itemIndex,0)
		local actionId = UserActionGetId(hotbarId,itemIndex,0)
		if( actionId ~= 0 ) then
			itemId = actionId
		end
		
		-- if its a macro reference, we need to dereference it
		if( actionType == SystemData.UserAction.TYPE_MACRO_REFERENCE ) then
			local macroId = UserActionGetId(hotbarId,itemIndex,0)
			local macroIndex = MacroSystemGetMacroIndexById(macroId)
			actionType = SystemData.UserAction.TYPE_MACRO
			hotbarId = MacroWindow.MACROLIST_ID
			itemIndex = macroIndex
		end
	end
	
	local itemData = { windowName = "Hotbar"..hotbarId,
						itemId = itemId,
						itemType = ItemProperties.type.TYPE_ACTION,
						actionType = actionType,
						itemLoc = {hotbarId=hotbarId, itemIndex=itemIndex},
						binding = SystemData.Hotbar[hotbarId].Bindings[slot] }
	ItemProperties.SetActiveItem(itemData)
	
end

function Hotbar.UseActiveSlot()
	local hotbarId = SystemData.Hotbar.ActiveHotbar
	
	if( hotbarId == WindowGetId(SystemData.ActiveWindow.name) ) then
		local slot = SystemData.Hotbar.ActiveSlot
		Hotbar.UseSlot(hotbarId, slot)
	end
end

function Hotbar.SetPage(newPage)
	-- if newpage is nil its coming from code
	if( newPage == nil ) then
		newPage = SystemData.Hotbar.SetPage
	end
	
	if( newPage ~= Hotbar.StaticPageNum ) then
		-- have to clear before the page number changes
		for slot = 1, Hotbar.NUM_BUTTONS do	
			Hotbar.ClearHotbarItem(HotbarSystem.STATIC_HOTBAR_ID,slot,true)
		end	
	
		--Debug.Print("SETPAGE: "..newPage)
		local this = "Hotbar"..HotbarSystem.STATIC_HOTBAR_ID
		
		Hotbar.StaticPageNum = newPage
		LabelSetText(this.."PageNum",L""..Hotbar.StaticPageNum)
		
		Hotbar.ReloadHotbar(HotbarSystem.STATIC_HOTBAR_ID)
		
		SetStaticHotbarPage(Hotbar.StaticPageNum)
	end
end

function Hotbar.KeyRecorded()
	if( Hotbar.RecordingHotbar == WindowGetId(SystemData.ActiveWindow.name) ) then
		WindowSetShowing("AssignHotkeyInfo",false)
	
	    if( SystemData.BindingActionString ~= L"" ) then
	        body = GetStringFromTid(Hotbar.TID_BINDING_CONFLICT_BODY)..L"\n\n"..SystemData.BindingActionString
	        local BindingConfirmWindow =
            {
                windowName = "Hotbar",
	            titleTid = Hotbar.TID_BINDING_CONFLICT_TITLE,
		        body = body,
	        }

            UO_StandardDialog.CreateDialog(BindingConfirmWindow)
	    else
            SystemData.Hotbar[Hotbar.RecordingHotbar].Bindings[Hotbar.RecordingSlot] = SystemData.RecordedKey
	        SystemData.Hotbar[Hotbar.RecordingHotbar].BindingDisplayStrings[Hotbar.RecordingSlot] = SystemData.RecordedKeySmallDisplay
        		
	        HotbarUpdateBinding(Hotbar.RecordingHotbar,Hotbar.RecordingSlot,SystemData.RecordedKey)
	        local HotkeyLabel = "Hotbar"..Hotbar.RecordingHotbar.."Button"..Hotbar.RecordingSlot.."Hotkey"
	        LabelSetText(HotkeyLabel, SystemData.RecordedKeySmallDisplay)
		end
		
		Hotbar.RecordingHotbar = nil
	end
end

function Hotbar.OnResizeBegin()
	this = WindowUtils.GetActiveDialog()
    WindowUtils.BeginResize( this, "topleft", 65, 50, false, Hotbar.OnResizeEnd)
end

function Hotbar.OnResizeEnd(curWindow)
	local width, height = WindowGetDimensions(curWindow)
	
	--Debug.Print("Hotbar.OnResizeEnd: "..curWindow.." width: "..width..", height: "..height)
	
	if( width >= height ) then
		-- show the correct handle
		WindowSetShowing(curWindow.."HorizHandle",true)
		WindowSetShowing(curWindow.."VertHandle",false)
		
		-- anchor the first button to the handle
		WindowClearAnchors(curWindow.."Button"..1)
		WindowAddAnchor(curWindow.."Button"..1,"topright",curWindow.."HorizHandle","topleft",0,0)
		
		-- anchor the rest of the buttons to the previous one
		-- and hide the ones that are outside the window
		for slot=2, Hotbar.NUM_BUTTONS do
			local button = curWindow.."Button"..slot
			if( (slot*50) > (width - Hotbar.HANDLE_OFFSET) ) then
				WindowSetShowing(button, false)
			else
				local relativeTo = curWindow.."Button"..(slot-1)
				WindowClearAnchors(button)
				WindowAddAnchor(button,"topright",relativeTo,"topleft",0,0)			
				WindowSetShowing(button, true)
			end
		end
		
		local numVisibleButtons = math.min(math.floor((width-Hotbar.HANDLE_OFFSET)/50),Hotbar.NUM_BUTTONS)
		local newHeight = 50
		local newWidth = math.min((numVisibleButtons * 50) + Hotbar.HANDLE_OFFSET,50*(Hotbar.NUM_BUTTONS+Hotbar.HANDLE_OFFSET))

		WindowSetDimensions(curWindow,newWidth,newHeight)
	else
		-- show the correct handle
		WindowSetShowing(curWindow.."HorizHandle",false)
		WindowSetShowing(curWindow.."VertHandle",true)
		
		-- anchor the first button to the handle
		WindowClearAnchors(curWindow.."Button"..1)
		WindowAddAnchor(curWindow.."Button"..1,"bottomright",curWindow.."VertHandle","topright",0,0)
		
		-- anchor the rest of the buttons to the previous one
		-- and hide the ones that are outside the window
		for slot=2, Hotbar.NUM_BUTTONS do
			local button = curWindow.."Button"..slot
			if( (slot*50) > (height - Hotbar.HANDLE_OFFSET) ) then
				WindowSetShowing(button, false)
			else
				local relativeTo = curWindow.."Button"..(slot-1)
				WindowClearAnchors(button)
				WindowAddAnchor(button,"bottomleft",relativeTo,"topleft",0,0)			
				WindowSetShowing(button, true)
			end
		end

		local numVisibleButtons = math.floor((height-Hotbar.HANDLE_OFFSET)/50)
		local newHeight = math.min((numVisibleButtons * 50) + Hotbar.HANDLE_OFFSET,50*(Hotbar.NUM_BUTTONS+Hotbar.HANDLE_OFFSET))
		local newWidth = 50
		WindowSetDimensions(curWindow,newWidth,newHeight)		
	end
end

function Hotbar.OnPageUp()
	local newPage = (Hotbar.StaticPageNum % 9) + 1
	
	Hotbar.SetPage(newPage)
end

function Hotbar.OnPageDown()
	local newPage = 0
	
	if( Hotbar.StaticPageNum == 1 ) then
		newPage = 9
	else
		newPage = Hotbar.StaticPageNum - 1
	end
	
	Hotbar.SetPage(newPage)
end