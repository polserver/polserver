----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

HotbarSystem = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------
HotbarSystem.RegisteredSpellIcons = {}

HotbarSystem.HighlightSpellIconInput = {}
HotbarSystem.HighlightSpellIconInput.highlightSpellID = 0
HotbarSystem.HighlightSpellIconInput.highlightSpellEnabled = 0

HotbarSystem.ContextReturnCodes = {}
HotbarSystem.ContextReturnCodes.CLEAR_ITEM = 1
HotbarSystem.ContextReturnCodes.ASSIGN_KEY = 2
HotbarSystem.ContextReturnCodes.NEW_HOTBAR = 3
HotbarSystem.ContextReturnCodes.DESTROY_HOTBAR = 4
HotbarSystem.ContextReturnCodes.TARGET_SELF = 5
HotbarSystem.ContextReturnCodes.TARGET_CURRENT = 6
HotbarSystem.ContextReturnCodes.TARGET_CURSOR = 7
HotbarSystem.ContextReturnCodes.EDIT_ITEM = 8
HotbarSystem.ContextReturnCodes.ENABLE_REPEAT = 9
HotbarSystem.ContextReturnCodes.DISABLE_REPEAT = 10

HotbarSystem.TID_CLEAR_ITEM = 1077858
HotbarSystem.TID_ASSIGN_HOTKEY = 1078019
HotbarSystem.TID_NEW_HOTBAR = 1078020
HotbarSystem.TID_DESTROY_HOTBAR = 1078026
HotbarSystem.TID_DESTROY_CONFIRM = 1078027
HotbarSystem.TID_CURSOR = 1078071
HotbarSystem.TID_SELF = 1078072
HotbarSystem.TID_CURRENT = 1078073
HotbarSystem.TID_TARGET = 1078074
HotbarSystem.TID_EDIT_ITEM = 1078196
HotbarSystem.TID_ENABLE_REPEAT = 1079431 -- "Enable Repeating"
HotbarSystem.TID_DISABLE_REPEAT = 1079433 -- "Disable Repeating"

----------------------------------------------------------------
-- MainMenuWindow Functions
----------------------------------------------------------------

HotbarSystem.STATIC_HOTBAR_ID = 1
HotbarSystem.MAX_HOTBAR_ID = 5000

HotbarSystem.TID_ASSIGN_HOTKEY_DESC = 1078096

-- TEMP VARIABLES
HotbarSystem.OffsetX = 945
HotbarSystem.OffsetY = 910
HotbarSystem.OffsetIncrement = -60

HotbarSystem.RegisteredGenericObjectType = {}
HotbarSystem.RegisteredObjects = {}
HotbarSystem.ReferencedTextures = {}
HotbarSystem.ObjectSlots = {}
HotbarSystem.ObjectSlotsSize = {}
HotbarSystem.MacroReferenceSlots = {}

HotbarSystem.DarkItemLabel = { r=245,g=229,b=0 }
HotbarSystem.LightItemLabel = { r=0,g=0,b=0 }

HotbarSystem.NextId = 2

function HotbarSystem.Initialize()
	-- setup the assign key description window
	CreateWindow("AssignHotkeyInfo",false)
	LabelSetText("AssignHotkeyInfoText",GetStringFromTid(HotbarSystem.TID_ASSIGN_HOTKEY_DESC))
	local x, y = LabelGetTextDimensions( "AssignHotkeyInfoText" )
	WindowSetDimensions("AssignHotkeyInfo",x+16,y+16)
		
	-- create a hotbar for each id in the list
	for index, hotbarId in pairs(SystemData.Hotbar.HotbarIds) do
		HotbarSystem.SpawnNewHotbar(hotbarId)
	end
	
	WindowRegisterEventHandler( "Root", WindowData.ObjectInfo.Event, "HotbarSystem.UpdateItemSlot")	
	WindowRegisterEventHandler( "Root", SystemData.Events.MACRO_CHANGED, "HotbarSystem.UpdateMacroReferenceSlot")
	WindowRegisterEventHandler( "Root", SystemData.Events.HOTBAR_HIGHLIGHT_SPELL_ICON, "HotbarSystem.HighlightSpellIcon")
	WindowRegisterEventHandler( "Root", WindowData.ObjectTypeQuantity.Event, "HotbarSystem.UpdateQuantity")

end

function HotbarSystem.Shutdown()
end

function HotbarSystem.DestroyHotbar(hotbarId)
	HotbarUnregister(hotbarId)

	DestroyWindow("Hotbar"..hotbarId)
	-- We dont want to keep track of window positions for hotbars that are permanently destroyed
	WindowUtils.ClearWindowPosition("Hotbar"..hotbarId)
end

function HotbarSystem.SpawnNewHotbar(hotbarId)
	-- If the hotbarId is passed in, this thing is already registered in code (from loading UserSettings)
	local setPosition = false
	if( hotbarId == nil ) then
		hotbarId = HotbarSystem.GetNextHotbarId()
		HotbarRegisterNew(hotbarId)
		setPosition = true
	end
	
	--Debug.Print("HotbarSystem.SpawnNewHotbar: "..hotbarId)
	
	SystemData.DynamicWindowId = hotbarId
	CreateWindowFromTemplate("Hotbar"..hotbarId, "Hotbar", "Root")
	
	-- dynamic hotbars need to have their position generated when created for the first time
	if( setPosition == true ) then
		if( hotbarId ~= HotbarSystem.STATIC_HOTBAR_ID ) then
			WindowClearAnchors("Hotbar"..hotbarId)
			WindowAddAnchor("Hotbar"..hotbarId, "topleft", "Root", "topleft", HotbarSystem.OffsetX, HotbarSystem.OffsetY)
			HotbarSystem.OffsetY = HotbarSystem.OffsetY + HotbarSystem.OffsetIncrement	
			-- when we get to the top, start over at the bottom
			if( HotbarSystem.OffsetY < 0 ) then
			    HotbarSystem.OffsetY = 910
			end
		end
	end
end

function HotbarSystem.GetNextHotbarId()
	-- find the next available id
	local newHotbarId = HotbarSystem.NextId
	
	while newHotbarId ~= HotbarSystem.MAX_HOTBAR_ID do
		local found = false
		for hotbarId, value in pairs(SystemData.Hotbar.HotbarIds) do
			if( hotbarId == newHotbarId ) then
				found = true
			end
		end
		
		if( found ~= true ) then
			break
		end
		
		newHotbarId = newHotbarId + 1
	end
	
	HotbarSystem.NextId = newHotbarId + 1
	
	return newHotbarId
end

function HotbarSystem.SetIconForAction(element, hotbarId, itemIndex, subIndex, isDropped)
	local bSuccess = false
	local bDisabled = false
	local type = UserActionGetType(hotbarId, itemIndex, subIndex)
	local id = UserActionGetId(hotbarId, itemIndex, subIndex)
	local elementIcon = element.."SquareIcon"
	local elementHotkey = element.."Hotkey"
	
	--Debug.Print("HotbarSystem.SetIconForAction: element: "..tostring(element).." hotbarId: "..tostring(hotbarId).." itemIndex: "..tostring(itemIndex).." subIndex: "..tostring(subIndex).." id: "..tostring(id).." type: "..tostring(type))
	
	-- use item is a crazy special case so handle that first
	if( type == SystemData.UserAction.TYPE_USE_ITEM ) then
		if( HotbarSystem.ObjectSlots[id] == nil ) then
			HotbarSystem.ObjectSlots[id] = {}
			HotbarSystem.ObjectSlotsSize[id] = 0
		end
		
		HotbarSystem.ObjectSlotsSize[id] = HotbarSystem.ObjectSlotsSize[id] + 1
			
		HotbarSystem.ObjectSlots[id][element] = {hotbarId=hotbarId, itemIndex=itemIndex, subIndex=subIndex}
		
		-- register for this object if its not already registered
		if( HotbarSystem.RegisteredObjects[element] == nil ) then
			RegisterWindowData(WindowData.ObjectInfo.Type, id)
			HotbarSystem.RegisteredObjects[element] = id		
		end	
	
		local iconId = UserActionUseItemGetIconId(hotbarId,itemIndex,0)
		
		if( isDropped or DoesPlayerHaveItem(id) ) then	
			item = WindowData.ObjectInfo[id]
			
			if( item ~= nil ) then
			    if( item.name ~= nil and item.quantity > 1) then
				    WindowSetDimensions(elementIcon, item.newWidth, item.newHeight)
				    DynamicImageSetTexture(elementIcon, item.iconName, 0, 0 )
				    DynamicImageSetTextureScale(elementIcon, item.iconscale)
				    WindowSetTintColor(elementIcon,item.hue.r,item.hue.g,item.hue.b)
				    WindowSetAlpha(elementIcon,item.hue.a/255)				
    			
				    UserActionUseItemSetIconId(hotbarId,itemIndex,subIndex,item.iconId,0)
			    end
    			
			    if( item.quantity ~= nil) then
				    LabelSetText(element.."Quantity",L""..item.quantity)
			    end
			end
			
			-- drop the item back into the container or paperdoll
			if( isDropped ) then
				SystemData.ActiveObject.SourceId = Cursor.Data.SourceId
				SystemData.ActiveObject.DropSourceType = source
				BroadcastEvent(SystemData.Events.OBJECT_DROP_UI)
			end
			
			LabelSetTextColor(elementHotkey,HotbarSystem.DarkItemLabel.r,HotbarSystem.DarkItemLabel.g,HotbarSystem.DarkItemLabel.b)
			
			bSuccess = true
			
		-- If its not in your pack anymore just use the icon and disable it
		elseif( iconId ~= 0 and iconId ~= nil ) then
			name, x, y, scale, newWidth, newHeight = RequestTileArt(iconId,50,50)
			WindowSetDimensions(elementIcon, newWidth, newHeight)
			DynamicImageSetTexture(elementIcon, name, x, y )
			DynamicImageSetTextureScale(elementIcon, scale)
			
			LabelSetTextColor(elementHotkey,HotbarSystem.DarkItemLabel.r,HotbarSystem.DarkItemLabel.g,HotbarSystem.DarkItemLabel.b)
			
			HotbarSystem.ReferencedTextures[element] = iconId	
			
			bDisabled = true
			bSuccess = true
		end
	-- weapon abilities are also a special case
	elseif (type == SystemData.UserAction.TYPE_USE_OBJECTTYPE) then
		bDisabled, bSuccess = HotbarSystem.SetIconForUseObjectTypeAction(element, hotbarId, itemIndex, subIndex, isDropped, id, elementIcon, elementHotkey, bDisabled, bSuccess )
	elseif (type == SystemData.UserAction.TYPE_WEAPON_ABILITY) then
		EquipmentData.RegisterWeaponAbilitySlot(element,id)
		LabelSetTextColor(elementHotkey,HotbarSystem.LightItemLabel.r,HotbarSystem.LightItemLabel.g,HotbarSystem.LightItemLabel.b)
		
		bSuccess = true
	else
		-- determine the icon id
		local iconId
		if( type == SystemData.UserAction.TYPE_SPELL ) then
			iconId = GetAbilityData(id)
			HotbarSystem.RegisterSpellIcon(element, id)
		elseif type == SystemData.UserAction.TYPE_SKILL then
			-- convert the id to the skill index and get the id for it
			local skillIndex = CSVUtilities.getRowIdWithColumnValue(WindowData.SkillsCSV, "ServerId", id)
			iconId = WindowData.SkillsCSV[skillIndex].IconId	
		elseif type == SystemData.UserAction.TYPE_INVOKE_VIRTUE then
			iconId = VirtueMenu.VirtueData[id].iconId
		elseif type == SystemData.UserAction.TYPE_MACRO_REFERENCE then
			local macroIndex = MacroSystemGetMacroIndexById(id)
			iconId = UserActionMacroGetIconId(MacroWindow.MACROLIST_ID,macroIndex)
			if(	HotbarSystem.MacroReferenceSlots[id] == nil ) then
				HotbarSystem.MacroReferenceSlots[id] = {}
			end
			HotbarSystem.MacroReferenceSlots[id][element] = {hotbarId=hotbarId, itemIndex=itemIndex, subIndex=subIndex}
		else
			-- if it didnt hit any of the special cases then it came from the action window
			local actionData = ActionsWindow.GetActionDataForType(type)
			iconId = actionData.iconId
		end
		
		--Debug.Print("Generic Action: "..tostring(type).." iconId: "..tostring(iconId))
		
		if( iconId ~= nil ) then
			local texture, x, y = GetIconData( iconId )
			WindowSetDimensions(elementIcon, 50, 50)
			DynamicImageSetTexture( elementIcon, texture, x, y )		
			DynamicImageSetTextureScale(elementIcon, 0.78 )
			
			LabelSetTextColor(elementHotkey,HotbarSystem.LightItemLabel.r,HotbarSystem.LightItemLabel.g,HotbarSystem.LightItemLabel.b)
			
			bSuccess = true
		end
	end
	
	if( bSuccess == true ) then
		if( bDisabled == true ) then
			WindowSetShowing(element.."Disabled",true)
			ButtonSetDisabledFlag(element,true)
		else	
			WindowSetShowing(element.."Disabled",false)
			ButtonSetDisabledFlag(element,false)
		end
	end
	
	return bSuccess
end

--Sets the icon for the use objecttype action
function HotbarSystem.SetIconForUseObjectTypeAction(element, hotbarId, itemIndex, subIndex, isDropped, specialId, elementIcon, elementHotkey, bDisabled, bSuccess )
	if( HotbarSystem.ObjectSlots[specialId] == nil ) then
		HotbarSystem.ObjectSlots[specialId] = {}
		HotbarSystem.ObjectSlotsSize[specialId] = 0
	end
	
	HotbarSystem.ObjectSlotsSize[specialId] = HotbarSystem.ObjectSlotsSize[specialId] + 1
	HotbarSystem.ObjectSlots[specialId][element] = {hotbarId=hotbarId, itemIndex=itemIndex, subIndex=subIndex}
	
	local objectType, objectHue = UserActionUseObjectTypeGetObjectTypeHue(specialId)
	--Debug.Print(" specialId "..specialId)
	--Debug.Print("hotbarId "..hotbarId.." itemIndex "..itemIndex.." subIndex "..subIndex)
	--Debug.Print("objectTYpe "..objectType.." objectHue "..objectHue)
	
	--Default to objectType if it can't find the given item
	local iconId = objectType
	
	-- register for this object if its not already registered
	if( HotbarSystem.RegisteredGenericObjectType[element] == nil ) then
	--Debug.Print("REGISTER for OBJECTYPE "..specialId)
		RegisterWindowData(WindowData.ObjectTypeQuantity.Type, specialId)
		HotbarSystem.RegisteredGenericObjectType[element] = specialId		
	end	
	
	item = WindowData.ObjectTypeQuantity[specialId]
	if( isDropped or (item~= nil and item.quantity >= 1) ) then	
		if( item ~= nil ) then
			WindowSetDimensions(elementIcon, item.newWidth, item.newHeight)
			DynamicImageSetTexture(elementIcon, item.iconName, 0, 0 )
			DynamicImageSetTextureScale(elementIcon, item.iconscale)
			WindowSetTintColor(elementIcon,item.hue.r,item.hue.g,item.hue.b)
			WindowSetAlpha(elementIcon,item.hue.a/255)				
		    
			UserActionUseObjectTypeSetIconObjectTypeHue(hotbarId, itemIndex, subIndex, objectType, objectHue)
			LabelSetText(element.."Quantity",L""..item.quantity)
		end
		
		-- drop the item back into the container or paperdoll
		if( isDropped ) then
			SystemData.ActiveObject.SourceId = Cursor.Data.SourceId
			SystemData.ActiveObject.DropSourceType = source
			BroadcastEvent(SystemData.Events.OBJECT_DROP_UI)
		end
		
		LabelSetTextColor(elementHotkey,HotbarSystem.DarkItemLabel.r,HotbarSystem.DarkItemLabel.g,HotbarSystem.DarkItemLabel.b)
		bSuccess = true
		
	-- If its not in your pack anymore just use the icon and disable it
	elseif( iconId ~= nil and iconId ~= 0 ) then
		name, x, y, scale, newWidth, newHeight = RequestTileArt(iconId,50,50)
		WindowSetDimensions(elementIcon, newWidth, newHeight)
		DynamicImageSetTexture(elementIcon, name, x, y )
		DynamicImageSetTextureScale(elementIcon, scale)
		
		LabelSetTextColor(elementHotkey,HotbarSystem.DarkItemLabel.r,HotbarSystem.DarkItemLabel.g,HotbarSystem.DarkItemLabel.b)
		
		HotbarSystem.ReferencedTextures[element] = iconId	
		
		bDisabled = true
		bSuccess = true
	end
	
	return bDisabled, bSuccess
end

function HotbarSystem.ClearActionIcon(element, hotbarId, itemIndex, subIndex, bUnregister)
	local elementIcon = element.."SquareIcon"
	local elementHotkey = element.."Hotkey"
	
	--Debug.Print("HotbarSystem.ClearActionIcon: "..tostring(element).." hotbarId: "..tostring(hotbarId).." itemIndex: "..tostring(itemIndex).." subIndex: "..tostring(subIndex))
	
	WindowSetDimensions(elementIcon, 50, 50)
	DynamicImageSetTexture(elementIcon, "", 0, 0 )
	DynamicImageSetTextureScale(elementIcon, 0.78 )	
	WindowSetTintColor(elementIcon,255,255,255)
	WindowSetAlpha(elementIcon,1.0)
		
	LabelSetTextColor(elementHotkey,HotbarSystem.DarkItemLabel.r,HotbarSystem.DarkItemLabel.g,HotbarSystem.DarkItemLabel.b)
	
	WindowSetShowing(element.."Disabled",false)
	ButtonSetDisabledFlag(element,false)
	
	if( bUnregister == true ) then
		-- clear out the macro reference if necesary
		for itemId, elements in pairs(HotbarSystem.MacroReferenceSlots) do
			elements[element] = nil
			if( table.getn(elements) == 0 ) then
				elements = nil
			end			
		end

		-- clear the weapon ability (this does nothing if its not a weapon ability)
		EquipmentData.UnregisterWeaponAbilitySlot(element)
		-- clear the spell registration (this does nothing if it is not a spell
		HotbarSystem.UnregisterSpellIcon(element)
		
		-- unregister the object info for this slot if necesary
		if( HotbarSystem.RegisteredObjects[element] ~= nil ) then
			local itemId = HotbarSystem.RegisteredObjects[element]
			--Debug.Print("UNREGISTERING HOTBAR OBJECT: "..tostring(hotbarId)..", "..tostring(itemIndex).." itemId: "..tostring(itemId))
			HotbarSystem.ObjectSlots[itemId][element] = nil
			if( HotbarSystem.ObjectSlots[itemId] ~= nil) then
				if( HotbarSystem.ObjectSlotsSize[itemId] == 1 ) then
					HotbarSystem.ObjectSlots[itemId] = nil
				end
				HotbarSystem.ObjectSlotsSize[itemId] = HotbarSystem.ObjectSlotsSize[itemId] - 1
			end			
			
			UnregisterWindowData(WindowData.ObjectInfo.Type,HotbarSystem.RegisteredObjects[element])
			HotbarSystem.RegisteredObjects[element] = nil
		end
		
		-- unregister the generic object type info for this slot if necesary
		if( HotbarSystem.RegisteredGenericObjectType[element] ~= nil) then
			local itemId = HotbarSystem.RegisteredGenericObjectType[element]
			--Debug.Print("UNREGISTERING HOTBAR OBJECT: "..tostring(hotbarId)..", "..tostring(itemIndex).." itemId: "..tostring(itemId).." element "..element)
			
			HotbarSystem.UpdateQuantityForOneSlot(element)
			HotbarSystem.ObjectSlots[itemId][element] = nil
			if( HotbarSystem.ObjectSlots[itemId] ~= nil) then
				if (HotbarSystem.ObjectSlotsSize[itemId] == 1 ) then
					HotbarSystem.ObjectSlots[itemId] = nil
				end
				HotbarSystem.ObjectSlotsSize[itemId] = HotbarSystem.ObjectSlotsSize[itemId] - 1
			end		
			
			
			UnregisterWindowData(WindowData.ObjectTypeQuantity.Type,HotbarSystem.RegisteredGenericObjectType[element])
			HotbarSystem.RegisteredGenericObjectType[element] = nil
		end
		
		if( HotbarSystem.ReferencedTextures[element] ~= nil ) then
			ReleaseTileArt(HotbarSystem.ReferencedTextures[element])
			HotbarSystem.ReferencedTextures[element] = nil
		end
	end
end

function HotbarSystem.UpdateItemSlot()
	local id = WindowData.UpdateInstanceId
	
	if( HotbarSystem.ObjectSlots[id] ~= nil ) then
		-- if the player has this item then enable it
		if( DoesPlayerHaveItem(id) ) then
			for element, itemLoc in pairs(HotbarSystem.ObjectSlots[id]) do
				WindowSetShowing(element.."Disabled",false)
				ButtonSetDisabledFlag(element,false)
					
				local item = WindowData.ObjectInfo[id]	
				
				-- also update the image if it isnt set yet
				local elementIcon = element.."SquareIcon"
				-- always update the hue
				WindowSetTintColor(elementIcon,item.hue.r,item.hue.g,item.hue.b)
				WindowSetAlpha(elementIcon,item.hue.a/255)									
				if( UserActionUseItemGetIconId(itemLoc.hotbarId,itemLoc.itemIndex,itemLoc.subIndex) == 0 ) then
					WindowSetDimensions(elementIcon, item.newWidth, item.newHeight)
					DynamicImageSetTexture(elementIcon, item.iconName, 0, 0 )
					DynamicImageSetTextureScale(elementIcon, item.iconscale)
				
					UserActionUseItemSetIconId(itemLoc.hotbarId,itemLoc.itemIndex,itemLoc.subIndex,item.iconId)
				end			
			end
		-- if this item has left the players backpack then disable it
		else
			for element, itemLoc in pairs(HotbarSystem.ObjectSlots[id]) do
				WindowSetShowing(element.."Disabled",true)
				ButtonSetDisabledFlag(element,true)
			end
		end
	end
end

function HotbarSystem.UpdateQuantityForOneSlot(element)
	local elementIcon = element.."SquareIcon"
	LabelSetText(element.."Quantity",L"")
end

function HotbarSystem.UpdateQuantity()
	local id = WindowData.UpdateInstanceId
	local quantity = 0
	
	if( HotbarSystem.ObjectSlots[id] ~= nil ) then
		local item = WindowData.ObjectTypeQuantity[id]
		
		if( item ~= nil ) then
			quantity = item.quantity
		end

		for element, itemLoc in pairs(HotbarSystem.ObjectSlots[id]) do
			local elementIcon = element.."SquareIcon"
			if(item ~= nil and quantity > 0) then
				WindowSetShowing(element.."Disabled",false)
				ButtonSetDisabledFlag(element,false)
				
				WindowSetDimensions(elementIcon, item.newWidth, item.newHeight)
			    DynamicImageSetTexture(elementIcon, item.iconName, 0, 0 )
			    DynamicImageSetTextureScale(elementIcon, item.iconscale)
			    WindowSetTintColor(elementIcon,item.hue.r,item.hue.g,item.hue.b)
			    WindowSetAlpha(elementIcon,item.hue.a/255)		
			    
				LabelSetText(element.."Quantity",L""..quantity)	
			else
				WindowSetShowing(element.."Disabled",true)
				ButtonSetDisabledFlag(element,true)
				LabelSetText(element.."Quantity",L"")
			end
			
		end
	end
end

function HotbarSystem.UpdateMacroReferenceSlot()
	local id = WindowData.UpdateInstanceId
	
	if( HotbarSystem.MacroReferenceSlots[id] ~= nil ) then
		local macroIndex = MacroSystemGetMacroIndexById(id)
		
		for element, itemLoc in pairs(HotbarSystem.MacroReferenceSlots[id]) do
			-- if macroIndex is 0 then the macro was deleted
			if( macroIndex == 0 ) then
				HotbarSystem.ClearActionIcon(element, itemLoc.hotbarId, itemLoc.itemIndex, itemLoc.subIndex, true)
				-- right now macro references can only exist in the hotbar
				HotbarClearItem(itemLoc.hotbarId,itemLoc.itemIndex)
			-- else the icon might have changed so reset it
			else
				HotbarSystem.SetIconForAction(element, itemLoc.hotbarId, itemLoc.itemIndex, itemLoc.subIndex, false)
			end
		end
	end
end

function HotbarSystem.CreateUserActionContextMenuOptions(hotbarId, itemIndex, subIndex, slotWindow)
	local actionType = UserActionGetType(hotbarId,itemIndex,subIndex)

	--Debug.Print("HotbarSystem.CreateUserActionContextMenuOptions: "..tostring(hotbarId)..", "..tostring(itemIndex)..", "..tostring(subIndex).." actionType: "..tostring(actionType))
	
	local param = {HotbarId=hotbarId, ItemIndex=itemIndex, SubIndex=subIndex, SlotWindow=slotWindow, ActionType=actionType}
	
	ContextMenu.CreateLuaContextMenuItem(HotbarSystem.TID_CLEAR_ITEM,0,HotbarSystem.ContextReturnCodes.CLEAR_ITEM,param)
	
	if( UserActionHasTargetType(hotbarId,itemIndex,subIndex) ) then
		local targetType = UserActionGetTargetType(hotbarId,itemIndex,subIndex)
		-- determine which target type is pressed (add one to type for 1 based lua array)
		local pressed = { false, false, false }
		pressed[targetType+1] = true
		--Debug.Print("TargetType: "..targetType)
		local subMenu = {
			{ tid = HotbarSystem.TID_SELF,flags=0,returnCode=HotbarSystem.ContextReturnCodes.TARGET_SELF,param=param,pressed=pressed[1+SystemData.Hotbar.TargetType.TARGETTYPE_SELF] },
			{ tid = HotbarSystem.TID_CURSOR,flags=0,returnCode=HotbarSystem.ContextReturnCodes.TARGET_CURSOR,param=param,pressed=pressed[1+SystemData.Hotbar.TargetType.TARGETTYPE_CURSOR] },
			{ tid = HotbarSystem.TID_CURRENT,flags=0,returnCode=HotbarSystem.ContextReturnCodes.TARGET_CURRENT,param=param,pressed=pressed[1+SystemData.Hotbar.TargetType.TARGETTYPE_CURRENT] } }

		ContextMenu.CreateLuaContextMenuItem(HotbarSystem.TID_TARGET,0,0,param,false,subMenu) 
	end	
	
	-- if its a macro reference, we need to dereference it for the edit window
	local editParam = {HotbarId=hotbarId, ItemIndex=itemIndex, SubIndex=subIndex, SlotWindow=slotWindow, ActionType=actionType}
	if( actionType == SystemData.UserAction.TYPE_MACRO_REFERENCE ) then
		local macroId = UserActionGetId(hotbarId,itemIndex,0)
		local macroIndex = MacroSystemGetMacroIndexById(macroId)
		editParam.ActionType = SystemData.UserAction.TYPE_MACRO
		editParam.HotbarId = MacroWindow.MACROLIST_ID
		editParam.ItemIndex = macroIndex
		if not UserActionMacroGetRepeatEnabled( editParam.HotbarId, editParam.ItemIndex ) then
			ContextMenu.CreateLuaContextMenuItem(HotbarSystem.TID_ENABLE_REPEAT,0,HotbarSystem.ContextReturnCodes.ENABLE_REPEAT,editParam)
		else
			ContextMenu.CreateLuaContextMenuItem(HotbarSystem.TID_DISABLE_REPEAT,0,HotbarSystem.ContextReturnCodes.DISABLE_REPEAT,editParam)
		end
	end			
	
	local actionData = ActionsWindow.GetActionDataForType(editParam.ActionType)
	if( actionData ~= nil and actionData.editWindow ~= nil ) then
		ContextMenu.CreateLuaContextMenuItem(HotbarSystem.TID_EDIT_ITEM,0,HotbarSystem.ContextReturnCodes.EDIT_ITEM,editParam)
	end
end

function HotbarSystem.ContextMenuCallback(returnCode,param)
	local bHandled = true
	
	if( returnCode == HotbarSystem.ContextReturnCodes.TARGET_SELF ) then
		UserActionSetTargetType(param.HotbarId,param.ItemIndex,param.SubIndex,SystemData.Hotbar.TargetType.TARGETTYPE_SELF)
	elseif( returnCode == HotbarSystem.ContextReturnCodes.TARGET_CURRENT ) then
		UserActionSetTargetType(param.HotbarId,param.ItemIndex,param.SubIndex,SystemData.Hotbar.TargetType.TARGETTYPE_CURRENT)
	elseif( returnCode == HotbarSystem.ContextReturnCodes.TARGET_CURSOR ) then
		UserActionSetTargetType(param.HotbarId,param.ItemIndex,param.SubIndex,SystemData.Hotbar.TargetType.TARGETTYPE_CURSOR)
	elseif( returnCode == HotbarSystem.ContextReturnCodes.EDIT_ITEM ) then		
		ActionEditWindow.OpenEditWindow(param.ActionType,param.SlotWindow,param.HotbarId,param.ItemIndex,param.SubIndex)
	elseif( returnCode == HotbarSystem.ContextReturnCodes.ENABLE_REPEAT ) then
		UserActionMacroSetRepeatEnabled(param.HotbarId,param.ItemIndex,true)
	elseif( returnCode == HotbarSystem.ContextReturnCodes.DISABLE_REPEAT ) then
		UserActionMacroSetRepeatEnabled(param.HotbarId,param.ItemIndex,false)
	else
		bHandled = false
	end
	
	return bHandled
end

function HotbarSystem.RegisterSpellIcon(iconWindow,spellId)
	HotbarSystem.RegisteredSpellIcons[iconWindow] = spellId	
end

function HotbarSystem.UnregisterSpellIcon(iconWindow)
	HotbarSystem.RegisteredSpellIcons[iconWindow] = nil	
end

function HotbarSystem.HighlightSpellIcon()
	local spellId = SystemData.HotbarSystem.HighlightSpellIconInput.highlightSpellID
	local highlightEnabled = SystemData.HotbarSystem.HighlightSpellIconInput.highlightSpellEnabled
	for iconWindow, id in pairs(HotbarSystem.RegisteredSpellIcons) do
		if( iconWindow ~= nil and id == spellId ) then
			if (highlightEnabled ~= 0) then	
				WindowSetTintColor(iconWindow.."SquareIcon",255,0,0)
			else
				WindowSetTintColor(iconWindow.."SquareIcon",255,255,255)
			end
		end
	end
end
