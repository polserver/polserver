----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

Shopkeeper = {}
Shopkeeper.TID ={}
Shopkeeper.TID.SELLABLE		= 1077865		-- SELLABLE ITEMS
Shopkeeper.TID.SALES		= 1077867		-- PENDING SALES
Shopkeeper.TID.NPCSTORE		= 1077868		-- NPC STORE
Shopkeeper.TID.PURCHASES	= 1077869		-- PENDING PURCHASES
Shopkeeper.TID.NPCVENDOR	= 1077870		-- NPC VENDOR
Shopkeeper.TID.Accept		= 1013076		-- Accept
Shopkeeper.TID.Cancel		= 1006045		-- Cancel
--Shopkeeper.TID.Spent		= 1077871		-- "Spent: "
Shopkeeper.TID.Spent		= 1079160		-- Total Gold --3000087	Total 
Shopkeeper.TID.Quantity		= 1077826		-- Quantity
Shopkeeper.TID.Items		= 1077872		-- Items
Shopkeeper.TID.Cost			= 1060034		-- Cost
Shopkeeper.TID.Purchase		= 1011530		-- Purchase
Shopkeeper.TID.All			= 1077866		-- All
Shopkeeper.TID.Remove		= 1011403		-- Remove
Shopkeeper.TID.Clear		= 3000154		-- Clear

----------------------------------------------------------------
-- Shopkeeper Functions
----------------------------------------------------------------
-- Helper function
function Shopkeeper.ReleaseRegisteredObjects(id)
	if( Shopkeeper.RegisteredItems[id] ~= nil ) then
		for id, value in pairs(Shopkeeper.RegisteredItems[id]) do
			UnregisterWindowData(WindowData.ObjectInfo.Type, id)
			UnregisterWindowData(WindowData.ItemProperties.Type, id)
		end
	end
	Shopkeeper.RegisteredItems[id] = {}
end
 
-- OnInitialize Handler
function Shopkeeper.Initialize()
    this = SystemData.ActiveWindow.name
    merchantId = SystemData.DynamicWindowId
    WindowSetId(this, merchantId)

	-- initialize these tables each time the window is opened
	Shopkeeper.SellContainerIds = {}
	Shopkeeper.NumRows = {}
	Shopkeeper.RegisteredItems = {}
	Shopkeeper.PurchasedItems = {}
	Shopkeeper.PurchasedItemsViewOrder = {}
	Shopkeeper.NumPurchasedItems = 0
	Shopkeeper.TotalPurchaseCost = 0	
	Shopkeeper.OfferAccepted = false
	Shopkeeper.PlayerGold = 0

    Shopkeeper.NumRows[merchantId] = 0
    
    Interface.DestroyWindowOnClose[this] = true

	if( WindowData.ShopData.IsSelling == true ) then
		LabelSetText ("StoreName", GetStringFromTid(Shopkeeper.TID.SELLABLE	) )
		LabelSetText ("PurchaseListTitle", GetStringFromTid(Shopkeeper.TID.SALES) )	
		
		Shopkeeper.UpdateSellItems(merchantId)
	else
		-- get the sell container id
		RegisterWindowData(WindowData.ObjectInfo.Type, merchantId)
		local sellContainerId = WindowData.ObjectInfo[merchantId].sellContainerId
		Shopkeeper.SellContainerIds[merchantId] = sellContainerId

		RegisterWindowData(WindowData.ContainerWindow.Type, sellContainerId)
		--WindowRegisterEventHandler(this, WindowData.ContainerWindow.Event, "Shopkeeper.UpdateItems")
		WindowRegisterEventHandler(this, WindowData.ObjectInfo.Event, "Shopkeeper.UpdateObject")
		
		LabelSetText ("StoreName", GetStringFromTid(Shopkeeper.TID.NPCSTORE) )
		LabelSetText ("PurchaseListTitle", GetStringFromTid(Shopkeeper.TID.PURCHASES) )
		
		Shopkeeper.UpdateBuyItems(merchantId, sellContainerId)
	end

	WindowRegisterEventHandler(this, WindowData.ItemProperties.Event, "Shopkeeper.UpdateObjectName")
	
	--Get the amount of gold player has
	WindowRegisterEventHandler(this, WindowData.PlayerStatus.Event, "Shopkeeper.UpdatePlayersGold")
	RegisterWindowData(WindowData.PlayerStatus.Type, 0)
	Shopkeeper.PlayerGold = WindowData.PlayerStatus.Gold
	
    WindowUtils.SetWindowTitle (this, GetStringFromTid(Shopkeeper.TID.NPCVENDOR) )

    ButtonSetText("PurchaseButton", GetStringFromTid(Shopkeeper.TID.Accept))
    ButtonSetText("CancelPurchaseButton", GetStringFromTid(Shopkeeper.TID.Clear))    

    LabelSetText ("TotalCostText", GetStringFromTid(Shopkeeper.TID.Spent))
    LabelSetText ("TotalCostVal", L""..Shopkeeper.TotalPurchaseCost..L"/"..Shopkeeper.PlayerGold)
    
    LabelSetText ("ShopItemsHeaderQuantityHeader", GetStringFromTid(Shopkeeper.TID.Quantity))
    LabelSetText ("ShopItemsHeaderItemNamesHeader", GetStringFromTid(Shopkeeper.TID.Items))
    LabelSetText ("ShopItemsHeaderItemCostsHeader", GetStringFromTid(Shopkeeper.TID.Cost))
    LabelSetText ("ShopItemsHeaderItemPurchaseHeader", GetStringFromTid(Shopkeeper.TID.Purchase))
    
    LabelSetText ("PurchasedItemsHeaderQuantityHeader", GetStringFromTid(Shopkeeper.TID.Quantity))
    LabelSetText ("PurchasedItemsHeaderItemNamesHeader", GetStringFromTid(Shopkeeper.TID.Items))
    LabelSetText ("PurchasedItemsHeaderItemCostsHeader", GetStringFromTid(Shopkeeper.TID.Cost))
    LabelSetText ("PurchasedItemsHeaderItemPurchaseHeader", GetStringFromTid(Shopkeeper.TID.Purchase))            
    
end

function Shopkeeper.Shutdown()	
	local this = SystemData.ActiveWindow.name
	local merchantId = WindowGetId(this)

	UnregisterWindowData(WindowData.PlayerStatus.Type, 0)

	if( WindowData.ShopData.IsSelling == true ) then		
		local numItems = table.getn(WindowData.ShopData.Sell.Types)
		
		for slotIndex=1, numItems do
			UnregisterWindowData(WindowData.ItemProperties.Type,WindowData.ShopData.Sell.Ids[slotIndex])	
			ReleaseTileArt(WindowData.ShopData.Sell.Types[slotIndex])
		end
		
		-- release tile art from the buy side
		for objId, quantity in pairs(Shopkeeper.PurchasedItems) do
			local slotIndex = Shopkeeper.getSlotIndexFromObjId(objId,merchantId)
			ReleaseTileArt(WindowData.ShopData.Sell.Types[slotIndex])
		end
	else
		local sellContainerId = WindowData.ObjectInfo[merchantId].sellContainerId
		Shopkeeper.ReleaseRegisteredObjects(merchantId)
		UnregisterWindowData(WindowData.ContainerWindow.Type,sellContainerId)
		UnregisterWindowData(WindowData.ObjectInfo.Type,merchantId)
	end
	
	if( Shopkeeper.OfferAccepted == false ) then
		BroadcastEvent(SystemData.Events.SHOP_CANCEL_OFFER)
	end	
	
	if( ItemProperties.GetCurrentWindow() == this ) then
		ItemProperties.ClearMouseOverItem()
	end		
	
end
	
function Shopkeeper.UpdatePlayersGold()
	local this = SystemData.ActiveWindow.name
	Shopkeeper.PlayerGold = WindowData.PlayerStatus.Gold
	LabelSetText ("TotalCostVal", L""..Shopkeeper.TotalPurchaseCost..L"/"..Shopkeeper.PlayerGold)
end
				
function Shopkeeper.UpdateRows(id,numItems,windowName)
        local numRows = Shopkeeper.NumRows[id]
        local previousItemName, itemWindowName
        
        if( numRows < numItems ) then
                for i = numRows+1, numItems do
					local itemWindowName = windowName.."ShopItem"..i
                        CreateWindowFromTemplate( itemWindowName, "ShopItemTemplate", "ShopItemsScrollWindowScrollChild" )
                        if (i == 1)  then
                                WindowAddAnchor( itemWindowName, "topleft", "ShopItemsScrollWindowScrollChild", "topleft", 5, 5)
                                myCharSlot = characterSlot 
                        else
                                WindowAddAnchor( itemWindowName, "bottomleft", previousItemName, "topleft", 0, 5)                               
                        end
                        previousItemName = itemWindowName
                        ButtonSetText(itemWindowName.."BuyMore",L"+")
                        ButtonSetText(itemWindowName.."BuyLess",L"-")
                        ButtonSetText(itemWindowName.."BuyAll",GetStringFromTid(Shopkeeper.TID.All))                        
                end
        elseif( numRows > numItems ) then
                for i = numItems+1, numRows do
                        DestroyWindow(windowName.."ShopItem"..i)
                end
        end
        Shopkeeper.NumRows[id] = numItems
end

function Shopkeeper.UpdateSellItems(merchantId)
	local this = "Shopkeeper_"..merchantId
	
	local numItems = table.getn(WindowData.ShopData.Sell.Names)
	
	Shopkeeper.UpdateRows(merchantId,numItems,this)
	
	for slotIndex=1, numItems do
		local objId = WindowData.ShopData.Sell.Ids[slotIndex]
		local quantity = WindowData.ShopData.Sell.Quantities[slotIndex]
		local value = WindowData.ShopData.Sell.Prices[slotIndex]
		local name = Shopkeeper.stripFirstNumber( WindowData.ShopData.Sell.Names[slotIndex] )
		--local name = WindowData.ShopData.Sell.Names[slotIndex]
		local objType = WindowData.ShopData.Sell.Types[slotIndex]
		
		RegisterWindowData(WindowData.ItemProperties.Type, objId)
		
		--Debug.Print(L"ITEM name: "..name)
        LabelSetText(this.."ShopItem"..slotIndex.."Quantity", L""..quantity )
        LabelSetText(this.."ShopItem"..slotIndex.."Name",name)
        LabelSetText(this.."ShopItem"..slotIndex.."Cost",L""..value)
        
        local elementIcon = this.."ShopItem"..slotIndex.."IconHolderSquareIcon"
		Shopkeeper.displaySellIcon(slotIndex,elementIcon)
        
        WindowSetId(this.."ShopItem"..slotIndex.."IconHolderSquareIcon", objId)
        WindowSetId(this.."ShopItem"..slotIndex.."BuyMore", objId)
        WindowSetId(this.."ShopItem"..slotIndex.."BuyLess", objId)
        WindowSetId(this.."ShopItem"..slotIndex.."BuyAll", objId) 		
	end	
	
    ScrollWindowUpdateScrollRect( "ShopItemsScrollWindow" )	
end

function Shopkeeper.UpdateBuyItems(merchantId, containerId)
	--Debug.Print("Shopkeeper.UpdateBuyItems")
    
	this = "Shopkeeper_"..merchantId
	local data = WindowData.ContainerWindow[containerId]
	
	-- Create any contents slots we need
	contents = data.ContainedItems
	numItems = data.numItems

	Shopkeeper.UpdateRows(merchantId,numItems,this)
	
	Shopkeeper.ReleaseRegisteredObjects(merchantId)

	for i = 1, numItems do
		item = data.ContainedItems[i]
		Shopkeeper.RegisteredItems[merchantId][item.objectId] = true
		RegisterWindowData(WindowData.ObjectInfo.Type, item.objectId)
		RegisterWindowData(WindowData.ItemProperties.Type, item.objectId)
	            
		-- perform the initial update of this object
		WindowData.UpdateInstanceId = item.objectId
		Shopkeeper.UpdateObject(this)
	end

    ScrollWindowUpdateScrollRect( "ShopItemsScrollWindow" )	
end

function Shopkeeper.UpdateObject(windowName)
	if( windowName == nil ) then
		windowName = SystemData.ActiveWindow.name
	end
	
	local updateId = WindowData.UpdateInstanceId
	local containerId = WindowData.ObjectInfo[updateId].containerId
	local merchantId = 0
	local found = false
	
	for id, value in pairs(Shopkeeper.SellContainerIds) do
		if( value == containerId ) then
			merchantId = id
			found = true
			break
		end
	end	
	
	-- if this object is in my container
	if( found and merchantId == WindowGetId(windowName) ) then
		-- find the slot index
		local containedItems = WindowData.ContainerWindow[containerId].ContainedItems
		local numItems = WindowData.ContainerWindow[containerId].numItems
		local slotIndex = 0
		for i=1, numItems do
			if( containedItems[i].objectId == updateId ) then
				slotIndex = i
				break
			end
		end

		item = WindowData.ObjectInfo[updateId]

        Shopkeeper.displayBuyIcon(updateId, windowName.."ShopItem"..slotIndex.."IconHolderSquareIcon")
        LabelSetText(windowName.."ShopItem"..slotIndex.."Quantity", L""..item.shopQuantity )
        --LabelSetText(windowName.."ShopItem"..slotIndex.."Name",item.shopName)
        LabelSetText(windowName.."ShopItem"..slotIndex.."Cost",L""..item.shopValue)
        
        WindowSetId(windowName.."ShopItem"..slotIndex.."BuyMore", updateId)
        WindowSetId(windowName.."ShopItem"..slotIndex.."BuyLess", updateId)
        WindowSetId(windowName.."ShopItem"..slotIndex.."BuyAll", updateId)
    end
end

function Shopkeeper.UpdateObjectName(windowName)
	if( windowName == nil ) then
		windowName = SystemData.ActiveWindow.name
	end
	
	local updateId = WindowData.UpdateInstanceId

	if( WindowData.ShopData.IsSelling == true ) then
		local numItems = table.getn(WindowData.ShopData.Sell.Names)
		for slotIndex=1, numItems do
			if( WindowData.ShopData.Sell.Ids[slotIndex] == updateId ) then
				propList = WindowData.ItemProperties[updateId].PropertiesList
				propLen = table.getn(propList)
				
				if( propLen > 0 ) then			
					--ButtonSetText(this.."ShopItem"..slotIndex.."Name",propList[1])
					LabelSetText(this.."ShopItem"..slotIndex.."Name", Shopkeeper.stripFirstNumber(propList[1]) )
				end
			end
		end
	else
		--Debug.Print("updateId = "..tostring(updateId))
		local containerId = WindowData.ObjectInfo[updateId].containerId
		local merchantId = 0
		local found = false
		
		for id, value in pairs(Shopkeeper.SellContainerIds) do
			if( value == containerId ) then
				merchantId = id
				found = true
				break
			end
		end	
		
		-- if this object is in my container
		if( found and merchantId == WindowGetId(windowName) ) then
			-- find the slot index
			local containedItems = WindowData.ContainerWindow[containerId].ContainedItems
			local numItems = WindowData.ContainerWindow[containerId].numItems
			local slotIndex = 0
			for i=1, numItems do
				if( containedItems[i].objectId == updateId ) then
					slotIndex = i
					break
				end
			end
			
			data = WindowData.ItemProperties[updateId]
			propList = data.PropertiesList
			propLen = table.getn(propList)
			
			if( propLen > 0 ) then
				-- chop the amount off
				--ButtonSetText(windowName.."ShopItem"..slotIndex.."Name",propList[1])
				LabelSetText(windowName.."ShopItem"..slotIndex.."Name", Shopkeeper.stripFirstNumber(propList[1]) )
				WindowSetId(windowName.."ShopItem"..slotIndex.."Name", updateId)
			end
		end
	end
end

-- TO DO: UPDATE SHOPKEEPER'S QUANTITY VALUE
function Shopkeeper.BuyMore()
	local this = WindowUtils.GetActiveDialog()
	local merchantId = WindowGetId(this)
    local objId = WindowGetId(SystemData.ActiveWindow.name)
    --Debug.Print("Shopkeeper.BuyMore() objId = "..objId)
    
    local name, cost, quantity, slotIndex = Shopkeeper.getItemData(merchantId,objId)
	
    if (Shopkeeper.PurchasedItems[objId] == nil) then
        Shopkeeper.AddItemToPurchaseList(objId, 1)
        Shopkeeper.TotalPurchaseCost = Shopkeeper.TotalPurchaseCost + cost
    else
		-- verify our pending purchase of that item is not maxed out
		if ( Shopkeeper.PurchasedItems[objId] < quantity ) then 
			local numItems = Shopkeeper.PurchasedItems[objId] + 1
			LabelSetText("PurchasedItem"..tostring(objId).."Quantity",L""..numItems)
			local itemsCost = cost * numItems
			LabelSetText("PurchasedItem"..tostring(objId).."Cost",L""..itemsCost)
			Shopkeeper.PurchasedItems[objId] =  numItems
			Shopkeeper.TotalPurchaseCost = Shopkeeper.TotalPurchaseCost + cost
			-- update source quantity
			LabelSetText(this.."ShopItem"..slotIndex.."Quantity", L""..(quantity - numItems))				
		end		
    end

    LabelSetText ("TotalCostVal", L""..Shopkeeper.TotalPurchaseCost..L"/"..Shopkeeper.PlayerGold)
end

-- TO DO: UPDATE SHOPKEEPER'S QUANTITY VALUE
function Shopkeeper.BuyLess()
		local this = WindowUtils.GetActiveDialog()
        local objId = WindowGetId(SystemData.ActiveWindow.name)
        local merchantId = WindowGetId(this)
        local objViewOrder = nil
        --Debug.Print("Shopkeeper.BuyLess() objId = "..objId)

        local name, cost, quantity, slotIndex = Shopkeeper.getItemData(merchantId,objId)

        if (Shopkeeper.PurchasedItems[objId] ~= nil) then
                local numItems = Shopkeeper.PurchasedItems[objId] - 1
                if (numItems > 0) then 
                        LabelSetText("PurchasedItem"..tostring(objId).."Quantity",L""..numItems)
                        local itemsCost = cost * numItems
                        LabelSetText("PurchasedItem"..tostring(objId).."Cost",L""..itemsCost)
                        Shopkeeper.PurchasedItems[objId] =  numItems
                else
                        --Debug.Print("Shopkeeper.BuyLess() REMOVING OBJECT !!!"..objId)
                        -- Find the item in the purchase list
                        for i = 1,Shopkeeper.NumPurchasedItems do
                                if (Shopkeeper.PurchasedItemsViewOrder[i] == objId) then
                                        objViewOrder = i                                        
                                        break
                                end 
                        end
                        
                        -- if we found him, destroy it and adjust anchor of next item, and reorder the vieworder list
                        if( objViewOrder ~= nil ) then
                            --Debug.Print("Shopkeeper.BuyLess() removing objId: " ..objId)
                            --Debug.Print("Shopkeeper.BuyLess() removing objViewOrder: " ..objViewOrder)
                            DestroyWindow("PurchasedItem"..objId)   
                            
                            if( objViewOrder < Shopkeeper.NumPurchasedItems ) then
								WindowClearAnchors( "PurchasedItem"..Shopkeeper.PurchasedItemsViewOrder[objViewOrder+1])
								if (objViewOrder == 1) then
										WindowAddAnchor( "PurchasedItem"..Shopkeeper.PurchasedItemsViewOrder[objViewOrder+1], "topleft", "PurchasedItemsScrollWindowScrollChild", "topleft", 5, 5)        
								else
										WindowAddAnchor( "PurchasedItem"..Shopkeeper.PurchasedItemsViewOrder[objViewOrder+1], "bottomleft", "PurchasedItem"..Shopkeeper.PurchasedItemsViewOrder[objViewOrder-1], "topleft", 0, 5)                               
								end
								
								for slotIndex = objViewOrder, Shopkeeper.NumPurchasedItems - 1 do
									Shopkeeper.PurchasedItemsViewOrder[slotIndex] = Shopkeeper.PurchasedItemsViewOrder[slotIndex+1]
								end
                            end
                            Shopkeeper.PurchasedItemsViewOrder[Shopkeeper.NumPurchasedItems] = nil

                            Shopkeeper.NumPurchasedItems = Shopkeeper.NumPurchasedItems - 1
                        end                        

                        Shopkeeper.PurchasedItems[objId] = nil                
                end
                Shopkeeper.TotalPurchaseCost = Shopkeeper.TotalPurchaseCost - cost
                LabelSetText ("TotalCostVal", L""..Shopkeeper.TotalPurchaseCost..L"/"..Shopkeeper.PlayerGold)  
				-- update source quantity
				local numItems = 0
				if( Shopkeeper.PurchasedItems[objId] ~= nil ) then 
					numItems = Shopkeeper.PurchasedItems[objId]
				end
				LabelSetText(this.."ShopItem"..slotIndex.."Quantity", L""..(quantity - numItems))                                  
        end
        
		ScrollWindowUpdateScrollRect( "PurchasedItemsScrollWindow" )
end

function Shopkeeper.BuyAll()

    local objId = WindowGetId(SystemData.ActiveWindow.name)
	Shopkeeper.BuyAllForID(objId)
end

function Shopkeeper.BuyAllForID(objId)

	--Debug.Print("BuyAllForID: objId = "..objId)
	
    local this = WindowUtils.GetActiveDialog()
    local merchantId = WindowGetId(this)

    local name, cost, quantity, slotIndex = Shopkeeper.getItemData(merchantId,objId)

    -- IF HITTING "Remove" FROM THE RIGHT WINDOW, YOU WANT TO CLEAR THE ITEM FROM THE LIST !!!
    local x,y,purchaseWindow = string.find(SystemData.ActiveWindow.name, "PurchasedItem(.+)")
    
    if ( purchaseWindow ) then
        local numItems = Shopkeeper.PurchasedItems[objId]
        
        -- SET UP A DELETE CONDITION USING Shopkeeper.BuyLess()
        Shopkeeper.PurchasedItems[objId] = 1
        Shopkeeper.BuyLess()

        Shopkeeper.TotalPurchaseCost = Shopkeeper.TotalPurchaseCost - numItems*cost + cost
        LabelSetText(this.."ShopItem"..slotIndex.."Quantity", L""..quantity)
        LabelSetText ("TotalCostVal", L""..Shopkeeper.TotalPurchaseCost..L"/"..Shopkeeper.PlayerGold)
                  
    elseif (Shopkeeper.PurchasedItems[objId] == nil) then
        Shopkeeper.AddItemToPurchaseList(objId, quantity)
        local itemsCost = cost * quantity
        LabelSetText("PurchasedItem"..tostring(objId).."Cost",L""..itemsCost)
        Shopkeeper.TotalPurchaseCost = Shopkeeper.TotalPurchaseCost + itemsCost
        LabelSetText ("TotalCostVal", L""..Shopkeeper.TotalPurchaseCost..L"/"..Shopkeeper.PlayerGold)
        -- update source quantity
		LabelSetText(this.."ShopItem"..slotIndex.."Quantity", L""..(0))	
    elseif (Shopkeeper.PurchasedItems[objId] < quantity) then
        Shopkeeper.PurchasedItems[objId] = quantity
        LabelSetText("PurchasedItem"..tostring(objId).."Quantity",L""..quantity)
		local itemsCost = cost * quantity
		LabelSetText("PurchasedItem"..tostring(objId).."Cost",L""..itemsCost)
		Shopkeeper.TotalPurchaseCost = Shopkeeper.TotalPurchaseCost + cost
		-- update source quantity
		LabelSetText(this.."ShopItem"..slotIndex.."Quantity", L""..(0))	
    end
end

function Shopkeeper.AddItemToPurchaseList(objId, numItems)
	local this = WindowUtils.GetActiveDialog()
	local merchantId = WindowGetId(this)
    local name = nil
    local cost = nil
        
    Shopkeeper.NumPurchasedItems = Shopkeeper.NumPurchasedItems + 1
    CreateWindowFromTemplate( "PurchasedItem"..objId, "ShopItemTemplate", "PurchasedItemsScrollWindowScrollChild" )        
        
    if (Shopkeeper.NumPurchasedItems == 1) then
            WindowAddAnchor( "PurchasedItem"..objId, "topleft", "PurchasedItemsScrollWindowScrollChild", "topleft", 5, 5)        
    else
            WindowAddAnchor( "PurchasedItem"..objId, "bottomleft", "PurchasedItem"..Shopkeeper.PurchasedItemsViewOrder[Shopkeeper.NumPurchasedItems - 1], "topleft", 0, 5)                               
    end           
    
	local name, cost, quantity, slotIndex = Shopkeeper.getItemData(merchantId,objId,"PurchasedItem"..tostring(objId).."IconHolderSquareIcon")

    LabelSetText("PurchasedItem"..tostring(objId).."Quantity",L""..numItems)
    ButtonSetText("PurchasedItem"..tostring(objId).."BuyMore",L"+")
    ButtonSetText("PurchasedItem"..tostring(objId).."BuyLess",L"-")
    ButtonSetText("PurchasedItem"..tostring(objId).."BuyAll",GetStringFromTid(Shopkeeper.TID.Remove))

    WindowSetId("PurchasedItem"..objId.."BuyMore", objId)
    WindowSetId("PurchasedItem"..objId.."BuyLess", objId)
    WindowSetId("PurchasedItem"..objId.."BuyAll", objId)

    LabelSetText("PurchasedItem"..tostring(objId).."Name", Shopkeeper.stripFirstNumber(name) )
    --ButtonSetText("PurchasedItem"..tostring(objId).."Name",name)
    LabelSetText("PurchasedItem"..tostring(objId).."Cost",L""..cost)
    
    Shopkeeper.PurchasedItems[objId] = numItems
    Shopkeeper.PurchasedItemsViewOrder[Shopkeeper.NumPurchasedItems] = objId
    
    -- update source quantity
    LabelSetText(this.."ShopItem"..slotIndex.."Quantity", L""..(quantity - numItems))
    
    ScrollWindowUpdateScrollRect("PurchasedItemsScrollWindow")   
end

-- TO DO: USE Shopkeeper.PurchasedItems
function Shopkeeper.purchaseItems()
	local this = WindowUtils.GetActiveDialog()
	local merchantId = WindowGetId(this)
	
	local itemIndex = 1
	for objId, buyQuantity in pairs(Shopkeeper.PurchasedItems) do
		local name, cost, quantity, slotIndex = Shopkeeper.getItemData(merchantId,objId)
		
		WindowData.ShopData.OfferIds[itemIndex] = objId
		WindowData.ShopData.OfferQuantities[itemIndex] = buyQuantity
		
		itemIndex = itemIndex + 1
	end
	
	BroadcastEvent(SystemData.Events.SHOP_OFFER_ACCEPT)
	
	-- this lets the shutdown method know that the offer went through
	Shopkeeper.OfferAccepted = true
	
	DestroyWindow(this)
end

function Shopkeeper.cancelPurchase()
--Debug.Print("Shopkeeper.cancelPurchase")

    for i = 1,Shopkeeper.NumPurchasedItems do
 
        -- BuyAll is actually the Remove action for the right window
		--Shopkeeper.BuyAllForID(Shopkeeper.PurchasedItemsViewOrder[i])
		
    	WindowClearAnchors( "PurchasedItem"..Shopkeeper.PurchasedItemsViewOrder[i])
        DestroyWindow("PurchasedItem"..Shopkeeper.PurchasedItemsViewOrder[i])       
    end
    
	Shopkeeper.SellContainerIds = {}
	Shopkeeper.NumRows = {}
	Shopkeeper.RegisteredItems = {}
	Shopkeeper.PurchasedItems = {}
	Shopkeeper.PurchasedItemsViewOrder = {}
	Shopkeeper.NumPurchasedItems = 0
	Shopkeeper.TotalPurchaseCost = 0	    
    
    LabelSetText ("TotalCostVal", L""..Shopkeeper.TotalPurchaseCost..L"/"..Shopkeeper.PlayerGold)
    
	local this = SystemData.ActiveWindow.name
	local merchantId = WindowGetId(this)
    --Shopkeeper.UpdateSellItems(merchantId)
    
	ScrollWindowSetOffset( "PurchasedItemsScrollWindow", 0 )
	ScrollWindowUpdateScrollRect( "PurchasedItemsScrollWindow" )
	ScrollWindowSetOffset( "ShopItemsScrollWindow", 0 )
    ScrollWindowUpdateScrollRect("ShopItemsScrollWindow")   
end

function Shopkeeper.displaySellIcon(slotIndex, iconWindowName)
	local objType = WindowData.ShopData.Sell.Types[slotIndex]

	name, x, y, scale, newWidth, newHeight = RequestTileArt(objType,30,30)
	WindowSetDimensions(iconWindowName, newWidth, newHeight)
	DynamicImageSetTexture(iconWindowName, name, x, y )
	DynamicImageSetTextureScale(iconWindowName, scale)		
end

function Shopkeeper.getSlotIndexFromObjId(objId,merchantId)
	local slotIndex = 0
	if( WindowData.ShopData.IsSelling ) then	
		for i=1, table.getn(WindowData.ShopData.Sell.Ids) do
			if( WindowData.ShopData.Sell.Ids[i] == objId ) then
				slotIndex = i
				break
			end
		end
	else
		-- find the slot index
		local sellContainerId = WindowData.ObjectInfo[merchantId].sellContainerId
		local containedItems = WindowData.ContainerWindow[sellContainerId].ContainedItems
		local numItems = WindowData.ContainerWindow[sellContainerId].numItems
		for i=1, numItems do
			if( containedItems[i].objectId == objId ) then
				slotIndex = i
				break
			end
		end	
	end
	
	return slotIndex
end

function Shopkeeper.displayBuyIcon(objId, iconWindowName)
        local item = WindowData.ObjectInfo[objId]

        if( item.iconName ~= "" ) then
                WindowSetDimensions(iconWindowName, item.newWidth, item.newHeight)		
		DynamicImageSetTexture(iconWindowName, item.iconName, 0, 0 )
			
		DynamicImageSetTextureScale(iconWindowName, item.iconscale)
			
		WindowSetTintColor(iconWindowName,item.hue.r,item.hue.g,item.hue.b)
		WindowSetAlpha(iconWindowName,item.hue.a/255)			
			
		--parent = WindowGetParent(iconWindowName)
		--WindowClearAnchors(iconWindowName)
		--WindowAddAnchor(iconWindowName, "topleft", parent, "topleft", 15+((40-item.newWidth)/2), 15+((40-item.newHeight)/2))
			
		WindowSetShowing(iconWindowName, true)
	else
		WindowSetShowing(iconWindowName, false)
	end
        WindowSetId(iconWindowName, objId)
end

function Shopkeeper.getItemData(merchantId,objId,iconWindow)
	local name = nil
	local cost = nil
	local quantity = nil
	local slotIndex = nil
	
	slotIndex = Shopkeeper.getSlotIndexFromObjId(objId,merchantId)
	--Debug.Print("slotIndex: "..slotIndex)
	if( WindowData.ShopData.IsSelling ) then
		--name = WindowData.ShopData.Sell.Names[slotIndex]
		name = Shopkeeper.stripFirstNumber( WindowData.ShopData.Sell.Names[slotIndex] )
		cost = WindowData.ShopData.Sell.Prices[slotIndex]	
		quantity = WindowData.ShopData.Sell.Quantities[slotIndex]	
		
		if( iconWindow ) then
			Shopkeeper.displaySellIcon(slotIndex,iconWindow)
		end
	else	
		local data = WindowData.ItemProperties[objId]
		local propList = data.PropertiesList
		local propLen = table.getn(propList)
	     
		if( propLen > 0 ) then
				--name=propList[1]
				name=Shopkeeper.stripFirstNumber(propList[1])
		end

        cost = WindowData.ObjectInfo[objId].shopValue	
        quantity = WindowData.ObjectInfo[objId].shopQuantity	
        
		if( iconWindow ) then
			Shopkeeper.displayBuyIcon(objId,iconWindow)
		end        	
	end
	
	--Debug.Print(L"name: "..name)
	--Debug.Print(L" cost: "..cost)
	--Debug.Print(L" quantity: "..quantity)
	return name, cost, quantity, slotIndex
end

function Shopkeeper.ItemMouseOver()
	local this = SystemData.ActiveWindow.name
	local objectId = WindowGetId(this)
	local dialog = WindowUtils.GetActiveDialog()
	
	if objectId then
		local itemData = { windowName = dialog,
						   itemId = objectId,
						   itemType = ItemProperties.type.TYPE_ITEM }
		ItemProperties.SetActiveItem(itemData)
	end
end

function Shopkeeper.stripFirstNumber(wStr)
	local tempStr = wstring.gsub(wStr, L"^%d* ", L"" )
	return tempStr
end

