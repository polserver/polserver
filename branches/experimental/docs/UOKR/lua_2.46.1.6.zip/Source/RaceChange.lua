----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

RaceChangeWindow = {}

local WindowName

local RCWskinColor 
local RCWhairStyle 
local RCWhairColor
local RCWfacialHairStyle
local RCWfacialHairColor

local RCWrace
local RCWgender

local WindowList = {}

function RaceChangeWindow.Initialize()
	Debug.PrintToDebugConsole(L"RaceChangeWindow.Initialize started")
	WindowName = SystemData.ActiveWindow.name


--	Debug.PrintToDebugConsole(L"Gender= "..StringToWString(tostring( WindowData.RaceChange.Gender)))
--	Debug.PrintToDebugConsole(L"Race= "..StringToWString(tostring( WindowData.RaceChange.Race)))

--	Debug.PrintToDebugConsole(L"win name= "..StringToWString(SystemData.ActiveWindow.name))

	
    ButtonSetText (WindowName.."OkButton", L"Ok")
    
    --LabelSetText( WindowName.."Text", GetStringFromTid(CharacterCreation.TID.Appearance))
    LabelSetText( WindowName.."SkinLabel", GetStringFromTid(CharacterCreation.TID.SelectFace))
    LabelSetText( WindowName.."SkinColorLabel", GetStringFromTid(CharacterCreation.TID.SkinTone))
    LabelSetText( WindowName.."HairLabel", GetStringFromTid(CharacterCreation.TID.HairStyle))
    LabelSetText( WindowName.."HairColorLabel", GetStringFromTid(CharacterCreation.TID.HairColor))
    LabelSetText( WindowName.."FacialHairLabel", GetStringFromTid(CharacterCreation.TID.FacialHairStyle))
    LabelSetText( WindowName.."FacialHairColorLabel", GetStringFromTid(CharacterCreation.TID.FacialHairColor ))


    UOBuildTableFromCSV ("Data/GameData/characterhues.csv", "CharacterHuesCSV")
    UOBuildTableFromCSV ("Data/GameData/characterrace.csv", "RacesCSV")
    UOBuildTableFromCSV ("Data/GameData/elfhairhues.csv", "ElfHairHuesCSV")
    UOBuildTableFromCSV ("Data/GameData/elfskinhues.csv", "ElfSkinHuesCSV")
    UOBuildTableFromCSV ("Data/GameData/facialhairstyle.csv", "FacialHairstylesCSV")
    UOBuildTableFromCSV ("Data/GameData/femaleelfhairstyle.csv", "FemaleElfHairstylesCSV")
    UOBuildTableFromCSV ("Data/GameData/femalehumanhairstyle.csv", "FemaleHumanHairstylesCSV")
    UOBuildTableFromCSV ("Data/GameData/maleelfhairstyle.csv", "MaleElfHairstylesCSV")
    UOBuildTableFromCSV ("Data/GameData/malehumanhairstyle.csv", "MaleHumanHairstylesCSV")
    UOBuildTableFromCSV ("Data/GameData/facestyles.csv", "FacesCSV")

	RCWrace = WindowData.RaceChange.Race
	RCWgender = WindowData.RaceChange.Gender
	
	if (RCWrace == 1) then
		WindowUtils.SetWindowTitle (WindowName, GetStringFromTid (1079262)) --"Change Race To Human"
	else
		WindowUtils.SetWindowTitle (WindowName, GetStringFromTid (1079444)) --"Change Race To Elf"	
	end
	

	if (RCWrace == 1) then
		-- SETUP DEFAULT HUMAN COLOR PICKER WINDOWS
		-- TO DO: GET HUES FROM RESPECTIVE CSV FILE !!!
		local colorPickerWindowName = nil
		local switch = false
		local colorTable = {}
		local startHue = nil
		local maxHue = nil
		local defaultHue = nil
		for key, colorPickerName in pairs({"Skin", "Hair", "FacialHair"}) do
			colorPickerWindowName = WindowName..colorPickerName.."ColorPicker"
			table.insert (WindowList, colorPickerWindowName)

			CreateWindowFromTemplate( colorPickerWindowName, "ColorPickerWindowTemplate", "Root" )
	        
			if (colorPickerName == "Skin") then
				startHue = 1002
				maxHue = 1057
				defaultHue =  1010
				RCWskinColor = defaultHue
			elseif (colorPickerName == "Hair") then
		 		startHue = 1102
		 		maxHue = 1148
		 		defaultHue = 1130
				RCWhairColor = defaultHue

			elseif (colorPickerName == "FacialHair") then
				startHue =  1102
				maxHue = 1148
				defaultHue =  1123
				RCWfacialHairColor = defaultHue
			end
			 
			colorTable = {} 
			
			local i = 1 
			for hue=startHue,maxHue do
				colorTable[i]= hue
				i = i + 1  
			end
			
			ColorPickerWindow.SetColorTable(colorTable, colorPickerWindowName)
			 		
			ColorPickerWindow.SetNumColorsPerRow(7)
	        
			ColorPickerWindow.DrawColorTable(colorPickerWindowName)
  			WindowClearAnchors (colorPickerWindowName)
			WindowAddAnchor( colorPickerWindowName, "bottomleft", WindowName.."FacialHair", "topleft", 30, 10)
			WindowSetShowing( colorPickerWindowName, false)


		end

    else
		-- CREATE ELF SKIN & HAIR COLOR PICKER WINDOWS
		for key, colorPickerName in pairs({"ElfSkin", "ElfHair"}) do
			colorPickerWindowName = WindowName..colorPickerName.."ColorPicker"

			CreateWindowFromTemplate( colorPickerWindowName, "ColorPickerWindowTemplate", "Root" )

			colorTable = {}

			if colorPickerName == "ElfSkin" then
				defaultHue =  1245
				RCWskinColor = defaultHue
				local numHues = CSVUtilities.getNumRows(WindowData.ElfSkinHuesCSV)

				for hueIndex = 1,numHues do
					colorTable[hueIndex] = WindowData.ElfSkinHuesCSV[hueIndex].ElfSkinHues
				end
			elseif colorPickerName == "ElfHair" then
				defaultHue =  52
				RCWhairColor = defaultHue
				local numHues = CSVUtilities.getNumRows(WindowData.ElfHairHuesCSV)
				for hueIndex = 1,numHues do
					if (WindowData.ElfHairHuesCSV[hueIndex].ElfHairHues) then
						colorTable[hueIndex] = WindowData.ElfHairHuesCSV[hueIndex].ElfHairHues
					end
				end
			end
			
			-- default these to 0 since they have to be set to something
			RCWfacialHairColor = 0
			RCWfacialHairStyle = 0
			
			ColorPickerWindow.SetColorTable(colorTable, colorPickerWindowName)

			ColorPickerWindow.SetNumColorsPerRow(7)
			ColorPickerWindow.DrawColorTable(colorPickerWindowName)

			ColorPickerWindow.SetHue(defaultHue, colorPickerWindowName)

  			WindowClearAnchors (colorPickerWindowName)
  			WindowAddAnchor( colorPickerWindowName, "bottomleft", WindowName.."Hair", "topleft", 30, 10)
			WindowSetShowing( colorPickerWindowName, false)
		end
	end


	--  if you are currently human then show the elf model.  Gender stays the same
	-- race has been set by the server
	if (RCWrace == 1) then
		-- becoming a human
		RCWrace = 0

		ColorPickerWindow.SetHue(RCWskinColor, WindowName.."SkinColorPicker")
		ColorPickerWindow.SetHue(RCWhairColor, WindowName.."HairColorPicker")

		if (RCWgender == 0) then -- male
			RCWhairStyles = CharacterCreation.createWearableTable(WindowData.MaleHumanHairstylesCSV)
			RCWhairStyle  = WindowData.MaleHumanHairstylesCSV[2].TileArtId
			RCWfacialHairStyles = CharacterCreation.createWearableTable(WindowData.FacialHairstylesCSV)
			RCWfacialHairStyle = 0

		else
			RCWhairStyles = CharacterCreation.createWearableTable(WindowData.FemaleHumanHairstylesCSV)
			RCWhairStyle  = WindowData.FemaleHumanHairstylesCSV[2].TileArtId
			RCWfacialHairStyle = 0
		
		end
	end
	if (RCWrace == 2) then 
		-- becoming elf
		RCWrace = 1

		if (RCWgender == 0) then -- male
			RCWhairStyles = CharacterCreation.createWearableTable(WindowData.MaleElfHairstylesCSV)
			RCWhairStyle  = WindowData.MaleElfHairstylesCSV[2].TileArtId
			RCWfacialHairStyles = CharacterCreation.createWearableTable(WindowData.FacialHairstylesCSV)
			RCWfacialHairStyle  = 0

		else
			RCWhairStyles = CharacterCreation.createWearableTable(WindowData.FemaleElfHairstylesCSV)
			RCWhairStyle  = WindowData.FemaleElfHairstylesCSV[2].TileArtId
			RCWfacialHairStyle  = 0
		
		end

		ColorPickerWindow.SetHue(RCWskinColor, WindowName.."ElfSkinColorPicker")
		ColorPickerWindow.SetHue(RCWhairColor, WindowName.."ElfHairColorPicker")

		-- don't show facial hair stuff for elvees
		WindowSetShowing (WindowName.."FacialHairLabel", false)
		WindowSetShowing (WindowName.."FacialHairStyle", false)
		WindowSetShowing (WindowName.."FacialHairBackground", false)
		WindowSetShowing (WindowName.."FacialHairUpButton", false)
		WindowSetShowing (WindowName.."FacialHairDownButton", false)

		WindowSetShowing (WindowName.."FacialHairColor", false)
		WindowSetShowing (WindowName.."FacialHairColorLabel", false)

	end
	
	-- update the current name of hair type and facial hair type
	local index = RaceChangeWindow.updateWearableItemIndex(RCWhairStyles, "HairStyle", RCWhairStyle, true)
	RCWhairStyle = RCWhairStyles[index].id

	-- don't show facial hair stuff for elves
	if (RCWrace == 0) then
		index = RaceChangeWindow.updateWearableItemIndex(RCWfacialHairStyles, "FacialHairStyle", RCWfacialHairStyle, true)
		RCWfacialHairStyle = RCWfacialHairStyles[index].id
	end
	
	RaceChangeWindow.ColorSkin()
	RaceChangeWindow.ColorHair()
	
	-- don't show facial hair stuff for elves
	if (RCWrace == 0) then
		RaceChangeWindow.ColorFacialHair()
	end
	
	-- hide the face change selector
	WindowSetShowing (WindowName.."SkinLabel", false)
	WindowSetShowing (WindowName.."SkinStyle", false)
	WindowSetShowing (WindowName.."SkinBackground", false)
	WindowSetShowing (WindowName.."SkinUpButton", false)
	WindowSetShowing (WindowName.."SkinDownButton", false)

	
	Interface.OnCloseCallBack[WindowName] = RaceChangeWindow.UserClosedWindow


end

function RaceChangeWindow.HandleOkButton()

--	Debug.PrintToDebugConsole(L"RaceChangeWindow.HandleOkButton() - skin color =  "..StringToWString(tostring(RCWskinColor)))
--	Debug.PrintToDebugConsole(L"RaceChangeWindow.HandleOkButton() - RCWhairStyle =  "..StringToWString(tostring(RCWhairStyle)))
--	Debug.PrintToDebugConsole(L"RaceChangeWindow.HandleOkButton() - RCWhairColor =  "..StringToWString(tostring(RCWhairColor)))
--	Debug.PrintToDebugConsole(L"RaceChangeWindow.HandleOkButton() - RCWfacialHairStyle =  "..StringToWString(tostring(RCWfacialHairStyle)))
--	Debug.PrintToDebugConsole(L"RaceChangeWindow.HandleOkButton() - RCWfacialHairColor =  "..StringToWString(tostring(RCWfacialHairColor)))
	
	SendRaceChangeResponse(RCWskinColor, RCWhairStyle, RCWhairColor, RCWfacialHairStyle, RCWfacialHairColor)

	RaceChangeWindow.OnCloseWindow()
end

function RaceChangeWindow.UserClosedWindow()
	SendRaceChangeResponse(0, 0, 0, 0, 0)

	RaceChangeWindow.OnCloseWindow()

end

-- helper function to increment or decrement one unit through wearables table
-- increment = true means increment up one
-- increment = false means decrement down one unit
-- increment = nil means don't increment or decrement
function RaceChangeWindow.updateWearableItemIndex(appearanceTable, appearanceLabel, appearanceStyle, increment)

    local appearanceIndex;
	for i,v in ipairs(appearanceTable) do
		if (v.id == appearanceStyle) then
			appearanceIndex = i;
			break;
		end
	end


	local numStyles = table.getn(appearanceTable)

	if (increment) then
	    if (appearanceIndex == numStyles) then
	        appearanceIndex = 1
		else
		    appearanceIndex = appearanceIndex + 1
		end
	elseif (increment == false) then -- decrement
	    if (appearanceIndex == 1) then
	        appearanceIndex = numStyles
		else
		    appearanceIndex = appearanceIndex - 1
		end
	end

	LabelSetText(WindowName..appearanceLabel, GetStringFromTid(appearanceTable[appearanceIndex].tid))
	return appearanceIndex
end

function RaceChangeWindow.ToggleAppearanceItemUp()
	local appearanceIndex

	if SystemData.ActiveWindow.name == WindowName.."HairUpButton" then
		appearanceIndex = RaceChangeWindow.updateWearableItemIndex(RCWhairStyles, "HairStyle", RCWhairStyle, true)
		RCWhairStyle = RCWhairStyles[appearanceIndex].id
	elseif SystemData.ActiveWindow.name == WindowName.."FacialHairUpButton" then
		if (RCWrace == 0) then
			appearanceIndex = RaceChangeWindow.updateWearableItemIndex(RCWfacialHairStyles, "FacialHairStyle", RCWfacialHairStyle, true)
			RCWfacialHairStyle = RCWfacialHairStyles[appearanceIndex].id
		end
	end
end

function RaceChangeWindow.ToggleAppearanceItemDown()
    local appearanceIndex

 	if SystemData.ActiveWindow.name == WindowName.."HairDownButton" then
		appearanceIndex = RaceChangeWindow.updateWearableItemIndex(RCWhairStyles, "HairStyle", RCWhairStyle, false)
		RCWhairStyle = RCWhairStyles[appearanceIndex].id
	elseif SystemData.ActiveWindow.name == WindowName.."FacialHairDownButton" then
		if (RCWrace == 0) then
			appearanceIndex = RaceChangeWindow.updateWearableItemIndex(RCWfacialHairStyles, "FacialHairStyle", RCWfacialHairStyle, false)
			RCWfacialHairStyle = RCWfacialHairStyles[appearanceIndex].id
		end
	end
end

function RaceChangeWindow.ShowColorPicker()
	
	RaceChangeWindow.HideColorPickerWindows()
	
    if (SystemData.ActiveWindow.name == WindowName.."SkinColorBar") then
    	if (RCWrace == 0) then
	        if  (not(WindowGetShowing(WindowName.."SkinColorPicker"))) then
	            WindowSetShowing(WindowName.."SkinColorPicker",true)       
	            ColorPickerWindow.SetAfterColorSelectionFunction(RaceChangeWindow.ColorSkin)
	        else
	            WindowSetShowing(WindowName.."SkinColorPicker",false)        
	        end
	    elseif (RCWrace == 1) then
	    	if  (not(WindowGetShowing(WindowName.."ElfSkinColorPicker"))) then
	            WindowSetShowing(WindowName.."ElfSkinColorPicker",true)       
	            ColorPickerWindow.SetAfterColorSelectionFunction(RaceChangeWindow.ColorSkin)
	        else
	            WindowSetShowing(WindowName.."ElfSkinColorPicker",false)        
	        end
	    end     
    elseif (SystemData.ActiveWindow.name == WindowName.."HairColorBar") then
        if (RCWrace == 0) then
	        if  (not(WindowGetShowing(WindowName.."HairColorPicker"))) then
	            WindowSetShowing(WindowName.."HairColorPicker",true)
	            ColorPickerWindow.SetAfterColorSelectionFunction(RaceChangeWindow.ColorHair)
	        else
	            WindowSetShowing(WindowName.."HairColorPicker",false)
	        end
	    elseif (RCWrace == 1) then
	    	if  (not(WindowGetShowing(WindowName.."ElfHairColorPicker"))) then
	            WindowSetShowing(WindowName.."ElfHairColorPicker",true)
	            ColorPickerWindow.SetAfterColorSelectionFunction(RaceChangeWindow.ColorHair)
	        else
	            WindowSetShowing(WindowName.."ElfHairColorPicker",false)
	        end
	    end
    elseif (SystemData.ActiveWindow.name == WindowName.."FacialHairColorBar") then
		if (RCWrace == 0) then
			if  (not(WindowGetShowing(WindowName.."FacialHairColorPicker"))) then
				WindowSetShowing(WindowName.."FacialHairColorPicker",true)       
				ColorPickerWindow.SetAfterColorSelectionFunction(RaceChangeWindow.ColorFacialHair)
			else
				WindowSetShowing(WindowName.."FacialHairColorPicker",false)        
			end
        end
    end

end

function RaceChangeWindow.ColorSkin()
    local red, green, blue, alpha
    if (RCWrace == 0) then
	    RCWskinColor = ColorPickerWindow.colorSelected[WindowName.."SkinColorPicker"]
	    red, green, blue, alpha  = HueRGBAValue(ColorPickerWindow.colorSelected[WindowName.."SkinColorPicker"])
	elseif (RCWrace == 1) then
	    RCWskinColor = ColorPickerWindow.colorSelected[WindowName.."ElfSkinColorPicker"]
	    red, green, blue, alpha  = HueRGBAValue(ColorPickerWindow.colorSelected[WindowName.."ElfSkinColorPicker"])
	end
    WindowSetTintColor(WindowName.."SkinColorBar", red, green, blue)
    
end

function RaceChangeWindow.ColorHair()
    local red, green, blue, alpha
    if (RCWrace == 0) then
	    RCWhairColor = ColorPickerWindow.colorSelected[WindowName.."HairColorPicker"]
	    red, green, blue, alpha  = HueRGBAValue(ColorPickerWindow.colorSelected[WindowName.."HairColorPicker"])
	elseif (RCWrace == 1) then
	    RCWhairColor = ColorPickerWindow.colorSelected[WindowName.."ElfHairColorPicker"]
	    red, green, blue, alpha  = HueRGBAValue(ColorPickerWindow.colorSelected[WindowName.."ElfHairColorPicker"])
	end
    WindowSetTintColor(WindowName.."HairColorBar", red, green, blue)
    
end

function RaceChangeWindow.ColorFacialHair()
    RCWfacialHairColor = ColorPickerWindow.colorSelected[WindowName.."FacialHairColorPicker"]
    local red, green, blue, alpha  = HueRGBAValue(ColorPickerWindow.colorSelected[WindowName.."FacialHairColorPicker"])
    WindowSetTintColor(WindowName.."FacialHairColorBar", red, green, blue)
    
end 

function RaceChangeWindow.HideColorPickerWindows()
	Debug.PrintToDebugConsole(L"RaceChangeWindow.HideColorPickerWindows")
   if (RCWrace == 0) then
	   WindowSetShowing(WindowName.."SkinColorPicker", false)
	   WindowSetShowing(WindowName.."HairColorPicker", false)
	   WindowSetShowing(WindowName.."FacialHairColorPicker", false)
   else
	   WindowSetShowing(WindowName.."ElfSkinColorPicker", false)
	   WindowSetShowing(WindowName.."ElfHairColorPicker", false)
	end
end

function RaceChangeWindow.DestroyColorPickerWindows()
   if (RCWrace == 0) then
	   DestroyWindow(WindowName.."SkinColorPicker")
	   DestroyWindow(WindowName.."HairColorPicker")
	   DestroyWindow(WindowName.."FacialHairColorPicker")
	else
	   DestroyWindow(WindowName.."ElfSkinColorPicker")
	   DestroyWindow(WindowName.."ElfHairColorPicker")
	end
end


function RaceChangeWindow.Shutdown()
    UOUnloadCSVTable ("RacesCSV")
    UOUnloadCSVTable ("ElfHairHuesCSV")
    UOUnloadCSVTable ("ElfSkinHuesCSV")
    UOUnloadCSVTable ("FacialHairstylesCSV")
    UOUnloadCSVTable ("FemaleElfHairstylesCSV")
    UOUnloadCSVTable ("FemaleHumanHairstylesCSV")
    UOUnloadCSVTable ("MaleElfHairstylesCSV")
    UOUnloadCSVTable ("MaleHumanHairstylesCSV")
    UOUnloadCSVTable ("FacesCSV")
    
   for i = 1, table.getn (WindowList) do
		DestroyWindow (WindowList[i])
   end
   WindowList = {}

	RaceChangeWindow.DestroyColorPickerWindows()
	
end

function RaceChangeWindow.OnCloseWindow()
	RaceChangeWindow.Shutdown()
	DestroyWindow (WindowName)
end

