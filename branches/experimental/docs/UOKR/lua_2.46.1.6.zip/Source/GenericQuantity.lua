
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

GenericQuantity = { }
GenericQuantity.containerId = {}
GenericQuantity.sourceType = {}
GenericQuantity.sourcePos = {}
GenericQuantity.quantityAmount = {}
GenericQuantity.hasGenericWindow = {}
GenericQuantity.maxAmount = 1
----------------------------------------------------------------
-- GenericQuantity Functions
----------------------------------------------------------------
function GenericQuantity.Initialize()
	WindowRegisterEventHandler("Root", SystemData.Events.OBJECT_QUANTITY_WINDOW, "GenericQuantity.CreateFromWorld")
end

--Sets the Window close to where the player dragged their mouse
function GenericQuantity.HandleArchorWindow(genericWindow)
	propWindowWidth = 200
	propWindowHeight = 100
	propWindowWidth = propWindowWidth + 12

	-- Set the window position
	windowOffset = -20
	scaleFactor = 1/InterfaceCore.scale	
	
	mouseX = SystemData.MousePosition.x
	propWindowX = mouseX - windowOffset - (propWindowWidth / scaleFactor)
	if propWindowX < 0 then
		propWindowX = mouseX + windowOffset
	end
		
	mouseY = SystemData.MousePosition.y
	propWindowY = mouseY - windowOffset - (propWindowHeight / scaleFactor)
	if propWindowY < 0 then
		propWindowY = mouseY + windowOffset
	end
	
	WindowAddAnchor(genericWindow, "topleft", "Root", "topleft", 6, 3)
	WindowSetOffsetFromParent(genericWindow, propWindowX * scaleFactor, propWindowY * scaleFactor)
end

function GenericQuantity.GenericCreateWindow(quantity, objectId)
	local windowName = "GenericQuantityWindow"..objectId
	local buttonName = windowName.."Button"
	local sliderName = windowName.."SliderBar"

	if( GenericQuantity.hasGenericWindow[objectId] ~= true) then
		CreateWindowFromTemplate(windowName, "GenericQuantityWindow", "Root")
		GenericQuantity.HandleArchorWindow(windowName)
		Interface.DestroyWindowOnClose[windowName] = true
		TextEditBoxSetText(windowName.."AmountInput", L""..quantity)
		WindowAssignFocus(windowName.."AmountInput", true)
		WindowSetId(windowName, objectId)
		WindowUtils.SetWindowTitle(windowName, GetStringFromTid(1077826) ) -- "Quantity"
		GenericQuantity.quantityAmount[objectId] = quantity
		GenericQuantity.hasGenericWindow[objectId] = true
	
		ButtonSetText(buttonName, GetStringFromTid(3000093) )-- "Okay"
		SliderBarSetCurrentPosition( sliderName, GenericQuantity.maxAmount )
	else
		GenericQuantity.HandleArchorWindow(windowName)
	end	
end

--When the window gets the object from the world
function GenericQuantity.CreateFromWorld()
	local objId = SystemData.ActiveObject.Id
	GenericQuantity.sourceType[objId] = SystemData.ActiveObject.PickUpSourceType
	GenericQuantity.containerId[objId] = SystemData.ActiveObject.SourceId
	GenericQuantity.sourcePos[objId] = {x=SystemData.ActiveObject.SourcePos.x,y=SystemData.ActiveObject.SourcePos.y}
	
	RegisterWindowData(WindowData.ObjectInfo.Type, objId)
	local item = WindowData.ObjectInfo[objId]
	GenericQuantity.GenericCreateWindow(item.quantity, objId)
	UnregisterWindowData(WindowData.ObjectInfo.Type, objId)
end

-- OnInitialize Handler
function GenericQuantity.Create(objectId, quantity, contId, sourcePos )
	GenericQuantity.containerId[objectId] = contId
	GenericQuantity.sourceType[objectId] = SystemData.DragItem.SOURCETYPE_CONTAINER
	GenericQuantity.sourcePos[objectId] = sourcePos
	GenericQuantity.GenericCreateWindow( quantity, objectId)
end

function GenericQuantity.DestroyWindow()
	local id = WindowGetId(WindowUtils.GetActiveDialog())
	local this = "GenericQuantityWindow"..id
	
	GenericQuantity.containerId[id] = nil
	GenericQuantity.sourceType[id] = nil
	GenericQuantity.sourcePos[id] = nil
	GenericQuantity.hasGenericWindow[id] = nil
	--Debug.Print("On destroy Window "..this)
	DestroyWindow(this)
end

function GenericQuantity.Shutdown()
	local id = WindowGetId(WindowUtils.GetActiveDialog())
	local this = "GenericQuantityWindow"..id
	
	GenericQuantity.containerId[id] = nil
	GenericQuantity.sourceType[id] = nil
	GenericQuantity.sourcePos[id] = nil
	GenericQuantity.hasGenericWindow[id] = nil
end

function GenericQuantity.OnKeyEscape()
	GenericQuantity.DestroyWindow()
end
				
function GenericQuantity.OnKeyEnter()
	GenericQuantity.OnOkay()
end

function GenericQuantity.OnTextChanged()
	local id = WindowGetId(WindowUtils.GetActiveDialog())
	--Exit out of text amount if the active window is 0
	if(id == 0) then
		return
	end
	local windowName = "GenericQuantityWindow"..id
	local sliderName = windowName.."SliderBar"
	local quantityLabel = windowName.."AmountInput"

	--Hexadecimal of 0 and 9 and Backspace
	
	local amount = GenericQuantity.quantityAmount[id]
	local quantityInputText = TextEditBoxGetText(quantityLabel)
	local outputNum = nil
	if( quantityInputText ~= nil ) then
	    outputNum = tonumber(WStringToString(quantityInputText))
	end
	
	if( outputNum ~= nil) then	
		if( outputNum > amount ) then
			outputNum = amount
			TextEditBoxSetText(quantityLabel, L""..outputNum)
		end	
		
		local slideAmount =  (outputNum/amount) * GenericQuantity.maxAmount
		SliderBarSetCurrentPosition( sliderName, slideAmount )
	else
		SliderBarSetCurrentPosition( sliderName, 0 )
	end

end

function GenericQuantity.UpdateQuantity()
	local id = WindowGetId(WindowUtils.GetActiveDialog())
	local this = "GenericQuantityWindow"..id
	local quantityLabel = this.."AmountInput"
	local sliderName = this.."SliderBar"
	local amount = GenericQuantity.quantityAmount[id]

	local quantiyAmount = math.floor(amount * SliderBarGetCurrentPosition(sliderName))

	TextEditBoxSetText( quantityLabel, L""..quantiyAmount)
end

function GenericQuantity.OnOkay()
	local id = WindowGetId(WindowUtils.GetActiveDialog())
	local this = "GenericQuantityWindow"..id
	local inputName = this.."AmountInput"
	quantityInputText = TextEditBoxGetText(inputName)
	
	outputNum = tonumber(WStringToString(quantityInputText))
	if (GenericQuantity.sourceType[id] == SystemData.DragItem.SOURCETYPE_CONTAINER) then
		
		Cursor.OnItemDragQuantity(GenericQuantity.sourceType[id], GenericQuantity.containerId[id], GenericQuantity.sourcePos[id], id, outputNum)
	else 
		Cursor.OnItemDragQuantity(GenericQuantity.sourceType[id], 0, {x=0,y=0}, id, outputNum)
	end
	
	GenericQuantity.DestroyWindow()
end
