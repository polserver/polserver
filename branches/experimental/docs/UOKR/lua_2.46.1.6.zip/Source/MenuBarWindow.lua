----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

MenuBarWindow = {}
MenuBarWindow.MenuBarData = {}
--MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleHelp"] = {}
--MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleHelp"].ToolTipTid = 1061037 -- Help
--MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleHelp"].ToggleWindow = nil
--MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleHelp"].KeyBinding = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleMainMenu"] = {}
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleMainMenu"].ToolTipTid = 1049755 -- Main Menu
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleMainMenu"].ToggleWindow = "MainMenuWindow"
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleMainMenu"].KeyBinding = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleMap"] = {}
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleMap"].ToolTipTid = 1077438 -- World Map
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleMap"].ToggleWindow = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleMap"].KeyBinding = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleGuild"] = {}
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleGuild"].ToolTipTid = 1063308 -- Guild
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleGuild"].ToggleWindow = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleGuild"].KeyBinding = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleSkills"] = {}
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleSkills"].ToolTipTid = 3000084 -- Skills
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleSkills"].ToggleWindow = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleSkills"].KeyBinding = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleVirtues"] = {}
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleVirtues"].ToolTipTid = 1077439 -- Virtues
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleVirtues"].ToggleWindow = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleVirtues"].KeyBinding = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleQuests"] = {}
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleQuests"].ToolTipTid = 1077440 -- Quest Journal
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleQuests"].ToggleWindow = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleQuests"].KeyBinding = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarTogglePaperdoll"] = {}
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarTogglePaperdoll"].ToolTipTid = 1077437 -- Character Sheet
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarTogglePaperdoll"].ToggleWindow = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarTogglePaperdoll"].KeyBinding = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleMacros"] = {}
--MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleMacros"].ToolTipTid = 1078506	-- Macros / Actions
--MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleMacros"].ToggleWindow = nil
--MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleMacros"].KeyBinding = nil
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleFriendsList"] = {}
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleFriendsList"].ToolTipTid = 1078517	-- Friends List
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleFriendsList"].ToggleWindow = "FriendsList"
MenuBarWindow.MenuBarData["MenuBarWindowStatusBarToggleFriendsList"].KeyBinding = nil

MenuBarWindow.MenuBarData.WarMode = 0

----------------------------------------------------------------
-- General Functions
----------------------------------------------------------------

function MenuBarWindow.Initialize()
	WindowRegisterEventHandler("MenuBarWindowStatusBar", SystemData.Events.TOGGLE_BACKPACK_WINDOW, "MenuBarWindow.ToggleInventoryWindow")
	WindowRegisterEventHandler("MenuBarWindowStatusBar", SystemData.Events.TOGGLE_PAPERDOLL_CHARACTER_WINDOW, "MenuBarWindow.TogglePaperdollWindow")
	WindowRegisterEventHandler("MenuBarWindowStatusBar", SystemData.Events.TOGGLE_GUILD_WINDOW, "MenuBarWindow.ToggleGuildWindow")
	WindowRegisterEventHandler("MenuBarWindowStatusBar", SystemData.Events.TOGGLE_SKILLS_WINDOW, "MenuBarWindow.ToggleSkillsWindow")
	WindowRegisterEventHandler("MenuBarWindowStatusBar", SystemData.Events.TOGGLE_VIRTUES_WINDOW, "MenuBarWindow.ToggleVirtuesWindow")
	WindowRegisterEventHandler("MenuBarWindowStatusBar", SystemData.Events.TOGGLE_QUEST_LOG_WINDOW, "MenuBarWindow.ToggleQuestWindow")
	WindowRegisterEventHandler("MenuBarWindowStatusBar", SystemData.Events.TOGGLE_HELP_WINDOW, "MenuBarWindow.ToggleHelpWindow")
	WindowRegisterEventHandler("MenuBarWindowStatusBar", SystemData.Events.TOGGLE_WORLD_MAP_WINDOW, "MenuBarWindow.ToggleMapWindow")
    WindowRegisterEventHandler("MenuBarWindowStatusBar", WindowData.PlayerStatus.Event, "MenuBarWindow.ToggleWarMode")

	RegisterWindowData(WindowData.PlayerEquipmentSlot.Type, EquipmentData.EQPOS_BACKPACK)
	RegisterWindowData(WindowData.PlayerStatus.Type, 0)
  	
  	ButtonSetStayDownFlag("MenuBarWarButton", true)	
	
	WindowSetShowing("MenuBarWindowStatusBar",true)
end

function MenuBarWindow.Shutdown()
	UnregisterWindowData(WindowData.PlayerEquipmentSlot.Type, EquipmentData.EQPOS_BACKPACK)
	UnregisterWindowData(WindowData.PlayerStatus.Type, 0)
end

function MenuBarWindow.Update( timePassed )

end

----------------------------------------------------------------
-- Menu Bar Functions
----------------------------------------------------------------

function MenuBarWindow.GetData()
    local windowName = SystemData.ActiveWindow.name
    return MenuBarWindow.MenuBarData[windowName]
end

function MenuBarWindow.OnMouseoverMenuBtn()
	data = MenuBarWindow.GetData()
	btnName = SystemData.ActiveWindow.name
	
	if data ~= nil then
		text = GetStringFromTid(data.ToolTipTid)
		Tooltips.CreateTextOnlyTooltip(btnName, text)
		Tooltips.Finalize()
		Tooltips.AnchorTooltip( Tooltips.ANCHOR_WINDOW_TOP )
	else
		--Debug.Print(L"Tooltip data was nil")
	end 
end

function MenuBarWindow.ToggleMenuButton()	
--Debug.Print( L"Called MenuBarWindow.ToggleMenuButton()" )
	data = MenuBarWindow.GetData()
	
	-- Setting ToggleWindow to nil indicates that we have to use a custom handler
    if (data.ToggleWindow) then
    	ToggleWindowByName(data.ToggleWindow, SystemData.ActiveWindow.name, MenuBarWindow.ToggleMenuButton)	
	else
		--Debug.Print( L"ERROR MenuBarWindow.ToggleMenuButton - no data found for window = "..StringToWString(SystemData.ActiveWindow.name) )
    end
end

function MenuBarWindow.ToggleInventoryWindow()
--Debug.Print( L"Called MenuBarWindow.ToggleInventoryWindow()" )
	local objectId = WindowData.PlayerEquipmentSlot[EquipmentData.EQPOS_BACKPACK].objectId
	
	if( Cursor.IconOnCursor() and Cursor.Data.Type == Cursor.TYPE_ITEM ) then
		SystemData.ActiveObject.SourceId = objectId
		SystemData.ActiveObject.DropSourceType = SystemData.DragItem.SOURCETYPE_OBJECT
		BroadcastEvent(SystemData.Events.OBJECT_DROP_UI)
	else
		local windowName = "ContainerWindow_"..objectId
		local showing
		local my_paperdoll = "PaperdollWindow"..WindowData.PlayerStatus.PlayerId
		local my_paperdoll_backpackicon = "PaperdollWindow"..WindowData.PlayerStatus.PlayerId.."ToggleInventory"
		if(DoesWindowNameExist(windowName)) then
			showing = WindowGetShowing(windowName)
			if (showing) then
				DestroyWindow(windowName)
				if DoesWindowNameExist(my_paperdoll) and WindowGetShowing(my_paperdoll) then
					ButtonSetPressedFlag( my_paperdoll_backpackicon, false )
				end
			else
				UserActionUseItem(objectId,false)
				if DoesWindowNameExist(my_paperdoll) and WindowGetShowing(my_paperdoll) then
					ButtonSetPressedFlag( my_paperdoll_backpackicon, true )
				end
			end
		else
			showing = false
			UserActionUseItem(objectId,false)
			if DoesWindowNameExist(my_paperdoll) and WindowGetShowing(my_paperdoll) then
				ButtonSetPressedFlag( my_paperdoll_backpackicon, true )
			end
		end
	end
end

function MenuBarWindow.ToggleMapWindow()

	if WindowGetShowing("RadarWindow") then
		RadarWindow.ToggleMap()
	elseif WindowGetShowing("MapWindow") then
		WindowSetShowing("MapWindow", false)
		WindowSetShowing("RadarWindow", false) 	
	else
		MapWindow.ToggleRadar()
	end		
end

function MenuBarWindow.ToggleGuildWindow()

	local showing = GuildWindow.getShowing()
	
	-- unlike other MenuBar windows, the Guild Window is dynamic. So it is not just
	--   shown and hidden, but created and destroyed each time
	GuildWindow.ToggleGuildWindow()
end

function MenuBarWindow.ToggleSkillsWindow()
	SkillsWindow.ToggleSkillsWindow()

	-- if window is active, hilite button on menu bar
	local WindowName = "SkillsWindow"
	showing = WindowGetShowing(WindowName)
end

function MenuBarWindow.ToggleVirtuesWindow()
	-- unlike other MenuBar windows, Quest Log is dynamic. So it is not just
	--   shown and hidden, but created and destroyed each time
	VirtueMenu.ToggleVirtueMenuWindow()
end

function MenuBarWindow.ToggleQuestWindow()
	-- unlike other MenuBar windows, Quest Log is dynamic. So it is not just
	--   shown and hidden, but created and destroyed each time
	QuestLog.ToggleQuestLogWindow()
end

function MenuBarWindow.ToggleHelpWindow()

	if HelpMenu == nil then
		Debug.Print(L"MenuBarWindow.ToggleHelpWindow ERROR: Static object HelpMenu not found")
		return
	end
	local showing = HelpMenu.getShowing()
	
	-- unlike other MenuBar windows, Help Menu is dynamic. So it is not just
	--   shown and hidden, but created and destroyed each time
	HelpMenu.ToggleHelpMenu()
end

function MenuBarWindow.TogglePaperdollWindow()
	playerId = WindowData.PlayerStatus.PlayerId
	local windowName = "PaperdollWindow"..playerId

	if(DoesWindowNameExist(windowName)) then
		DestroyWindow(windowName)
	else
	    UserActionUseItem(playerId,true)
	end
end


function MenuBarWindow.ToggleWarMode()
    if( WindowData.PlayerStatus.InWarMode ) then
            MenuBarWindow.MenuBarData.WarMode = 1
            ButtonSetPressedFlag( "MenuBarWarButton", true )          
    else
            MenuBarWindow.MenuBarData.WarMode = 0
            ButtonSetPressedFlag( "MenuBarWarButton", false )
    end
end


function MenuBarWindow.ToggleWarModeButton()
        UserActionToggleWarMode()
end

function MenuBarWindow.ToggleMacrosWindow()
	ToggleWindowByName( "MacroWindow", "", MainMenuWindow.ToggleMacroWindow )
	local macroShowing = WindowGetShowing("MacroWindow")
	WindowSetShowing("ActionsWindow",macroShowing)	
	WindowSetShowing("MainMenuWindow",false)	
end