
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

DebugWindow = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

-- Channel Id's.. These will be moved to code-generated variables soon.

local LuaLog            = {}
LuaLog.SYSTEM           = 1
LuaLog.ERROR            = 2
LuaLog.DEBUG            = 3
LuaLog.FUNCTION         = 4

local InterfaceLog      = {}
InterfaceLog.DEBUG      = 1
InterfaceLog.WARNING    = 2
InterfaceLog.ERROR      = 3

DebugWindow.logging = false

----------------------------------------------------------------
-- DebugWindow Functions
----------------------------------------------------------------

local function UpdateLoggingButton ()

    if ( DebugWindow.logging == true) then
        ButtonSetText("DebugWindowToggleLogging", L"Logs (On)") 
    else
        ButtonSetText("DebugWindowToggleLogging", L"Logs (Off)")
    end

end

-- OnInitialize Handler
function DebugWindow.Initialize()
	
	CreateWindow("DebugWindowOptions",false)
	
	WindowUtils.SetWindowTitle("DebugWindow",L"Debug Window")

    -- Display Settings
    TextLogDisplaySetShowTimestamp( "DebugWindowText", false )
    TextLogDisplaySetShowLogName( "DebugWindowText", true )
    TextLogDisplaySetShowFilterType( "DebugWindowText", true )

     -- Add the Lua Log
    TextLogDisplayAddLog("DebugWindowText", "Lua", true)
    
    TextLogDisplaySetFilterColor("DebugWindowText", "Lua", LuaLog.SYSTEM, 255, 0, 255 ) -- Magenta
    TextLogDisplaySetFilterColor("DebugWindowText", "Lua", LuaLog.ERROR, 255, 0, 0 ) -- Red
    TextLogDisplaySetFilterColor("DebugWindowText", "Lua", LuaLog.DEBUG, 255, 255, 0 ) -- Yellow
    TextLogDisplaySetFilterColor("DebugWindowText", "Lua", LuaLog.FUNCTION, 0, 175, 50 ) -- Green
    
    -- Add the Interface Log    
    TextLogDisplayAddLog("DebugWindowText", "Interface", true)  
    
    TextLogDisplaySetFilterColor("DebugWindowText", "Interface", InterfaceLog.ERROR, 255, 0, 0 ) -- Red 
    TextLogDisplaySetFilterColor("DebugWindowText", "Interface", InterfaceLog.WARNING, 255, 255, 0 ) -- Green
    TextLogDisplaySetFilterColor("DebugWindowText", "Interface", InterfaceLog.DEBUG, 0, 255, 255 ) -- Cyan
    
    ButtonSetText("DebugWindowReloadUi", L"Reload UI")
    
    DebugWindow.logging = TextLogGetEnabled( "Lua" )
    
    UpdateLoggingButton()
    
    WindowSetAlpha("DebugWindow", 0.75)
    
    -- Load settings
    WindowSetShowing("DebugWindow", DevData.DebugWindow.isShowing )
    WindowClearAnchors("DebugWindow")
    WindowAddAnchor("DebugWindow", "topleft", "Root", "topleft", DevData.DebugWindow.screenPos.x, DevData.DebugWindow.screenPos.y )

	if( DevData.DebugWindow.size.x ~= 0 and DevData.DebugWindow.size.y ~= 0 ) then
		WindowSetDimensions("DebugWindow", DevData.DebugWindow.size.x, DevData.DebugWindow.size.y )
	end

	-- Options		
	ButtonSetText( "DebugWindowToggleOptions", L"Options")	
	
	WindowUtils.SetWindowTitle( "DebugWindow", L"Debug Options")
	
	LabelSetText(  "DebugWindowOptionsFiltersTitle", L"Logging Filters:" )
	LabelSetText(  "DebugWindowOptionsFilterType1Label", L"Ui System Messages" )
	LabelSetText(  "DebugWindowOptionsFilterType2Label", L"Error Messages" )
	LabelSetText(  "DebugWindowOptionsFilterType3Label", L"Debug Messages" )
	LabelSetText(  "DebugWindowOptionsFilterType4Label", L"Function Calls Messages" )
	
	for index = 1, 4 do
		ButtonSetStayDownFlag( "DebugWindowOptionsFilterType"..index.."Button", true )
		
		TextLogDisplaySetFilterState( "DebugWindowText", "Lua", index, DevData.DebugWindow.luaFilters[index] )
		ButtonSetPressedFlag( "DebugWindowOptionsFilterType"..index.."Button", DevData.DebugWindow.luaFilters[index] )		
	end

	LabelSetText(  "DebugWindowOptionsErrorHandlingTitle", L"Generate lua-errors from:" )
	LabelSetText(  "DebugWindowOptionsErrorOption1Label", L"Lua calls to ERROR()" )
	LabelSetText(  "DebugWindowOptionsErrorOption2Label", L"Errors in lua calls to C" )
	
	for index = 1, 2 do
		ButtonSetStayDownFlag( "DebugWindowOptionsErrorOption"..index.."Button", true )
	end
	ButtonSetPressedFlag( "DebugWindowOptionsErrorOption1Button", DevData.useDevErrorHandling  )	
	ButtonSetPressedFlag( "DebugWindowOptionsErrorOption2Button", GetUseLuaErrorHandling() )	
	
	
	LabelSetText(  "DebugWindowOptionsLuaDebugLibraryLabel", L"Load Lua Debug Library" )
	ButtonSetPressedFlag( "DebugWindowOptionsLuaDebugLibraryButton", GetLoadLuaDebugLibrary() )
	
	WindowSetShowing("DebugWindowOptions", false )
	
end

-- OnShutdown Handler
function DebugWindow.Shutdown()
	-- Save the settings across reloads
	DevData.DebugWindow.isShowing = WindowGetShowing("DebugWindow")
	DevData.DebugWindow.screenPos.x, DevData.DebugWindow.screenPos.y = WindowGetOffsetFromParent("DebugWindow")
	DevData.DebugWindow.size.x, DevData.DebugWindow.size.y = WindowGetDimensions("DebugWindow")
end

function DebugWindow.ToggleLogging()

    DebugWindow.logging = DebugWindow.logging == false
    
    if( DebugWindow.logging ) then
        Debug.Print( L" Logging ON" )
    else
        Debug.Print( L" Logging OFF" )
    end
    
    TextLogSetIncrementalSaving( "Lua", DebugWindow.logging, "logs/lua.log");
    TextLogSetEnabled( "Lua", DebugWindow.logging )
    
    --TextLogSetIncrementalSaving( "Interface", logging, "logs/interface.log");
    --TextLogSetEnabled( "Interface", logging )

    local logEnabled = TextLogGetEnabled( "Lua" )
    if( logEnabled ) then
        Debug.Print( L" Lua Log ENABLED" )
    else
        Debug.Print( L" Lua Log DISABLED" )
    end
    
    UpdateLoggingButton ()

end

function DebugWindow.OnResizeBegin()
    WindowUtils.BeginResize( "DebugWindow", "topleft", 300, 200, false, nil)
end

--- Options Window

function DebugWindow.ToggleOptions()
	local showing = WindowGetShowing( "DebugWindowOptions" )
	WindowSetShowing("DebugWindowOptions", showing == false )
end

function DebugWindow.UpdateDisplayFilter()

	local filterId = WindowGetId(SystemData.ActiveWindow.name)
	
	DevData.DebugWindow.luaFilters[filterId] = not DevData.DebugWindow.luaFilters[filterId]
	
	ButtonSetPressedFlag( "DebugWindowOptionsFilterType"..filterId.."Button", DevData.DebugWindow.luaFilters[filterId] )
	TextLogDisplaySetFilterState( "DebugWindowText", "Lua", filterId, DevData.DebugWindow.luaFilters[filterId] )

end

function DebugWindow.UpdateLuaErrorHandling()

	DevData.useDevErrorHandling = not DevData.useDevErrorHandling ;
	ButtonSetPressedFlag( "DebugWindowOptionsErrorOption1Button", DevData.useDevErrorHandling  )	
end

function DebugWindow.UpdateCodeErrorHandling()
	local enabled = GetUseLuaErrorHandling()
	enabled = not enabled
	
	SetUseLuaErrorHandling( enabled )
	ButtonSetPressedFlag( "DebugWindowOptionsErrorOption2Button", enabled )
end

function DebugWindow.UpdateLoadLuaDebugLibrary()
	local enabled = GetLoadLuaDebugLibrary()
	enabled = not enabled

	SetLoadLuaDebugLibrary( enabled )
	ButtonSetPressedFlag( "DebugWindowOptionsLuaDebugLibraryButton", enabled )
end
