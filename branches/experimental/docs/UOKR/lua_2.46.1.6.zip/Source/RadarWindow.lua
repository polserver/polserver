----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

RadarWindow = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

RadarWindow.TargetId = 0
RadarWindow.HasTarget = false

RadarWindow.Width = 256
RadarWindow.Height = 256
RadarWindow.Radius = 104

RadarWindow.OffsetX = 0
RadarWindow.OffsetY = 0
RadarWindow.Rotation = 45

RadarWindow.IconWindowNamePrefix = "RadarWaypoint"
RadarWindow.RootWindowName = "RadarWindow"
----------------------------------------------------------------
-- Functions
----------------------------------------------------------------

function RadarWindow.Initialize()
	UOSetWaypointDisplayMode("RADAR")
	local windowName = "RadarWindow"
	WindowSetAlpha("RadarWindowMap",1.0) --TODO: figure out alpha value
		
	-- create the player waypoint
	waypointWindowNameRoot = RadarWindow.IconWindowNamePrefix
	rootWindow = RadarWindow.RootWindowName
    waypointWindowName = waypointWindowNameRoot.."Player"
    MapWindow.waypointWindowNames["RADAR"].Player = {}
    MapWindow.waypointWindowNames["RADAR"].Player.name = waypointWindowName
    CreateWindowFromTemplate(waypointWindowName, "MapWaypointIconTemplate", rootWindow )

	UORadarSetWindowSize(RadarWindow.Width, RadarWindow.Height)
	MapWindow.UpdateDisplayModeMap()
	UOSetRadarRotation(RadarWindow.Rotation)
	
	WindowUtils.RestoreWindowPosition("RadarWindow")
	
	WindowSetShowing("RadarWindow", false)
end

function RadarWindow.Shutdown()
	WindowUtils.SaveWindowPosition("RadarWindow")
end

function RadarWindow.ToggleMap()
	--Debug.Print("RadarWindow.ToggleMap()")
	UOSetWaypointDisplayMode("ATLAS")
	UORadarSetWindowSize(MapWindow.Width, MapWindow.Height)
	UOSetRadarRotation(MapWindow.Rotation)
	UORadarSetWindowOffset(MapWindow.OffsetX, MapWindow.OffsetY)
	MapWindow.UpdateDisplayModeMap()
	local facet = UOGetRadarFacet()
	LabelSetText("MapWindowTitle", GetStringFromTid(MapWindow.FacetTID[facet]))
	WindowSetShowing("RadarWindow", false)
	WindowSetShowing("MapWindow", true)
end