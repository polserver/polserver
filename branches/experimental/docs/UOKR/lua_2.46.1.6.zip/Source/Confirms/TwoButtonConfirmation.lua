
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

TwoButtonConfirmation = 
{ 
	knownWindows = {},
}


----------------------------------------------------------------
-- TwoButtonConfirmation (Manager) Functions
----------------------------------------------------------------


function TwoButtonConfirmation.inherits(gumpData)
	CGManager.debug( L"TwoButtonConfirmation.inherits called. ")

	gumpData.Shutdown = gumpData.Shutdown or TwoButtonConfirmation.Shutdown
	gumpData.OnCloseWindow = gumpData.OnCloseWindow or TwoButtonConfirmation.OnCloseWindow
	
end


-- requires that self.descData is already set and contains at least 3 values
--
function TwoButtonConfirmation.parseDescAsTextAndTwoButtons(gumpData)
	CGManager.debug( L"setting data for "..gumpData.name )
	
	gumpData.text = CGManager.translateTID(gumpData.descData[1])
	gumpData.leftButtonName = CGManager.translateTID(gumpData.descData[2])
	gumpData.rightButtonName = CGManager.translateTID(gumpData.descData[3])
	
	gumpData.leftButtonID = gumpData.buttonIDs[1]
	gumpData.rightButtonID = gumpData.buttonIDs[2]
	

	CGManager.debug( L"gumpData.text = "..gumpData.text..L",  leftButtonName = "..gumpData.leftButtonName..L",  rightButtonName = "..gumpData.rightButtonName )	
	CGManager.debug( L"setting button IDs to leftButtonID = "..gumpData.leftButtonID..L" and rightButtonID"..gumpData.rightButtonID )
	TwoButtonConfirmation.inherits(gumpData)
end


-- requires that self.descData is already set and contains at least 4 values
--
function TwoButtonConfirmation.parseDescAsTitleTextAndTwoButtons(gumpData)
	CGManager.debug( L"setting data for "..gumpData.name )
	gumpData.title = CGManager.translateTID(gumpData.descData[1])
	gumpData.text = CGManager.translateTID(gumpData.descData[2])
	gumpData.leftButtonName = CGManager.translateTID(gumpData.descData[3])
	gumpData.rightButtonName = CGManager.translateTID(gumpData.descData[4])
	
	gumpData.leftButtonID = gumpData.buttonIDs[1]
	gumpData.rightButtonID = gumpData.buttonIDs[2]
	
	TwoButtonConfirmation.inherits(gumpData)
end

function TwoButtonConfirmation.parseData(gumpData)
	CGManager.debug( L"TwoButtonConfirmation.parseData called. ")
	
	CGManager.debug( L"TwoButtonConfirmation.parseData(gumpData) - setting data for = "..gumpData.name )
	if gumpData.descDataCount > 3 then
		TwoButtonConfirmation.parseDescAsTitleTextAndTwoButtons(gumpData)
	elseif gumpData.descDataCount > 2 then
		TwoButtonConfirmation.parseDescAsTextAndTwoButtons(gumpData)
	else
		CGManager.debug( L"TwoButtonConfirmation.parseData insufficient descData. descDataCount = "..gumpData.descDataCount )
	end
end



-- this sets the DestroyWindowOnClose flag
--
function TwoButtonConfirmation:Init()
	CGManager.debug( L"TwoButtonConfirmation.Init called. ")
	
	--setmetatable(self, TwoButtonConfirmation)
	--self.__index = self
	
	if not CGManager.retriveBasicGumpData( self ) then
		return false
	end
	
	CGManager.debug( L"returned from retriveBasicGumpData with self.descData[1] = "..self.descData[1] )
	
	if self.setDataFunction then
		self:setDataFunction()
	end
	
	CGManager.debug( L"returned from retriveBasicGumpData with self.descData[1] = "..self.text )
	
	TwoButtonConfirmation.setFields(self)
	
	TwoButtonConfirmation.knownWindows[self.windowName] = self
--Interface.DestroyWindowOnClose[self.windowName] = true
	
	Debug.PrintToDebugConsole( L"Initialize "..self.name )
end


function TwoButtonConfirmation.setFields(self)
	CGManager.debug( L"TwoButtonConfirmation.setFields called. ")

	if self.title then
		WindowUtils.SetActiveDialogTitle( self.title )
    end
    LabelSetText( self.windowName.."ScrollChildText", self.text )
	ButtonSetText(self.windowName.."LeftButtonName", self.leftButtonName )
	WindowSetId( self.windowName.."LeftButtonName", self.leftButtonID )	
	ButtonSetText(self.windowName.."RightButtonName", self.rightButtonName )
	WindowSetId( self.windowName.."RightButtonName", self.rightButtonID )	
end



function TwoButtonConfirmation.getActiveWindow()
	WindowName = WindowGetParent(SystemData.ActiveWindow.name)
	
	return TwoButtonConfirmation.knownWindows[WindowName]
end



----------------------------------------------------------------
-- TwoButtonConfirmation Functions
----------------------------------------------------------------

function TwoButtonConfirmation.new()
	CGManager.debug( L"TwoButtonConfirmation.new called. ")

	NewDialog = {}
	
	--setmetatable(NewWindow, TwoButtonConfirmation)
	--TwoButtonConfirmation.__index = TwoButtonConfirmation
	
	--TwoButtonConfirmation.inherits(NewDialog)
	
	UO_GenericGump.debug( L"finished TwoButtonConfirmation.new()" )
	return NewDialog
end


-- OnInitialize Handler
function TwoButtonConfirmation.Initialize()
	CGManager.debug( L"TwoButtonConfirmation.Initialize called. ")
	NewDialog = TwoButtonConfirmation.new()
	NewDialog.setDataFunction = TwoButtonConfirmation.parseData

	--TwoButtonConfirmation.setDataFunction = function(o) CGManager.debug( L"could not find a self.setDataFunction") end, -- do nothing
	TwoButtonConfirmation.Init(NewDialog)

end 


function TwoButtonConfirmation.LeftButtonPressed()
	CGManager.debug( L"TwoButtonConfirmation.LeftButtonPressed called. ")
	
	gumpData = TwoButtonConfirmation.getActiveWindow()
	if  gumpData.LeftButtonFunction then
		gumpData.LeftButtonFunction()
	else
		TwoButtonConfirmation.DefaultButtonFunction(gumpData)
	end	
end


--
function TwoButtonConfirmation.RightButtonPressed()
	CGManager.debug( L"TwoButtonConfirmation.RightButtonPressed called. ")
	
	gumpData = TwoButtonConfirmation.getActiveWindow()
	if  gumpData.RightButtonFunction then
		gumpData.RightButtonFunction()
	else
		TwoButtonConfirmation.DefaultButtonFunction(gumpData)
	end	
end



function TwoButtonConfirmation.DefaultButtonFunction(self)
	CGManager.debug( L"TwoButtonConfirmation.DefaultButtonFunction called. ")
	
	buttonID = WindowGetId( SystemData.ActiveWindow.name )
	if not buttonID then	
		Debug.PrintToDebugConsole( L"ERROR in TwoButtonConfirmation.DefaultButtonFunction: no ID set for button pressed." )
		return
	end
	CGManager.debug( L"called TwoButtonConfirmation.DefaultButtonFunction(). Sending button value of "..buttonID )

	CGManager.broadcastButtonPress( buttonID, self )
	self.OnCloseWindow()
end



-- OnShutdown Handler
-- will call DestroyWindow automatically
--
function TwoButtonConfirmation.Shutdown()
	UO_DefaultWindow.CloseDialog()
end


-- will call DestroyWindow automatically
--
function TwoButtonConfirmation.OnCloseWindow()
	CGManager.debug( L"TwoButtonConfirmation.OnCloseWindow called. ")
	UO_DefaultWindow.CloseDialog()
end



