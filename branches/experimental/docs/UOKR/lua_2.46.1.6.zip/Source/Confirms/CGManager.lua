
----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------


CGManager = {
	NumOfWindows = 0,
	--knownWindows = { },
}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

--CGManager.DEBUG_ON = true
CGManager.DEBUG_ON = false


--CGManager.DISPLAY_GUMPNOTFOUND = true
CGManager.DISPLAY_GUMPNOTFOUND = false


--constants for Text IDs for localized strings
--
--CGManager.OKAY_TID = 1011036
--CGManager.CANCEL_TID = 1011012


----------------------------------------------------------------
-- Client Gump Manager Functions
----------------------------------------------------------------

function CGManager.Initialize()
	WindowRegisterEventHandler( "Root", SystemData.Events.CLIENT_GUMP_ARRIVED, "CGManager.GumpArrived")

	-- *** TODO: should find a better way to map Gump IDs to Window names that can stay in sync with the server

--[[
	enum CLIENT_GUMP_ID 
	{
		NO_CLIENT_GUMP,
		CONFIRM_TARGET,  // works for both PHYSICAL_ATTACK, SPELL_ATTACK,


		MAX_CLIENT_GUMP_ID
	};
--]]
	CGManager.TemplateName = {}
	CGManager.TemplateName[1] = "TwoButtonConfirmation" -- CONFIRM_TARGET
end


function CGManager.GumpArrived()

	gumpId = WindowData.ClientGump.GumpId
	objId = WindowData.ClientGump.ObjectId

	templateName = CGManager.TemplateName[gumpId]
	
	if not templateName then
		Debug.PrintToDebugConsole( L"ERROR in CGManager.GGArrived: No Client Gump window fround for gumpId = "..gumpId )
		
		if CGManager.DISPLAY_GUMPNOTFOUND then
			templateName = "NoGumpFound"
		else
			return false
		end
	end
	
	
	
	CGManager.NumOfWindows = CGManager.NumOfWindows + 1	
	windowName = templateName.."-"..CGManager.NumOfWindows

	CGManager.debug( L"creating window = "..StringToWString(windowName)..L" using template = "..StringToWString(templateName) )
	CreateWindowFromTemplate( windowName, templateName, "Root" )
	
	-- *** could use this to access windows by index
	--WindowSetId( windowName, CGManager.NumOfWindows )
	
	--CGManager.knownWindows[NumOfWindows] = windowName

	CGManager.debug( CGManager.GumpToString() )
end




----------------------------------------------------------------
-- Client Gump Utility Functions
----------------------------------------------------------------

function CGManager.retriveBasicGumpData( gumpData )
	if not gumpData then
		Debug.PrintToDebugConsole( L"ERROR: gumpData does not exist." )
		return false
	end      
	if not WindowData.ClientGump.GumpId then
		Debug.PrintToDebugConsole( L"ERROR: required field WindowData.ClientGump.GumpId could not be retrieved." )
		return false
	end      	
	
	gumpData.gumpID = WindowData.ClientGump.GumpId
	
	if not WindowData.ClientGump.ObjectId then
		Debug.PrintToDebugConsole( L"ERROR: required field WindowData.ClientGump.objectID could not be retrieved." )
		return false
	end   
	
	gumpData.objectID = WindowData.ClientGump.ObjectId
	
	gumpData.windowName = SystemData.ActiveWindow.name
	gumpData.name = StringToWString(gumpData.windowName)
	
	gumpData.stringData = WindowData.ClientGump.stringData
	gumpData.stringDataCount = WindowData.ClientGump.stringDataCount
	
	gumpData.descData = WindowData.ClientGump.desc
	gumpData.descDataCount = WindowData.ClientGump.descCount
	
	gumpData.buttonIDs = WindowData.ClientGump.buttonIdData
	gumpData.buttonCount = WindowData.ClientGump.buttonIdDataCount
	
	CGManager.debug( L"recieved call to create "..StringToWString(gumpData.windowName)..L" with gumpID = "..gumpData.gumpID..L" ,objectID = "..gumpData.objectID  )
	return true
end



function CGManager.broadcastButtonPress( buttonID, gumpData )

	if not CGManager.writeBasicGumpData( gumpData ) then
		Debug.PrintToDebugConsole( L"ERROR in CGManager.broadcastButtonPress: could not broadcast button trigger." )
		return false	
	end 
    ReturnWindowData.ClientGump.ButtonId = buttonID
    
    -- TODO: figure out where to get this value to broadcast
    BroadcastEvent(SystemData.Events.CLIENT_GUMP_ACTION)
    
	CGManager.debug( L"Broadcast CLIENT_GUMP_ACTION with buttonID = "..ReturnWindowData.ClientGump.ButtonId..L"\n"  )
end

function CGManager.writeBasicGumpData( gumpData )

	if not gumpData or not gumpData.gumpID or not gumpData.objectID then
		Debug.PrintToDebugConsole( L"ERROR in CGManager.writeBasicGumpData: basic Client Gump Data not found." )
		return false
	end   
	
	ReturnWindowData.ClientGump.GumpId = gumpData.gumpID 
	ReturnWindowData.ClientGump.ObjectId = gumpData.objectID
	
	CGManager.debug( L"Set outgoing values gumpID = "..ReturnWindowData.ClientGump.GumpId..L" ,objectID = "..ReturnWindowData.ClientGump.ObjectId   )
	return true
end


-- Additional fields that may need to be set by some gumps
--[[
	ReturnWindowData.ClientGump.NumCountSelections
	ReturnWindowData.ClientGump.CountSelections[1..NumCountSelections]
	
	and
	
	ReturnWindowData.ClientGump.NumEntries
	ReturnWindowData.ClientGump.CountEntries[1.. NumEntries].Id
	ReturnWindowData.ClientGump.CountEntries[1.. NumEntries].Length
	ReturnWindowData.ClientGump.CountEntries[1.. NumEntries].Text[Length] 
--]]

function CGManager.GumpToString()

	CGManager.debug( L"GumpToString stringDataCount = ".. WindowData.ClientGump.stringDataCount..L"  descCount = "..WindowData.ClientGump.descCount..L"  buttonIdDataCount = "..WindowData.ClientGump.buttonIdDataCount )

	--begin debug print
	tmp = L"CGManager.GumpArrived:\n"
	tmp = tmp..L"gumpId = "..WindowData.ClientGump.GumpId..L"\n"
	tmp = tmp..L"objId = "..WindowData.ClientGump.ObjectId..L"\n"
	
	for i=1, WindowData.ClientGump.stringDataCount do
		tmp = tmp..L"stringData["..i..L"] = "..WindowData.ClientGump.stringData[i]..L"\n"
	end
	
	for i=1, WindowData.ClientGump.descCount do
		tmp = tmp..L"desc["..i..L"] = "..WindowData.ClientGump.desc[i]..L", "..GetStringFromTid(tonumber(WindowData.ClientGump.desc[i]))..L"\n"
	end

	for i=1, WindowData.ClientGump.buttonIdDataCount do
		tmp = tmp..L"buttonID["..i..L"] = "..WindowData.ClientGump.buttonIdData[i]..L"\n"
	end
	
--[[	
	localizedDataCount = WindowData.ClientGump.localizedDataCount
	for i, s in ipairs(WindowData.ClientGump.localizedData) do
		if i>localizedDataCount then
			break
		end
		tmp = tmp..L"localizedData["..i..L"] = "..s..L"\n"
	end
	
	gumppicNumDataCount = WindowData.ClientGump.gumppicNumDataCount
	for i, s in ipairs(WindowData.ClientGump.gumppicNumData) do
		if i>gumppicNumDataCount then
			break
		end
		tmp = tmp..L"gumppicNumData["..i..L"] = "..s..L"\n"
	end
--]]
	
	
	return tmp
end

function CGManager.ConcatStringFromTID(TIDTable, spacer, beginIdx, endIdx)
	result = L""
	for i, tid in ipairs(TIDTable) do
		if i>endIdx then break end
		
		if i>=beginIdx then
			result = result..GetStringFromTid(tonumber(tid))..spacer
		end
	end
	return result
end


function CGManager.ConcatStringFromTID(TIDTable, spacer, beginIdx, endIdx)
	return GGManager.ConcatStringFromTID(TIDTable, spacer, beginIdx, endIdx)
end


function CGManager.translateTID(tid)
	return GGManager.translateTID(tid)
end


function CGManager.debug(wstr)
	if CGManager.DEBUG_ON then
		Debug.PrintToDebugConsole(wstr)
	end
end