----------------------------------------------------------------
-- Global Functions
----------------------------------------------------------------

function GetString( id )
	if( id == nil ) then
		return L""
	end

	return GetStringFromTable("Default", id )
end

function GetStringLC( id )
	if( id == nil ) then
		return L""
	end

	local text = GetStringFromTable("Default", id )
	return text --string.tolower(text)
end

function GetStringFormat( id, paramTable)
	if( id == nil ) then
		Debug.PrintToDebugConsole(L"Invalid params to GetStringFormat( id, paramTable): id is nil" )
		return L""
	elseif( paramTable == nil) then
		Debug.PrintToDebugConsole(L"Invalid params to GetStringFormat( id, paramTable): table is nil" )
		return L""
	end
      
    -- If the C-substitution is enabled, use it.
    if(  GetStringFormatFromTable ~= nil ) then
    
		local params = {}
        -- Add empty strings to the end of the param table
        for index = 1, 5 do
            if( paramTable[index] ~= nil and paramTable[index] ~= L"" ) then
            
				params[index] = L""..paramTable[index]
            else
                params[index] = L" "
            end
        end
    
		 --Debug.PrintToDebugConsole(L" Parmas: "..params[1]..L", "..params[2]..L", "..params[3]..L", "..params[4]..L", "..params[5] )
         text = GetStringFormatFromTable( "Default", id, params[1], params[2], params[3], params[4], params[5] )
	
	-- Else, Use the Lua subsitution
	else
	    

	     text = GetStringFromTable("Default", id )
	
	    --Debug.PrintToDebugConsole(L"GetStringFormat: Start Text = "..text )

	    -- Replace each param tag with the variable
	    local paramIndex = 1
	    while paramTable[paramIndex] ~= nil do		
    	
		    local tag = L"<<"..paramIndex..L">>"	
		    local paramText = L""..paramTable[paramIndex]
    		
		    --Debug.PrintToDebugConsole(L"GetStringFormat: Text = "..text..L", Tag = "..tag..L", Param = "..paramText )
    		
		    text = wstring.gsub( text, tag, paramText )
    		
		    paramIndex = paramIndex + 1
	    end
	
	    --Debug.PrintToDebugConsole(L"GetStringFormat: End Text = "..text )
	end	
	
	return text
end

function GetAbilityDesc( id )
	if( id == nil ) then
		return L""
	end

	return GetStringFromTable("AbilityDescriptions", id )
end