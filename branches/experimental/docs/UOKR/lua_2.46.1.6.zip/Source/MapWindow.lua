----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

MapWindow = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

MapWindow.TID = {MapOptions=1078473, Waypoints=1078474, WorldMap=1077438, YourLocation=1078897,
			     CreateWaypoint=1079482, EditWaypoint=1079483, DeleteWaypoint=1079484, ViewWaypoint=1079571}
MapWindow.Width = 660
MapWindow.Height = 660
MapWindow.Rotation = 0

-- These are no longer used !!!
MapWindow.OffsetX = 0
MapWindow.OffsetY = 0

MapWindow.FacetTID = {}
MapWindow.FacetTID[0]=1012001
MapWindow.FacetTID[1]=1012000
MapWindow.FacetTID[2]=1012002
MapWindow.FacetTID[3]=1060643
MapWindow.FacetTID[4]=1063258

MapWindow.FacetDimensions = {}
MapWindow.FacetDimensions[0]={x=7168,y=4096}
MapWindow.FacetDimensions[1]={x=7168,y=4096}
MapWindow.FacetDimensions[2]={x=2304,y=1600}
MapWindow.FacetDimensions[3]={x=2560,y=2048}
MapWindow.FacetDimensions[4]={x=1448,y=1448}

MapWindow.IconWindowNamePrefix = "MapWaypoint"
MapWindow.RootWindowName = "Map"

MapWindow.ZoomScale = 0.1
MapWindow.MaxWaypointsPerFacet = 500
MapWindow.MaxWaypointTypesPerLegend = 30
MapWindow.PlayerCreatedWaypointType = 14

MapWindow.waypointWindowNames = {}
MapWindow.waypointWindowNames["ATLAS"] = {}
MapWindow.waypointWindowNames["RADAR"] = {}
MapWindow.numCreatedWaypoints = {ATLAS=0,RADAR=0}
MapWindow.WaypointUpdateTimerCount = 0
MapWindow.WaypointsNeedUpdate = false
MapWindow.WAYPOINT_UPDATE_FREQ = 0.2

MapWindow.CenterX, MapWindow.CenterY = nil
MapWindow.DragX, MapWindow.DragY = nil
MapWindow.DragOn = false

MapWindow.ContextReturnCodes = {}
MapWindow.ContextReturnCodes.CREATE_WAYPOINT = 0
MapWindow.ContextReturnCodes.EDIT_WAYPOINT = 1
MapWindow.ContextReturnCodes.VIEW_WAYPOINT = 2
----------------------------------------------------------------
-- Functions
----------------------------------------------------------------

function MapWindow.Update(timeElapsed)
	MapWindow.WaypointUpdateTimerCount = MapWindow.WaypointUpdateTimerCount + timeElapsed
    if( MapWindow.WaypointUpdateTimerCount > MapWindow.WAYPOINT_UPDATE_FREQ and MapWindow.WaypointsNeedUpdate ) then
		MapWindow.UpdateDisplayModeWaypoints()
        MapWindow.WaypointUpdateTimerCount = 0
        MapWindow.WaypointsNeedUpdate = false
    end
end

function MapWindow.OnWaypointsUpdated()
	MapWindow.WaypointsNeedUpdate = true
end

function MapWindow.Initialize()
	UOSetWaypointDisplayMode("ATLAS")
	RegisterWindowData(WindowData.WaypointList.Type,0)
	RegisterWindowData(WindowData.Radar.Type,0)
	RegisterWindowData(WindowData.WaypointDisplay.Type,0)
	RegisterWindowData(WindowData.PlayerLocation.Type,0)
	WindowRegisterEventHandler("MapWindow", WindowData.Radar.Event, "MapWindow.UpdateDisplayModeMap")
	WindowRegisterEventHandler("MapWindow", WindowData.WaypointList.Event, "MapWindow.OnWaypointsUpdated")
	
	-- create the player waypoint   
	waypointWindowNameRoot = MapWindow.IconWindowNamePrefix
	rootWindow = MapWindow.RootWindowName
    waypointWindowName = waypointWindowNameRoot.."Player"
    MapWindow.waypointWindowNames["ATLAS"].Player = {}
    MapWindow.waypointWindowNames["ATLAS"].Player.name = waypointWindowName
    CreateWindowFromTemplate(waypointWindowName, "MapWaypointIconTemplate", rootWindow )   
	
	LabelSetText("MapWindowTitle", GetStringFromTid(MapWindow.FacetTID[UOGetRadarFacet()]))
	LabelSetText("MapScrollWindowTitle", GetStringFromTid(MapWindow.TID.Waypoints))
	ButtonSetText("ShowMapOptionsButton", GetStringFromTid(MapWindow.TID.MapOptions))
	
	-- GENERATE AN EMPTY LIST OF MAP WAYPOINTS IN THE LEGEND
	for waypoint_display_type_index = 1, MapWindow.MaxWaypointTypesPerLegend do
		currentWaypointListWindowName = "MapLegendWaypointIcon"..waypoint_display_type_index
		currentWaypointListLabelWindowName = "MapLegendWaypointLabel"..waypoint_display_type_index
		if(WindowData.WaypointDisplay.displayTypes.ATLAS ~= nil and waypoint_display_type_index ~= nil and
		   WindowData.WaypointDisplay.displayTypes.ATLAS[waypoint_display_type_index] ~= nil) then
			mapWaypointIconId = WindowData.WaypointDisplay.displayTypes.ATLAS[waypoint_display_type_index].iconId
		end
		if(WindowData.WaypointDisplay.typeNames ~= nil and waypoint_display_type_index ~= nil) then
			mapWaypointName = WindowData.WaypointDisplay.typeNames[waypoint_display_type_index]
		end
		
		CreateWindowFromTemplate(currentWaypointListWindowName, "MapLegendIconTemplate", "MapScrollChild" )
		CreateWindowFromTemplate(currentWaypointListLabelWindowName, "WaypointLabelTemplate", "MapScrollChild" )

		WindowSetShowing(currentWaypointListWindowName, false)
		WindowSetShowing(currentWaypointListLabelWindowName, false)
	end
	ScrollWindowUpdateScrollRect("MapScrollWindow")
	
	-- FILL IN THE MAP LEGEND
	MapWindow.UpdateMapLegend()
end

function MapWindow.Shutdown()
	UnregisterWindowData(WindowData.WaypointList.Type,0)
	UnregisterWindowData(WindowData.Radar.Type,0)
	UnregisterWindowData(WindowData.WaypointDisplay.Type,0)
	UnregisterWindowData(WindowData.PlayerLocation.Type,0)
end

-- GENERATE AN ICON FOR EACH WAYPOINT DISPLAYED ON THE MAP LEGEND SCROLL WINDOW
-- TO DO: MAKE EACH MAP LEGEND ICON A DYNAMIC MAP DISPLAY OPTION BUTTON!
function MapWindow.UpdateMapLegend()
    local numWaypointDisplayTypes = table.getn(WindowData.WaypointDisplay.typeNames)
	local currentWaypointListWindowName, previousWaypointListWindowName, currentWaypointListLabelWindowName = nil
	local previousWaypointListWindowName = nil
	local mapWaypointIconId, mapWaypointName, iconTexture, iconTextureX, iconTextureY = nil
	local first = true

    for waypoint_display_type_index = 1, MapWindow.MaxWaypointTypesPerLegend do
		currentWaypointListWindowName = "MapLegendWaypointIcon"..waypoint_display_type_index
		currentWaypointListLabelWindowName = "MapLegendWaypointLabel"..waypoint_display_type_index
        WindowClearAnchors(currentWaypointListWindowName)
        WindowClearAnchors(currentWaypointListLabelWindowName)
		WindowSetShowing(currentWaypointListWindowName, false)
		WindowSetShowing(currentWaypointListLabelWindowName, false)
	end

	local mapLegendsDisplayed = 0

	for waypoint_display_type_index = 1, numWaypointDisplayTypes do
		currentWaypointListWindowName = "MapLegendWaypointIcon"..waypoint_display_type_index
		currentWaypointListLabelWindowName = "MapLegendWaypointLabel"..waypoint_display_type_index
		mapWaypointIconId = WindowData.WaypointDisplay.displayTypes.ATLAS[waypoint_display_type_index].iconId

  		mapWaypointName = WindowData.WaypointDisplay.typeNames[waypoint_display_type_index]

		if WindowData.WaypointDisplay.displayTypes.ATLAS[waypoint_display_type_index].isDisplayed then
		    local displayIndex = WindowData.WaypointDisplay.displayTypes.ATLAS[waypoint_display_type_index].displayIndex

		    MapWindow.UpdateWaypointIcon(mapWaypointIconId, currentWaypointListWindowName)

			if (first==true) then
				WindowAddAnchor(currentWaypointListWindowName, "topleft", "MapScrollChild", "topleft", 0, 0)
				first=false
			else
				WindowAddAnchor(currentWaypointListWindowName, "topleft", previousWaypointListWindowName, "topleft", 0, 75)
			end

			LabelSetText(currentWaypointListLabelWindowName.."Text", mapWaypointName)
			WindowAddAnchor(currentWaypointListLabelWindowName, "topleft", currentWaypointListWindowName, "topleft", 64, -10)

			previousWaypointListWindowName = currentWaypointListWindowName
			WindowSetShowing(currentWaypointListWindowName, true)
			WindowSetShowing(currentWaypointListLabelWindowName, true)
			WindowSetId(currentWaypointListWindowName, waypoint_display_type_index)
			mapLegendsDisplayed = mapLegendsDisplayed + 1
		end
	end
	ScrollWindowUpdateScrollRect("MapScrollWindow")
end

function MapWindow.UpdatePlayerWaypoints(curDisplayMode,currentFacet,displayWidthRange,displayHeightRange,rootWindow)
	-- DISPLAY CURRENT PLAYER LOCATION AS THE LAST WAYPOINT (IF VISIBLE AND IN RANGE!)
	local playerX, playerY = UOGetWorldPosToRadar(WindowData.PlayerLocation.x, WindowData.PlayerLocation.y)
	local playerIsWithinRange = true
	local playerIsOnFacet = (WindowData.PlayerLocation.facet == currentFacet)
	local playerIsDisplayed = false
	local playerCreatedIconId = nil
	
	if (curDisplayMode == "ATLAS" and
	    WindowData.WaypointDisplay.displayTypes.ATLAS[MapWindow.PlayerCreatedWaypointType] ~= nil) then	
		playerIsDisplayed = WindowData.WaypointDisplay.displayTypes.ATLAS[MapWindow.PlayerCreatedWaypointType].isDisplayed
		playerCreatedIconId = WindowData.WaypointDisplay.displayTypes.ATLAS[MapWindow.PlayerCreatedWaypointType].iconId
		playerIsWithinRange = (playerX > 0 and playerX < displayWidthRange and playerY > 0 and playerY < displayHeightRange)
	elseif (curDisplayMode == "RADAR" and WindowData.WaypointDisplay.displayTypes.RADAR[MapWindow.PlayerCreatedWaypointType] ~= nil) then
		playerIsDisplayed = WindowData.WaypointDisplay.displayTypes.RADAR[MapWindow.PlayerCreatedWaypointType].isDisplayed
		playerCreatedIconId = WindowData.WaypointDisplay.displayTypes.RADAR[MapWindow.PlayerCreatedWaypointType].iconId
		
		-- Use the distance formula to see if the waypoint is less than that of RadarWindow's radius
	    local centerX, centerY = UOGetWorldPosToRadar(MapWindow.CenterX, MapWindow.CenterY)
	    local WaypointDistanceFromCenter = ( (math.abs(playerX - centerX)) ^ 2 +
											 (math.abs(playerY - centerY)) ^ 2) ^ 0.5
		playerIsWithinRange = (WaypointDistanceFromCenter < RadarWindow.Radius)		
	end	
	
	local waypointWindowName = MapWindow.waypointWindowNames[curDisplayMode].Player.name
	if (playerIsWithinRange and playerIsDisplayed and playerIsOnFacet) then
		WindowClearAnchors(waypointWindowName)
		MapWindow.UpdateWaypointIcon(playerCreatedIconId, waypointWindowName)
		WindowAddAnchor(waypointWindowName, "topleft", rootWindow, "center", playerX, playerY)
		if( MapWindow.waypointWindowNames[curDisplayMode].Player.visible == nil or MapWindow.waypointWindowNames[curDisplayMode].Player.visible == false ) then
		    WindowSetShowing(waypointWindowName, true)
		    MapWindow.waypointWindowNames[curDisplayMode].Player.visible = true
		end
		WindowSetId(waypointWindowName, MapWindow.MaxWaypointsPerFacet)
	else
	    if( MapWindow.waypointWindowNames[curDisplayMode].Player.visible == nil or MapWindow.waypointWindowNames[curDisplayMode].Player.visible == true ) then
		    WindowSetShowing(waypointWindowName, false)
		    MapWindow.waypointWindowNames[curDisplayMode].Player.visible = false
		end
	end
end

-- TO DO: MAKE SURE MAP PARAMETERS ARE CORRECT !!
function MapWindow.UpdateDisplayModeMap()
    local displayWidthRange, displayHeightRange = nil
	local currentFacet = UOGetRadarFacet()
	MapWindow.CenterX, MapWindow.CenterY = UOGetRadarCenter()
	UOSetWaypointMapFacet(currentFacet)
	local curDisplayMode = WindowData.WaypointDisplay.currentDisplayMode
	
    if (curDisplayMode == "ATLAS") then
	    displayWidthRange = MapWindow.Width
	    displayHeightRange = MapWindow.Height     
	    LabelSetText("MapWindowTitle", GetStringFromTid(MapWindow.FacetTID[currentFacet]))
		
        DynamicImageSetTextureScale("MapImage", WindowData.Radar.TexScale)
        DynamicImageSetTexture("MapImage","radar_texture", WindowData.Radar.TexCoordX, WindowData.Radar.TexCoordY)
        DynamicImageSetRotation("MapImage", WindowData.Radar.TexRotation)
		
    elseif (curDisplayMode == "RADAR") then	
	    displayWidthRange = RadarWindow.Width
	    displayHeightRange = RadarWindow.Height     
        local xOffset = RadarWindow.Width / 2
        local yOffset = RadarWindow.Height / 2
        CircleImageSetTexture("RadarWindowMap","radar_texture", WindowData.Radar.TexCoordX + xOffset, WindowData.Radar.TexCoordY + yOffset)
        CircleImageSetTextureScale("RadarWindowMap", WindowData.Radar.TexScale)
        CircleImageSetRotation("RadarWindowMap", WindowData.Radar.TexRotation)
    end
	
	MapWindow.WaypointsNeedUpdate = true
	
    --Debug.Print("IN "..WindowData.WaypointDisplay.currentDisplayMode.." MODE, WindowData.WaypointList.waypointCount = "..
	--			 WindowData.WaypointList.waypointCount..", numWaypointsDisplayed = "..numWaypointsDisplayed)
end

function MapWindow.UpdateDisplayModeWaypoints()
    local waypointWindowNameRoot, rootWindow, displayWidthRange, displayHeightRange = nil
	local currentFacet = UOGetRadarFacet()
	MapWindow.CenterX, MapWindow.CenterY = UOGetRadarCenter()
	local curDisplayMode = WindowData.WaypointDisplay.currentDisplayMode
	
    if (curDisplayMode == "ATLAS") then
        if( WindowGetShowing("MapWindow") == false and WindowGetShowing("MapOptionsWindow") == false) then
            return
        end
	    displayWidthRange = MapWindow.Width
	    displayHeightRange = MapWindow.Height    
        waypointWindowNameRoot = MapWindow.IconWindowNamePrefix
	    rootWindow = MapWindow.RootWindowName		
    elseif (curDisplayMode == "RADAR") then
        if( WindowGetShowing("RadarWindow") == false ) then
            return
        end    
	    displayWidthRange =  RadarWindow.Width
	    displayHeightRange = RadarWindow.Height    
	    waypointWindowNameRoot = RadarWindow.IconWindowNamePrefix
	    rootWindow = RadarWindow.RootWindowName
    end
	
	local numWaypointsDisplayed = 0
	local waypointIsDisplayed = false
	
	if (WindowData.WaypointList.waypointCount and WindowData.WaypointList.waypointCount > 0) then
		for waypointId = 1,WindowData.WaypointList.waypointCount do	
		    local waypointWindowName = nil
		    local wtype, wflags, wname, wfacet, wx, wy, wz = UOGetWaypointInfo(waypointId) 
		    local waypointX, waypointY = UOGetWorldPosToRadar(wx, wy)
	            local waypointIsWithinRange = true
		    local waypointIsOnFacet = (wfacet == currentFacet)
		    
		    if( waypointId > MapWindow.numCreatedWaypoints[curDisplayMode] ) then
		        waypointWindowName = waypointWindowNameRoot..waypointId
		        MapWindow.waypointWindowNames[curDisplayMode][waypointId] = {}
		        MapWindow.waypointWindowNames[curDisplayMode][waypointId].name = waypointWindowName
			CreateWindowFromTemplate(waypointWindowName, "MapWaypointIconTemplate", rootWindow )
  		        MapWindow.numCreatedWaypoints[curDisplayMode] = MapWindow.numCreatedWaypoints[curDisplayMode] + 1	        
		    else
		        waypointWindowName = MapWindow.waypointWindowNames[curDisplayMode][waypointId].name
		    end
		    
			if (curDisplayMode == "ATLAS") then	
			    waypointIsWithinRange = (waypointX > 20 and waypointX < displayWidthRange and waypointY > 20 and waypointY < displayHeightRange)
				waypointIsDisplayed = WindowData.WaypointDisplay.displayTypes.ATLAS[wtype].isDisplayed
				waypointIconId = WindowData.WaypointDisplay.displayTypes.ATLAS[wtype].iconId
			elseif (curDisplayMode == "RADAR") then
				waypointIsDisplayed = WindowData.WaypointDisplay.displayTypes.RADAR[wtype].isDisplayed
				waypointIconId = WindowData.WaypointDisplay.displayTypes.RADAR[wtype].iconId

				-- Use the distance formula to see if the waypoint is less than that of RadarWindow's radius
			    local centerX, centerY = UOGetWorldPosToRadar(MapWindow.CenterX, MapWindow.CenterY)
			    local WaypointDistanceFromCenter = ( (math.abs(waypointX - centerX)) ^ 2 +
													 (math.abs(waypointY - centerY)) ^ 2) ^ 0.5
				waypointIsWithinRange = (WaypointDistanceFromCenter < RadarWindow.Radius)
			end	
			
			if (waypointIsWithinRange and waypointIsDisplayed and waypointIsOnFacet) then
				WindowClearAnchors(waypointWindowName)
				if (SystemData.Waypoint.TypeIsCustomizable[wtype] == 1) then
					WindowAddAnchor(waypointWindowName, "topleft", rootWindow, "center", waypointX, waypointY)
				else
					WindowAddAnchor(waypointWindowName, "topleft", rootWindow, "center", waypointX, waypointY)
				end
				if( MapWindow.waypointWindowNames[curDisplayMode][waypointId].visible == nil or MapWindow.waypointWindowNames[curDisplayMode][waypointId].visible == false ) then
				    WindowSetShowing(waypointWindowName, true)
				    MapWindow.waypointWindowNames[curDisplayMode][waypointId].visible = true
				end
			    		
			    MapWindow.UpdateWaypointIcon(waypointIconId, waypointWindowName)
			    
			    -- ONLY DISPLAY WAYPOINT NAME IF WAYPOINTNAMESBUTTON IS SELECTED
			    if (MapOptionsWindow.DisplayWaypointNames and MapWindow.ZoomScale <= -1) then
			    	LabelSetText(waypointWindowName.."Name", wname)
			    	WindowUtils.FitTextToLabel(waypointWindowName.."Name", wname)
			    	WindowSetShowing(waypointWindowName.."Name", true)
			    else
			        WindowSetShowing(waypointWindowName.."Name", false)
			    end
			    
			    WindowSetId(waypointWindowName, waypointId)				

				numWaypointsDisplayed = numWaypointsDisplayed + 1  
		    else
				if( MapWindow.waypointWindowNames[curDisplayMode][waypointId].visible == nil or MapWindow.waypointWindowNames[curDisplayMode][waypointId].visible == true ) then
				    WindowSetShowing(waypointWindowName, false)
				    MapWindow.waypointWindowNames[curDisplayMode][waypointId].visible = false
				end
			end
		end
	end
	
    for waypointId = WindowData.WaypointList.waypointCount + 1, MapWindow.numCreatedWaypoints[curDisplayMode] do
        local waypointWindowName = MapWindow.waypointWindowNames[curDisplayMode][waypointId].name
	    if( MapWindow.waypointWindowNames[curDisplayMode][waypointId].visible == nil or MapWindow.waypointWindowNames[curDisplayMode][waypointId].visible == true ) then
	        WindowSetShowing(waypointWindowName, false)
	        MapWindow.waypointWindowNames[curDisplayMode][waypointId].visible = false
	    end
    end	
	
    MapWindow.UpdatePlayerWaypoints(curDisplayMode,currentFacet,displayWidthRange,displayHeightRange,rootWindow)
end

function MapWindow.ShowMapOptions()
   WindowSetShowing("MapOptionsWindow", true)
   WindowSetShowing("MapWindow", false)
end

-- TO DO: CENTER RADAR ON PLAYER'S LOCATION WHEN TOGGLING TO RADAR MODE
function MapWindow.ToggleRadar()
	UOSetWaypointDisplayMode("RADAR")
	UOResetWaypointMapFacet()
	UORadarSetWindowSize(RadarWindow.Width, RadarWindow.Height)
	UOSetRadarRotation(RadarWindow.Rotation)
	UORadarSetWindowOffset(RadarWindow.OffsetX, RadarWindow.OffsetY)
	MapWindow.UpdateDisplayModeMap()
	WindowSetShowing("MapWindow", false)
	WindowSetShowing("MapOptionsWindow", false)
	WindowSetShowing("RadarWindow", true)	
end

function MapWindow.ToggleFacetUp()
	local facet_id = UOGetRadarFacet() + 1
	if (facet_id > 4) then
		facet_id = 0
	end
	LabelSetText("MapWindowTitle", GetStringFromTid(MapWindow.FacetTID[facet_id]))
	UOSetWaypointMapFacet(facet_id)
	
	MapWindow.CenterX = MapWindow.FacetDimensions[facet_id].x / 2
	MapWindow.CenterY = MapWindow.FacetDimensions[facet_id].y / 2
	UOCenterRadarOnLocation(MapWindow.CenterX, MapWindow.CenterY, facet_id)
end

function MapWindow.ToggleFacetDown()
	local facet_id = UOGetRadarFacet() - 1
	if (facet_id < 0) then
		facet_id = 4
	end
	LabelSetText("MapWindowTitle", GetStringFromTid(MapWindow.FacetTID[facet_id]))
	UOSetWaypointMapFacet(facet_id)

	MapWindow.CenterX = MapWindow.FacetDimensions[facet_id].x / 2
	MapWindow.CenterY = MapWindow.FacetDimensions[facet_id].y / 2
	UOCenterRadarOnLocation(MapWindow.CenterX, MapWindow.CenterY, facet_id)
end

function MapWindow.MouseOver()
	local waypointId = WindowGetId(SystemData.ActiveWindow.name)
    local wtype, wflags, wname, wfacet, wx, wy, wz = nil
    
    -- IF THE LAST WAYPOINT, IT'S THE CURRENT PLAYER LOCATION !!
	if (string.find(SystemData.ActiveWindow.name, tostring(MapWindow.MaxWaypointsPerFacet)) ) then
    	wname = GetStringFromTid(MapWindow.TID.YourLocation)
    else
    	wtype, wflags, wname, wfacet, wx, wy, wz = UOGetWaypointInfo(waypointId)	
    end
    
	local itemData = { windowName = SystemData.ActiveWindow.name,
						itemId = waypointId,
						itemType = ItemProperties.type.TYPE_WSTRINGDATA,
						binding = L"",
						detail = nil,
						title =	wname,
						body = L""}

	ItemProperties.SetActiveItem(itemData)
end

function MapWindow.ToggleLegend()
    local windowName = SystemData.ActiveWindow.name
    local disabledWaypointWindowName = windowName.."DisabledGraphic"
    local waypointDisplayType = WindowGetId(SystemData.ActiveWindow.name)
 	local displayIndex = WindowData.WaypointDisplay.displayTypes.ATLAS[waypointDisplayType].displayIndex
 	local currentDisplayState = WindowData.WaypointDisplay.displayTypes.ATLAS[waypointDisplayType].isDisplayed
 	local waypointIconId = WindowData.WaypointDisplay.displayTypes.ATLAS[waypointDisplayType].iconId
 	local iconTexture, x, y = nil
    local waypointIconWidth, waypointIconHeight = nil

	-- TOGGLE THE currentDisplayState BOOLEAN
	UOSetWaypointTypeDisplayInfo(waypointDisplayType, "ATLAS", displayIndex, not(currentDisplayState))
	MapWindow.UpdateDisplayModeMap()
	
	-- REMOVE DISABLED IMAGE IF DISPLAY IS TRUE
	if (not(currentDisplayState)) then
	    if DoesWindowNameExist(disabledWaypointWindowName) then
	        DestroyWindow(disabledWaypointWindowName)
	    end
	-- CREATE DISABLED IMAGE IF DISPLAY IS FALSE
	else
	    CreateWindowFromTemplate(disabledWaypointWindowName, "DisabledWaypointTemplate", windowName)
	    WindowAddAnchor(disabledWaypointWindowName, "center", windowName.."Graphic", "center", 0, 0)
	    WindowSetId(disabledWaypointWindowName, waypointDisplayType)
	end
	
	ScrollWindowUpdateScrollRect("MapScrollWindow")
end

function MapWindow.GetCenter()
	if (WindowData.WaypointDisplay.currentDisplayMode == "ATLAS") then
   		return UOGetRadarPosToWorld(MapWindow.Width/2, MapWindow.Height/2)
	elseif (WindowData.WaypointDisplay.currentDisplayMode == "RADAR") then
		return UOGetRadarPosToWorld(RadarWindow.Width/2, RadarWindow.Height/2)	
	end	 		      
end

function MapWindow.SetDragOn(flags, x, y)
	if (not MapWindow.DragOn) then
		MapWindow.CenterX, MapWindow.CenterY = MapWindow.GetCenter()
		MapWindow.DragX, MapWindow.DragY = x, y
		MapWindow.WAYPOINT_UPDATE_FREQ = 0
	else
	    MapWindow.DragOn = true
	end		 
end

function MapWindow.SetDragOff(flags, x, y)
    MapWindow.WAYPOINT_UPDATE_FREQ = 0.2
    MapWindow.DragOn = false
    MapWindow.DragX, MapWindow.DragY = nil, nil
    MapWindow.CenterX, MapWindow.CenterY = nil, nil
end 

function MapWindow.MouseDrag(flags, deltaX, deltaY)		
	if (deltaX ~=0 or deltaY ~= 0) then
		local facet = UOGetRadarFacet()
		local newCenterX, newCenterY = nil
		
		if (MapWindow.ZoomScale == 0) then
			newCenterX	= MapWindow.CenterX - deltaX
			newCenterY	= MapWindow.CenterY - deltaY
		elseif(MapWindow.ZoomScale > 0) then
			newCenterX	= MapWindow.CenterX - (deltaX*(1/MapWindow.ZoomScale))
			newCenterY	= MapWindow.CenterY - (deltaY*(1/MapWindow.ZoomScale))
		elseif(MapWindow.ZoomScale < 0) then
			newCenterX	= MapWindow.CenterX - (deltaX*(1/(1 + math.abs(MapWindow.ZoomScale))))
			newCenterY	= MapWindow.CenterY - (deltaY*(1/(1 + math.abs(MapWindow.ZoomScale))))
		end  
		
		local withinRange = (newCenterX < MapWindow.FacetDimensions[facet].x and newCenterX > 0 and newCenterY < MapWindow.FacetDimensions[facet].y and newCenterY > 0)
		
		if (withinRange and MapWindow.ZoomScale < 1) then
			UOCenterRadarOnLocation(newCenterX, newCenterY, facet)
			MapWindow.CenterX = newCenterX
			MapWindow.CenterY = newCenterY
		end
	end
end 

function MapWindow.DblClick(flags, x, y)
	local worldX, worldY = UOGetRadarPosToWorld(x, y)
	local facet = UOGetRadarFacet()

	local withinRange = (worldX < MapWindow.FacetDimensions[facet].x and worldX > 0 and worldY < MapWindow.FacetDimensions[facet].y and worldY > 0)

	if (withinRange) then
	    MapWindow.CenterX = worldX
	    MapWindow.CenterY = worldY
		UOCenterRadarOnLocation(worldX, worldY, facet)
	end
end

-- ZOOM: zoom range is from 0.0 to -2.0
function MapWindow.ZoomOut()
   	MapWindow.ZoomScale = MapWindow.ZoomScale + 0.05
	if (MapWindow.ZoomScale > 1) then
		MapWindow.ZoomScale = 1
	end
	UOSetRadarZoom(MapWindow.ZoomScale)
end

function MapWindow.ZoomIn()
	MapWindow.ZoomScale = MapWindow.ZoomScale - 0.05
	if (MapWindow.ZoomScale < -2.0) then
		MapWindow.ZoomScale = -2.0
	end
	UOSetRadarZoom(MapWindow.ZoomScale)
end

function MapWindow.Zoom(x, y, delta)
   	MapWindow.ZoomScale = MapWindow.ZoomScale + (delta * -0.05)
	if (MapWindow.ZoomScale > 1) then
		MapWindow.ZoomScale = 1
	end
	if (MapWindow.ZoomScale < -2.0) then
		MapWindow.ZoomScale = -2.0
	end
	UOSetRadarZoom(MapWindow.ZoomScale)
end

function MapWindow.UpdateWaypointIcon(waypointIconId, waypointIconWindowName)
	local iconTexture, x, y = GetIconData(waypointIconId)
	local waypointIconWidth, waypointIconHeight = UOGetTextureSize("icon"..waypointIconId)

	WindowSetDimensions(waypointIconWindowName, waypointIconWidth, waypointIconHeight)
	WindowSetDimensions(waypointIconWindowName.."Graphic", waypointIconWidth, waypointIconHeight)
	DynamicImageSetTexture(waypointIconWindowName.."Graphic", iconTexture, x, y)
end

function MapWindow.OnShown()
    ButtonSetPressedFlag("MenuBarWindowStatusBarToggleMap",true)
end

function MapWindow.OnHidden()
    ButtonSetPressedFlag("MenuBarWindowStatusBarToggleMap",false)
end

function MapWindow.ShowCreateWaypointContextMenu(flags, mouseX, mouseY)
	local waypointX, waypointY, waypointZ = UOGetRadarPosToWorld(mouseX, mouseY)
	local params = {x=waypointX, y=waypointY, z=0, facetId=UOGetRadarFacet()} 
	
	ContextMenu.CreateLuaContextMenuItem(MapWindow.TID.CreateWaypoint,0,MapWindow.ContextReturnCodes.CREATE_WAYPOINT,params)
	ContextMenu.ActivateLuaContextMenu(MapWindow.ContextMenuCallback)
end

function MapWindow.ShowEditWaypointContextMenu()
	local waypointId = WindowGetId(SystemData.ActiveWindow.name)
	local params = {id=waypointId, x=nil, y=nil, z=nil, facetId=UOGetRadarFacet(), iconId = nil, type=nil, name=nil}
	local type, flags, localizedDescription, facet, wx, wy, wz = UOGetWaypointInfo(waypointId)
	
	params.x = wx
	params.y = wy
	params.z = wz
	params.iconId = WindowData.WaypointDisplay.displayTypes.ATLAS[type].iconId
	params.typeId = type
	params.name =localizedDescription
	
	if (SystemData.Waypoint.TypeIsCustomizable[type] == 1) then
		ContextMenu.CreateLuaContextMenuItem(MapWindow.TID.EditWaypoint,0,MapWindow.ContextReturnCodes.EDIT_WAYPOINT,params)
	else
		ContextMenu.CreateLuaContextMenuItem(MapWindow.TID.ViewWaypoint,0,MapWindow.ContextReturnCodes.VIEW_WAYPOINT,params)
	end
	
	ContextMenu.ActivateLuaContextMenu(MapWindow.ContextMenuCallback)

end

function MapWindow.ContextMenuCallback(returnCode,params)
	if( params ~= nil ) then
		if (returnCode == MapWindow.ContextReturnCodes.CREATE_WAYPOINT) then
			UserWaypointWindow.InitializeCreateWaypointData(params)
		elseif(returnCode == MapWindow.ContextReturnCodes.EDIT_WAYPOINT) then
			UserWaypointWindow.InitializeEditWaypointData(params)
		elseif(returnCode == MapWindow.ContextReturnCodes.VIEW_WAYPOINT) then
			UserWaypointWindow.InitializeViewWaypointData(params)
		end
	end
end