----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

HuePickerWindow = {}

HuePickerWindow.NUM_COLORS = 200
HuePickerWindow.COLORS_PER_ROW = 20
HuePickerWindow.SWATCH_SIZE = 15

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

----------------------------------------------------------------
-- MainMenuWindow Functions
----------------------------------------------------------------

-- OnInitialize Handler
function HuePickerWindow.Initialize()
    local id = WindowData.HuePicker.ObjectId
    local windowName = SystemData.ActiveWindow.name
    
    HuePickerWindow[id] = {}
    HuePickerWindow[id].ListType = WindowData.HuePicker.ListType
    HuePickerWindow[id].Brightness = 0
    
    WindowSetId(windowName,id)
    
    ColorPickerWindow.SetNumColorsPerRow(HuePickerWindow.COLORS_PER_ROW)
    ColorPickerWindow.SetSwatchSize(HuePickerWindow.SWATCH_SIZE)
    ColorPickerWindow.SetAfterColorSelectionFunction(HuePickerWindow.ColorPicked)
    ColorPickerWindow.SetWindowPadding(1,1)
    ColorPickerWindow.SetFrameEnabled(false)
    ColorPickerWindow.SetCloseButtonEnabled(false)
    
    HuePickerWindow.UpdateHueTable(windowName.."Picker",id,1)
end

function HuePickerWindow.Shutdown()

end

function HuePickerWindow.UpdateHueTable(this,id,newBrightness)
    local hueTable = {}

    if( newBrightness ~= HuePickerWindow[id].Brightness ) then
        HuePickerWindow[id].Brightness = newBrightness
    
        for i=1, HuePickerWindow.NUM_COLORS do
            hueTable[i] = ((i-1)*5)+HuePickerWindow[id].Brightness + 1
        end
    end
    
    ColorPickerWindow.SetColorTable(hueTable,this)
    ColorPickerWindow.DrawColorTable(this)
end

function HuePickerWindow.ColorPicked(windowName)
    local huePickerWindow = WindowGetParent(windowName)
    local id = WindowGetId(huePickerWindow)
    local huePicked = ColorPickerWindow.colorSelected[windowName]
    
    HuePickerColorSelected(id,HuePickerWindow[id].ListType,huePicked)
    
    DestroyWindow(huePickerWindow)
end