----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

WaypointIconPickerWindow = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

WaypointIconPickerWindow.numWaypointIconsPerRow = 6
WaypointIconPickerWindow.WaypointIconSelected = {}
WaypointIconPickerWindow.AfterWaypointIconSelectionFunction = {}

----------------------------------------------------------------
-- MainMenuWindow Functions
----------------------------------------------------------------

-- OnInitialize Handler
function WaypointIconPickerWindow.Initialize()
	
	local this = SystemData.ActiveWindow.name
	local id = SystemData.DynamicWindowId
	WindowSetId(this, id)
	
	WaypointIconPickerWindow[id] = {}
	
	Interface.DestroyWindowOnClose[this] = true
end

function WaypointIconPickerWindow.SetNumWaypointIconsPerRow(numWaypointIconsPerRow)
	WaypointIconPickerWindow.numWaypointIconsPerRow = numWaypointIconsPerRow
end

function WaypointIconPickerWindow.DrawWaypointIconTable(parent)
	
	RegisterWindowData(WindowData.WaypointDisplay.Type,0)
	
	local numInRow = 0
    local firstRowWindow = nil
    local currentWaypointIconWindowName, previousWaypointIconWindowName = nil
    local relativeAnchorWaypointIconWindowName = nil
    local WaypointIconId = nil
    local numIcons = table.getn(WindowData.WaypointDisplay.iconIds)
    local waypointIconWidth, waypointIconHeight, previousIconWidth, previousIconHeight = nil

    WindowSetDimensions(parent, (WaypointIconPickerWindow.numWaypointIconsPerRow * 70), ( (( numIcons/WaypointIconPickerWindow.numWaypointIconsPerRow) * 65)) + 35)

    for iconIdsIndex = 1, numIcons do
    	WaypointIconId = WindowData.WaypointDisplay.iconIds[iconIdsIndex]
        currentWaypointIconWindowName = parent..tostring(WaypointIconId)
        
		if (WaypointIconPickerWindow.GenerateWaypointIcon(WaypointIconId, currentWaypointIconWindowName, parent)) then
			WindowSetId(currentWaypointIconWindowName, iconIdsIndex)
			
    		waypointIconWidth, waypointIconHeight = UOGetTextureSize("icon"..WaypointIconId)
	        
	        if (iconIdsIndex == 1) then
	            WindowAddAnchor( currentWaypointIconWindowName, "bottomleft", parent.."_TitleBar", "topleft", 30, 0)
	            relativeAnchorWaypointIconWindowName = currentWaypointIconWindowName
	            firstRowWindow = currentWaypointIconWindowName       
	        elseif (numInRow < WaypointIconPickerWindow.numWaypointIconsPerRow-1) then
	            WindowAddAnchor( currentWaypointIconWindowName, "topleft", previousWaypointIconWindowName, "topleft", previousIconWidth, 0)
	            numInRow = numInRow + 1
	            relativeAnchorWaypointIconWindowName = currentWaypointIconWindowName
	        elseif (numInRow == WaypointIconPickerWindow.numWaypointIconsPerRow-1) then
	            WindowAddAnchor( currentWaypointIconWindowName, "topleft", firstRowWindow, "topleft", 0, 64)
	            numInRow = 0
	            relativeAnchorWaypointIconWindowName = currentWaypointIconWindowName
	            firstRowWindow =  currentWaypointIconWindowName
	        end
	        previousWaypointIconWindowName = currentWaypointIconWindowName
			previousIconWidth, previousIconHeight = waypointIconWidth, waypointIconHeight 
	    	
			CreateWindowFromTemplate( currentWaypointIconWindowName.."Frame", "UO_Default_Inner_Window_Frame", currentWaypointIconWindowName )
			WindowAddAnchor( currentWaypointIconWindowName.."Frame", "topleft", currentWaypointIconWindowName, "topleft", 0, 0)
			WindowAddAnchor( currentWaypointIconWindowName.."Frame", "bottomright", currentWaypointIconWindowName, "bottomright", 0, 0)              
    	
		end
	end
	
	-- Add background and frame to WaypointIconPicker window
	CreateWindowFromTemplate( parent.."Background", "UO_Default_Black_Background", parent )
	WindowAddAnchor( parent.."Background", "topleft", parent, "topleft", 0, 0)
	WindowAddAnchor( parent.."Background", "bottomright", parent, "bottomright", 0, 0)
	CreateWindowFromTemplate( parent.."Frame", "UO_Default_Inner_Window_Frame", parent )
	WindowAddAnchor( parent.."Frame", "topleft", parent, "topleft", 0, 0)
	WindowAddAnchor( parent.."Frame", "bottomright", parent, "bottomright", 0, 0)
	
	UnregisterWindowData(WindowData.WaypointDisplay.Type,0)
end

function WaypointIconPickerWindow.SetWaypointIcon()
   local parent = WindowGetParent(SystemData.ActiveWindow.name)

   WaypointIconPickerWindow.WaypointIconSelected[parent] = WindowGetId(SystemData.ActiveWindow.name)
   WindowSetShowing(parent, false)     
   if (WaypointIconPickerWindow.AfterWaypointIconSelectionFunction[parent]) then
	WaypointIconPickerWindow.AfterWaypointIconSelectionFunction[parent]()
   end 		
end

function WaypointIconPickerWindow.SetAfterWaypointIconSelectionFunction(funcCall, parent)
	WaypointIconPickerWindow.AfterWaypointIconSelectionFunction[parent] = funcCall
end

function WaypointIconPickerWindow.SetWaypointIconId(WaypointIconId, parent)  
	WaypointIconPickerWindow.WaypointIconSelected[parent]= WaypointIconId
    WindowSetShowing(parent, false)
end

function WaypointIconPickerWindow.GenerateWaypointIcon(waypointIconId, waypointIconWindowName, rootWindow)
	local iconTexture, x, y = GetIconData(waypointIconId)
    local waypointIconWidth, waypointIconHeight = UOGetTextureSize("icon"..waypointIconId)

	if (waypointIconWidth and waypointIconHeight) then
		CreateWindowFromTemplate(waypointIconWindowName, "WaypointIconPickerItemTemplate", rootWindow )
		WindowSetDimensions(waypointIconWindowName, waypointIconWidth, waypointIconHeight)
	    WindowSetDimensions(waypointIconWindowName.."Graphic", waypointIconWidth, waypointIconHeight)
		DynamicImageSetTexture(waypointIconWindowName.."Graphic", iconTexture, x, y)
		return true
	else
		return false
	end
end
