----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

NameWindow = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------
NameWindow.FadeTimeId = {}
NameWindow.TimePassed = {}
NameWindow.AlphaStart = 1
NameWindow.AlphaDiff = 0.01
NameWindow.FadeStartTime = 4
--[[
NONE			= NOHUE
INNOCENT		= BLUE
FRIEND		= GREEN
CANATTACK	= GREY
CRIMINAL		= GREY
ENEMY		= ORANGE
MURDERER		= RED
INVULNERABLE	= YELLOW
]]
NameWindow.Notoriety = {NONE = 1, INNOCENT = 2, FRIEND = 3, CANATTACK =4, CRIMINAL=5, ENEMY=6, MURDERER=7, INVULNERABLE=8 }
NameWindow.TextColors = {}
NameWindow.TextColors[NameWindow.Notoriety.NONE]    =  { r=128,   g=200,   b=255 } --- BLUE
NameWindow.TextColors[NameWindow.Notoriety.INNOCENT]   = { r=128,   g=200,   b=255  } --- BLUE
NameWindow.TextColors[NameWindow.Notoriety.FRIEND]   = { r=80,   g=240,   b=180 } --- GREEN 
NameWindow.TextColors[NameWindow.Notoriety.CANATTACK]   = { r=200, g=200, b=200 } --- GREY/SYS
NameWindow.TextColors[NameWindow.Notoriety.CRIMINAL]   = { r=200, g=200, b=200 } --- GREY/SYS
NameWindow.TextColors[NameWindow.Notoriety.ENEMY]  = { r=242, g=159, b=77   } --- ORANGE
NameWindow.TextColors[NameWindow.Notoriety.MURDERER]  =  { r=255, g=64  , b=64   } --- RED  
NameWindow.TextColors[NameWindow.Notoriety.INVULNERABLE]  = { r=255, g=255, b=0   } --- YELLOW 
----------------------------------------------------------------
-- NameWindow Functions
----------------------------------------------------------------

function NameWindow.InitializeEvents()
    -- we only want to register for these events once so we dont get the event for every instance of the name window
    WindowRegisterEventHandler("Root", WindowData.MobileName.Event, "NameWindow.UpdateStatus")
    WindowRegisterEventHandler("Root", SystemData.Events.DESTROY_ALL_OVERHEAD_NAME, "NameWindow.DestroyAllNameWindows")
end

function NameWindow.Initialize()
	local this = SystemData.ActiveWindow.name
	local mobileId = SystemData.DynamicWindowId

	WindowSetId(this, mobileId)
	NameWindow.FadeTimeId[mobileId] = NameWindow.AlphaStart
	NameWindow.TimePassed[mobileId] = 0
	RegisterWindowData(WindowData.MobileName.Type, mobileId)	

	NameWindow.UpdateStatus(mobileId)
end

function NameWindow.Shutdown()
	local this = SystemData.ActiveWindow.name
	local mobileId = WindowGetId(this)
	
	NameWindow.FadeTimeId[mobileId] = nil
	NameWindow.TimePassed[mobileId] = nil
	
	DetachWindowFromWorldObject( mobileId, "NameWindow_"..mobileId )
	UnregisterWindowData(WindowData.MobileName.Type, mobileId)
end

function NameWindow.OnShown()
    -- window was shown so reset the timers and the font alpha
	local this = SystemData.ActiveWindow.name
	local mobileId = WindowGetId(this)
	
	NameWindow.FadeTimeId[mobileId] = NameWindow.AlphaStart
	NameWindow.TimePassed[mobileId] = 0
	
	local labelName = this.."Text"
	WindowSetFontAlpha( labelName, NameWindow.AlphaStart)	
end


function NameWindow.UpdateStatus(mobileIdLua)
	local mobileId = WindowData.UpdateInstanceId
	if(mobileIdLua ~= nil) then
		mobileId =mobileIdLua
	end
	local data = WindowData.MobileName[mobileId]
	
	local windowName = "NameWindow_"..mobileId
	--If windowName does not exist exit funciton
	if( DoesWindowNameExist( windowName) == false ) then
		return
	end
	
	if(data.MobName ~= nil) then
		local labelName = windowName.."Text"
		LabelSetText(labelName, L""..data.MobName)

		local hue = NameWindow.TextColors[data.Notoriety+1]
		LabelSetTextColor(labelName, hue.r, hue.g, hue.b)
	else
		--Destroy window if the mobile status is not there anymore, player probably teleported and we didn't delete the mobiles name
  		DestroyWindow("NameWindow_"..mobileId)
	end
end

function NameWindow.Update( timePassed )
	if (SystemData.Settings.GameOptions.showNames ~= SystemData.Settings.GameOptions.SHOWNAMES_ALL) then
		for i, id in pairs(NameWindow.FadeTimeId) do
			NameWindow.TimePassed[i] = NameWindow.TimePassed[i] + timePassed
			if(NameWindow.TimePassed[i] > NameWindow.FadeStartTime ) then
				local windowName = "NameWindow_"..i
				NameWindow.FadeTimeId[i] = NameWindow.FadeTimeId[i] - NameWindow.AlphaDiff
				if(NameWindow.FadeTimeId[i] <= 0) then
					--Remove Name Window
					DestroyWindow(windowName)
					NameWindow.FadeTimeId[i] = nil
					NameWindow.TimePassed[i] = nil
				else
					local labelName = windowName.."Text"
					WindowSetFontAlpha( labelName, NameWindow.FadeTimeId[i])
				end
			end
		end
	end
end

function NameWindow.DestroyAllNameWindows()
	for i, id in pairs(NameWindow.FadeTimeId) do
		local windowName = "NameWindow_"..i
		DestroyWindow(windowName)
	end
end