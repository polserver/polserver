----------------------------------------------------------------
-- Global Variables
----------------------------------------------------------------

GroupWindow = {}

----------------------------------------------------------------
-- Local Variables
----------------------------------------------------------------

GroupWindow.groupMemberIds = {}
GroupWindow.selectedGroupMemberWindowName = "selectedGroupMember"
GroupWindow.TID = { PartyMembers=1075670, Party=3000332} 
GroupWindow.Spells = { Heal = 29, Cure = 11 }
 
----------------------------------------------------------------
-- MainMenuWindow Functions
----------------------------------------------------------------

-- OnInitialize Handler
function GroupWindow.Initialize()
	WindowSetAlpha("GroupWindowShowViewBackground", 0.75)
	RegisterWindowData(WindowData.PartyMember.Type,0)
	WindowRegisterEventHandler( "GroupWindow", WindowData.MobileStatus.Event, "GroupWindow.UpdateStatus")
	WindowRegisterEventHandler( "GroupWindow", WindowData.MobileName.Event, "GroupWindow.UpdateName")
	WindowRegisterEventHandler( "GroupWindow", WindowData.PartyMember.Event, "GroupWindow.UpdateParty")
	WindowRegisterEventHandler( "GroupWindow", WindowData.HealthBarColor.Event, "GroupWindow.TintHealthBar")

    Interface.DestroyWindowOnClose["GroupWindow"] = true
	LabelSetText("GroupWindowShowViewName", GetStringFromTid(GroupWindow.TID.Party))--Members))

	local xsize, ysize = WindowGetDimensions("GroupWindowHideView")
    WindowSetDimensions("GroupWindow", xsize, ysize )

--	WindowSetDimensions("GroupWindow", 275, 150 + WindowData.PartyMember.NUM_PARTY_MEMBERS * 100) -- 300
	GroupWindow.ClearGroupWindow()

    if (WindowData.PartyMember.NUM_PARTY_MEMBERS > 0) then
		GroupWindow.DrawGroupList()
        GroupWindow.HideGroup()
	end
end

function GroupWindow.Shutdown()
	UnregisterWindowData(WindowData.PartyMember.Type,0)
end

function GroupWindow.ShowGroup()
    --Debug.Print("GroupWindow.ShowGroup()")
	
    WindowSetShowing("GroupWindowShowView", true)
    WindowSetShowing("GroupWindowHideView", false)
    
    local xsize, ysize = WindowGetDimensions("GroupWindowShowView")
    WindowSetDimensions("GroupWindow", xsize, ysize )
    
end

function GroupWindow.HideGroup()
    --Debug.Print("GroupWindow.HideGroup()")

    WindowSetShowing("GroupWindowShowView", false)
    WindowSetShowing("GroupWindowHideView", true)

    local xsize, ysize = WindowGetDimensions("GroupWindowHideView")
    WindowSetDimensions("GroupWindow", xsize, ysize )

end

function GroupWindow.DrawGroupList()
	--Debug.Print("GroupWindow.DrawGroupList()")
    --WindowData.PartyMember.amLootable

    local currentMemberWindowName = nil
    local previousMemberWindowName = nil
    local partyMemberId = nil

    local i = 1

    WindowSetDimensions("GroupWindow", 276, 140 + ((WindowData.PartyMember.NUM_PARTY_MEMBERS - 1) * 48) )
	WindowSetDimensions("GroupWindowShowView", 276, 140 + ((WindowData.PartyMember.NUM_PARTY_MEMBERS -1) * 48) )

    if (WindowData.PartyMember.NUM_PARTY_MEMBERS > 0) then
    	while (i <= WindowData.PartyMember.NUM_PARTY_MEMBERS) do
            partyMemberId = WindowData.PartyMember[i].memberId
            currentMemberWindowName = "Member"..tostring(partyMemberId)
          
            if (partyMemberId == WindowData.PartyMember.partyLeaderId) then
            	if not(DoesWindowNameExist(currentMemberWindowName)) then
					CreateWindowFromTemplate( currentMemberWindowName, "GroupWindowPartyLeader", "GroupWindowShowView" )
				end
				CircleImageSetTextureScale(currentMemberWindowName.."Portrait",0.4)
				CircleImageSetTexture(currentMemberWindowName.."Portrait","paperdoll_texture"..partyMemberId,100,45)
            elseif not(DoesWindowNameExist(currentMemberWindowName)) then
                CreateWindowFromTemplate( currentMemberWindowName, "GroupMemberItemTemplate", "GroupWindowShowView" )
            end

            WindowClearAnchors(currentMemberWindowName)

            if (i == 1) then
            	WindowAddAnchor( currentMemberWindowName, "topleft", "GroupWindowShowView", "topleft", 3, 40)
                first=false
            else
            	WindowAddAnchor( currentMemberWindowName, "bottomleft", previousMemberWindowName, "topleft", 0, 10)
            end    
            
            RegisterWindowData(WindowData.MobileStatus.Type, partyMemberId) 
            RegisterWindowData(WindowData.MobileName.Type, partyMemberId)  
            RegisterWindowData(WindowData.HealthBarColor.Type, partyMemberId) 
           
            GroupWindow.TintHealthBar(partyMemberId)    

            WindowSetId(currentMemberWindowName, partyMemberId)
            WindowSetId(currentMemberWindowName.."HealButton", partyMemberId)
            WindowSetId(currentMemberWindowName.."CureButton", partyMemberId)
            previousMemberWindowName = currentMemberWindowName
            GroupWindow.groupMemberIds[i] = partyMemberId
            GroupWindow.UpdateName(partyMemberId)
            i = i + 1
        end
        GroupWindow.UpdateStatus()
    end
end         

function GroupWindow.UpdateName(mobileId)
	if (mobileId == nil) then
		mobileId = WindowData.UpdateInstanceId
	end
	
    for key, partyMemberId in pairs(GroupWindow.groupMemberIds) do
        if( mobileId == partyMemberId ) then
			local currentMemberWindowName = "Member"..tostring(mobileId)
			if WindowData and WindowData.MobileName and WindowData.MobileName[mobileId] and (WindowData.MobileName[mobileId].MobName ~= nil) then
				LabelSetText(currentMemberWindowName.."Name", WindowData.MobileName[mobileId].MobName)
				--WindowUtils.FitTextToLabel(currentMemberWindowName.."Name", WindowData.MobileName[mobileId].MobName)
			else
				--Debug.Print( L"ERROR: GroupWindow.UpdateName() has run into a problem. Couldn't set a player's name. Defaulting to ''???''" )
				LabelSetText(currentMemberWindowName.."Name", L"???" )		
			end
		end
	end
end

function GroupWindow.UpdateStatus()
	--Debug.Print("GroupWindow.UpdateStatus()")
	local currentMemberWindowName = nil

    for key, partyMemberId in pairs(GroupWindow.groupMemberIds) do
        if( WindowData.UpdateInstanceId == partyMemberId ) then
        	currentMemberWindowName = "Member"..tostring(partyMemberId)
        	StatusBarSetCurrentValue( currentMemberWindowName.."HealthBar", WindowData.MobileStatus[partyMemberId].CurrentHealth )
        	StatusBarSetMaximumValue( currentMemberWindowName.."HealthBar", WindowData.MobileStatus[partyMemberId].MaxHealth )
        	
        	local curMana =  WindowData.MobileStatus[partyMemberId].CurrentMana
        	local maxMana =  WindowData.MobileStatus[partyMemberId].MaxMana
        	local curStamina = WindowData.MobileStatus[partyMemberId].CurrentStamina
        	local maxStamina = WindowData.MobileStatus[partyMemberId].MaxStamina
        	
        	--Need to set the curMana to full if the server gives us 0 for cur mana and 0 for maxMana
        	if( curMana == 0 and maxMana == 0) then
        		curMana = 1
        		maxMana = 1
        	end
        	
        	if( curStamina == 0 and maxStamina == 0) then
        		curStamina = 1
        		maxStamina = 1
        	end
        	
        	StatusBarSetCurrentValue( currentMemberWindowName.."ManaBar", curMana)
        	StatusBarSetMaximumValue( currentMemberWindowName.."ManaBar",  maxMana)
        	StatusBarSetCurrentValue( currentMemberWindowName.."StaminaBar", curStamina)
        	StatusBarSetMaximumValue( currentMemberWindowName.."StaminaBar", maxStamina)
        	--Debug.Print("current mana "..WindowData.MobileStatus[partyMemberId].CurrentMana.."current stamina "..WindowData.MobileStatus[partyMemberId].CurrentStamina)
			if (partyMemberId == WindowData.PartyMember.partyLeaderId) then
				CircleImageSetTextureScale(currentMemberWindowName.."Portrait",0.4)
				CircleImageSetTexture(currentMemberWindowName.."Portrait","paperdoll_texture"..partyMemberId,100,45)
			end
        end        			
	end
end

function GroupWindow.TintHealthBar(mobileId)
	--If mobileIdLua is not nil then we are calling this function from within Lua
	if( mobileId== nil ) then
		mobileId = WindowData.UpdateInstanceId
	end
	
	local windowTintName = "Member"..tostring(mobileId).."HealthBar"
	--Colors the health bar to the correct color
	HealthBarColor.UpdateHealthBarColor(windowTintName, WindowData.HealthBarColor[mobileId].VisualStateId)

end

function GroupWindow.UpdateParty()
    --Debug.Print("GroupWindow.UpdateParty()")
    
    GroupWindow.ClearGroupWindow()
    
    if (WindowData.PartyMember.NUM_PARTY_MEMBERS > 0) then
    	GroupWindow.DrawGroupList()
        WindowSetShowing("GroupWindowHideView", true)
    end    
end

function GroupWindow.ClearGroupWindow()

	for key, formerPartyMemberId in pairs(GroupWindow.groupMemberIds) do
    	UnregisterWindowData(WindowData.MobileStatus.Type, formerPartyMemberId)
    	UnregisterWindowData(WindowData.MobileName.Type, formerPartyMemberId)
    	UnregisterWindowData(WindowData.HealthBarColor.Type, formerPartyMemberId)
    	
		local i = 1
		local formerMemberExistsInCurrentParty = false
    
        -- Find out if former party member id is in current party
	   	if (WindowData.PartyMember.NUM_PARTY_MEMBERS > 0) then
			while (i <= WindowData.PartyMember.NUM_PARTY_MEMBERS) do
		    	local currentPartyMemberId = WindowData.PartyMember[i].memberId
		    	if (currentPartyMemberId == formerPartyMemberId) then
		    		formerMemberExistsInCurrentParty = true
		    		break
				end
				i = i+1
		    end
		end
	    
	    -- Destroy the former party member window if he's not in the current party
	    if not(formerMemberExistsInCurrentParty) and (DoesWindowNameExist("Member"..tostring(formerPartyMemberId))) then
	    	WindowSetShowing("Member"..tostring(formerPartyMemberId), false)
	    	DestroyWindow("Member"..tostring(formerPartyMemberId))
	    end
    end
    
    GroupWindow.groupMemberIds = {}
	WindowSetShowing("GroupWindowHideView", false)
	WindowSetShowing("GroupWindowShowView", false)
end

function GroupWindow.OnRClick()
	local mobileId = WindowGetId(SystemData.ActiveWindow.name)
	RequestContextMenu(mobileId)
end

function GroupWindow.OnMobileDblClicked()
	local mobileId = WindowGetId(SystemData.ActiveWindow.name)
	UserActionUseItem(mobileId,false)
end

function GroupWindow.OnItemClicked()
	local mobileId = WindowGetId(SystemData.ActiveWindow.name)
	--Handle Single Left Click on party member in the target manager
	HandleSingleLeftClkTarget(mobileId)
end

function GroupWindow.HealPartyMember()
	local mobileId = WindowGetId(SystemData.ActiveWindow.name)
	if(mobileId) then
		UserActionCastSpellOnId(GroupWindow.Spells.Heal, mobileId)
	end
end

function GroupWindow.CurePartyMember()
	local mobileId = WindowGetId(SystemData.ActiveWindow.name)
	if(mobileId) then
		UserActionCastSpellOnId(GroupWindow.Spells.Cure, mobileId)
	end
end
